"""Kiểm thử 3 phương pháp trên cảnh tổng hợp có ảnh chuẩn (ground truth) độ phân giải cao:
 1) một khung phóng to bicubic; 2) mô phỏng pipeline cũ (tịnh tiến toàn khung + shift-and-add Gauss, trọng số chống bóng ma 1/(1+d²/576), làm nét 2 lượt);
 3) pipeline mới (sr_ref.super_resolve + làm nét nhẹ). Chạy: python3 evaluate.py [--out DIR]"""
import numpy as np, cv2, sys, time, os
from skimage.metrics import structural_similarity as ssim
from scipy.ndimage import maximum_filter, minimum_filter, gaussian_filter
from sr_ref import *

rng = np.random.default_rng(7)
LW, LH = 384, 288   # khung thấp; ảnh chuẩn 768x576

def make_scene(kind, seed=1):
    r = np.random.default_rng(seed); W, H = LW * 2, LH * 2
    yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
    base = 90 + 60 * (xx / W) + 30 * (yy / H)
    tex = gaussian_filter(r.standard_normal((H, W)), 1.1) * 38 + gaussian_filter(r.standard_normal((H, W)), 3.0) * 60
    img = np.clip(np.stack([base + tex * .9, base * .95 + tex, base * .85 + tex * .8], -1), 0, 255).astype(np.uint8)
    masks = {}
    if kind in ('static', 'text', 'hdr', 'lowlight', 'noisy', 'motion'):
        cv2.rectangle(img, (0, 0), (W, H // 2), (170, 175, 180), -1) if kind in ('text',) else None
        for i, (sc, th) in enumerate([(0.9, 1), (0.7, 1), (0.55, 1), (0.45, 1)]):
            cv2.putText(img, 'Sub-pixel detail 0123456789', (20, 40 + 38 * i), cv2.FONT_HERSHEY_SIMPLEX, sc, (15, 15, 15), th, cv2.LINE_AA)
        masks['text'] = (slice(10, 190), slice(10, 520))
    # đường mảnh
    for a in np.linspace(0, np.pi / 2, 12):
        cv2.line(img, (60, H - 40), (int(60 + 300 * np.cos(a)), int(H - 40 - 280 * np.sin(a)) ), (20, 20, 20), 1, cv2.LINE_AA)
    masks['lines'] = (slice(H - 330, H - 30), slice(50, 380))
    # zone plate (alias)
    zy, zx = np.mgrid[0:200, 0:200].astype(np.float32); zr = ((zx - 100) ** 2 + (zy - 100) ** 2)
    zp = 128 + 110 * np.cos(zr * 0.0105)
    img[40:240, W - 240:W - 40] = np.clip(zp, 0, 255).astype(np.uint8)[..., None]
    masks['zone'] = (slice(40, 240), slice(W - 240, W - 40))
    # vùng kết cấu phức tạp
    tt = gaussian_filter(r.standard_normal((200, 260)), 0.9) * 90 + 120
    img[H - 230:H - 30, W - 300:W - 40] = np.clip(tt[..., None] * np.array([1, .95, .8]), 0, 255).astype(np.uint8)
    img = img.astype(np.float32)
    masks['texture'] = (slice(H - 230, H - 30), slice(W - 300, W - 40))
    if kind == 'hdr':
        l = srgb2lin(np.clip(img, 0, 255)); l = l * 0.04  # tối
        l[:, W // 2:] = np.clip(srgb2lin(np.clip(img[:, W // 2:], 0, 255)) * 1.0, 0, 1)
        l[H // 2:, :W // 3] *= 0.15
        img = lin2srgb(l).astype(np.float32)
    return np.clip(img, 0, 255).astype(np.float32), masks

def render_frames(gt, n=5, peak=1500., read=2.0, motion=False, jpeg_q=None, seed=3):
    r = np.random.default_rng(seed); H, W = gt.shape[:2]; frames = []; shifts = []
    obj_boxes = []
    for k in range(n):
        im = gt.copy().astype(np.uint8) if motion else gt.copy()
        if motion:
            x = 230 + 18 * k * 2; y = 380
            cv2.rectangle(im, (x, y), (x + 70, y + 50), (250, 40, 40), -1)
            cv2.circle(im, (x + 35, y + 25), 14, (30, 30, 250), -1); obj_boxes.append((x, y, x + 70, y + 50))
        if k == 0: dx = dy = 0.0; ang = 0.0
        else: dx, dy, ang = r.uniform(-6, 6), r.uniform(-6, 6), r.uniform(-.15, .15)
        # ánh xạ toạ độ HR (tâm ảnh làm gốc xoay)
        M = cv2.getRotationMatrix2D((W / 2, H / 2), ang, 1.0); M[0, 2] += dx; M[1, 2] += dy
        im = cv2.warpAffine(im.astype(np.float32), M, (W, H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)
        im = cv2.GaussianBlur(im, (0, 0), 1.0)            # PSF quang học (~0,5 điểm ảnh thấp)
        lo = cv2.resize(im, (W // 2, H // 2), interpolation=cv2.INTER_AREA)  # lấy mẫu của cảm biến (mở khẩu 2x2)
        lin = srgb2lin(np.clip(lo, 0, 255)) * r.uniform(.985, 1.015)
        ph = r.poisson(lin * peak) / peak + r.standard_normal(lin.shape) * read / peak * 1.0
        out = np.clip(np.round(lin2srgb(ph)), 0, 255).astype(np.uint8)
        if jpeg_q:
            ok, buf = cv2.imencode('.jpg', out[..., ::-1], [cv2.IMWRITE_JPEG_QUALITY, jpeg_q]); out = cv2.imdecode(buf, 1)[..., ::-1]
        frames.append(out.astype(np.float32)); shifts.append((dx, dy, ang))
    return frames, shifts, obj_boxes

def refine(img, amount=1.0, thr=8.0, kern='k7'):
    k = np.array([1, 6, 15, 20, 15, 6, 1], np.float32) / 64 if kern == 'k7' else np.array([.0002, .0220, .2282, .4992, .2282, .0220, .0002], np.float32)
    y = luma_g(img).astype(np.float32); bl = cv2.sepFilter2D(y, -1, k, k, borderType=cv2.BORDER_REPLICATE)
    dl = y - bl; ad = np.abs(dl); add = amount * dl * (ad / (ad + thr))
    return np.clip(img + add[..., None], 0, 255)

def legacy_merge(frames, post=True):
    """Mô phỏng MultiFrame.merge: dịch tịnh tiến toàn khung (ECC dưới điểm ảnh), cộng dồn Gauss σ=0,72 ở lưới 2x trong miền sRGB,
    trọng số chống bóng ma 1/(1+d²/576), tiên nghiệm bicubic λ=0,2; rồi làm nét 2 lượt như PhotoProcessor."""
    h, w = frames[0].shape[:2]; ow, oh = w * 2, h * 2
    base = frames[0]; bl = luma_g(base).astype(np.float32)
    accY = np.zeros((oh, ow)); accW = np.zeros((oh, ow)); CB = np.zeros((3, h, w)); CW = np.zeros((h, w))
    kt = ktab(0.72); ys, xs = np.mgrid[0:h, 0:w]
    for k, f in enumerate(frames):
        if k == 0: dx = dy = 0.0
        else:
            warp = np.eye(2, 3, dtype=np.float32)
            try:
                _, warp = cv2.findTransformECC(bl, luma_g(f).astype(np.float32), warp, cv2.MOTION_TRANSLATION, (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 100, 1e-5), None, 5)
                dx, dy = float(warp[0, 2]), float(warp[1, 2])
            except cv2.error: dx = dy = 0.0
        rx, ry = xs - dx, ys - dy
        yv = luma_g(f)
        if k == 0: wt = np.ones((h, w))
        else:
            rg = bilinear(bl, np.clip(rx, 0, w - 1), np.clip(ry, 0, h - 1)); d = np.round(yv) - rg; wt = 1 / (1 + d * d / 576)
        oxf, oyf = 2 * rx + .5, 2 * ry + .5; ox, oy = np.floor(oxf).astype(int), np.floor(oyf).astype(int)
        qx = np.clip(((oxf - ox) * KQ).astype(int), 0, KQ - 1); qy = np.clip(((oyf - oy) * KQ).astype(int), 0, KQ - 1)
        for jy in range(4):
            for jx in range(4):
                xx, yy = ox.ravel() - 1 + jx, oy.ravel() - 1 + jy; m = (xx >= 0) & (xx < ow) & (yy >= 0) & (yy < oh)
                ww = wt.ravel() * kt[qy.ravel(), jy] * kt[qx.ravel(), jx]
                scatter(accY, yy, xx, yv.ravel() * ww, m); scatter(accW, yy, xx, ww, m)
        bx, by = np.round(rx).astype(int), np.round(ry).astype(int); m = (bx >= 0) & (bx < w) & (by >= 0) & (by < h)
        for c in range(3): scatter(CB[c], by, bx, (f[..., c] - yv) * wt, m)
        scatter(CW, by, bx, wt, m)
    CB /= np.maximum(CW, 1e-3)
    prior = cv2.resize(bl, (ow, oh), interpolation=cv2.INTER_CUBIC)
    Y = (accY + .2 * prior) / (accW + .2)
    cu = [cv2.resize(cv2.bilateralFilter(CB[c].astype(np.float32), 9, 20, 2.5), (ow, oh), interpolation=cv2.INTER_LINEAR) for c in range(3)]
    img = np.stack([Y + cu[0], Y + cu[1], Y + cu[2]], -1)
    img = np.clip(img, 0, 255)
    return refine(refine(img, 1.0, 8, 'k7'), .7, 14, 'fine') if post else img

def psnr(a, b, m=None):
    if m is not None: a, b = a[m], b[m]
    mse = np.mean((a - b) ** 2); return 99. if mse < 1e-9 else 10 * np.log10(255 ** 2 / mse)

def metrics(out, gt, masks, extra_mask=None):
    o = np.clip(out, 0, 255); g = gt
    res = {'PSNR': psnr(o, g), 'SSIM': ssim(g.astype(np.uint8), np.round(o).astype(np.uint8), channel_axis=2, data_range=255)}
    gy = luma_g(g); gx_, gy_ = np.gradient(gy); gm = np.hypot(gx_, gy_); edge = gm > np.percentile(gm, 85)
    res['PSNR_edges'] = psnr(o, g, np.repeat(edge[..., None], 3, 2))
    ox_, oy_ = np.gradient(luma_g(o)); res['detail_ratio'] = float(np.hypot(ox_, oy_)[edge].mean() / gm[edge].mean())
    over = np.maximum(luma_g(o) - maximum_filter(gy, 5), 0) + np.maximum(minimum_filter(gy, 5) - luma_g(o), 0); res['ringing'] = float(over.mean())
    for name, (sy, sx) in masks.items():
        mm = np.zeros(g.shape, bool); mm[sy, sx] = True; res['PSNR_' + name] = psnr(o, g, mm)
    flat = luma_g(o)[-60:-30, 400:470] if False else None
    if extra_mask is not None: res['PSNR_motion'] = psnr(o, g, np.repeat(extra_mask[..., None], 3, 2))
    return res

def run_case(name, kind, peak, read, motion=False, jpeg_q=92, outdir=None):
    gt, masks = make_scene(kind); fr, sh, boxes = render_frames(gt, 5, peak, read, motion, jpeg_q)
    gt_eval = gt
    emask = None
    if motion:
        gt = gt.copy().astype(np.uint8); x, y, x2, y2 = boxes[0]; cv2.rectangle(gt, (x, y), (x2, y2), (250, 40, 40), -1); cv2.circle(gt, ((x + x2) // 2, (y + y2) // 2), 14, (30, 30, 250), -1)
        gt = gt.astype(np.float32); gt_eval = gt; emask = np.zeros(gt.shape[:2], bool)
        for (a, b, c, d) in boxes: emask[max(0, b - 6):d + 6, max(0, a - 6):c + 6] = True
    t = {}
    t0 = time.time(); single = cv2.resize(fr[0], None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC); t['single'] = time.time() - t0
    t0 = time.time(); legacy = legacy_merge(fr); t['legacy'] = time.time() - t0
    t0 = time.time(); new, info = super_resolve(fr, force_ref=0); new = refine(new, .25, 14, 'fine'); t['new'] = time.time() - t0
    rows = {'single': metrics(single, gt_eval, masks, emask), 'legacy': metrics(legacy, gt_eval, masks, emask), 'new': metrics(new, gt_eval, masks, emask)}
    if outdir:
        os.makedirs(outdir, exist_ok=True)
        crop = lambda im: im[40:280, 20:340] if kind != 'motion' else im[330:470, 200:460]
        if motion: crop = lambda im: im[340:470, 200:520]
        m = np.concatenate([crop(x).astype(np.uint8) for x in (gt_eval, single, legacy, new)], 1)
        cv2.imwrite(os.path.join(outdir, f'{name}_gt_single_legacy_new.png'), cv2.resize(m, None, fx=1.5, fy=1.5, interpolation=cv2.INTER_NEAREST)[..., ::-1])
    return rows, info, t

if __name__ == '__main__':
    out = sys.argv[sys.argv.index('--out') + 1] if '--out' in sys.argv else 'results'
    cases = [('static', 'static', 1500, 2.0, False), ('text_lines', 'text', 1500, 2.0, False), ('lowlight', 'lowlight', 120, 3.0, False),
             ('noisy', 'noisy', 400, 4.0, False), ('hdr', 'hdr', 1500, 2.0, False), ('motion', 'motion', 1500, 2.0, True)]
    lines = []
    for nm, kind, peak, read, mot in cases:
        rows, info, t = run_case(nm, kind, peak, read, mot, outdir=out)
        lines.append(f'\n### {nm}  (peak={peak}, read={read}, ref={info["ref"]}, khung dùng={info["used"]}/5, tin cậy TB={np.mean(info["reliable"]) * 100:.0f}%)')
        keys = [k for k in rows['new'].keys()]
        lines.append('| chỉ số | ' + ' | '.join(['1 khung bicubic', 'cũ (LK+shift-add)', 'mới (SR)']) + ' |'); lines.append('|---|---|---|---|')
        for k in keys: lines.append(f'| {k} | ' + ' | '.join(f'{rows[m][k]:.3f}' for m in ('single', 'legacy', 'new')) + ' |')
        lines.append(f'\nthời gian Python (không đại diện cho máy): {t}')
        print(lines[-len(keys) - 4:], flush=True)
    open(os.path.join(out, 'results.md'), 'w').write('\n'.join(lines)); print('\n'.join(lines))
