"""Bản tham chiếu Python (numpy/scipy/cv2) của thuật toán trong SuperRes.kt, dùng để kiểm thử số học trên ảnh tổng hợp có đáp án.
Cùng ý tưởng: LK kim tự tháp theo ô (IRLS) + Forward-Backward + photometric -> độ tin cậy; splatting Gauss 2x trong không gian tuyến tính;
trọng số = tin cậy x độ nét x nhiễu x Geman-McClure; chính quy hoá về bicubic tham chiếu; khử nhiễu 3x3; Richardson-Lucy nhẹ + chặn cực trị.
KHÔNG phải mã chạy trên máy: kết quả chỉ chứng minh thiết kế thuật toán, chưa chứng minh bản Kotlin."""
import numpy as np, cv2
from scipy.ndimage import map_coordinates, uniform_filter, minimum_filter, maximum_filter

def srgb2lin(g):
    c = g / 255.0
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)

def lin2srgb(l):
    l = np.clip(l, 0, 1)
    return 255.0 * np.where(l <= 0.0031308, 12.92 * l, 1.055 * l ** (1 / 2.4) - 0.055)

def luma_g(img):  # img HxWx3 float 0..255 (RGB)
    return 0.299 * img[..., 0] + 0.587 * img[..., 1] + 0.114 * img[..., 2]

def lin_luma(img):
    l = srgb2lin(img)
    return 0.2126 * l[..., 0] + 0.7152 * l[..., 1] + 0.0722 * l[..., 2]

def down2(a):
    k = np.array([1, 3, 3, 1], np.float32) / 8
    h, w = a.shape
    p = np.pad(a, ((1, 1), (1, 1)), mode='edge')
    t = sum(k[i] * p[:, i:i + 2 * (w // 2):2][:, :w // 2] for i in range(4)) if False else None
    # horizontal
    cols = [p[:, 2 * np.arange(w // 2) + i] for i in range(4)]
    t = sum(k[i] * cols[i] for i in range(4))
    rows = [t[2 * np.arange(h // 2) + i, :] for i in range(4)]
    return sum(k[i] * rows[i] for i in range(4))

def blur121(a):
    return cv2.sepFilter2D(a.astype(np.float32), -1, np.array([.25, .5, .25], np.float32), np.array([.25, .5, .25], np.float32), borderType=cv2.BORDER_REPLICATE)

def build_pyr(l0, levels):
    p = [None] * levels
    if levels > 1:
        p[1] = down2(l0)
    p[0] = blur121(l0)
    for l in range(2, levels):
        p[l] = down2(p[l - 1])
    return p

def noise_profile(l):
    lap = cv2.filter2D(l.astype(np.float32), -1, np.array([[1, -2, 1], [-2, 4, -2], [1, -2, 1]], np.float32))[1:-1:3, 1:-1:2]
    v = l[1:-1:3, 1:-1:2]
    a = np.abs(lap); m = a < 90
    k = np.sqrt(np.pi / 2) / 6
    gs = float(np.clip(k * a[m].mean(), 1.2, 9)) if m.any() else 3.0
    bins = np.clip((v / 16).astype(int), 0, 15)
    bs = np.full(16, np.nan)
    for b in range(16):
        sel = m & (bins == b)
        if sel.sum() >= 300: bs[b] = np.clip(k * a[sel].mean(), 1, 12)
    for b in range(16):
        if np.isnan(bs[b]):
            ok = np.where(~np.isnan(bs))[0]
            bs[b] = bs[ok[np.argmin(abs(ok - b))]] if len(ok) else gs
    return gs, np.repeat(bs, 16)

def tile_energy(l, tile=64):
    l1 = down2(l)
    gx = np.zeros_like(l1); gy = np.zeros_like(l1)
    gx[:, 1:-1] = (l1[:, 2:] - l1[:, :-2]) * .5; gy[1:-1] = (l1[2:] - l1[:-2]) * .5
    e = gx ** 2 + gy ** 2
    t1 = tile // 2
    th, tw = (l1.shape[0] + t1 - 1) // t1, (l1.shape[1] + t1 - 1) // t1
    out = np.zeros((th, tw))
    for j in range(th):
        for i in range(tw):
            out[j, i] = e[j * t1:(j + 1) * t1, i * t1:(i + 1) * t1].mean()
    return out

def bilinear(img, u, v):
    return map_coordinates(img, [v, u], order=1, mode='nearest')

class Field:
    def __init__(s, w, h, win, step):
        s.w, s.h = w, h
        s.win = min(win, w, h); s.step = step
        s.gw = max(1, (w - s.win) // step + 1); s.gh = max(1, (h - s.win) // step + 1)
        n = s.gw * s.gh
        s.fx = np.zeros(n); s.fy = np.zeros(n); s.conf = np.zeros(n); s.tex = np.zeros(n); s.gm = np.zeros(n)
        s.res = -np.ones(n); s.fb = np.ones(n); s.ok = np.zeros(n, bool)
    def cx(s, i): return s.win * .5 + i * s.step
    def _ij(s, xl, yl):
        u = np.clip((xl - s.win * .5) / s.step, 0, s.gw - 1); v = np.clip((yl - s.win * .5) / s.step, 0, s.gh - 1)
        i0 = np.minimum(np.floor(u).astype(int), max(s.gw - 2, 0)); j0 = np.minimum(np.floor(v).astype(int), max(s.gh - 2, 0))
        return i0, np.minimum(i0 + 1, s.gw - 1), j0, np.minimum(j0 + 1, s.gh - 1), u - i0, v - j0
    def sample(s, xl, yl, arrs=None):
        i0, i1, j0, j1, tx, ty = s._ij(xl, yl)
        out = []
        for a in (arrs or (s.fx, s.fy)):
            out.append((a[j0 * s.gw + i0] * (1 - tx) + a[j0 * s.gw + i1] * tx) * (1 - ty) + (a[j1 * s.gw + i0] * (1 - tx) + a[j1 * s.gw + i1] * tx) * ty)
        return out
    def min_around(s, a, xl, yl):
        i0, i1, j0, j1, _, _ = s._ij(xl, yl)
        return np.minimum(np.minimum(a[j0 * s.gw + i0], a[j0 * s.gw + i1]), np.minimum(a[j1 * s.gw + i0], a[j1 * s.gw + i1]))

def solve_level(A, B, f, prev, g0, rc, maxdev, texthr, iters):
    h, w = A.shape; win = f.win; n = (win - 2) ** 2
    gy_all, gx_all = np.gradient(A)
    yy, xx = np.mgrid[1:win - 1, 1:win - 1].astype(np.float64)
    for j in range(f.gh):
        for i in range(f.gw):
            c = j * f.gw + i; x0 = i * f.step; y0 = j * f.step
            if prev is not None:
                t = prev.sample(np.array([(x0 + win * .5) * .5]), np.array([(y0 + win * .5) * .5])); ox, oy = t[0][0] * 2, t[1][0] * 2
            else: ox, oy = g0
            ix0, iy0 = ox, oy
            f.fx[c], f.fy[c] = ox, oy
            gx = gx_all[y0 + 1:y0 + win - 1, x0 + 1:x0 + win - 1]; gy = gy_all[y0 + 1:y0 + win - 1, x0 + 1:x0 + win - 1]
            hxx, hxy, hyy = (gx * gx).sum(), (gx * gy).sum(), (gy * gy).sum()
            tr = hxx + hyy; lmin = (tr / 2 - np.sqrt(max(tr * tr / 4 - (hxx * hyy - hxy ** 2), 0))) / n
            f.tex[c] = lmin; f.gm[c] = np.sqrt(gx ** 2 + gy ** 2).mean()
            if lmin < texthr: continue
            A_w = A[y0 + 1:y0 + win - 1, x0 + 1:x0 + win - 1]
            good = True; sres = 0; cnt = 0
            for _ in range(iters):
                u = x0 + xx + ox; v = y0 + yy + oy
                valid = (u >= 0) & (u <= w - 1.001) & (v >= 0) & (v <= h - 1.001)
                if valid.sum() < n / 2: good = False; break
                val = map_coordinates(B, [v[valid], u[valid]], order=1)
                e = val - A_w[valid]; wr = 1 / (1 + e * e / rc ** 2)
                gxv, gyv = gx[valid], gy[valid]
                bx, by = (wr * gxv * e).sum(), (wr * gyv * e).sum()
                axx, axy, ayy = (wr * gxv * gxv).sum(), (wr * gxv * gyv).sum(), (wr * gyv * gyv).sum()
                sres = np.abs(e).sum(); cnt = valid.sum()
                det = axx * ayy - axy ** 2
                if det < 1e-6 * n: break
                dx = np.clip((ayy * bx - axy * by) / det, -2, 2); dy = np.clip((-axy * bx + axx * by) / det, -2, 2)
                ox -= dx; oy -= dy
                if abs(ox - ix0) > maxdev or abs(oy - iy0) > maxdev: good = False; break
                if abs(dx) < .01 and abs(dy) < .01: break
            if good: f.fx[c], f.fy[c], f.ok[c], f.res[c] = ox, oy, True, (sres / cnt if cnt else -1)
            else: f.fx[c], f.fy[c] = ix0, iy0

def fill_unreliable(f, dflt):
    rel = f.ok.copy()
    if not rel.any(): f.fx[:] = dflt[0]; f.fy[:] = dflt[1]; return
    for _ in range(f.gw + f.gh):
        nx, ny, mk = f.fx.copy(), f.fy.copy(), np.zeros_like(rel); ch = False
        for j in range(f.gh):
            for i in range(f.gw):
                c = j * f.gw + i
                if rel[c]: continue
                sx = sy = m = 0
                for dj in (-1, 0, 1):
                    for di in (-1, 0, 1):
                        jj, ii = j + dj, i + di
                        if 0 <= jj < f.gh and 0 <= ii < f.gw and rel[jj * f.gw + ii]: sx += f.fx[jj * f.gw + ii]; sy += f.fy[jj * f.gw + ii]; m += 1
                if m: nx[c], ny[c], mk[c], ch = sx / m, sy / m, True, True
        if not ch: break
        f.fx, f.fy = np.where(mk, nx, f.fx), np.where(mk, ny, f.fy); rel |= mk

def global_shift(ref, cur, r=10):
    m = r + 1; h, w = ref.shape; best, bx, by = 1e18, 0, 0
    if w <= 2 * m + 4 or h <= 2 * m + 4: return (0, 0)
    R = ref[m:h - m:2, m:w - m:2]
    for sy in range(-r, r + 1):
        for sx in range(-r, r + 1):
            sad = np.abs(R - cur[m + sy:h - m + sy:2, m + sx:w - m + sx:2]).mean() + (abs(sx) + abs(sy)) * .02
            if sad < best: best, bx, by = sad, sx, sy
    return (bx, by)

def flow_pyr(A, B, min_level, g0, sigma, texthr):
    top = len(A) - 1; fields = [None] * len(A)
    for l in range(top, min_level - 1, -1):
        h, w = A[l].shape
        win, step = (24, 12) if l >= 2 else ((32, 16) if l == 1 else (48, 24))
        win, step = (win, step) if min(w, h) >= 160 else (min(win, 32), min(step, 16))
        f = Field(w, h, win, step)
        rc = max(14, 4 * sigma) if l > 0 else max(8, 3 * sigma + 4)
        dev = 6 if l == top else (2.5 if l == 0 else 3)
        solve_level(A[l], B[l], f, None if l == top else fields[l + 1], g0, rc, dev, texthr, 8 if l >= 1 else 6)
        fill_unreliable(f, (g0[0] * 2 ** (top - l), g0[1] * 2 ** (top - l)))
        fields[l] = f
    return fields

def forward_backward(fw, bw):
    for c in range(fw.gw * fw.gh):
        if not fw.ok[c]: fw.fb[c] = 1; continue
        i, j = c % fw.gw, c // fw.gw
        px, py = fw.cx(i) + fw.fx[c], fw.cx(j) + fw.fy[c]
        if px < 0 or py < 0 or px > fw.w or py > fw.h: fw.fb[c] = .5; continue
        b = bw.sample(np.array([px]), np.array([py]))
        err = np.hypot(fw.fx[c] + b[0][0], fw.fy[c] + b[1][0]); fw.fb[c] = np.clip((1 - err) / .65, 0, 1)

def finalize_conf(f0, f1, sigma, texthr):
    textured = good = 0
    for c in range(f0.gw * f0.gh):
        i, j = c % f0.gw, c // f0.gw
        if f0.tex[c] < texthr: cf = .7
        else:
            textured += 1
            if not f0.ok[c]: cf = 0
            else:
                rho = f0.res[c] / (1.2 * sigma + .35 * f0.gm[c] + 1); cp = np.clip(1 - (rho - 1) / 1.5, 0, 1)
                fbc = f1.min_around(f1.fb, np.array([f0.cx(i) * .5]), np.array([f0.cx(j) * .5]))[0] if f1 is not None else 1
                cf = cp * fbc
            if cf < .12: cf = 0
            if cf >= .5: good += 1
        f0.conf[c] = cf
    return good, textured

KQ = 32
def ktab(sig=0.62):
    t = np.zeros((KQ, 4))
    for q in range(KQ):
        f = q / KQ
        for j in range(4): t[q, j] = np.exp(-((j - 1) - f) ** 2 / (2 * sig * sig))
        t[q] /= t[q].sum()
    return t
KT = ktab()

def per_pixel_flow(f, w, h):
    ys, xs = np.mgrid[0:h, 0:w]
    fx, fy, cf = f.sample(xs.ravel() + .5, ys.ravel() + .5, (f.fx, f.fy))[0:2] + [None]
    i0, i1, j0, j1, _, _ = f._ij(xs.ravel() + .5, ys.ravel() + .5)
    cfm = np.minimum(np.minimum(f.conf[j0 * f.gw + i0], f.conf[j0 * f.gw + i1]), np.minimum(f.conf[j1 * f.gw + i0], f.conf[j1 * f.gw + i1]))
    return fx.reshape(h, w), fy.reshape(h, w), cfm.reshape(h, w)

def rl_deconv(I, sig=0.85, iters=2):
    k = np.exp(-(np.arange(-2, 3) ** 2) / (2 * sig * sig)); k = (k / k.sum()).astype(np.float32)
    bl = lambda a: cv2.sepFilter2D(a.astype(np.float32), -1, k, k, borderType=cv2.BORDER_REPLICATE)
    E = I.copy()
    for _ in range(iters):
        E = E * bl(I / (bl(E) + 1e-4))
    return E

def scatter(acc, yy, xx, vals, m):
    H, W = acc.shape
    acc += np.bincount((yy * W + xx)[m], weights=vals[m], minlength=H * W).reshape(H, W)

def super_resolve(frames, scale=2, lam=0.10, deconv=True, denoise=True, robust=True, force_ref=None, splat_sigma=0.5, rl_sigma=1.0, rl_iters=3, slack_k=0.12, amount=1.0, night=False, night_dn=2.2, night_amount=1.0):
    """frames: list of HxWx3 float32 sRGB 0..255. Trả (ảnh 2x sRGB float, thông tin)."""
    n = len(frames); h, w = frames[0].shape[:2]
    lg = [luma_g(f).astype(np.float32) for f in frames]
    noise = [noise_profile(l) for l in lg]
    te = [tile_energy(l) for l in lg]
    score = []
    for i in range(n):
        s = np.sort(te[i].ravel()); half = max(1, len(s) // 2); score.append(s[-half:].mean() - noise[i][0] ** 2 * .125)
    ref = int(np.argmax(score)) if force_ref is None else force_ref; sigma = noise[ref][0]; nlf = noise[ref][1]
    texthr = max(6., 1.5 * sigma ** 2)
    levels = 1
    while levels < 4 and (min(w, h) >> levels) >= 64: levels += 1
    top = levels - 1
    pr = build_pyr(lg[ref].copy(), levels)
    fields = {}; gains = {}; used = [ref]; info = {'reliable': []}
    for k in range(n):
        if k == ref: continue
        pc = build_pyr(lg[k].copy(), levels)
        g = global_shift(pr[top], pc[top])
        fw = flow_pyr(pr, pc, 0, g, sigma, texthr)
        bw = flow_pyr(pc, pr, 1, (-g[0], -g[1]), sigma, texthr) if top >= 1 else None
        if bw is not None: forward_backward(fw[1], bw[1])
        good, tex = finalize_conf(fw[0], fw[1] if top >= 1 else None, sigma, texthr)
        gf = good / tex if tex else 1.0
        if tex >= 12 and gf < .25: continue
        # gain
        f0 = fw[0]; ys, xs = np.mgrid[5:h - 5:7, 5:w - 5:7]
        t = f0.sample(xs.ravel() + .5, ys.ravel() + .5); cx = np.round(xs.ravel() + t[0]).astype(int); cy = np.round(ys.ravel() + t[1]).astype(int)
        ok = (cx >= 0) & (cx < w) & (cy >= 0) & (cy < h)
        la = lin_luma(frames[ref])[ys.ravel(), xs.ravel()]; lb = lin_luma(frames[k])[np.clip(cy, 0, h - 1), np.clip(cx, 0, w - 1)]
        m = ok & (la > .03) & (la < .85) & (lb > .03) & (lb < .85) & (lb / np.maximum(la, 1e-6) > .5) & (lb / np.maximum(la, 1e-6) < 2)
        gains[k] = float(np.clip(la[m].sum() / lb[m].sum(), .8, 1.25)) if m.any() else 1.0
        fields[k] = f0; used.append(k); info['reliable'].append(gf)
    nf = len(used)
    if nf < 2: raise RuntimeError('không đủ khung')
    # trọng số khung
    smin = min(noise[k][0] for k in used)
    noiseW = {k: float(np.clip((smin / noise[k][0]) ** 2, .5, 1)) for k in used}
    emax = np.max([te[k] for k in used], axis=0)
    sharpW = {k: np.clip(np.sqrt((te[k] + 2) / (emax + 2)), .4, 1) for k in used}
    KT = ktab(splat_sigma)
    ow, oh = w * scale, h * scale
    accY = np.zeros((oh, ow)); accW = np.zeros((oh, ow))
    CB = np.zeros((3, h, w)); CW = np.zeros((h, w))
    baseL = np.round(luma_g(frames[ref])).astype(np.float32)
    lift = 1.0
    if night:
        med = np.median(baseL); lift = float(np.clip(0.09 / max(srgb2lin(np.array(med)), 0.004), 1, 3.5))
    dn_k = (night_dn if night else 2.2) * (1 + .35 * (lift - 1)); amount = night_amount if night else amount
    gx_r = np.zeros((h, w), np.float32)
    ys, xs = np.mgrid[0:h, 0:w]
    for k in used:
        img = frames[k]; lg_k = np.round(luma_g(img)); ylin_own = lin_luma(img); ye = lin2srgb(ylin_own)
        if k == ref: fx = fy = np.zeros((h, w)); cf = np.ones((h, w))
        else: fx, fy, cf = per_pixel_flow(fields[k], w, h)
        wt = sharpW[k][np.minimum(ys >> 6, sharpW[k].shape[0] - 1), np.minimum(xs >> 6, sharpW[k].shape[1] - 1)] * noiseW[k]
        rx, ry = xs - fx, ys - fy
        if k != ref:
            rxc, ryc = np.clip(rx, 0, w - 1.001), np.clip(ry, 0, h - 1.001)
            ix, iy = rxc.astype(int), ryc.astype(int); ax, ay = rxc - ix, ryc - iy
            b00, b10, b01, b11 = baseL[iy, ix], baseL[iy, ix + 1], baseL[iy + 1, ix], baseL[iy + 1, ix + 1]
            rg = (b00 * (1 - ax) + b10 * ax) * (1 - ay) + (b01 * (1 - ax) + b11 * ax) * ay
            d = lg_k * gains[k] ** (1 / 2.2) - rg
            gmx = np.maximum(np.abs(b10 - b00 + b11 - b01) * .5, np.abs(b01 - b00 + b11 - b10) * .5)
            sg = nlf[np.clip(rg.astype(int), 0, 255)]
            t2 = (1.6 * sg) ** 2 + (.5 * gmx) ** 2 + 4
            qq = 1 + d * d / t2
            wt = wt * cf / (qq * qq if robust else 1 + d * d / t2)
            wt = np.where(cf <= .001, 0, wt)
        ylin = ylin_own * gains.get(k, 1.0)
        oxf, oyf = scale * rx + .5, scale * ry + .5
        ox, oy = np.floor(oxf).astype(int), np.floor(oyf).astype(int)
        qx = np.clip(((oxf - ox) * KQ).astype(int), 0, KQ - 1); qy = np.clip(((oyf - oy) * KQ).astype(int), 0, KQ - 1)
        wtf = wt.ravel(); yl = ylin.ravel()
        for jy in range(4):
            for jx in range(4):
                xx, yy = ox.ravel() - 1 + jx, oy.ravel() - 1 + jy
                m = (xx >= 0) & (xx < ow) & (yy >= 0) & (yy < oh)
                ww = wtf * KT[qy.ravel(), jy] * KT[qx.ravel(), jx]
                scatter(accY, yy, xx, yl * ww, m); scatter(accW, yy, xx, ww, m)
        bx, by = np.round(rx).astype(int), np.round(ry).astype(int)
        m = (bx >= 0) & (bx < w) & (by >= 0) & (by < h) & (wt >= 1e-4)
        for c in range(3):
            scatter(CB[c], by, bx, ((img[..., c] - ye) * gains.get(k, 1.0) ** (1 / 2.2) * wt), m)
        scatter(CW, by, bx, wt, m)
    CB /= np.maximum(CW, 1e-3)
    # khử nhiễu màu song phương nhẹ dẫn hướng bằng độ sáng tham chiếu
    for c in range(3):
        CB[c] = cv2.bilateralFilter(CB[c].astype(np.float32), 9, 20, 2.5)
    # tiên nghiệm bicubic của tham chiếu (tuyến tính)
    prior = np.clip(cv2.resize(lin_luma(frames[ref]).astype(np.float32), (ow, oh), interpolation=cv2.INTER_CUBIC), 0, 1)
    yl = (accY + lam * prior) / (accW + lam)
    yg = lin2srgb(yl)
    I = yl.copy()
    if denoise:
        neff = 4 * accW; dnk = dn_k; sAfter = nlf[np.clip(yg.astype(int), 0, 255)] / np.sqrt(np.maximum(neff, 1)); inv2 = 1 / (dnk * sAfter) ** 2
        s = yg.copy(); sw = np.ones_like(yg)
        P = np.pad(yg, 1, mode='edge')
        for dj in (-1, 0, 1):
            for di in (-1, 0, 1):
                if dj == 0 and di == 0: continue
                v = P[1 + dj:1 + dj + oh, 1 + di:1 + di + ow]; q = 1 + (v - yg) ** 2 * inv2
                sp = .5 if (dj == 0 or di == 0) else .35
                wgt = sp / (q * q); s += v * wgt; sw += wgt
        I = srgb2lin(s / sw)
    out_l = I
    if deconv:
        E = rl_deconv(I, rl_sigma, rl_iters)
        mn = minimum_filter(I, 3, mode='nearest'); mx = maximum_filter(I, 3, mode='nearest'); slack = slack_k * (mx - mn)
        E = np.clip(E, mn - slack, mx + slack)
        dc = np.clip(accW / .6, 0, 1); out_l = I + amount * dc * dc * (E - I)
    if lift > 1.001: out_l = out_l * lift / (1 + (lift - 1) * out_l)
    ye_f = lin2srgb(out_l)
    cu = [cv2.resize(CB[c].astype(np.float32), (ow, oh), interpolation=cv2.INTER_LINEAR) for c in range(3)]
    res = np.stack([ye_f + cu[0], ye_f + cu[1], ye_f + cu[2]], -1)
    info.update(ref=ref, used=nf, sigma=sigma, lift=lift)
    return np.clip(res, 0, 255), info
