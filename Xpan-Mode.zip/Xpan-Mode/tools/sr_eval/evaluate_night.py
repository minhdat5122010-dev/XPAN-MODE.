"""Thiếu sáng: 1 khung phơi ngắn (ảnh thường) vs 9 khung phơi dài + LUNA Night. Mô hình cảm biến: điện tử = Poisson(lin·PH·e) + nhiễu đọc rn (e-)."""
import numpy as np, cv2
from evaluate import make_scene, refine, metrics
from sr_ref import *
PH, RN = 3000., 4.0
def render(gt, n, e, dark, jpeg_q=92, seed=5):
    r = np.random.default_rng(seed); H, W = gt.shape[:2]; frames = []
    lin_gt = srgb2lin(gt) * dark
    for k in range(n):
        dx, dy, ang = (0, 0, 0) if k == 0 else (r.uniform(-4, 4), r.uniform(-4, 4), r.uniform(-.1, .1))
        M = cv2.getRotationMatrix2D((W / 2, H / 2), ang, 1.0); M[0, 2] += dx; M[1, 2] += dy
        im = cv2.warpAffine(lin_gt.astype(np.float32), M, (W, H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)
        im = cv2.GaussianBlur(im, (0, 0), 1.0); lo = cv2.resize(im, (W // 2, H // 2), interpolation=cv2.INTER_AREA)
        el = r.poisson(np.clip(lo, 0, None) * PH * e) + r.standard_normal(lo.shape) * RN
        lin = el / (PH * e)
        out = np.clip(np.round(lin2srgb(np.clip(lin, 0, 1))), 0, 255).astype(np.uint8)
        ok, buf = cv2.imencode('.jpg', out[..., ::-1], [cv2.IMWRITE_JPEG_QUALITY, jpeg_q]); out = cv2.imdecode(buf, 1)[..., ::-1]
        frames.append(out.astype(np.float32))
    return frames
def lift_curve(img, g):
    l = srgb2lin(img); l = l * g / (1 + (g - 1) * l); return lin2srgb(l)
for dark, name in ((0.05, 'tối vừa (0,05)'), (0.015, 'rất tối (0,015)')):
    gt, masks = make_scene('static')
    fs = render(gt, 1, 1.0, dark)            # ảnh thường: phơi 1/30s
    fn = render(gt, 9, 11.0, dark)           # 9 khung x 0,33s (≈3s)
    # đích: GT tối rồi nâng cùng đường cong
    glin = srgb2lin(gt) * dark; med = np.median(np.round(luma_g(lin2srgb(cv2.resize(glin.astype(np.float32), (gt.shape[1] // 2, gt.shape[0] // 2), interpolation=cv2.INTER_AREA)))))
    lift = float(np.clip(0.09 / max(srgb2lin(np.array(med)), .004), 1, 3.5))
    gt_t = lift_curve(lin2srgb(glin), lift)
    single = cv2.resize(fs[0], None, fx=2, fy=2, interpolation=cv2.INTER_CUBIC); single = lift_curve(single, lift)
    post = lambda o: refine(refine(o, 1.0, 8, 'k7'), .7, 14, 'fine')
    base, ib = super_resolve(fn, force_ref=0); base = lift_curve(post(base), lift)           # SR thường + nâng sáng + làm nét như ảnh ngày
    nt, inf = super_resolve(fn, force_ref=0, night=True)
    nt = refine(refine(nt, .8, 18, 'k7'), .5, 22, 'fine')                                     # hậu xử lý thiếu sáng (ngưỡng cao)
    print(f'\n== {name}, lift={lift:.2f}, khung dùng={inf["used"]}/9')
    for lab, o in (('1 khung phơi ngắn + nâng sáng', single), ('9 khung dài + SR thường', base), ('9 khung dài + LUNA Night', nt)):
        r = metrics(o, gt_t, masks); print(f'{lab:34s} PSNR {r["PSNR"]:.2f}  SSIM {r["SSIM"]:.3f}  chi tiết {r["detail_ratio"]:.3f}  text {r["PSNR_text"]:.2f}  tex {r["PSNR_texture"]:.2f}')
    cv2.imwrite(f'results/night_{dark}.png', cv2.resize(np.concatenate([x[40:240, 20:300].astype(np.uint8) for x in (gt_t, single, base, nt)], 1), None, fx=1.4, fy=1.4, interpolation=cv2.INTER_NEAREST)[..., ::-1])
