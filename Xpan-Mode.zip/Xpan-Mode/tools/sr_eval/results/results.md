
### static  (peak=1500, read=2.0, ref=0, khung dùng=5/5, tin cậy TB=100%)
| chỉ số | 1 khung bicubic | cũ (LK+shift-add) | mới (SR) |
|---|---|---|---|
| PSNR | 21.500 | 21.892 | 21.699 |
| SSIM | 0.767 | 0.792 | 0.789 |
| PSNR_edges | 14.872 | 15.193 | 15.021 |
| detail_ratio | 0.222 | 0.254 | 0.248 |
| ringing | 0.001 | 0.000 | 0.000 |
| PSNR_text | 28.161 | 28.677 | 28.577 |
| PSNR_lines | 26.850 | 27.365 | 27.013 |
| PSNR_zone | 11.977 | 12.336 | 12.135 |
| PSNR_texture | 24.486 | 24.996 | 25.021 |

thời gian Python (không đại diện cho máy): {'single': 0.06743526458740234, 'legacy': 0.7511377334594727, 'new': 1.2460134029388428}

### text_lines  (peak=1500, read=2.0, ref=0, khung dùng=5/5, tin cậy TB=100%)
| chỉ số | 1 khung bicubic | cũ (LK+shift-add) | mới (SR) |
|---|---|---|---|
| PSNR | 21.156 | 21.493 | 21.337 |
| SSIM | 0.797 | 0.823 | 0.820 |
| PSNR_edges | 14.476 | 14.755 | 14.607 |
| detail_ratio | 0.235 | 0.267 | 0.258 |
| ringing | 0.595 | 0.264 | 0.497 |
| PSNR_text | 23.572 | 24.162 | 23.933 |
| PSNR_lines | 26.669 | 27.029 | 26.893 |
| PSNR_zone | 11.974 | 12.273 | 12.096 |
| PSNR_texture | 24.502 | 24.705 | 24.962 |

thời gian Python (không đại diện cho máy): {'single': 0.0012006759643554688, 'legacy': 0.42597508430480957, 'new': 1.229043960571289}

### lowlight  (peak=120, read=3.0, ref=0, khung dùng=5/5, tin cậy TB=100%)
| chỉ số | 1 khung bicubic | cũ (LK+shift-add) | mới (SR) |
|---|---|---|---|
| PSNR | 20.761 | 21.563 | 21.179 |
| SSIM | 0.588 | 0.719 | 0.666 |
| PSNR_edges | 14.686 | 15.069 | 14.829 |
| detail_ratio | 0.265 | 0.278 | 0.255 |
| ringing | 0.582 | 0.149 | 0.211 |
| PSNR_text | 24.961 | 27.105 | 26.398 |
| PSNR_lines | 24.658 | 26.328 | 25.547 |
| PSNR_zone | 11.911 | 12.268 | 12.011 |
| PSNR_texture | 23.160 | 24.364 | 23.759 |

thời gian Python (không đại diện cho máy): {'single': 0.0013585090637207031, 'legacy': 0.5119054317474365, 'new': 0.8451926708221436}

### noisy  (peak=400, read=4.0, ref=0, khung dùng=5/5, tin cậy TB=100%)
| chỉ số | 1 khung bicubic | cũ (LK+shift-add) | mới (SR) |
|---|---|---|---|
| PSNR | 21.373 | 21.866 | 21.537 |
| SSIM | 0.724 | 0.786 | 0.760 |
| PSNR_edges | 14.849 | 15.182 | 14.935 |
| detail_ratio | 0.234 | 0.258 | 0.237 |
| ringing | 0.046 | 0.005 | 0.007 |
| PSNR_text | 27.503 | 28.507 | 28.085 |
| PSNR_lines | 26.404 | 27.301 | 26.700 |
| PSNR_zone | 11.971 | 12.329 | 12.045 |
| PSNR_texture | 24.244 | 24.986 | 24.608 |

thời gian Python (không đại diện cho máy): {'single': 0.0015873908996582031, 'legacy': 0.4385719299316406, 'new': 0.8467929363250732}

### hdr  (peak=1500, read=2.0, ref=0, khung dùng=5/5, tin cậy TB=100%)
| chỉ số | 1 khung bicubic | cũ (LK+shift-add) | mới (SR) |
|---|---|---|---|
| PSNR | 21.924 | 22.372 | 22.153 |
| SSIM | 0.782 | 0.832 | 0.816 |
| PSNR_edges | 14.697 | 15.077 | 14.896 |
| detail_ratio | 0.234 | 0.270 | 0.264 |
| ringing | 0.318 | 0.073 | 0.190 |
| PSNR_text | 34.471 | 36.557 | 35.517 |
| PSNR_lines | 37.954 | 41.566 | 39.686 |
| PSNR_zone | 11.976 | 12.363 | 12.143 |
| PSNR_texture | 24.500 | 25.017 | 25.063 |

thời gian Python (không đại diện cho máy): {'single': 0.0014119148254394531, 'legacy': 0.4716610908508301, 'new': 0.9626100063323975}

### motion  (peak=1500, read=2.0, ref=0, khung dùng=5/5, tin cậy TB=96%)
| chỉ số | 1 khung bicubic | cũ (LK+shift-add) | mới (SR) |
|---|---|---|---|
| PSNR | 21.456 | 21.521 | 21.660 |
| SSIM | 0.766 | 0.785 | 0.785 |
| PSNR_edges | 14.861 | 15.167 | 15.031 |
| detail_ratio | 0.223 | 0.253 | 0.252 |
| ringing | 0.015 | 0.060 | 0.012 |
| PSNR_text | 28.150 | 28.663 | 28.678 |
| PSNR_lines | 26.191 | 23.674 | 26.197 |
| PSNR_zone | 11.979 | 12.328 | 12.157 |
| PSNR_texture | 24.496 | 24.957 | 25.000 |
| PSNR_motion | 24.475 | 17.400 | 24.323 |

thời gian Python (không đại diện cho máy): {'single': 0.0018310546875, 'legacy': 0.4710426330566406, 'new': 1.2574522495269775}