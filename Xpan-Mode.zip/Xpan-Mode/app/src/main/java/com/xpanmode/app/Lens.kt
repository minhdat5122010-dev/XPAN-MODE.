package com.xpanmode.app

import android.graphics.ImageFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.roundToInt

/**
 * Một ống kính (camera sau). openId = ID dùng để mở trực tiếp.
 * parentId = camera logic chứa ống kính này (nếu có) – dùng làm phương án dự phòng
 * (mở camera logic và đặt zoom ratio để HAL tự chuyển sang tele).
 */
class Lens(
    val openId: String,
    val parentId: String?,
    val eqMm: Float,
    val focalMm: Float,
    val aperture: Float,
    val sensorW: Float,
    val sensorH: Float,
    val maxMp: Float,
    val hasAf: Boolean,
    val listed: Boolean
) {
    var zoom = 1f              // eqMm / eqMm của camera chính
    var useFallback = false    // true khi không mở trực tiếp được
    var status = "chưa thử"

    fun describe(): String {
        val l = Locale.US
        return "• ${eqMm.roundToInt()}mm (tương đương 35mm) | thực ${String.format(l, "%.2f", focalMm)}mm" +
            " f/${String.format(l, "%.1f", aperture)} | ID $openId${if (!listed) " (ẩn)" else ""}" +
            (parentId?.let { " ⊂ logic $it" } ?: "") +
            " | cảm biến ${String.format(l, "%.1f", sensorW)}x${String.format(l, "%.1f", sensorH)}mm" +
            " | JPEG tối đa ${maxMp.roundToInt()}MP | AF: ${if (hasAf) "có" else "không"} | $status"
    }
}

class ScanResult(val lenses: List<Lens>, val notes: List<String>)

object LensScanner {

    fun scan(cm: CameraManager): ScanResult {
        val listed = cm.cameraIdList.toSet()
        val chars = LinkedHashMap<String, CameraCharacteristics>()

        fun probe(id: String) {
            if (chars.containsKey(id)) return
            try {
                chars[id] = cm.getCameraCharacteristics(id)
            } catch (e: Exception) {
                // ID không tồn tại / bị chặn
            }
        }

        listed.forEach { probe(it) }
        // Nhiều hãng giấu camera tele/macro khỏi cameraIdList -> dò thêm các ID ẩn
        for (i in 0..120) probe(i.toString())
        // ID vật lý do camera logic khai báo
        chars.values.toList().forEach { c -> c.physicalCameraIds.forEach { probe(it) } }

        val parent = HashMap<String, String>()
        for ((id, c) in chars) for (p in c.physicalCameraIds) if (!parent.containsKey(p)) parent[p] = id

        val notes = ArrayList<String>()
        val found = ArrayList<Lens>()
        val logicals = ArrayList<Lens>()

        for ((id, c) in chars) {
            if (c.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_BACK) continue
            val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.toList() ?: emptyList()
            if (!caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE)) {
                notes += "ID $id: bỏ qua (camera chiều sâu / IR)"; continue
            }
            if (caps.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MONOCHROME)) {
                notes += "ID $id: bỏ qua (cảm biến đơn sắc)"; continue
            }
            val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = (map?.getOutputSizes(ImageFormat.JPEG)?.toList() ?: emptyList()) +
                (map?.getHighResolutionOutputSizes(ImageFormat.JPEG)?.toList() ?: emptyList())
            val ps = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
            val fl = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
            if (sizes.isEmpty() || ps == null || fl == null || fl.isEmpty()) {
                notes += "ID $id: bỏ qua (không có luồng JPEG / thiếu thông tin cảm biến)"; continue
            }
            val diag = hypot(ps.width, ps.height)
            val f = fl[0]
            val eq = f * 43.27f / diag
            val ap = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_APERTURES)?.firstOrNull() ?: 0f
            val mp = sizes.maxOf { it.width.toLong() * it.height } / 1_000_000f
            val af = (c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f) > 0f
            val lens = Lens(id, parent[id], eq, f, ap, ps.width, ps.height, mp, af, id in listed)
            if (c.physicalCameraIds.isNotEmpty()) logicals += lens else found += lens
        }

        if (found.isEmpty()) found += logicals

        val mainEq = logicals.firstOrNull()?.eqMm
            ?: found.minByOrNull { abs(it.eqMm - 24f) }?.eqMm
            ?: 24f
        found.forEach { it.zoom = it.eqMm / mainEq }

        // Gộp trùng tiêu cự (±4%), ưu tiên camera có trong danh sách chuẩn
        val result = ArrayList<Lens>()
        for (l in found.sortedWith(compareBy({ it.eqMm }, { !it.listed }))) {
            val dup = result.any { abs(it.eqMm - l.eqMm) / l.eqMm < 0.04f }
            if (dup) notes += "ID ${l.openId}: trùng tiêu cự với ống kính khác, đã gộp" else result += l
        }
        return ScanResult(result, notes)
    }
}
