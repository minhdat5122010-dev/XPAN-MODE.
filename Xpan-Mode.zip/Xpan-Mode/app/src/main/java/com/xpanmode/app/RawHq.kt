package com.xpanmode.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureResult
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteOrder
import java.nio.channels.FileChannel
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * HQ RAW: dựng từng khung RAW (Bayer 16-bit) thành ảnh sRGB bằng bộ xử lý riêng của app
 * (trừ mức đen -> cân bằng trắng -> bù tối góc -> giải mosaic Hamilton-Adams -> ma trận màu -> gamma sRGB -> đường cong tông khớp ảnh JPEG của máy),
 * KHÔNG khử nhiễu, KHÔNG làm nét kiểu của ISP. Các khung dựng xong lưu JPEG chất lượng 100 rồi đưa vào bộ ghép LUNA như ảnh thường.
 */
object RawHq {
    /** Mã màu: 0 = R, 1 = G trên hàng đỏ (Gr), 2 = G trên hàng xanh (Gb), 3 = B. Chỉ số theo vị trí (y&1)*2 + (x&1) trong khối 2x2. */
    private val COLOR_AT = arrayOf(
        intArrayOf(0, 1, 2, 3), // RGGB
        intArrayOf(1, 0, 3, 2), // GRBG
        intArrayOf(2, 3, 0, 1), // GBRG
        intArrayOf(3, 2, 1, 0)  // BGGR
    )

    class Meta(
        val cfa: Int,
        /** Mức đen theo vị trí (y&1)*2+(x&1). */
        val black: IntArray,
        val white: Int,
        /** Hệ số cân bằng trắng theo mã màu (R, Gr, Gb, B). */
        val gains: FloatArray,
        /** Ma trận 3x3 (hàng trước) từ RGB camera đã cân bằng trắng sang sRGB tuyến tính. */
        val ccm: FloatArray,
        val shadeCols: Int,
        val shadeRows: Int,
        /** Bản đồ bù tối góc 4 kênh (R, Gr, Gb, B) hoặc null. */
        val shade: Array<FloatArray>?
    )

    class Input(val files: List<File>, val w: Int, val h: Int, val meta: Meta)

    class Rendered(val files: List<File>, val w: Int, val h: Int)

    private val XYZD50_TO_SRGB = floatArrayOf(
        3.1338561f, -1.6168667f, -0.4906146f,
        -0.9787684f, 1.9161415f, 0.0334540f,
        0.0719453f, -0.2289914f, 1.4052427f
    )

    private fun mul3(a: FloatArray, b: FloatArray): FloatArray {
        val o = FloatArray(9)
        for (r in 0 until 3) for (c in 0 until 3) {
            var s = 0f
            for (k in 0 until 3) s += a[r * 3 + k] * b[k * 3 + c]
            o[r * 3 + c] = s
        }
        return o
    }

    /** Lấy thông số xử lý RAW từ đặc tính camera + kết quả chụp của khung đầu. Null nếu thiếu dữ liệu cần thiết. */
    fun metaFrom(c: CameraCharacteristics, res: CaptureResult): Meta? {
        val cfa = c.get(CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT) ?: return null
        if (cfa !in 0..3) return null
        val white = c.get(CameraCharacteristics.SENSOR_INFO_WHITE_LEVEL) ?: return null
        val bl = c.get(CameraCharacteristics.SENSOR_BLACK_LEVEL_PATTERN)
        val black = IntArray(4) { i -> bl?.getOffsetForIndex(i and 1, i shr 1) ?: 0 }
        var gains: FloatArray? = null
        var ccm: FloatArray? = null
        val g = res.get(CaptureResult.COLOR_CORRECTION_GAINS)
        val t = res.get(CaptureResult.COLOR_CORRECTION_TRANSFORM)
        if (g != null && t != null) {
            val gg = floatArrayOf(g.red, g.greenEven, g.greenOdd, g.blue)
            val cc = FloatArray(9) { i -> t.getElement(i % 3, i / 3).toFloat() }
            if (gg.all { it > 0.1f && it < 20f } && cc.any { abs(it) > 0.05f }) { gains = gg; ccm = cc }
        }
        if (gains == null || ccm == null) {
            val n = res.get(CaptureResult.SENSOR_NEUTRAL_COLOR_POINT) ?: return null
            val fm = c.get(CameraCharacteristics.SENSOR_FORWARD_MATRIX1) ?: return null
            val nr = n[0].toFloat()
            val ng = n[1].toFloat()
            val nb = n[2].toFloat()
            if (nr <= 0f || ng <= 0f || nb <= 0f) return null
            gains = floatArrayOf(ng / nr, 1f, 1f, ng / nb)
            val f = FloatArray(9) { i -> fm.getElement(i % 3, i / 3).toFloat() }
            ccm = mul3(XYZD50_TO_SRGB, f)
        }
        var cols = 0
        var rows = 0
        var shade: Array<FloatArray>? = null
        val lm = res.get(CaptureResult.STATISTICS_LENS_SHADING_CORRECTION_MAP)
        // RAW đã được máy bù tối góc sẵn (lensShadingApplied) thì không bù lần nữa, tránh góc ảnh bị sáng quá
        val shadingDone = c.get(CameraCharacteristics.SENSOR_INFO_LENS_SHADING_APPLIED) == true
        if (!shadingDone && lm != null && lm.columnCount >= 2 && lm.rowCount >= 2) {
            cols = lm.columnCount
            rows = lm.rowCount
            shade = Array(4) { ch -> FloatArray(cols * rows) { i -> lm.getGainFactor(ch, i % cols, i / cols) } }
        }
        return Meta(cfa, black, white, gains, ccm, cols, rows, shade)
    }

    // ------------------------------------------------------------------------------------------ dựng ảnh

    private const val HALO = 4
    private const val SH = 32

    private val OETF = FloatArray(4096) {
        val v = it / 4095f
        255f * (if (v <= 0.0031308f) 12.92f * v else 1.055f * Math.pow(v.toDouble(), 1.0 / 2.4).toFloat() - 0.055f)
    }

    private fun mirror(v: Int, n: Int): Int {
        var x = v
        if (x < 0) x = -x
        if (x >= n) x = 2 * (n - 1) - x
        return x.coerceIn(0, n - 1)
    }

    private fun lumaOf(p: Int): Int = (299 * ((p shr 16) and 255) + 587 * ((p shr 8) and 255) + 114 * (p and 255)) / 1000

    /** Áp đường cong tông (theo độ sáng) lên một điểm ảnh, giữ tỉ lệ R:G:B. */
    private fun tone(p: Int, lut: FloatArray): Int {
        val r = (p shr 16) and 255
        val g = (p shr 8) and 255
        val b = p and 255
        val y = 0.299f * r + 0.587f * g + 0.114f * b
        if (y < 0.5f) return p
        val yi = y.toInt().coerceIn(0, 254)
        val fr = y - yi
        val yo = lut[yi] * (1f - fr) + lut[yi + 1] * fr
        val k = (yo / y).coerceIn(0f, 6f)
        val nr = (r * k + 0.5f).toInt().coerceIn(0, 255)
        val ng = (g * k + 0.5f).toInt().coerceIn(0, 255)
        val nb = (b * k + 0.5f).toInt().coerceIn(0, 255)
        return (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
    }

    private fun applyLut(bmp: Bitmap, lut: FloatArray) {
        val w = bmp.width
        val h = bmp.height
        val sh = 64
        val strips = (h + sh - 1) / sh
        java.util.stream.IntStream.range(0, strips).parallel().forEach { si ->
            val y0 = si * sh
            val n = min(sh, h - y0)
            val buf = IntArray(w * n)
            synchronized(bmp) { bmp.getPixels(buf, 0, w, 0, y0, w, n) }
            for (i in buf.indices) buf[i] = tone(buf[i], lut)
            synchronized(bmp) { bmp.setPixels(buf, 0, w, 0, y0, w, n) }
        }
    }

    private fun histOf(bmp: Bitmap, step: Int): IntArray {
        val hist = IntArray(256)
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w)
        var y = 0
        while (y < h) {
            bmp.getPixels(px, 0, w, 0, y, w, 1)
            var x = 0
            while (x < w) { hist[lumaOf(px[x]).coerceIn(0, 255)]++; x += step }
            y += step
        }
        return hist
    }

    /** Khớp biểu đồ độ sáng của ảnh dựng với ảnh JPEG của máy -> đường cong tông tổng thể giống ảnh máy (độ sáng, tương phản). */
    private fun matchLut(src: IntArray, ref: IntArray): FloatArray {
        val ts = max(1L, src.fold(0L) { a, v -> a + v })
        val tr = max(1L, ref.fold(0L) { a, v -> a + v })
        val cs = DoubleArray(256)
        val cr = DoubleArray(256)
        var a = 0L
        var b = 0L
        for (i in 0 until 256) {
            a += src[i]; b += ref[i]
            cs[i] = a.toDouble() / ts
            cr[i] = b.toDouble() / tr
        }
        val lut = FloatArray(256)
        var j = 0
        for (i in 0 until 256) {
            while (j < 255 && cr[j] < cs[i]) j++
            lut[i] = j.toFloat()
        }
        val sm = FloatArray(256) { i ->
            var s = 0f
            var n = 0
            for (d in -4..4) { s += lut[(i + d).coerceIn(0, 255)]; n++ }
            s / n
        }
        for (i in 1 until 256) if (sm[i] < sm[i - 1]) sm[i] = sm[i - 1]
        sm[0] = max(0f, sm[0])
        return sm
    }

    /** Dựng một khung RAW (vùng cắt x0,y0,cw,ch tính bằng điểm ảnh RAW) thành Bitmap sRGB. */
    private fun renderFrame(f: File, input: Input, x0: Int, y0: Int, cw: Int, ch: Int, lut: FloatArray?): Bitmap {
        val m = input.meta
        val rw = input.w
        val rh = input.h
        val raf = RandomAccessFile(f, "r")
        val out = Bitmap.createBitmap(cw, ch, Bitmap.Config.ARGB_8888)
        try {
            val bb = raf.channel.map(FileChannel.MapMode.READ_ONLY, 0, raf.length()).order(ByteOrder.LITTLE_ENDIAN)
            val sb = bb.asShortBuffer()
            val colorAt = COLOR_AT[m.cfa]
            val inv = FloatArray(4) { i -> 1f / max(1, m.white - m.black[i]).toFloat() }
            // nội suy bản đồ bù tối góc theo cột (tính sẵn cho từng cột RAW)
            val shade = m.shade
            val cols = m.shadeCols
            val rows = m.shadeRows
            val cx0 = IntArray(if (shade != null) rw else 0)
            val cfx = FloatArray(if (shade != null) rw else 0)
            if (shade != null) for (x in 0 until rw) {
                val gx = (x + 0.5f) / rw * (cols - 1)
                val c0 = gx.toInt().coerceIn(0, cols - 2)
                cx0[x] = c0
                cfx[x] = (gx - c0).coerceIn(0f, 1f)
            }
            val W = cw + 2 * HALO
            val strips = (ch + SH - 1) / SH
            java.util.stream.IntStream.range(0, strips).parallel().forEach { si ->
                val ys = si * SH
                val nrows = min(SH, ch - ys)
                val H = nrows + 2 * HALO
                val s = FloatArray(W * H)
                for (yl in 0 until H) {
                    val gy = mirror(y0 + ys + yl - HALO, rh)
                    var ry0 = 0
                    var fy = 0f
                    if (shade != null) {
                        val gyf = (gy + 0.5f) / rh * (rows - 1)
                        ry0 = gyf.toInt().coerceIn(0, rows - 2)
                        fy = (gyf - ry0).coerceIn(0f, 1f)
                    }
                    for (xl in 0 until W) {
                        val gx = mirror(x0 + xl - HALO, rw)
                        val pos = ((yl and 1) shl 1) or (xl and 1)
                        val col = colorAt[pos]
                        val v = (sb.get(gy * rw + gx).toInt() and 0xFFFF) - m.black[pos]
                        var gain = m.gains[col]
                        if (shade != null) {
                            val sh = shade[col]
                            val i0 = ry0 * cols + cx0[gx]
                            val a = sh[i0] * (1f - cfx[gx]) + sh[i0 + 1] * cfx[gx]
                            val b = sh[i0 + cols] * (1f - cfx[gx]) + sh[i0 + cols + 1] * cfx[gx]
                            gain *= a * (1f - fy) + b * fy
                        }
                        val lin = if (v > 0) v * inv[pos] * gain else 0f
                        s[yl * W + xl] = if (lin > 1f) 1f else lin
                    }
                }
                val gP = FloatArray(W * H)
                val rP = FloatArray(W * H)
                val bP = FloatArray(W * H)
                // lượt 1: kênh xanh (Hamilton-Adams: chọn hướng nội suy theo độ biến thiên nhỏ hơn)
                for (y in 2 until H - 2) for (x in 2 until W - 2) {
                    val i = y * W + x
                    val col = colorAt[((y and 1) shl 1) or (x and 1)]
                    if (col == 1 || col == 2) { gP[i] = s[i]; continue }
                    val c0 = s[i]
                    val l1 = s[i - 1]; val r1 = s[i + 1]; val u1 = s[i - W]; val d1 = s[i + W]
                    val gh = (l1 + r1) * 0.5f + (2f * c0 - s[i - 2] - s[i + 2]) * 0.25f
                    val gv = (u1 + d1) * 0.5f + (2f * c0 - s[i - 2 * W] - s[i + 2 * W]) * 0.25f
                    val dh = abs(l1 - r1) + abs(2f * c0 - s[i - 2] - s[i + 2])
                    val dv = abs(u1 - d1) + abs(2f * c0 - s[i - 2 * W] - s[i + 2 * W])
                    val g = if (dh < dv) gh else if (dh > dv) gv else (gh + gv) * 0.5f
                    gP[i] = if (g < 0f) 0f else if (g > 1f) 1f else g
                }
                // lượt 2: đỏ/xanh dương nội suy theo chênh lệch với kênh xanh
                for (y in 3 until H - 3) for (x in 3 until W - 3) {
                    val i = y * W + x
                    val col = colorAt[((y and 1) shl 1) or (x and 1)]
                    val g = gP[i]
                    when (col) {
                        0, 3 -> {
                            val d = ((s[i - W - 1] - gP[i - W - 1]) + (s[i - W + 1] - gP[i - W + 1]) +
                                (s[i + W - 1] - gP[i + W - 1]) + (s[i + W + 1] - gP[i + W + 1])) * 0.25f
                            if (col == 0) { rP[i] = s[i]; bP[i] = g + d } else { bP[i] = s[i]; rP[i] = g + d }
                        }
                        1 -> {
                            rP[i] = g + ((s[i - 1] - gP[i - 1]) + (s[i + 1] - gP[i + 1])) * 0.5f
                            bP[i] = g + ((s[i - W] - gP[i - W]) + (s[i + W] - gP[i + W])) * 0.5f
                        }
                        else -> {
                            bP[i] = g + ((s[i - 1] - gP[i - 1]) + (s[i + 1] - gP[i + 1])) * 0.5f
                            rP[i] = g + ((s[i - W] - gP[i - W]) + (s[i + W] - gP[i + W])) * 0.5f
                        }
                    }
                }
                val cc = m.ccm
                val px = IntArray(cw * nrows)
                for (y in HALO until H - HALO) for (x in HALO until W - HALO) {
                    val i = y * W + x
                    val r = rP[i]; val g = gP[i]; val b = bP[i]
                    val lr = cc[0] * r + cc[1] * g + cc[2] * b
                    val lg = cc[3] * r + cc[4] * g + cc[5] * b
                    val lb = cc[6] * r + cc[7] * g + cc[8] * b
                    val r8 = (OETF[((if (lr < 0f) 0f else if (lr > 1f) 1f else lr) * 4095f).toInt()] + 0.5f).toInt()
                    val g8 = (OETF[((if (lg < 0f) 0f else if (lg > 1f) 1f else lg) * 4095f).toInt()] + 0.5f).toInt()
                    val b8 = (OETF[((if (lb < 0f) 0f else if (lb > 1f) 1f else lb) * 4095f).toInt()] + 0.5f).toInt()
                    var p = (0xFF shl 24) or (r8.coerceIn(0, 255) shl 16) or (g8.coerceIn(0, 255) shl 8) or b8.coerceIn(0, 255)
                    if (lut != null) p = tone(p, lut)
                    px[(y - HALO) * cw + (x - HALO)] = p
                }
                synchronized(out) { out.setPixels(px, 0, cw, 0, ys, cw, nrows) }
            }
        } finally {
            try { raf.close() } catch (_: Exception) {}
        }
        return out
    }

    /**
     * Dựng toàn bộ các khung RAW của vùng cắt `region` (toạ độ ảnh JPEG bw x bh) thành các tệp JPEG chất lượng 100 trong thư mục `dir`.
     * Đường cong tông lấy từ khung đầu so với ảnh JPEG của máy rồi dùng chung cho mọi khung (các khung giống hệt nhau về tông, ghép không lệch).
     */
    fun render(dir: File, input: Input, jpeg: File, bw: Int, bh: Int, region: Rect, progress: ((Int) -> Unit)?): Rendered {
        val sx = input.w.toFloat() / bw
        val sy = input.h.toFloat() / bh
        if (abs(sx - sy) > 0.03f * sx) throw IllegalStateException("khung RAW lệch tỉ lệ so với JPEG")
        val x0 = (region.left * sx).toInt() and 1.inv()
        val y0 = (region.top * sy).toInt() and 1.inv()
        var cw = ((region.width() * sx).toInt() / 2) * 2
        var ch = ((region.height() * sy).toInt() / 2) * 2
        if (x0 + cw > input.w) cw = ((input.w - x0) / 2) * 2
        if (y0 + ch > input.h) ch = ((input.h - y0) / 2) * 2
        if (cw < 64 || ch < 64) throw IllegalStateException("vùng cắt RAW quá nhỏ")

        // biểu đồ độ sáng của ảnh JPEG (cùng vùng) làm chuẩn tông
        val refHist: IntArray = run {
            val dec = BitmapRegionDecoder.newInstance(jpeg.absolutePath, false)
            val o = BitmapFactory.Options().apply { inSampleSize = 4; inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val jb = try { dec.decodeRegion(region, o) } finally { dec.recycle() }
                ?: throw IllegalStateException("không giải mã được JPEG chuẩn")
            val h = histOf(jb, 1)
            jb.recycle()
            h
        }

        val outs = ArrayList<File>()
        val n = input.files.size
        var lut: FloatArray? = null
        try {
            for ((k, f) in input.files.withIndex()) {
                val bmp = renderFrame(f, input, x0, y0, cw, ch, lut)
                if (lut == null) {
                    val small = Bitmap.createScaledBitmap(bmp, max(1, cw / 4), max(1, ch / 4), false)
                    val l = matchLut(histOf(small, 1), refHist)
                    small.recycle()
                    lut = l
                    applyLut(bmp, l)
                }
                val of = File(dir, "rawhq_${System.nanoTime()}.jpg")
                FileOutputStream(of).use { bmp.compress(Bitmap.CompressFormat.JPEG, 100, it) }
                bmp.recycle()
                outs.add(of)
                progress?.invoke(100 * (k + 1) / n)
            }
        } catch (t: Throwable) {
            outs.forEach { try { it.delete() } catch (_: Throwable) {} }
            throw t
        }
        return Rendered(outs, cw, ch)
    }
}
