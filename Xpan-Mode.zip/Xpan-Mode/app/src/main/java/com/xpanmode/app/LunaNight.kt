package com.xpanmode.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * LUNA Night: chế độ thiếu sáng, xây trên LUNA Engine (căn chỉnh Lucas-Kanade dưới điểm ảnh của MultiFrame) nhưng đổi cách ghép:
 *
 *  1. STREAMING: mỗi khung JPEG vừa chụp xong được giải mã + căn chỉnh + cộng dồn ngay trong lúc máy còn đang phơi sáng,
 *     nên hết giờ đếm ngược chỉ còn vài giây hoàn thiện (không giữ cả chục khung 20MB trong RAM).
 *  2. CỘNG DỒN TRONG KHÔNG GIAN TUYẾN TÍNH (sRGB -> linear), trọng số chống bóng ma theo sai khác độ sáng với khung gốc,
 *     ngưỡng theo mức nhiễu ước lượng (nhiễu không bị coi là chuyển động; đèn xe chạy ngang bị loại hẳn).
 *  3. Căn chỉnh ảnh tối trên độ sáng đã nhân gain (ngưỡng chi tiết tỉ lệ gain²) để LK không bám vào nhiễu.
 *  4. TONE MAPPING THIẾU SÁNG: gamma nâng bóng tối trên "lớp nền" (đường bao dưới của ô 8x8 + bilateral trong log) giữ nguyên
 *     chi tiết cục bộ; độ lợi bị chặn theo chính điểm ảnh (không viền sáng cạnh vạch tối) và mờ dần về 1 ở vùng sáng
 *     (đèn không cháy); điểm đen thích nghi; knee mềm; bão hoà nhẹ. Khử nhiễu màu/độ sáng làm sau ở PhotoProcessor.
 */
object LunaNight {
    private const val MAX_PX = 9_000_000L     // quá ngưỡng này thì giải mã giảm 2x/4x (như gộp điểm ảnh của máy ảnh khi chụp đêm)
    private const val MAX_USED = 28           // số khung tối đa được ghép
    private const val MAX_INFLIGHT = 3        // khung chờ xử lý tối đa; đến sau sẽ bị bỏ (xử lý không kịp tốc độ chụp)
    private const val KEY = 0.20f             // độ sáng trung vị mục tiêu (tuyến tính) ~ mức máy tự phơi; ảnh đã đạt thì không nâng
    private const val A_MIN = 0.45f           // giới hạn mức nâng bóng tối (~ tối đa 4-5 stop ở trung vị)
    private const val BP_MAX = 0.010f
    private const val SAT = 1.12f
    private const val G0 = 0.25f
    private const val G1 = 0.70f
    private const val KNEE = 0.80f
    private const val KAPPA = 1.25f
    private const val LN2 = 0.6931472f
    private const val HB = 4096
    private const val RL = 4096
    private const val ENC_N = 16384

    private val LIN = FloatArray(256) { i ->
        val c = i / 255.0
        (if (c <= 0.04045) c / 12.92 else Math.pow((c + 0.055) / 1.055, 2.4)).toFloat()
    }
    private val ENC = IntArray(ENC_N + 1) { i ->
        val v = i.toDouble() / ENC_N
        val c = if (v <= 0.0031308) 12.92 * v else 1.055 * Math.pow(v, 1.0 / 2.4) - 0.055
        (c * 255.0 + 0.5).toInt().coerceIn(0, 255)
    }

    private class Img(val px: IntArray, val w: Int, val h: Int)

    private fun decode(path: String, rg: Rect, sample: Int): Img? {
        @Suppress("DEPRECATION")
        val dec = BitmapRegionDecoder.newInstance(path, false) ?: return null
        try {
            val o = BitmapFactory.Options().apply {
                inPreferredConfig = Bitmap.Config.ARGB_8888
                inSampleSize = sample
            }
            val b = dec.decodeRegion(rg, o) ?: return null
            val bw = b.width
            val bh = b.height
            val out = IntArray(bw * bh)
            b.getPixels(out, 0, bw, 0, 0, bw, bh)
            b.recycle()
            return Img(out, bw, bh)
        } finally {
            dec.recycle()
        }
    }

    class Session(private val zoom: Float, private val rotation: Int) {
        private val pool = Executors.newFixedThreadPool(2)
        private val inFlight = AtomicInteger(0)
        private val accepted = AtomicInteger(0)
        private val finished = AtomicInteger(0)
        private val baseReady = CountDownLatch(1)
        private val pendingFiles = ConcurrentLinkedQueue<File>()
        private val lock = Any()
        @Volatile private var aborted = false
        @Volatile private var failure: Throwable? = null

        /** Số khung thực sự được ghép / số khung bị bỏ vì xử lý không kịp. */
        @Volatile var used = 0
            private set
        @Volatile var dropped = 0
            private set

        private var region: Rect? = null
        private var sample = 1
        private var w = 0
        private var h = 0
        private var base: IntArray? = null
        private var baseS: FloatArray? = null
        private var baseL: ByteArray? = null
        private var baseMean = 0f
        private var gain = 1f
        private var sBest = 0f
        private val thr = FloatArray(256)
        private var accR: FloatArray? = null
        private var accG: FloatArray? = null
        private var accB: FloatArray? = null
        private var accW: FloatArray? = null

        /** Nhận một khung JPEG (đã ghi ra file). Khung đầu là khung gốc; xử lý nền, file tự xoá sau khi dùng. */
        fun add(f: File) {
            if (aborted) { f.delete(); return }
            val n = accepted.get()
            if (n > 0 && (inFlight.get() >= MAX_INFLIGHT || n >= MAX_USED)) {
                f.delete()
                dropped++
                return
            }
            val idx = accepted.getAndIncrement()
            inFlight.incrementAndGet()
            pendingFiles.add(f)
            try {
                pool.execute {
                    try {
                        if (idx == 0) setup(f) else accumulateFrame(f)
                    } catch (t: Throwable) {
                        if (idx == 0) failure = t
                    } finally {
                        pendingFiles.remove(f)
                        f.delete()
                        inFlight.decrementAndGet()
                        finished.incrementAndGet()
                    }
                }
            } catch (t: Throwable) {
                pendingFiles.remove(f)
                f.delete()
                inFlight.decrementAndGet()
                finished.incrementAndGet()
            }
        }

        fun abort() {
            aborted = true
            pool.shutdownNow()
            for (f in pendingFiles) f.delete()
            pendingFiles.clear()
            baseReady.countDown()
            base = null; baseS = null; baseL = null
            accR = null; accG = null; accB = null; accW = null
        }

        private fun setup(f: File) {
            try {
                @Suppress("DEPRECATION")
                val dec = BitmapRegionDecoder.newInstance(f.absolutePath, false)
                    ?: throw IllegalStateException("Không đọc được khung đầu")
                val bw = dec.width
                val bh = dec.height
                dec.recycle()
                // vùng cắt 65:24 (+ zoom số): cùng công thức với PhotoProcessor.process
                val z = zoom.coerceAtLeast(1f)
                val vertical = rotation == 90 || rotation == 270
                val aspect = if (vertical) 24f / 65f else 65f / 24f
                var cw = bw / z
                var ch = cw / aspect
                if (ch > bh / z) { ch = bh / z; cw = ch * aspect }
                val rawPx = cw.toLong() * ch.toLong()
                sample = if (rawPx <= MAX_PX) 1 else if (rawPx / 4 <= MAX_PX) 2 else 4
                val al = 8 * sample
                val cwi = (cw.toInt() / al) * al
                val chi = (ch.toInt() / al) * al
                val left = ((bw - cwi) / 2) / 2 * 2
                val top = ((bh - chi) / 2) / 2 * 2
                val rg = Rect(left, top, left + cwi, top + chi)
                val img = decode(f.absolutePath, rg, sample) ?: throw IllegalStateException("decodeRegion trả về null")
                w = img.w
                h = img.h
                region = rg
                val px = img.px
                val n = w * h
                val bl = ByteArray(n)
                var sum = 0L
                for (i in 0 until n) {
                    val l = MultiFrame.luma(px[i])
                    bl[i] = l.toByte()
                    sum += l
                }
                baseL = bl
                baseMean = sum.toFloat() / n
                gain = (100f / max(baseMean, 4f)).coerceIn(1f, 12f)
                baseS = MultiFrame.lumaDown(px, w, h, 4, gain)
                val sg = noiseSigma(bl, w, h)
                for (l in 0..255) thr[l] = max(18f, 5f * sg * sqrt(1f + l / 40f))
                accR = FloatArray(n)
                accG = FloatArray(n)
                accB = FloatArray(n)
                accW = FloatArray(n)
                base = px
                sBest = sharpness(px)
                synchronized(lock) { accumulate(px, 0f, 0f, 1f, 1f, true) }
                used = 1
            } finally {
                baseReady.countDown()
            }
        }

        private fun accumulateFrame(f: File) {
            baseReady.await()
            if (aborted) return
            val rg = region ?: return
            val b = base ?: return
            val bs = baseS ?: return
            val img = decode(f.absolutePath, rg, sample) ?: return
            if (img.w != w || img.h != h) return
            val cur = img.px
            // căn chỉnh: thô trên luma 1/4 đã nhân gain, rồi LK dưới điểm ảnh (cùng bộ của LUNA Engine)
            val cs = MultiFrame.lumaDown(cur, w, h, 4, gain)
            val c = MultiFrame.coarse(bs, cs, w / 4, h / 4)
            val sh = MultiFrame.refine(b, cur, w, h, c, gain)
            if (abs(sh[0]) > 24f || abs(sh[1]) > 24f) return    // rung/chuyển động quá mạnh: bỏ khung
            // khớp độ sáng với khung gốc (đèn nhấp nháy, AE trôi nhẹ)
            var s = 0L
            var cnt = 0
            var i = 0
            while (i < cur.size) { s += MultiFrame.luma(cur[i]); cnt++; i += 13 }
            val curMean = s.toFloat() / max(cnt, 1)
            val ratio = baseMean / max(curMean, 1f)
            var es = Math.pow(ratio.toDouble(), 2.2).toFloat().coerceIn(0.7f, 1.4f)
            if (abs(es - 1f) < 0.03f) es = 1f
            // "lucky imaging": khung nhoè do rung bị giảm trọng số hoặc bỏ hẳn so với khung nét nhất đã thấy
            val sp = sharpness(cur)
            synchronized(lock) {
                if (aborted) return
                if (sp > sBest) sBest = sp
                val q = sp / max(sBest, 1e-3f)
                if (q < 0.72f) return
                val q2 = q * q
                accumulate(cur, sh[0], sh[1], es, q2 * q2, false)
                used++
            }
        }

        /** Cộng khung vào bộ tích luỹ tuyến tính: điểm (x,y) lấy mẫu song tuyến tại (x+dx, y+dy) của khung hiện tại. */
        private fun accumulate(cur: IntArray, dx: Float, dy: Float, es: Float, fw: Float, isBase: Boolean) {
            val ar = accR ?: return
            val ag = accG ?: return
            val ab = accB ?: return
            val aw = accW ?: return
            val bl = baseL ?: return
            val w = this.w
            val h = this.h
            val ox = floor(dx).toInt()
            val oy = floor(dy).toInt()
            val fx = dx - ox
            val fy = dy - oy
            val w00 = (1f - fx) * (1f - fy)
            val w01 = fx * (1f - fy)
            val w10 = (1f - fx) * fy
            val w11 = fx * fy
            val esG = Math.pow(es.toDouble(), 1.0 / 2.2).toFloat()
            val thrT = thr
            val cores = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
            java.util.stream.IntStream.range(0, cores).parallel().forEach { c ->
                val yA = h * c / cores
                val yB = h * (c + 1) / cores
                for (y in yA until yB) {
                    val ra = (y + oy).coerceIn(0, h - 1) * w
                    val rb = (y + oy + 1).coerceIn(0, h - 1) * w
                    val o = y * w
                    for (x in 0 until w) {
                        val xa = (x + ox).coerceIn(0, w - 1)
                        val xb = (x + ox + 1).coerceIn(0, w - 1)
                        val p00 = cur[ra + xa]
                        val p01 = cur[ra + xb]
                        val p10 = cur[rb + xa]
                        val p11 = cur[rb + xb]
                        val r8 = ((p00 shr 16) and 255) * w00 + ((p01 shr 16) and 255) * w01 +
                            ((p10 shr 16) and 255) * w10 + ((p11 shr 16) and 255) * w11
                        val g8 = ((p00 shr 8) and 255) * w00 + ((p01 shr 8) and 255) * w01 +
                            ((p10 shr 8) and 255) * w10 + ((p11 shr 8) and 255) * w11
                        val b8 = (p00 and 255) * w00 + (p01 and 255) * w01 +
                            (p10 and 255) * w10 + (p11 and 255) * w11
                        var wt = 1f
                        if (!isBase) {
                            val l8 = (0.299f * r8 + 0.587f * g8 + 0.114f * b8) * esG
                            val bv = bl[o + x].toInt() and 255
                            val q = abs(l8 - bv) / thrT[bv]
                            val q2 = q * q
                            wt = fw / (1f + q2 * q2)
                        }
                        val i = o + x
                        ar[i] += wt * es * LIN[(r8 + 0.5f).toInt().coerceIn(0, 255)]
                        ag[i] += wt * es * LIN[(g8 + 0.5f).toInt().coerceIn(0, 255)]
                        ab[i] += wt * es * LIN[(b8 + 0.5f).toInt().coerceIn(0, 255)]
                        aw[i] += wt
                    }
                }
            }
        }

        /** Độ nét: trung bình |chênh lệch| giữa các khối 2x2 kề nhau ở vùng giữa ảnh (khối 2x2 giảm nhiễu; nhoè do rung làm số này tụt). */
        private fun sharpness(px: IntArray): Float {
            val x0 = (w / 4) / 2 * 2
            val x1 = (w * 3 / 4) / 2 * 2 - 2
            val y0 = (h / 4) / 2 * 2
            val y1 = (h * 3 / 4) / 2 * 2 - 2
            var s = 0L
            var n = 0
            var y = y0
            while (y < y1) {
                var x = x0
                while (x < x1) {
                    val i = y * w + x
                    val a = MultiFrame.luma(px[i]) + MultiFrame.luma(px[i + 1]) + MultiFrame.luma(px[i + w]) + MultiFrame.luma(px[i + w + 1])
                    val j = i + 2
                    val b = MultiFrame.luma(px[j]) + MultiFrame.luma(px[j + 1]) + MultiFrame.luma(px[j + w]) + MultiFrame.luma(px[j + w + 1])
                    val k = i + 2 * w
                    val c = MultiFrame.luma(px[k]) + MultiFrame.luma(px[k + 1]) + MultiFrame.luma(px[k + w]) + MultiFrame.luma(px[k + w + 1])
                    s += abs(a - b) + abs(a - c)
                    n++
                    x += 2
                }
                y += 2
            }
            return if (n > 0) s.toFloat() / n else 0f
        }

        /** Ước lượng σ nhiễu (thang 0-255) theo Immerkær trên độ sáng gamma của khung gốc. */
        private fun noiseSigma(l: ByteArray, w: Int, h: Int): Float {
            if (w < 8 || h < 8) return 3f
            var sum = 0.0
            var cnt = 0L
            var y = 1
            while (y < h - 1) {
                var x = 1
                while (x < w - 1) {
                    val i = y * w + x
                    val v = (l[i - w - 1].toInt() and 255) - 2 * (l[i - w].toInt() and 255) + (l[i - w + 1].toInt() and 255) -
                        2 * (l[i - 1].toInt() and 255) + 4 * (l[i].toInt() and 255) - 2 * (l[i + 1].toInt() and 255) +
                        (l[i + w - 1].toInt() and 255) - 2 * (l[i + w].toInt() and 255) + (l[i + w + 1].toInt() and 255)
                    val a = abs(v)
                    if (a < 90) { sum += a; cnt++ }
                    x += 3
                }
                y += 3
            }
            if (cnt == 0L) return 3f
            return (sqrt(Math.PI / 2.0) * sum / (6.0 * cnt)).toFloat().coerceIn(1.5f, 9f)
        }

        /**
         * Chờ các khung còn lại xử lý xong, rồi tone mapping thiếu sáng ra bitmap 8-bit (đã qua bộ lọc màu `proc`).
         * `progress` báo 0..100 (khoảng 40 đầu là chờ khung, phần sau là tone mapping).
         */
        fun finish(progress: ((Int) -> Unit)?, proc: (IntArray, Int, Int) -> Unit): Bitmap {
            pool.shutdown()
            while (!pool.awaitTermination(120, TimeUnit.MILLISECONDS)) {
                progress?.invoke(40 * finished.get() / max(accepted.get(), 1))
            }
            progress?.invoke(40)
            val fl = failure
            if (fl != null) throw fl
            if (aborted || used < 1 || accR == null) throw IllegalStateException("Không có khung nào để ghép")
            val out = toneMap(progress, proc)
            base = null; baseS = null; baseL = null
            accR = null; accG = null; accB = null; accW = null
            return out
        }

        private fun toneMap(progress: ((Int) -> Unit)?, proc: (IntArray, Int, Int) -> Unit): Bitmap {
            val w = this.w
            val h = this.h
            val n = w * h
            val ar = accR!!
            val ag = accG!!
            val ab = accB!!
            val yv = accW!!            // sau khi chuẩn hoá, mảng trọng số được dùng lại làm độ sáng Y
            val cores = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)

            // --- lượt 1: chuẩn hoá (trung bình có trọng số), Y tuyến tính, biểu đồ
            val histAll = IntArray(HB)
            java.util.stream.IntStream.range(0, cores).parallel().forEach { c ->
                val from = (n.toLong() * c / cores).toInt()
                val to = (n.toLong() * (c + 1) / cores).toInt()
                val hl = IntArray(HB)
                for (i in from until to) {
                    val inv = 1f / yv[i]
                    val r = ar[i] * inv
                    val g = ag[i] * inv
                    val b = ab[i] * inv
                    ar[i] = r; ag[i] = g; ab[i] = b
                    val y = 0.2126f * r + 0.7152f * g + 0.0722f * b
                    yv[i] = y
                    hl[(sqrt(y.coerceIn(0f, 1f)) * (HB - 1)).toInt()]++
                }
                synchronized(histAll) { for (k in 0 until HB) histAll[k] += hl[k] }
            }
            progress?.invoke(48)
            fun pct(p: Float): Float {
                val target = (n * p).toLong()
                var acc = 0L
                for (k in 0 until HB) {
                    acc += histAll[k]
                    if (acc >= target) { val s = k / (HB - 1f); return s * s }
                }
                return 1f
            }
            val bp = min(pct(0.005f) * 0.8f, BP_MAX)
            val invBp = 1f / (1f - bp)
            val medY = max((pct(0.5f) - bp) * invBp, 1e-4f)
            // mức nâng bóng tối: đưa trung vị lên KEY bằng hàm mũ a<1 trên lớp nền (ảnh đã đủ sáng thì a=1: không nâng)
            val a = if (medY < KEY) (ln(KEY) / ln(medY)).coerceIn(A_MIN, 1f) else 1f
            val satEff = 1f + (SAT - 1f) * ((1f - a) / (1f - A_MIN)).coerceIn(0f, 1f)

            // --- lớp nền: đường bao dưới (min của 4 khối 4x4) mỗi ô 8x8, log2, bilateral trên lưới thưa
            val gw = max(w / 8, 1)
            val gh = max(h / 8, 1)
            val grid = FloatArray(gw * gh)
            java.util.stream.IntStream.range(0, gh).parallel().forEach { gy ->
                for (gx in 0 until gw) {
                    var mn = Float.MAX_VALUE
                    for (sy in 0..1) for (sx in 0..1) {
                        var s = 0f
                        for (j in 0 until 4) {
                            val row = min(gy * 8 + sy * 4 + j, h - 1) * w + gx * 8 + sx * 4
                            for (i in 0 until 4) s += yv[min(row + i, n - 1)]
                        }
                        val m = s * (1f / 16f)
                        if (m < mn) mn = m
                    }
                    val yb = max(0f, mn - bp) * invBp
                    grid[gy * gw + gx] = ln(max(yb, 1e-4f)) / LN2
                }
            }
            val rr = 6
            val side = 2 * rr + 1
            val spat = FloatArray(side * side) { k ->
                val dy = k / side - rr
                val dx = k % side - rr
                exp(-(dx * dx + dy * dy) / (2f * 4f * 4f))
            }
            val rangeLut = FloatArray(RL) { k -> val d = k / 256f; exp(-(d * d) / (2f * 0.9f * 0.9f)) }
            val smooth = FloatArray(gw * gh)
            java.util.stream.IntStream.range(0, gh).parallel().forEach { gy ->
                for (gx in 0 until gw) {
                    val cv = grid[gy * gw + gx]
                    var sum = 0f
                    var ws = 0f
                    for (dy in -rr..rr) {
                        val yy = (gy + dy).coerceIn(0, gh - 1)
                        for (dx in -rr..rr) {
                            val xx = (gx + dx).coerceIn(0, gw - 1)
                            val v = grid[yy * gw + xx]
                            val idx = min((abs(v - cv) * 256f).toInt(), RL - 1)
                            val wg = spat[(dy + rr) * side + dx + rr] * rangeLut[idx]
                            sum += v * wg
                            ws += wg
                        }
                    }
                    smooth[gy * gw + gx] = min(sum / ws, 0f)       // nền <= 1 (log2 <= 0)
                }
            }
            progress?.invoke(55)

            // --- lượt 2: độ lợi cục bộ + knee + bão hoà + mã hoá sRGB, theo dải
            val gxI = IntArray(w)
            val gxF = FloatArray(w)
            for (x in 0 until w) {
                val f = ((x + 0.5f) / 8f - 0.5f).coerceIn(0f, (gw - 1).toFloat())
                val i0 = f.toInt()
                gxI[x] = i0
                gxF[x] = f - i0
            }
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val band = 64
            val bands = (h + band - 1) / band
            val done = AtomicInteger(0)
            val lnA1 = (a - 1f) * LN2
            val lnKappa = ln(KAPPA)
            java.util.stream.IntStream.range(0, bands).parallel().forEach { bi ->
                val y0 = bi * band
                val y1 = min(h, y0 + band)
                val bh = y1 - y0
                val px = IntArray(w * bh)
                for (y in y0 until y1) {
                    val gyf = ((y + 0.5f) / 8f - 0.5f).coerceIn(0f, (gh - 1).toFloat())
                    val gy0 = gyf.toInt()
                    val gy1 = min(gy0 + 1, gh - 1)
                    val fy = gyf - gy0
                    val rowA = gy0 * gw
                    val rowB = gy1 * gw
                    for (x in 0 until w) {
                        val i = y * w + x
                        var r = max(0f, ar[i] - bp) * invBp
                        var g = max(0f, ag[i] - bp) * invBp
                        var b = max(0f, ab[i] - bp) * invBp
                        val yp = 0.2126f * r + 0.7152f * g + 0.0722f * b
                        val gx0 = gxI[x]
                        val gx1 = min(gx0 + 1, gw - 1)
                        val fx = gxF[x]
                        val bb = (smooth[rowA + gx0] * (1f - fx) + smooth[rowA + gx1] * fx) * (1f - fy) +
                            (smooth[rowB + gx0] * (1f - fx) + smooth[rowB + gx1] * fx) * fy
                        var lnf = lnA1 * bb
                        // không nâng một điểm ảnh quá độ lợi của chính nó (tránh viền sáng cạnh vạch tối nhỏ)
                        val cap = lnKappa + (a - 1f) * ln(max(yp, 1e-4f))
                        if (lnf > cap) lnf = cap
                        if (lnf < 0f) lnf = 0f
                        // vùng đã sáng (đèn, cửa sổ) mờ dần về độ lợi 1 -> không cháy
                        val t = ((yp - G0) / (G1 - G0)).coerceIn(0f, 1f)
                        lnf *= 1f - t * t * (3f - 2f * t)
                        if (lnf > 0f) {
                            val gn = exp(lnf)
                            r *= gn; g *= gn; b *= gn
                        }
                        var yo = 0.2126f * r + 0.7152f * g + 0.0722f * b
                        if (yo > KNEE) {
                            val yc = KNEE + (1f - KNEE) * tanh((yo - KNEE) / (1f - KNEE))
                            val sc = yc / yo
                            r *= sc; g *= sc; b *= sc
                            yo = yc
                        }
                        if (satEff != 1f) {
                            r = yo + (r - yo) * satEff
                            g = yo + (g - yo) * satEff
                            b = yo + (b - yo) * satEff
                        }
                        val ri = (r.coerceIn(0f, 1f) * ENC_N + 0.5f).toInt()
                        val gi = (g.coerceIn(0f, 1f) * ENC_N + 0.5f).toInt()
                        val bi2 = (b.coerceIn(0f, 1f) * ENC_N + 0.5f).toInt()
                        px[(y - y0) * w + x] = (0xFF shl 24) or (ENC[ri] shl 16) or (ENC[gi] shl 8) or ENC[bi2]
                    }
                }
                proc(px, 0, px.size)
                synchronized(out) { out.setPixels(px, 0, w, 0, y0, w, bh) }
                progress?.invoke(55 + 40 * done.incrementAndGet() / bands)
            }
            progress?.invoke(95)
            return out
        }
    }
}
