package com.xpanmode.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Live Art: ảnh động như Live Photo. Khi bật, app thêm một luồng YUV nhỏ vào phiên xem trước của camera và liên tục giữ ~1,5s khung hình
 * THẬT gần nhất (đã cắt đúng khung 65:24 + zoom như ảnh chụp). Bấm chụp thì giữ thêm ~1,5s nữa. Sau khi ảnh tĩnh đã xử lí và lưu xong,
 * màu các khung video được KHỚP THEO ẢNH TĨNH (khớp histogram từng kênh: luồng xem trước của camera thường lệch màu so với JPEG, vd. giấy trắng
 * ám xanh lục lam), mã hoá MP4 H.264 ~3s với dấu thời gian thật rồi NHÚNG vào chính JPEG theo định dạng Motion Photo
 * (XMP Google: MotionPhoto / MicroVideo, MP4 nối cuối tệp). Chỉ áp dụng cho ảnh thường (không HQ / UP / thiếu sáng / phơi sáng lâu).
 */
object LiveArt {
    const val FPS = 12
    const val BEFORE_MS = 1500L
    const val AFTER_MS = 1500L
    private const val OUT_W = 960
    private const val MAX_FRAMES = 60

    class Frame(val bmp: Bitmap, val t: Long, val rot: Int)

    /** Một đoạn clip đang ghi; [frames] có sau ~AFTER_MS kể từ lúc bấm chụp. */
    class Clip(val rotation: Int) {
        @Volatile var shutterT = 0L
        @Volatile var frames: List<Frame>? = null
        val ready = CountDownLatch(1)
        fun await(timeoutMs: Long): List<Frame>? {
            try { ready.await(timeoutMs, TimeUnit.MILLISECONDS) } catch (_: InterruptedException) {}
            return frames
        }
    }

    /**
     * Vòng đệm khung hình: [onFrame] được gọi từ luồng ImageReader của camera cho mỗi khung YUV; chỉ lấy ~FPS khung/giây, đổi sang
     * bitmap nhỏ đã cắt khung. [active] cho biết Live Art có đang hoạt động không; [rotationNow] là góc xoay ảnh hiện tại.
     */
    class Recorder(private val active: () -> Boolean, private val rotationNow: () -> Int) {
        private val lock = Any()
        private val ring = ArrayList<Frame>()
        private var clip: Clip? = null
        private var collectUntil = 0L
        private var lastT = 0L
        private var yBuf = ByteArray(0)
        private var uBuf = ByteArray(0)
        private var vBuf = ByteArray(0)

        fun reset() {
            synchronized(lock) {
                clearRing()
                clip?.let { it.ready.countDown() }
                clip = null
            }
        }

        private fun clearRing() {
            for (f in ring) try { f.bmp.recycle() } catch (_: Throwable) {}
            ring.clear()
        }

        /** Bấm chụp: trả về clip sẽ có khung hình sau ~1,5s; null nếu Live Art không hoạt động / chưa có khung / đang ghi clip trước. */
        fun shutter(rotation: Int): Clip? = synchronized(lock) {
            if (clip != null || ring.isEmpty() || !active()) return@synchronized null
            val c = Clip(rotation)
            val now = SystemClock.uptimeMillis()
            c.shutterT = now
            clip = c
            collectUntil = now + AFTER_MS
            c
        }

        fun onFrame(img: Image, zoom: Float) {
            if (!active()) {
                synchronized(lock) { if (clip == null && ring.isNotEmpty()) clearRing() }
                return
            }
            val now = SystemClock.uptimeMillis()
            if (now - lastT < 1000L / FPS - 8L) return
            lastT = now
            val rot = rotationNow()
            val bmp = toBitmap(img, zoom, rot) ?: return
            synchronized(lock) {
                ring.add(Frame(bmp, now, rot))
                val c = clip
                if (c == null) {
                    val limit = now - BEFORE_MS - 250L
                    while (ring.isNotEmpty() && (ring[0].t < limit || ring.size > MAX_FRAMES)) ring.removeAt(0).bmp.recycle()
                } else if (now >= collectUntil || ring.size > MAX_FRAMES + 40) {
                    val from = c.shutterT - BEFORE_MS
                    val sel = ArrayList<Frame>()
                    for (f in ring) if (f.t >= from && f.rot == c.rotation) sel.add(f) else f.bmp.recycle()
                    ring.clear()
                    clip = null
                    c.frames = if (sel.size >= 4) sel else { sel.forEach { it.bmp.recycle() }; null }
                    c.ready.countDown()
                }
            }
        }

        /** Cắt YUV theo cùng cách cắt của ảnh chụp (giữa khung, tỉ lệ 65:24 / 24:65 theo góc xoay, chia zoom), thu nhỏ về ~OUT_W, sang ARGB. */
        private fun toBitmap(img: Image, zoom: Float, rot: Int): Bitmap? {
            val w = img.width
            val h = img.height
            val pl = img.planes
            if (pl.size < 3 || w < 64 || h < 64) return null
            val vertical = rot == 90 || rot == 270
            val aspect = if (vertical) 24f / 65f else 65f / 24f
            val z = max(zoom, 1f)
            var cw = w / z
            var ch = cw / aspect
            if (ch > h / z) { ch = h / z; cw = ch * aspect }
            val cl = ((w - cw) / 2f).toInt().coerceAtLeast(0)
            val ct = ((h - ch) / 2f).toInt().coerceAtLeast(0)
            var dw: Int
            var dh: Int
            if (cw >= ch) { dw = min(OUT_W, cw.toInt()); dh = (dw * ch / cw).toInt() }
            else { dh = min(OUT_W, ch.toInt()); dw = (dh * cw / ch).toInt() }
            dw = dw and 1.inv()
            dh = dh and 1.inv()
            if (dw < 32 || dh < 32) return null
            val yp = pl[0]
            val up = pl[1]
            val vp = pl[2]
            yBuf = fill(yBuf, yp.buffer)
            uBuf = fill(uBuf, up.buffer)
            vBuf = fill(vBuf, vp.buffer)
            val rsY = yp.rowStride
            val rsC = up.rowStride
            val psC = up.pixelStride
            val px = IntArray(dw * dh)
            val sx = cw / dw
            val sy = ch / dh
            for (y in 0 until dh) {
                val yy = min(h - 1, ct + ((y + 0.5f) * sy).toInt())
                val rowY = yy * rsY
                val rowC = (yy shr 1) * rsC
                for (x in 0 until dw) {
                    val xx = min(w - 1, cl + ((x + 0.5f) * sx).toInt())
                    val yv = yBuf[rowY + xx].toInt() and 255
                    val ci = rowC + (xx shr 1) * psC
                    val u = (uBuf[ci].toInt() and 255) - 128
                    val v = (vBuf[ci].toInt() and 255) - 128
                    var r = yv + ((1436 * v) shr 10)
                    var g = yv - ((352 * u + 731 * v) shr 10)
                    var b = yv + ((1814 * u) shr 10)
                    if (r < 0) r = 0 else if (r > 255) r = 255
                    if (g < 0) g = 0 else if (g > 255) g = 255
                    if (b < 0) b = 0 else if (b > 255) b = 255
                    px[y * dw + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                }
            }
            val bmp = Bitmap.createBitmap(dw, dh, Bitmap.Config.ARGB_8888)
            bmp.setPixels(px, 0, dw, 0, 0, dw, dh)
            return bmp
        }

        private fun fill(dst: ByteArray, src: java.nio.ByteBuffer): ByteArray {
            val n = src.remaining()
            val d = if (dst.size >= n) dst else ByteArray(n)
            src.get(d, 0, n)
            return d
        }
    }

    // ---------------- nhúng vào ảnh đã lưu ----------------

    /** Khớp màu video theo ảnh tĩnh, mã hoá MP4 rồi nhúng vào JPEG ở [uri] (Motion Photo). Lỗi thì giữ nguyên ảnh tĩnh. */
    fun embed(ctx: Context, uri: Uri, clip: Clip) {
        val frames = clip.await(8_000) ?: return
        var mp4: File? = null
        try {
            val lut = try { buildLut(ctx, uri, frames, clip.shutterT) } catch (_: Throwable) { identityLut() }
            mp4 = File.createTempFile("liveart_", ".mp4", ctx.cacheDir)
            if (!encode(frames, lut, clip.rotation, mp4)) return
            val cr = ctx.contentResolver
            val jpg = cr.openInputStream(uri)?.use { it.readBytes() } ?: return
            val video = mp4.readBytes()
            val stillUs = max(0L, clip.shutterT - frames[0].t) * 1000L
            val merged = buildMotionPhoto(jpg, video, stillUs) ?: return
            cr.openOutputStream(uri, "wt")?.use { it.write(merged) }
        } finally {
            frames.forEach { try { it.bmp.recycle() } catch (_: Throwable) {} }
            mp4?.delete()
        }
    }

    private fun identityLut(): Array<IntArray> = Array(3) { IntArray(256) { it } }

    /**
     * Khớp histogram từng kênh: khung gần lúc bấm chụp (±1) -> ảnh tĩnh đã xử lí. Cho ra bảng tra LUT 3×256 áp cho mọi khung video.
     * Không cần căn thẳng hàng hai ảnh nên không sợ lệch khung / chữ watermark; làm trơn LUT để tránh sọc màu.
     */
    private fun buildLut(ctx: Context, uri: Uri, frames: List<Frame>, shutterT: Long): Array<IntArray> {
        val cr = ctx.contentResolver
        val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bo) }
        if (bo.outWidth <= 0) return identityLut()
        var ss = 1
        while (bo.outWidth / ss > 800) ss *= 2
        val still = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = ss; inPreferredConfig = Bitmap.Config.ARGB_8888 })
        } ?: return identityLut()
        val hs = Array(3) { LongArray(256) }
        val hf = Array(3) { LongArray(256) }
        accumulate(still, hs)
        still.recycle()
        var nearest = 0
        var best = Long.MAX_VALUE
        for (i in frames.indices) {
            val d = abs(frames[i].t - shutterT)
            if (d < best) { best = d; nearest = i }
        }
        for (i in max(0, nearest - 1)..min(frames.size - 1, nearest + 1)) accumulate(frames[i].bmp, hf)
        val lut = Array(3) { IntArray(256) }
        for (c in 0 until 3) {
            val cs = cdf(hs[c])
            val cf = cdf(hf[c])
            var u = 0
            val raw = IntArray(256)
            for (v in 0 until 256) {
                while (u < 255 && cs[u] < cf[v]) u++
                raw[v] = u
            }
            // trơn LUT (trung bình ±3) rồi bảo đảm đơn điệu
            var prev = 0
            for (v in 0 until 256) {
                var s = 0
                var n = 0
                for (k in -3..3) { val j = v + k; if (j in 0..255) { s += raw[j]; n++ } }
                val o = max(prev, s / n)
                lut[c][v] = o.coerceIn(0, 255)
                prev = lut[c][v]
            }
        }
        return lut
    }

    private fun accumulate(b: Bitmap, h: Array<LongArray>) {
        val w = b.width
        val ht = b.height
        val px = IntArray(w * ht)
        b.getPixels(px, 0, w, 0, 0, w, ht)
        for (c in px) {
            h[0][(c shr 16) and 255]++
            h[1][(c shr 8) and 255]++
            h[2][c and 255]++
        }
    }

    private fun cdf(h: LongArray): DoubleArray {
        var total = 0L
        for (v in h) total += v
        val out = DoubleArray(256)
        var acc = 0L
        for (i in 0 until 256) { acc += h[i]; out[i] = if (total > 0) acc.toDouble() / total else i / 255.0 }
        return out
    }

    /** MP4 H.264 từ các khung ARGB (áp [lut]); dấu thời gian = thời điểm thật của từng khung; màu YUV BT.601 giới hạn, ghi rõ trong định dạng. */
    private fun encode(frames: List<Frame>, lut: Array<IntArray>, rotation: Int, out: File): Boolean {
        val w = frames[0].bmp.width
        val h = frames[0].bmp.height
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, (w * h * FPS * 0.18).toInt().coerceIn(3_000_000, 10_000_000))
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        if (Build.VERSION.SDK_INT >= 24) {
            fmt.setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT601_NTSC)
            fmt.setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
            fmt.setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_SDR_VIDEO)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        var muxer: MediaMuxer? = null
        var ok = false
        try {
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            enc.start()
            val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            muxer = mux
            mux.setOrientationHint(rotation)
            var track = -1
            var started = false
            val info = MediaCodec.BufferInfo()

            fun drain(end: Boolean) {
                var tries = 0
                while (true) {
                    val i = enc.dequeueOutputBuffer(info, if (end) 10_000L else 0L)
                    if (i == MediaCodec.INFO_TRY_AGAIN_LATER) {
                        if (!end) return
                        if (++tries > 300) return
                    } else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = mux.addTrack(enc.outputFormat)
                        mux.start()
                        started = true
                    } else if (i >= 0) {
                        val buf = enc.getOutputBuffer(i)
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                        if (info.size > 0 && started && buf != null) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            mux.writeSampleData(track, buf, info)
                        }
                        enc.releaseOutputBuffer(i, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                    }
                }
            }

            val px = IntArray(w * h)
            val rr = IntArray(w * h)
            val gg = IntArray(w * h)
            val bb = IntArray(w * h)
            val t0 = frames[0].t
            var lastPts = 0L
            for (k in frames.indices) {
                frames[k].bmp.getPixels(px, 0, w, 0, 0, w, h)
                for (i in px.indices) {
                    val c = px[i]
                    rr[i] = lut[0][(c shr 16) and 255]
                    gg[i] = lut[1][(c shr 8) and 255]
                    bb[i] = lut[2][c and 255]
                }
                var idx = -1
                var tries = 0
                while (idx < 0) {
                    idx = enc.dequeueInputBuffer(10_000L)
                    drain(false)
                    if (idx < 0 && ++tries > 300) return false
                }
                val img = enc.getInputImage(idx) ?: return false
                fillImage(img, rr, gg, bb, w, h)
                lastPts = (frames[k].t - t0) * 1000L
                enc.queueInputBuffer(idx, 0, w * h * 3 / 2, lastPts, 0)
                drain(false)
            }
            var idx = -1
            var tries = 0
            while (idx < 0) {
                idx = enc.dequeueInputBuffer(10_000L)
                if (idx < 0 && ++tries > 300) return false
            }
            enc.queueInputBuffer(idx, 0, 0, lastPts + 1_000_000L / FPS, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            drain(true)
            if (started) { mux.stop(); ok = true }
        } finally {
            try { enc.stop() } catch (_: Throwable) {}
            try { enc.release() } catch (_: Throwable) {}
            try { muxer?.release() } catch (_: Throwable) {}
        }
        return ok
    }

    /** ARGB đã qua LUT -> mặt phẳng Y / U / V của Image đầu vào bộ mã hoá (BT.601 giới hạn, chroma lấy trung bình khối 2×2). */
    private fun fillImage(img: Image, rr: IntArray, gg: IntArray, bb: IntArray, w: Int, h: Int) {
        val pl = img.planes
        val yb = pl[0].buffer
        val rsY = pl[0].rowStride
        val ub = pl[1].buffer
        val vb = pl[2].buffer
        val rsU = pl[1].rowStride
        val psU = pl[1].pixelStride
        val rsV = pl[2].rowStride
        val psV = pl[2].pixelStride
        for (y in 0 until h) {
            val o = y * w
            val base = y * rsY
            for (x in 0 until w) {
                val r = rr[o + x]
                val g = gg[o + x]
                val b = bb[o + x]
                yb.put(base + x, ((((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).coerceIn(16, 235)).toByte())
            }
        }
        for (y in 0 until h / 2) {
            for (x in 0 until w / 2) {
                val i0 = (2 * y) * w + 2 * x
                val i1 = i0 + w
                val r = (rr[i0] + rr[i0 + 1] + rr[i1] + rr[i1 + 1]) shr 2
                val g = (gg[i0] + gg[i0 + 1] + gg[i1] + gg[i1 + 1]) shr 2
                val b = (bb[i0] + bb[i0 + 1] + bb[i1] + bb[i1 + 1]) shr 2
                ub.put(y * rsU + x * psU, ((((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).coerceIn(16, 240)).toByte())
                vb.put(y * rsV + x * psV, ((((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).coerceIn(16, 240)).toByte())
            }
        }
    }

    private val XMP_HEADER = "http://ns.adobe.com/xap/1.0/\u0000".toByteArray(Charsets.ISO_8859_1)

    /** Ghép JPEG + XMP Motion Photo (cả khai báo v1 "MicroVideo" lẫn v2 "Container:Directory") + MP4 nối cuối. */
    fun buildMotionPhoto(jpg: ByteArray, mp4: ByteArray, stillUs: Long): ByteArray? {
        if (jpg.size < 4 || (jpg[0].toInt() and 255) != 0xFF || (jpg[1].toInt() and 255) != 0xD8) return null
        val xml = """<?xpacket begin="" id="W5M0MpCehiHzreSzNTczkc9d"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="XPAN Live Art">
 <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <rdf:Description rdf:about=""
    xmlns:GCamera="http://ns.google.com/photos/1.0/camera/"
    xmlns:Container="http://ns.google.com/photos/1.0/container/"
    xmlns:Item="http://ns.google.com/photos/1.0/container/item/"
    GCamera:MotionPhoto="1"
    GCamera:MotionPhotoVersion="1"
    GCamera:MotionPhotoPresentationTimestampUs="$stillUs"
    GCamera:MicroVideo="1"
    GCamera:MicroVideoVersion="1"
    GCamera:MicroVideoOffset="${mp4.size}"
    GCamera:MicroVideoPresentationTimestampUs="$stillUs">
   <Container:Directory>
    <rdf:Seq>
     <rdf:li rdf:parseType="Resource">
      <Container:Item Item:Mime="image/jpeg" Item:Semantic="Primary" Item:Length="0" Item:Padding="0"/>
     </rdf:li>
     <rdf:li rdf:parseType="Resource">
      <Container:Item Item:Mime="video/mp4" Item:Semantic="MotionPhoto" Item:Length="${mp4.size}" Item:Padding="0"/>
     </rdf:li>
    </rdf:Seq>
   </Container:Directory>
  </rdf:Description>
 </rdf:RDF>
</x:xmpmeta>
<?xpacket end="w"?>""".toByteArray(Charsets.UTF_8)
        val segLen = 2 + XMP_HEADER.size + xml.size
        if (segLen > 65535) return null
        val out = ByteArrayOutputStream(jpg.size + mp4.size + xml.size + 64)
        out.write(0xFF); out.write(0xD8)
        var pos = 2
        var wrote = false
        fun writeXmp() {
            out.write(0xFF); out.write(0xE1)
            out.write(segLen shr 8); out.write(segLen and 255)
            out.write(XMP_HEADER); out.write(xml)
            wrote = true
        }
        // duyệt các đoạn đầu tệp: giữ nguyên, bỏ XMP cũ (nếu có), chèn XMP mới ngay sau APP0 / APP1(Exif)
        while (pos + 4 <= jpg.size && (jpg[pos].toInt() and 255) == 0xFF) {
            val marker = jpg[pos + 1].toInt() and 255
            if (marker == 0xDA || marker == 0xD9) break
            val len = ((jpg[pos + 2].toInt() and 255) shl 8) or (jpg[pos + 3].toInt() and 255)
            val end = pos + 2 + len
            if (len < 2 || end > jpg.size) return null
            val isXmp = marker == 0xE1 && len - 2 >= XMP_HEADER.size && regionEquals(jpg, pos + 4, XMP_HEADER)
            val isHead = marker == 0xE0 || (marker == 0xE1 && !isXmp)
            if (!isHead && !wrote) writeXmp()
            if (!isXmp) out.write(jpg, pos, end - pos)
            pos = end
        }
        if (!wrote) writeXmp()
        out.write(jpg, pos, jpg.size - pos)
        out.write(mp4)
        return out.toByteArray()
    }

    private fun regionEquals(a: ByteArray, off: Int, b: ByteArray): Boolean {
        if (off + b.size > a.size) return false
        for (i in b.indices) if (a[off + i] != b[i]) return false
        return true
    }
}
