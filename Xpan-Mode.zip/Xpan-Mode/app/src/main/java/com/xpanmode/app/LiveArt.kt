package com.xpanmode.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Live Art: ảnh động như Live Photo. Khi bật, app liên tục giữ ~1,5s khung ngắm gần nhất (bản nhỏ); bấm chụp thì giữ thêm ~1,5s nữa,
 * mã hoá đoạn ~3s thành MP4 (H.264, đã áp bộ lọc xem trước) rồi NHÚNG vào chính tệp JPEG đã lưu theo định dạng Motion Photo
 * (XMP Google: MotionPhoto / MicroVideo + MP4 nối cuối tệp) nên thư viện ảnh hỗ trợ sẽ phát được như ảnh động.
 * Chỉ áp dụng cho ảnh thường (không HQ / UP / thiếu sáng / phơi sáng lâu).
 */
object LiveArt {
    const val FPS = 12
    const val BEFORE_MS = 1500L
    const val AFTER_MS = 1500L
    private const val MAX_W = 960

    /** Một đoạn clip đang ghi/mã hoá; [file] có sau ~AFTER_MS + thời gian mã hoá. */
    class Clip(val rotation: Int) {
        @Volatile var file: File? = null
        /** Thời điểm bấm chụp tính từ đầu clip (µs), dùng làm khung "ảnh tĩnh" của Motion Photo. */
        @Volatile var stillUs: Long = BEFORE_MS * 1000
        val done = CountDownLatch(1)
        fun await(timeoutMs: Long): File? {
            try { done.await(timeoutMs, TimeUnit.MILLISECONDS) } catch (_: InterruptedException) {}
            return file
        }
    }

    /**
     * Bộ ghi vòng: mỗi 1/FPS giây lấy một khung từ khung ngắm (grab(w, h) trả bitmap đã áp biến đổi/zoom, đúng chiều hiển thị).
     * Phải chạy trên luồng chính (TextureView.getBitmap).
     */
    class Recorder(
        private val cacheDir: File,
        private val active: () -> Boolean,
        private val viewSize: () -> Pair<Int, Int>,
        private val grab: (Int, Int) -> Bitmap?,
        private val matrix: () -> ColorMatrix
    ) {
        private class Frame(val bmp: Bitmap, val t: Long)

        private val main = Handler(Looper.getMainLooper())
        private val ring = ArrayList<Frame>()
        private var running = false
        private var clip: Clip? = null
        private var shutterT = 0L
        private var collectUntil = 0L
        private val tick = object : Runnable {
            override fun run() {
                if (!running) return
                try { step() } catch (_: Throwable) {}
                main.postDelayed(this, 1000L / FPS)
            }
        }

        fun start() {
            if (running) return
            running = true
            main.post(tick)
        }

        fun stop() {
            running = false
            main.removeCallbacks(tick)
            clear()
            clip = null
        }

        private fun clear() {
            for (f in ring) try { f.bmp.recycle() } catch (_: Throwable) {}
            ring.clear()
        }

        /** Bấm chụp: trả về clip sẽ có file sau ~1,5s + mã hoá; null nếu Live Art không hoạt động / đang ghi clip trước. */
        fun shutter(rotation: Int): Clip? {
            if (!running || clip != null || !active() || ring.isEmpty()) return null
            val c = Clip(rotation)
            clip = c
            shutterT = SystemClock.uptimeMillis()
            collectUntil = shutterT + AFTER_MS
            return c
        }

        private fun grabFrame(): Bitmap? {
            val (vw, vh) = viewSize()
            if (vw <= 0 || vh <= 0) return null
            var dw = min(MAX_W, vw)
            var dh = (vh.toLong() * dw / vw).toInt()
            dw = dw and 1.inv()
            dh = dh and 1.inv()
            if (dw < 16 || dh < 16) return null
            return grab(dw, dh)
        }

        private fun min(a: Int, b: Int) = if (a < b) a else b

        private fun step() {
            val c = clip
            if (c == null && !active()) {          // chế độ khác đang bật: bỏ vòng đệm để nhả bộ nhớ
                if (ring.isNotEmpty()) clear()
                return
            }
            val now = SystemClock.uptimeMillis()
            val b = grabFrame()
            if (b != null) ring.add(Frame(b, now))
            if (c == null) {
                // chỉ giữ ~BEFORE_MS + một chút
                val limit = now - BEFORE_MS - 250L
                while (ring.isNotEmpty() && ring[0].t < limit) ring.removeAt(0).bmp.recycle()
            } else if (now >= collectUntil) {
                val from = shutterT - BEFORE_MS
                val sel = ArrayList<Frame>()
                for (f in ring) if (f.t >= from) sel.add(f) else f.bmp.recycle()
                ring.clear()
                clip = null
                if (sel.size < 4) { sel.forEach { it.bmp.recycle() }; c.done.countDown(); return }
                c.stillUs = ((shutterT - sel[0].t).coerceAtLeast(0L)) * 1000L
                val cm = matrix()
                val ts = LongArray(sel.size) { sel[it].t }
                val bmps = sel.map { it.bmp }
                Thread { try { encode(bmps, ts, c, cm) } catch (_: Throwable) {} finally { bmps.forEach { try { it.recycle() } catch (_: Throwable) {} }; c.done.countDown() } }.start()
            }
        }

        private fun encode(bmps: List<Bitmap>, ts: LongArray, clip: Clip, cm: ColorMatrix) {
            val w = bmps[0].width
            val h = bmps[0].height
            val out = File.createTempFile("liveart_", ".mp4", cacheDir)
            val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
            fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            fmt.setInteger(MediaFormat.KEY_BIT_RATE, (w * h * FPS * 0.16).toInt().coerceIn(2_500_000, 9_000_000))
            fmt.setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            var muxer: MediaMuxer? = null
            var surf: android.view.Surface? = null
            try {
                enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                val inSurf = enc.createInputSurface()
                surf = inSurf
                enc.start()
                val mux = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                muxer = mux
                mux.setOrientationHint(clip.rotation)
                var track = -1
                var started = false
                var baseUs = -1L
                val info = MediaCodec.BufferInfo()
                val paint = Paint(Paint.FILTER_BITMAP_FLAG)
                paint.colorFilter = ColorMatrixColorFilter(cm)

                fun drain(end: Boolean) {
                    var tries = 0
                    while (true) {
                        val i = enc.dequeueOutputBuffer(info, if (end) 10_000L else 0L)
                        if (i == MediaCodec.INFO_TRY_AGAIN_LATER) {
                            if (!end) return
                            if (++tries > 300) return
                        } else if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                            track = mux.addTrack(enc.outputFormat)
                            mux.start()
                            started = true
                        } else if (i >= 0) {
                            val buf = enc.getOutputBuffer(i)
                            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                            if (info.size > 0 && started && buf != null) {
                                if (baseUs < 0) baseUs = info.presentationTimeUs
                                info.presentationTimeUs = (info.presentationTimeUs - baseUs).coerceAtLeast(0L)
                                buf.position(info.offset)
                                buf.limit(info.offset + info.size)
                                mux.writeSampleData(track, buf, info)
                            }
                            enc.releaseOutputBuffer(i, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
                        }
                    }
                }

                // đẩy khung vào bề mặt đầu vào của bộ mã hoá THEO NHỊP THẬT (thời điểm đẩy = dấu thời gian của khung) nên video đúng tốc độ gốc
                for (k in bmps.indices) {
                    val c: Canvas = try { inSurf.lockCanvas(null) } catch (_: Throwable) { inSurf.lockHardwareCanvas() }
                    c.drawBitmap(bmps[k], 0f, 0f, paint)
                    inSurf.unlockCanvasAndPost(c)
                    drain(false)
                    if (k + 1 < bmps.size) {
                        val gap = (ts[k + 1] - ts[k]).coerceIn(15L, 220L)
                        Thread.sleep(gap)
                    }
                }
                enc.signalEndOfInputStream()
                drain(true)
                if (started) { mux.stop(); clip.file = out } else out.delete()
            } finally {
                try { enc.stop() } catch (_: Throwable) {}
                try { enc.release() } catch (_: Throwable) {}
                try { surf?.release() } catch (_: Throwable) {}
                try { muxer?.release() } catch (_: Throwable) {}
                if (clip.file == null) out.delete()
            }
        }
    }

    /** Nhúng MP4 của [clip] vào tệp JPEG đã lưu ở [uri] (Motion Photo). Lỗi thì giữ nguyên ảnh tĩnh. */
    fun embed(ctx: Context, uri: Uri, clip: Clip) {
        val mp4 = clip.await(20_000) ?: return
        try {
            val cr = ctx.contentResolver
            val jpg = cr.openInputStream(uri)?.use { it.readBytes() } ?: return
            val video = mp4.readBytes()
            val merged = buildMotionPhoto(jpg, video, clip.stillUs) ?: return
            cr.openOutputStream(uri, "wt")?.use { it.write(merged) }
        } finally {
            mp4.delete()
        }
    }

    private val XMP_HEADER = "http://ns.adobe.com/xap/1.0/\u0000".toByteArray(Charsets.ISO_8859_1)

    /** Ghép JPEG + XMP Motion Photo (cả khai báo v1 "MicroVideo" lẫn v2 "Container:Directory") + MP4 nối cuối. */
    fun buildMotionPhoto(jpg: ByteArray, mp4: ByteArray, stillUs: Long): ByteArray? {
        if (jpg.size < 4 || (jpg[0].toInt() and 255) != 0xFF || (jpg[1].toInt() and 255) != 0xD8) return null
        val xml = """<?xpacket begin="" id="W5M0MpCehiHzreSzNTczkc9d"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/" x:xmptk="XPAN Live Art">
 <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
  <rdf:Description rdf:about=""
    xmlns:GCamera="http://ns.google.com/photos/1.0/camera/"
    xmlns:Container="http://ns.google.com/photos/1.0/container/"
    xmlns:Item="http://ns.google.com/photos/1.0/container/item/"
    GCamera:MotionPhoto="1"
    GCamera:MotionPhotoVersion="1"
    GCamera:MotionPhotoPresentationTimestampUs="$stillUs"
    GCamera:MicroVideo="1"
    GCamera:MicroVideoVersion="1"
    GCamera:MicroVideoOffset="${mp4.size}"
    GCamera:MicroVideoPresentationTimestampUs="$stillUs">
   <Container:Directory>
    <rdf:Seq>
     <rdf:li rdf:parseType="Resource">
      <Container:Item Item:Mime="image/jpeg" Item:Semantic="Primary" Item:Length="0" Item:Padding="0"/>
     </rdf:li>
     <rdf:li rdf:parseType="Resource">
      <Container:Item Item:Mime="video/mp4" Item:Semantic="MotionPhoto" Item:Length="${mp4.size}" Item:Padding="0"/>
     </rdf:li>
    </rdf:Seq>
   </Container:Directory>
  </rdf:Description>
 </rdf:RDF>
</x:xmpmeta>
<?xpacket end="w"?>""".toByteArray(Charsets.UTF_8)
        val segLen = 2 + XMP_HEADER.size + xml.size
        if (segLen > 65535) return null
        val out = ByteArrayOutputStream(jpg.size + mp4.size + xml.size + 64)
        out.write(0xFF); out.write(0xD8)
        var pos = 2
        var wrote = false
        fun writeXmp() {
            out.write(0xFF); out.write(0xE1)
            out.write(segLen shr 8); out.write(segLen and 255)
            out.write(XMP_HEADER); out.write(xml)
            wrote = true
        }
        // duyệt các đoạn đầu tệp: giữ nguyên, bỏ XMP cũ (nếu có), chèn XMP mới ngay sau APP0 / APP1(Exif)
        while (pos + 4 <= jpg.size && (jpg[pos].toInt() and 255) == 0xFF) {
            val marker = jpg[pos + 1].toInt() and 255
            if (marker == 0xDA || marker == 0xD9) break
            val len = ((jpg[pos + 2].toInt() and 255) shl 8) or (jpg[pos + 3].toInt() and 255)
            val end = pos + 2 + len
            if (len < 2 || end > jpg.size) return null
            val isXmp = marker == 0xE1 && len - 2 >= XMP_HEADER.size && regionEquals(jpg, pos + 4, XMP_HEADER)
            val isHead = marker == 0xE0 || (marker == 0xE1 && !isXmp)
            if (!isHead && !wrote) writeXmp()
            if (!isXmp) out.write(jpg, pos, end - pos)
            pos = end
        }
        if (!wrote) writeXmp()
        out.write(jpg, pos, jpg.size - pos)
        out.write(mp4)
        return out.toByteArray()
    }

    private fun regionEquals(a: ByteArray, off: Int, b: ByteArray): Boolean {
        if (off + b.size > a.size) return false
        for (i in b.indices) if (a[off + i] != b[i]) return false
        return true
    }
}
