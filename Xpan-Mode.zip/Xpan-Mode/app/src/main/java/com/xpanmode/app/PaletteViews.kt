package com.xpanmode.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlin.math.abs

/** Hai tab ở đáy ngăn kéo: "Bộ lọc" | "Bảng màu". */
class DrawerTabsView(ctx: Context) : View(ctx) {
    var selected = 0
        set(v) { field = v; invalidate() }
    var onSelect: ((Int) -> Unit)? = null

    private val dn = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labels = arrayOf("Bộ lọc", "Bảng màu")
    private val rect = RectF()

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val light = Theme.light
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h / 2f
        p.style = Paint.Style.FILL
        p.color = if (light) 0x14000000 else 0x1FFFFFFF
        rect.set(0f, 0f, w, h)
        c.drawRoundRect(rect, r, r, p)
        val segW = w / 2f
        // ô đang chọn
        rect.set(selected * segW + 2f * dn, 2f * dn, (selected + 1) * segW - 2f * dn, h - 2f * dn)
        p.color = if (light) 0xFFFFFFFF.toInt() else 0xFF3A3A3F.toInt()
        c.drawRoundRect(rect, r, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * dn
        p.color = ORANGE
        c.drawRoundRect(rect, r, r, p)
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.textSize = 11.5f * dn
        val fm = p.fontMetrics
        for (i in 0..1) {
            val sel = i == selected
            p.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            p.color = if (sel) ORANGE else (if (light) 0xFF55555A.toInt() else 0xCCFFFFFF.toInt())
            c.drawText(labels[i], segW * i + segW / 2f, h / 2f - (fm.ascent + fm.descent) / 2f, p)
        }
        p.typeface = Typeface.DEFAULT
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val i = if (e.x < width / 2f) 0 else 1
            if (i != selected) {
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                selected = i
                onSelect?.invoke(i)
            }
        }
        return true
    }
}

/** Nhãn chữ nhỏ, màu theo giao diện sáng/tối lúc vẽ. */
class PaletteLabelView(ctx: Context, var text: String, private val bold: Boolean = false, private val sizeDp: Float = 10f) : View(ctx) {
    var align = Paint.Align.LEFT
        set(v) { field = v; invalidate() }
    var dim = false
        set(v) { field = v; invalidate() }
    private val dn = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(t: String) { text = t; invalidate() }

    override fun onDraw(c: Canvas) {
        p.textSize = sizeDp * dn
        p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        p.textAlign = align
        val a = if (dim) 0x55 else 0xB0
        p.color = (a shl 24) or (if (Theme.light) 0x1B1B1E else 0xFFFFFF)
        val fm = p.fontMetrics
        val x = when (align) { Paint.Align.CENTER -> width / 2f; Paint.Align.RIGHT -> width.toFloat(); else -> 0f }
        c.drawText(text, x, height / 2f - (fm.ascent + fm.descent) / 2f, p)
    }
}

/**
 * Bảng chạm hai chiều: trục ngang = Color (nhạt ↔ đậm), trục dọc = Tone (sáng ở trên, tối ở dưới).
 * Chạm hai lần liên tiếp để về giữa (0, 0). Kéo gần giữa thì tự hít vào 0.
 */
class PalettePadView(ctx: Context) : View(ctx) {
    var color = 0
        set(v) { field = v.coerceIn(-100, 100); invalidate() }
    var tone = 0
        set(v) { field = v.coerceIn(-100, 100); invalidate() }
    /** Màu đại diện của kiểu đang chọn, tô ở mép phải bảng. */
    var accent = 0xFFE6E6E6.toInt()
        set(v) { field = v; invalidate() }
    var onChange: ((color: Int, tone: Int) -> Unit)? = null

    private val dn = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private val pad get() = 12f * dn
    private var lastTap = 0L
    private var downX = 0f
    private var downY = 0f
    private var moved = false

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 10f * dn
        box.set(0f, 0f, w, h)
        // nền: trái xám nhạt màu → phải đậm màu của kiểu; phủ thêm dải sáng (trên) / tối (dưới)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, w, 0f, 0xFF6A6A70.toInt(), accent, Shader.TileMode.CLAMP)
        c.drawRoundRect(box, r, r, p)
        p.shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(0x77FFFFFF, 0x00000000, 0xAA000000.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(box, r, r, p)
        p.shader = null
        // đường chữ thập giữa
        p.color = 0x55FFFFFF
        p.strokeWidth = 1f * dn
        c.drawLine(w / 2f, pad, w / 2f, h - pad, p)
        c.drawLine(pad, h / 2f, w - pad, h / 2f, p)
        // viền
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * dn
        p.color = 0x66FFFFFF
        c.drawRoundRect(0.5f * dn, 0.5f * dn, w - 0.5f * dn, h - 0.5f * dn, r, r, p)
        // nhãn bốn cạnh
        p.style = Paint.Style.FILL
        p.textSize = 8f * dn
        p.typeface = Typeface.DEFAULT
        p.color = 0xCCFFFFFF.toInt()
        p.textAlign = Paint.Align.CENTER
        val fm = p.fontMetrics
        val ty = -(fm.ascent + fm.descent) / 2f
        c.drawText("Sáng", w / 2f, 7f * dn + ty, p)
        c.drawText("Tối", w / 2f, h - 7f * dn + ty, p)
        p.textAlign = Paint.Align.LEFT
        c.drawText("Nhạt", 5f * dn, h / 2f - 8f * dn + ty, p)
        p.textAlign = Paint.Align.RIGHT
        c.drawText("Đậm", w - 5f * dn, h / 2f - 8f * dn + ty, p)
        // núm
        val x = pad + (w - 2f * pad) * (color + 100) / 200f
        val y = pad + (h - 2f * pad) * (100 - tone) / 200f
        p.color = 0x66000000
        c.drawCircle(x, y + 1f * dn, 10f * dn, p)
        p.color = Color.WHITE
        c.drawCircle(x, y, 9.5f * dn, p)
        p.color = ORANGE
        c.drawCircle(x, y, 4f * dn, p)
    }

    private fun setFrom(x: Float, y: Float) {
        val w = (width - 2f * pad).coerceAtLeast(1f)
        val h = (height - 2f * pad).coerceAtLeast(1f)
        var cc = Math.round(((x - pad) / w).coerceIn(0f, 1f) * 200f) - 100
        var tt = 100 - Math.round(((y - pad) / h).coerceIn(0f, 1f) * 200f)
        if (abs(cc) <= 4) cc = 0
        if (abs(tt) <= 4) tt = 0
        if (cc != color || tt != tone) {
            val crossed = (cc == 0 && color != 0) || (tt == 0 && tone != 0)
            color = cc; tone = tt
            if (crossed) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onChange?.invoke(cc, tt)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x; downY = e.y; moved = false
                setFrom(e.x, e.y)
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(e.x - downX) > 6f * dn || abs(e.y - downY) > 6f * dn) moved = true
                setFrom(e.x, e.y)
            }
            MotionEvent.ACTION_UP -> {
                val now = e.eventTime
                if (!moved && now - lastTap < 320) {
                    // chạm đúp: về giữa
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    if (color != 0 || tone != 0) { color = 0; tone = 0; onChange?.invoke(0, 0) }
                    lastTap = 0
                } else lastTap = if (moved) 0 else now
            }
        }
        return true
    }
}

/** Ô một kiểu bảng màu trong danh sách. */
class PaletteTileView(ctx: Context, private val style: PaletteStyle) : View(ctx) {
    var selectedItem = false
        set(v) { field = v; invalidate() }

    private val dn = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = 3f * dn
        box.set(m, m, w - m, h - m)
        val r = 9f * dn
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, box.top, 0f, box.bottom, 0xFF3A3A3F.toInt(), 0xFF111113.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(box, r, r, p)
        p.shader = null
        // dải màu đại diện bên trái
        val sw = 5f * dn
        p.shader = LinearGradient(0f, box.top + 6f * dn, 0f, box.bottom - 6f * dn, style.accent[0], style.accent[1], Shader.TileMode.CLAMP)
        c.drawRoundRect(box.left + 7f * dn, box.top + 7f * dn, box.left + 7f * dn + sw, box.bottom - 7f * dn, sw / 2f, sw / 2f, p)
        p.shader = null
        // tên
        val tx = box.left + 7f * dn + sw + 8f * dn
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.DEFAULT_BOLD
        p.color = Color.WHITE
        p.textSize = 11.5f * dn
        val maxW = box.right - tx - 4f * dn
        while (p.measureText(style.name) > maxW && p.textSize > 8f * dn) p.textSize -= 0.5f * dn
        val fm = p.fontMetrics
        c.drawText(style.name, tx, box.centerY() - 2f * dn, p)
        p.typeface = Typeface.DEFAULT
        p.color = if (selectedItem) ORANGE else 0x99FFFFFF.toInt()
        p.textSize = 9f * dn
        while (p.measureText(style.vi) > maxW && p.textSize > 7f * dn) p.textSize -= 0.5f * dn
        c.drawText(style.vi, tx, box.centerY() + 11f * dn, p)
        if (selectedItem) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f * dn
            p.color = ORANGE
            c.drawRoundRect(box.left - 1f * dn, box.top - 1f * dn, box.right + 1f * dn, box.bottom + 1f * dn, r + 1f * dn, r + 1f * dn, p)
            p.style = Paint.Style.FILL
        }
    }
}

/**
 * Nội dung tab "Bảng màu": danh sách kiểu (cuộn) ở trên; dưới là bảng chạm Tone × Color và thanh Palette (cường độ).
 * Ba thông số bằng 0 → Standard.
 */
class PalettePanel(ctx: Context) : LinearLayout(ctx) {
    var onStyle: ((Int) -> Unit)? = null
    var onPad: ((color: Int, tone: Int) -> Unit)? = null
    var onStrength: ((Int) -> Unit)? = null

    private val dn = resources.displayMetrics.density
    private val list = ScrollView(ctx)
    private val col = LinearLayout(ctx)
    private val tiles = ArrayList<PaletteTileView>()
    private val pad = PalettePadView(ctx)
    private val seek = SlimSeek(ctx)
    private val seekLabel = PaletteLabelView(ctx, "Palette", bold = true, sizeDp = 10f)
    private val seekValue = PaletteLabelView(ctx, "0", bold = false, sizeDp = 10f)
    private var sel = PaletteSel()

    init {
        orientation = LinearLayout.VERTICAL
        isClickable = true       // chặn chạm lọt xuống khay bộ lọc nằm phía dưới
        list.isVerticalScrollBarEnabled = false
        list.overScrollMode = View.OVER_SCROLL_NEVER
        list.isVerticalFadingEdgeEnabled = false
        col.orientation = LinearLayout.VERTICAL
        list.addView(col)

        var lastGroup = -1
        PaletteStyle.all.forEachIndexed { i, st ->
            if (st.group != lastGroup && i > 0) {
                lastGroup = st.group
                col.addView(PaletteLabelView(ctx, if (st.group == 0) "TÔNG DA" else "CẢM XÚC", bold = true, sizeDp = 9f),
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (22f * dn).toInt()).also { it.leftMargin = (6f * dn).toInt() })
            }
            val t = PaletteTileView(ctx, st)
            t.setOnClickListener { performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK); onStyle?.invoke(i) }
            tiles.add(t)
            col.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (44f * dn).toInt()))
            if (i == 0) {
                // nhóm Undertones bắt đầu ngay sau Standard
                lastGroup = 0
                col.addView(PaletteLabelView(ctx, "TÔNG DA", bold = true, sizeDp = 9f),
                    LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (22f * dn).toInt()).also { it.leftMargin = (6f * dn).toInt() })
            }
        }
        addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        addView(pad, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (112f * dn).toInt()).also {
            it.topMargin = (6f * dn).toInt(); it.leftMargin = (4f * dn).toInt(); it.rightMargin = (4f * dn).toInt()
        })

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        seekValue.align = Paint.Align.RIGHT
        row.addView(seekLabel, LinearLayout.LayoutParams(0, (22f * dn).toInt(), 1f))
        row.addView(seekValue, LinearLayout.LayoutParams(0, (22f * dn).toInt(), 1f))
        addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (22f * dn).toInt()).also { it.topMargin = (4f * dn).toInt(); it.leftMargin = (8f * dn).toInt(); it.rightMargin = (8f * dn).toInt() })
        seek.max = 100
        seek.origin = 0
        addView(seek, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (30f * dn).toInt()))

        pad.onChange = { c, t -> sel = sel.copy(color = c, tone = t); onPad?.invoke(c, t) }
        seek.onUser = { v -> sel = sel.copy(strength = v); seekValue.set(v.toString()); onStrength?.invoke(v) }
    }

    /** Cập nhật giao diện theo lựa chọn hiện tại (không phát lại sự kiện). */
    fun setState(s: PaletteSel) {
        sel = s
        tiles.forEachIndexed { i, t -> t.selectedItem = i == s.style }
        val st = PaletteStyle.all[s.style.coerceIn(0, PaletteStyle.all.size - 1)]
        pad.accent = st.accent[0]
        pad.color = s.color
        pad.tone = s.tone
        seek.progress = s.strength
        seekValue.set(s.strength.toString())
        // Standard không có hiệu ứng riêng nên thanh cường độ chỉ để trang trí
        val none = s.style == 0
        seek.alpha = if (none) 0.35f else 1f
        seekLabel.dim = none
        seekValue.dim = none
    }

    /** Cuộn danh sách tới kiểu đang chọn. */
    fun scrollToSelected() {
        val t = tiles.getOrNull(sel.style) ?: return
        list.post { list.scrollTo(0, (t.top - 40f * dn).toInt().coerceAtLeast(0)) }
    }
}
