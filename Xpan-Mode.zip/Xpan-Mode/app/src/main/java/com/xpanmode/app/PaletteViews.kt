package com.xpanmode.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RenderEffect
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Build
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Nút tròn mũi tên "<": đóng ngăn kéo bảng màu. */
class BackButtonView(ctx: Context) : View(ctx) {
    private val dn = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    init { isClickable = true; visibility = GONE }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - 1f * dn
        val light = Theme.light
        p.style = Paint.Style.FILL
        p.color = if (light) 0xE6FFFFFF.toInt() else 0xCC2A2A2E.toInt()
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * dn
        p.color = if (light) 0x33000000 else 0x33FFFFFF
        c.drawCircle(cx, cy, r, p)
        p.strokeWidth = 2.2f * dn
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = if (light) 0xFF1B1B1E.toInt() else Color.WHITE
        path.reset()
        path.moveTo(cx + r * 0.14f, cy - r * 0.36f)
        path.lineTo(cx - r * 0.18f, cy)
        path.lineTo(cx + r * 0.14f, cy + r * 0.36f)
        c.drawPath(path, p)
        p.strokeCap = Paint.Cap.BUTT
        p.style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                animate().cancel()
                animate().scaleX(0.86f).scaleY(0.86f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3.5f)).start()
        }
        return super.onTouchEvent(e)
    }
}

/** Nhãn chữ nhỏ, màu theo giao diện sáng/tối lúc vẽ. */
class PaletteLabelView(ctx: Context, var text: String, private val bold: Boolean = false, private val sizeDp: Float = 10f) : View(ctx) {
    var align = Paint.Align.LEFT
        set(v) { field = v; invalidate() }
    var dim = false
        set(v) { field = v; invalidate() }
    private val dn = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun set(t: String) { text = t; invalidate() }

    override fun onDraw(c: Canvas) {
        p.textSize = sizeDp * dn
        p.typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        p.textAlign = align
        val a = if (dim) 0x55 else 0xB0
        p.color = (a shl 24) or (if (Theme.light) 0x1B1B1E else 0xFFFFFF)
        val fm = p.fontMetrics
        val x = when (align) { Paint.Align.CENTER -> width / 2f; Paint.Align.RIGHT -> width.toFloat(); else -> 0f }
        c.drawText(text, x, height / 2f - (fm.ascent + fm.descent) / 2f, p)
    }
}

/**
 * Bảng chạm hai chiều dạng lưới chấm: trục ngang = Color (nhạt ↔ đậm), trục dọc = Tone (sáng ở trên, tối ở dưới).
 * Chạm vào thì núm phình to có quầng sáng và các chấm quanh núm nở ra như thấu kính; thả ra núm thu về chấm nhỏ.
 * Núm bám theo ngón tay có độ trễ mượt. Chạm đúp để về giữa (0, 0); kéo gần giữa thì tự hít vào 0.
 */
class PalettePadView(ctx: Context) : View(ctx) {
    var color = 0
        set(v) { field = v.coerceIn(-100, 100); invalidate() }
    var tone = 0
        set(v) { field = v.coerceIn(-100, 100); invalidate() }
    /** Màu đại diện của kiểu đang chọn, tô ở mép phải bảng. */
    var accent = 0xFFE6E6E6.toInt()
        set(v) { field = v; invalidate() }
    var onChange: ((color: Int, tone: Int) -> Unit)? = null

    private val dn = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()
    private val pad get() = 14f * dn
    private var lastTap = 0L
    private var downX = 0f
    private var downY = 0f
    private var moved = false
    /** 0 = thả, 1 = đang chạm (núm to + thấu kính chấm mạnh). */
    private var press = 0f
    private var pressAnim: ValueAnimator? = null
    /** Vị trí núm đang hiển thị (đuổi theo vị trí đích để chuyển động mượt). */
    private var kx = Float.NaN
    private var ky = Float.NaN

    init { isClickable = true }

    private fun targetX() = pad + (width - 2f * pad) * (color + 100) / 200f
    private fun targetY() = pad + (height - 2f * pad) * (100 - tone) / 200f

    private fun pressTo(v: Float) {
        pressAnim?.cancel()
        pressAnim = ValueAnimator.ofFloat(press, v).apply {
            duration = if (v > press) 200 else 280
            interpolator = if (v > press) OvershootInterpolator(2.2f) else DecelerateInterpolator(1.5f)
            addUpdateListener { press = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 10f * dn
        box.set(0f, 0f, w, h)
        // nền: trái xám nhạt màu → phải đậm màu của kiểu; phủ thêm dải sáng (trên) / tối (dưới)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, w, 0f, 0xFF6A6A70.toInt(), accent, Shader.TileMode.CLAMP)
        c.drawRoundRect(box, r, r, p)
        p.shader = LinearGradient(0f, 0f, 0f, h, intArrayOf(0x77FFFFFF, 0x00000000, 0xAA000000.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(box, r, r, p)
        p.shader = null

        // núm đuổi theo đích
        val tx = targetX()
        val ty = targetY()
        if (kx.isNaN()) { kx = tx; ky = ty }
        kx += (tx - kx) * 0.38f
        ky += (ty - ky) * 0.38f
        val moving = abs(tx - kx) > 0.4f || abs(ty - ky) > 0.4f
        if (!moving) { kx = tx; ky = ty }

        // lưới chấm: chấm gần núm nở to + sáng; hàng/cột đi qua núm sáng hơn (đường chữ thập chấm)
        val cols = 9
        val gap = (w - 2f * pad) / (cols - 1)
        val rows = Math.round((h - 2f * pad) / gap) + 1
        val gy = (h - 2f * pad) / (rows - 1).coerceAtLeast(1)
        val lens = (22f + 14f * press) * dn
        val base = 1.15f * dn
        for (j in 0 until rows) {
            val y = pad + j * gy
            for (i in 0 until cols) {
                val x = pad + i * gap
                val dx = x - kx
                val dy = y - ky
                val d2 = (dx * dx + dy * dy) / (lens * lens)
                val f = if (d2 > 9f) 0f else Math.exp((-d2).toDouble()).toFloat()
                val onLine = abs(dx) < gap * 0.5f || abs(dy) < gy * 0.5f
                var a = 0.30f + 0.65f * f * (0.4f + 0.6f * press)
                if (onLine) a = max(a, 0.62f)
                val rad = base * (1f + 1.7f * f * (0.35f + 0.65f * press)) * (if (onLine) 1.2f else 1f)
                p.color = ((a.coerceIn(0f, 1f) * 255f).toInt() shl 24) or 0xFFFFFF
                c.drawCircle(x, y, rad, p)
            }
        }

        // viền
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * dn
        p.color = 0x66FFFFFF
        c.drawRoundRect(0.5f * dn, 0.5f * dn, w - 0.5f * dn, h - 0.5f * dn, r, r, p)
        p.style = Paint.Style.FILL
        // nhãn bốn cạnh (mờ, để không rối lưới chấm)
        p.textSize = 8f * dn
        p.typeface = Typeface.DEFAULT
        p.color = 0x99FFFFFF.toInt()
        p.textAlign = Paint.Align.CENTER
        val fm = p.fontMetrics
        val lyc = -(fm.ascent + fm.descent) / 2f
        c.drawText("Sáng", w / 2f, 6.5f * dn + lyc, p)
        c.drawText("Tối", w / 2f, h - 6.5f * dn + lyc, p)
        p.textAlign = Paint.Align.LEFT
        c.drawText("Nhạt", 4f * dn, h / 2f - 9f * dn + lyc, p)
        p.textAlign = Paint.Align.RIGHT
        c.drawText("Đậm", w - 4f * dn, h / 2f - 9f * dn + lyc, p)

        // núm: chấm nhỏ khi thả, phình to + quầng sáng khi chạm
        val kr = (3.6f + 7.4f * press) * dn
        if (press > 0.01f) {
            p.color = ((0x22 * press.coerceIn(0f, 1f)).toInt() shl 24) or 0xFFFFFF
            c.drawCircle(kx, ky, kr * 2.3f, p)
            p.color = ((0x38 * press.coerceIn(0f, 1f)).toInt() shl 24) or 0xFFFFFF
            c.drawCircle(kx, ky, kr * 1.6f, p)
        }
        p.color = Color.WHITE
        c.drawCircle(kx, ky, kr, p)

        if (moving) postInvalidateOnAnimation()
    }

    private fun setFrom(x: Float, y: Float) {
        val w = (width - 2f * pad).coerceAtLeast(1f)
        val h = (height - 2f * pad).coerceAtLeast(1f)
        var cc = Math.round(((x - pad) / w).coerceIn(0f, 1f) * 200f) - 100
        var tt = 100 - Math.round(((y - pad) / h).coerceIn(0f, 1f) * 200f)
        if (abs(cc) <= 4) cc = 0
        if (abs(tt) <= 4) tt = 0
        if (cc != color || tt != tone) {
            val crossed = (cc == 0 && color != 0) || (tt == 0 && tone != 0)
            color = cc; tone = tt
            if (crossed) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onChange?.invoke(cc, tt)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                downX = e.x; downY = e.y; moved = false
                pressTo(1f)
                setFrom(e.x, e.y)
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(e.x - downX) > 6f * dn || abs(e.y - downY) > 6f * dn) moved = true
                setFrom(e.x, e.y)
            }
            MotionEvent.ACTION_UP -> {
                pressTo(0f)
                val now = e.eventTime
                if (!moved && now - lastTap < 320) {
                    // chạm đúp: về giữa
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    if (color != 0 || tone != 0) { color = 0; tone = 0; onChange?.invoke(0, 0) }
                    lastTap = 0
                } else lastTap = if (moved) 0 else now
            }
            MotionEvent.ACTION_CANCEL -> pressTo(0f)
        }
        return true
    }
}

/** Một ô trong danh sách: tên bộ lọc, nhãn tiếng Việt và hai màu đại diện (xem [filterAccent]). */
class PaletteItem(val name: String, val caption: String, val accent: IntArray)

/**
 * Hai màu đại diện cho một bộ lọc: một màu ấm (cam nhạt) và một màu lạnh (xanh) sau khi qua bộ lọc,
 * để nhìn ô là biết bộ lọc ấm/lạnh/nhạt/đậm/đen trắng thế nào. Dùng cho cả bộ lọc tự lưu.
 */
fun filterAccent(f: XpanFilter): IntArray {
    val m = f.previewMatrix().array
    fun ap(r: Int, g: Int, b: Int): Int {
        val nr = (m[0] * r + m[1] * g + m[2] * b + m[4]).toInt().coerceIn(0, 255)
        val ng = (m[5] * r + m[6] * g + m[7] * b + m[9]).toInt().coerceIn(0, 255)
        val nb = (m[10] * r + m[11] * g + m[12] * b + m[14]).toInt().coerceIn(0, 255)
        return Color.rgb(nr, ng, nb)
    }
    return intArrayOf(ap(250, 196, 120), ap(96, 144, 214))
}

/** Ô một bộ lọc trong danh sách. */
class PaletteTileView(ctx: Context, private val item: PaletteItem) : View(ctx) {
    var selectedItem = false
        set(v) { field = v; invalidate() }

    private val dn = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = 3f * dn
        box.set(m, m, w - m, h - m)
        val r = 9f * dn
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, box.top, 0f, box.bottom, 0xFF3A3A3F.toInt(), 0xFF111113.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(box, r, r, p)
        p.shader = null
        // dải màu đại diện bên trái
        val sw = 5f * dn
        p.shader = LinearGradient(0f, box.top + 6f * dn, 0f, box.bottom - 6f * dn, item.accent[0], item.accent[1], Shader.TileMode.CLAMP)
        c.drawRoundRect(box.left + 7f * dn, box.top + 7f * dn, box.left + 7f * dn + sw, box.bottom - 7f * dn, sw / 2f, sw / 2f, p)
        p.shader = null
        // tên
        val tx = box.left + 7f * dn + sw + 8f * dn
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.DEFAULT_BOLD
        p.color = Color.WHITE
        p.textSize = 11.5f * dn
        val maxW = box.right - tx - 4f * dn
        while (p.measureText(item.name) > maxW && p.textSize > 8f * dn) p.textSize -= 0.5f * dn
        c.drawText(item.name, tx, box.centerY() - 2f * dn, p)
        p.typeface = Typeface.DEFAULT
        p.color = if (selectedItem) ORANGE else 0x99FFFFFF.toInt()
        p.textSize = 9f * dn
        while (p.measureText(item.caption) > maxW && p.textSize > 7f * dn) p.textSize -= 0.5f * dn
        c.drawText(item.caption, tx, box.centerY() + 11f * dn, p)
        if (selectedItem) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f * dn
            p.color = ORANGE
            c.drawRoundRect(box.left - 1f * dn, box.top - 1f * dn, box.right + 1f * dn, box.bottom + 1f * dn, r + 1f * dn, r + 1f * dn, p)
            p.style = Paint.Style.FILL
        }
    }
}

/**
 * Ngăn kéo bảng màu: danh sách bộ lọc (có sẵn + của tôi, cuộn) ở trên; dưới là bảng chạm Tone × Color
 * và thanh Palette (cường độ bộ lọc đang chọn). Bấm giữ một ô bộ lọc tự lưu để đổi tên / ghi đè / xoá.
 */
class PalettePanel(ctx: Context) : LinearLayout(ctx) {
    var onItem: ((Int) -> Unit)? = null
    var onItemLong: ((Int) -> Unit)? = null
    var onPad: ((color: Int, tone: Int) -> Unit)? = null
    var onStrength: ((Int) -> Unit)? = null

    private val dn = resources.displayMetrics.density
    private val list = ScrollView(ctx)
    private val col = LinearLayout(ctx)
    private val tiles = ArrayList<PaletteTileView>()
    private var items: List<PaletteItem> = emptyList()
    private var selIdx = 0
    private val pad = PalettePadView(ctx)
    private val seek = SlimSeek(ctx)
    private val seekLabel = PaletteLabelView(ctx, "Palette", bold = true, sizeDp = 10f)
    private val seekValue = PaletteLabelView(ctx, "0", bold = false, sizeDp = 10f)
    private var rowRef: View? = null
    private var tileHDp = 44f

    init {
        orientation = LinearLayout.VERTICAL
        isClickable = true
        list.isVerticalScrollBarEnabled = false
        list.overScrollMode = View.OVER_SCROLL_NEVER
        list.isVerticalFadingEdgeEnabled = false
        col.orientation = LinearLayout.VERTICAL
        list.addView(col)
        addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        // mép trên / dưới của danh sách: ô tới gần mép thì mờ dần + co nhẹ + blur nhẹ thay vì bị cắt ngang
        list.setOnScrollChangeListener { _, _, _, _, _ -> updateEdges() }
        list.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateEdges() }

        addView(pad, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (112f * dn).toInt()).also {
            it.topMargin = (6f * dn).toInt(); it.leftMargin = (4f * dn).toInt(); it.rightMargin = (4f * dn).toInt()
        })

        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        seekValue.align = Paint.Align.RIGHT
        rowRef = row
        row.addView(seekLabel, LinearLayout.LayoutParams(0, (22f * dn).toInt(), 1f))
        row.addView(seekValue, LinearLayout.LayoutParams(0, (22f * dn).toInt(), 1f))
        addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (22f * dn).toInt()).also {
            it.topMargin = (4f * dn).toInt(); it.leftMargin = (8f * dn).toInt(); it.rightMargin = (8f * dn).toInt()
        })
        seek.max = 100
        seek.origin = 0
        addView(seek, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (30f * dn).toInt()))

        pad.onChange = { c, t -> onPad?.invoke(c, t) }
        seek.onUser = { v -> seekValue.set(v.toString()); onStrength?.invoke(v) }
    }

    /** X2D II: dùng riêng từng phần của bảng (danh sách bộ lọc ở popup; bảng chạm + thanh Palette ở thẻ trên màn ngắm). */
    fun setParts(showList: Boolean, showPad: Boolean, showRow: Boolean = showPad, showSeek: Boolean = showPad) {
        list.visibility = if (showList) View.VISIBLE else View.GONE
        pad.visibility = if (showPad) View.VISIBLE else View.GONE
        rowRef?.visibility = if (showRow) View.VISIBLE else View.GONE
        seek.visibility = if (showSeek) View.VISIBLE else View.GONE
    }

    /** Danh sách gọn (popup X2D II): ô thấp hơn + chừa lề hai bên / trên dưới để viền cam của ô đang chọn không dính mép. Gọi trước setItems. */
    fun setCompact(tileHeightDp: Float, insetDp: Float) {
        tileHDp = tileHeightDp
        val ix = (insetDp * dn).toInt()
        col.setPadding(ix, (4f * dn).toInt(), ix, (6f * dn).toInt())
    }

    /** Bảng chạm chiếm trọn view (không lề, không chiều cao cố định): dùng khi chỉ hiện mình bảng chạm. */
    fun setPadFill() {
        val lp = pad.layoutParams as? LinearLayout.LayoutParams ?: return
        lp.height = 0
        lp.weight = 1f
        lp.setMargins(0, 0, 0, 0)
        pad.layoutParams = lp
    }

    /** Chiều cao bảng chạm Tone × Color (px). */
    fun setPadHeight(px: Int) {
        val lp = pad.layoutParams as? LinearLayout.LayoutParams ?: return
        if (lp.height != px) { lp.height = px; pad.layoutParams = lp }
    }

    private fun header(text: String) {
        col.addView(PaletteLabelView(context, text, bold = true, sizeDp = 9f),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (22f * dn).toInt()).also { it.leftMargin = (6f * dn).toInt() })
    }

    /** Dựng lại danh sách. `builtIn` = số bộ lọc có sẵn (phần còn lại là bộ lọc của tôi). */
    fun setItems(entries: List<PaletteItem>, builtIn: Int) {
        items = entries
        col.removeAllViews()
        tiles.clear()
        entries.forEachIndexed { i, item ->
            if (i == 0) header("CÓ SẴN") else if (i == builtIn) header("CỦA TÔI")
            val t = PaletteTileView(context, item)
            t.setOnClickListener { onItem?.invoke(i) }   // tiếng + rung do MainActivity.filterTick() lo
            t.setOnLongClickListener { onItemLong?.invoke(i); true }
            tiles.add(t)
            col.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (tileHDp * dn).toInt()))
        }
        list.post { updateEdges() }
    }

    /**
     * Làm mềm hai mép trên/dưới của danh sách: mỗi ô (và tiêu đề nhóm) càng gần mép đang còn nội dung phía sau thì càng
     * mờ, co nhỏ và (Android 12+) bị blur nhẹ; ở đầu/cuối danh sách (không còn gì để cuộn) thì giữ nguyên, không mờ.
     */
    private fun updateEdges() {
        val h = list.height.toFloat()
        if (h <= 0f || col.childCount == 0) return
        val sy = list.scrollY.toFloat()
        val zone = 56f * dn
        val grace = 8f * dn
        val topS = (sy / zone).coerceIn(0f, 1f)
        val botS = ((col.height - h - sy) / zone).coerceIn(0f, 1f)
        for (i in 0 until col.childCount) {
            val v = col.getChildAt(i)
            val cy = v.top + v.height / 2f - sy          // tâm ô theo toạ độ khung nhìn của danh sách
            val ft = 1f - topS * (1f - ((cy + grace) / zone).coerceIn(0f, 1f))
            val fb = 1f - botS * (1f - ((h - cy + grace) / zone).coerceIn(0f, 1f))
            val f = min(ft, fb)
            val e = f * f * (3f - 2f * f)                 // smoothstep
            v.alpha = e
            val sc = 0.9f + 0.1f * e
            v.scaleX = sc
            v.scaleY = sc
            if (Build.VERSION.SDK_INT >= 31) {
                val r = (1f - e) * 4.5f * dn
                v.setRenderEffect(if (r > 0.4f) RenderEffect.createBlurEffect(r, r, Shader.TileMode.CLAMP) else null)
            }
        }
    }

    /** Chỉ đổi ô đang chọn (không động tới bảng chạm và thanh cường độ). */
    fun setSelected(i: Int) {
        selIdx = i
        tiles.forEachIndexed { k, t -> t.selectedItem = k == i }
        items.getOrNull(i)?.let { pad.accent = it.accent[0] }
        // bộ lọc gốc không có hiệu ứng nên thanh cường độ chỉ để trang trí
        val none = i == 0
        seek.alpha = if (none) 0.35f else 1f
        seekLabel.dim = none
        seekValue.dim = none
    }

    /** Cập nhật toàn bộ giao diện theo trạng thái hiện tại (không phát lại sự kiện). */
    fun setState(selected: Int, tone: Int, color: Int, strength: Int) {
        setSelected(selected)
        pad.color = color
        pad.tone = tone
        seek.progress = strength
        seekValue.set(strength.toString())
    }

    /** Cuộn danh sách tới bộ lọc đang chọn. */
    fun scrollToSelected() {
        val t = tiles.getOrNull(selIdx) ?: return
        list.post { list.scrollTo(0, (t.top - 40f * dn).toInt().coerceAtLeast(0)) }
    }
}
