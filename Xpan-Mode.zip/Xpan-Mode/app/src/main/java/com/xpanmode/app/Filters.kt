package com.xpanmode.app

import android.graphics.ColorMatrix
import org.json.JSONObject

/**
 * Bộ lọc màu lấy cảm hứng từ phong cách "Natural Colour" của Hasselblad:
 * tương phản mềm, đen hơi nâng, bão hoà vừa phải, tông da trung thực.
 * Cùng một công thức được dùng cho ảnh xuất (LUT từng kênh) và xem trước (ColorMatrix xấp xỉ).
 */
data class XpanFilter(
    val name: String,
    val contrast: Float = 1f,   // 1 = giữ nguyên, >1 = đường cong chữ S mạnh hơn
    val lift: Float = 0f,       // nâng vùng tối (0..0.05)
    val sat: Float = 1f,
    val r: Float = 1f,          // cân bằng màu (gain từng kênh)
    val g: Float = 1f,
    val b: Float = 1f,
    val mono: Boolean = false,
    val temp: Float = 0f,       // -1 (lạnh) .. 1 (ấm)
    val tint: Float = 0f,       // -1 (lục lam) .. 1 (đỏ sậm)
    val sharp: Float = 0f,      // 0..1, làm nét sau khi chụp
    // nhuộm màu theo vùng sáng (đơn vị 0..255, âm = bớt): vùng tối (sh) và vùng sáng (hi) – tạo "chất" riêng cho từng bộ lọc
    val shR: Float = 0f, val shG: Float = 0f, val shB: Float = 0f,
    val hiR: Float = 0f, val hiG: Float = 0f, val hiB: Float = 0f,
    val palette: PaletteSel? = null   // bảng màu (Tone / Color / Palette) áp sau bộ lọc
) {
    // gain hiệu dụng sau khi cộng lạnh/ấm và lục/đỏ sậm
    private val er: Float get() = r * (1f + 0.14f * temp) * (1f + 0.05f * tint)
    private val eg: Float get() = g * (1f - 0.10f * tint)
    private val eb: Float get() = b * (1f - 0.14f * temp) * (1f + 0.05f * tint)

    /** true nếu phần xử lý màu không làm gì (độ nét xử lý riêng), kể cả bảng màu. */
    val isIdentity: Boolean
        get() = baseIdentity && (palette?.isNeutral ?: true)

    private val baseIdentity: Boolean
        get() = contrast == 1f && lift == 0f && sat == 1f && r == 1f && g == 1f && b == 1f && !mono &&
            temp == 0f && tint == 0f && !hasSplit

    private val hasSplit: Boolean
        get() = shR != 0f || shG != 0f || shB != 0f || hiR != 0f || hiG != 0f || hiB != 0f

    /** Áp thêm phần chỉnh tay (lệch so với bộ lọc này). */
    fun adjusted(a: Adjust): XpanFilter = if (a.isZero) this else copy(
        contrast = (contrast * (1f + a.contrast / 100f * 0.35f)).coerceIn(0.6f, 1.5f),
        sat = (sat * (1f + a.sat / 100f * 0.6f)).coerceIn(0f, 2f),
        temp = (temp + a.temp / 100f).coerceIn(-1.5f, 1.5f),
        tint = (tint + a.tint / 100f).coerceIn(-1.5f, 1.5f),
        sharp = (sharp + a.sharp / 100f).coerceIn(0f, 1f)
    )

    /**
     * Cường độ "chất" của bộ lọc: k = 1 giữ nguyên, k = 0 trả về ảnh gốc, k > 1 (tới 2) đẩy đậm hơn nữa, ở giữa thì nội suy
     * từng thông số (cân bằng màu, bão hoà, tương phản, nhuộm vùng sáng/tối...). Dùng cho thanh Palette và trục Color
     * của bảng chạm. Bộ lọc đen trắng khi k < 1 chuyển thành giảm bão hoà dần.
     */
    fun scaled(k: Float): XpanFilter {
        if (k > 0.999f && k < 1.001f) return this
        val t = k.coerceIn(0f, 2f)
        fun mix(v: Float) = 1f + (v - 1f) * t
        val keepMono = mono && t >= 0.999f
        return copy(
            contrast = mix(contrast).coerceIn(0.6f, 1.6f), lift = (lift * t).coerceIn(0f, 0.09f),
            sat = if (mono) (if (keepMono) 1f else 1f - t) else mix(sat).coerceIn(0f, 2f), mono = keepMono,
            r = mix(r).coerceIn(0.7f, 1.3f), g = mix(g).coerceIn(0.7f, 1.3f), b = mix(b).coerceIn(0.7f, 1.3f),
            temp = (temp * t).coerceIn(-1.5f, 1.5f), tint = (tint * t).coerceIn(-1.5f, 1.5f), sharp = (sharp * t).coerceIn(0f, 1f),
            shR = (shR * t).coerceIn(-40f, 40f), shG = (shG * t).coerceIn(-40f, 40f), shB = (shB * t).coerceIn(-40f, 40f),
            hiR = (hiR * t).coerceIn(-40f, 40f), hiG = (hiG * t).coerceIn(-40f, 40f), hiB = (hiB * t).coerceIn(-40f, 40f)
        )
    }

    /** Gắn bảng màu; bảng màu Standard thì giữ nguyên bảng màu đã nằm sẵn trong bộ lọc (preset tự lưu). */
    fun withPalette(p: PaletteSel): XpanFilter = if (p.isNeutral) this else copy(palette = p)

    fun toJson(): JSONObject = JSONObject().put("n", name).put("c", contrast.toDouble()).put("l", lift.toDouble())
        .put("s", sat.toDouble()).put("r", r.toDouble()).put("g", g.toDouble()).put("b", b.toDouble())
        .put("m", mono).put("t", temp.toDouble()).put("i", tint.toDouble()).put("h", sharp.toDouble())
        .also { o ->
            if (hasSplit) o.put("sr", shR.toDouble()).put("sg", shG.toDouble()).put("sb", shB.toDouble())
                .put("hr", hiR.toDouble()).put("hg", hiG.toDouble()).put("hb", hiB.toDouble())
        }
        .also { o -> palette?.takeIf { !it.isNeutral }?.let { o.put("p", it.toJson()) } }

    private fun lut(gain: Float): IntArray {
        val a = ((contrast - 1f) * 2.5f).coerceIn(-1f, 1f)
        return IntArray(256) { i ->
            var x = (i / 255f * gain).coerceIn(0f, 1f)
            val s = x * x * (3f - 2f * x)
            x = x * (1f - a) + s * a
            x = lift + x * (1f - lift)
            (x * 255f + 0.5f).toInt().coerceIn(0, 255)
        }
    }

    /** Trả về hàm xử lý một mảng pixel ARGB (dùng cho từng dải ảnh). */
    fun processor(): (IntArray, Int, Int) -> Unit {
        val pal = palette?.processor()
        if (baseIdentity) return pal ?: { _, _, _ -> }
        val base = baseProcessor()
        if (pal == null) return base
        return { buf, from, to -> base(buf, from, to); pal(buf, from, to) }
    }

    private fun baseProcessor(): (IntArray, Int, Int) -> Unit {
        val lr = lut(er)
        val lg = lut(eg)
        val lb = lut(eb)
        val satQ = (sat * 256f).toInt()
        val mono = this.mono
        val split = hasSplit
        val sr = Math.round(shR); val sg = Math.round(shG); val sb = Math.round(shB)
        val hr = Math.round(hiR); val hg = Math.round(hiG); val hb = Math.round(hiB)
        return { buf, from, to ->
            for (i in from until to) {
                val p = buf[i]
                var rr = lr[(p shr 16) and 255]
                var gg = lg[(p shr 8) and 255]
                var bb = lb[p and 255]
                val l = (rr * 54 + gg * 183 + bb * 19) shr 8
                if (mono) {
                    rr = l; gg = l; bb = l
                } else if (satQ != 256) {
                    rr = (l + (((rr - l) * satQ) shr 8)).coerceIn(0, 255)
                    gg = (l + (((gg - l) * satQ) shr 8)).coerceIn(0, 255)
                    bb = (l + (((bb - l) * satQ) shr 8)).coerceIn(0, 255)
                }
                if (split) {
                    // vùng tối nhận màu `sh`, vùng sáng nhận màu `hi` (trọng số bình phương theo độ sáng)
                    val ws = ((255 - l) * (255 - l)) shr 8
                    val wh = (l * l) shr 8
                    rr = (rr + ((ws * sr + wh * hr) shr 8)).coerceIn(0, 255)
                    gg = (gg + ((ws * sg + wh * hg) shr 8)).coerceIn(0, 255)
                    bb = (bb + ((ws * sb + wh * hb) shr 8)).coerceIn(0, 255)
                }
                buf[i] = (p and 0xFF000000.toInt()) or (rr shl 16) or (gg shl 8) or bb
            }
        }
    }

    /** Ma trận xấp xỉ để xem trước trực tiếp trên TextureView. */
    fun previewMatrix(): ColorMatrix {
        val cm = ColorMatrix()
        cm.setSaturation(if (mono) 0f else sat)
        val scale = (1f - lift) * contrast
        val off = 255f * (lift + (1f - lift) * 0.5f * (1f - contrast))
        // nhuộm vùng tối/sáng: xấp xỉ tuyến tính theo độ sáng (nửa cường độ vì trọng số thật là bình phương)
        val lr = 0.2113f; val lg = 0.7148f; val lb = 0.0742f
        val dr = 0.5f * (hiR - shR) / 255f; val dg = 0.5f * (hiG - shG) / 255f; val db = 0.5f * (hiB - shB) / 255f
        val m = ColorMatrix(
            floatArrayOf(
                scale * er + dr * lr, dr * lg, dr * lb, 0f, off + 0.5f * shR,
                dg * lr, scale * eg + dg * lg, dg * lb, 0f, off + 0.5f * shG,
                db * lr, db * lg, scale * eb + db * lb, 0f, off + 0.5f * shB,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(m)
        palette?.previewMatrix()?.let { cm.postConcat(it) }
        return cm
    }

    companion object {
        fun fromJson(o: JSONObject, name: String): XpanFilter = XpanFilter(
            name,
            o.optDouble("c", 1.0).toFloat(), o.optDouble("l", 0.0).toFloat(), o.optDouble("s", 1.0).toFloat(),
            o.optDouble("r", 1.0).toFloat(), o.optDouble("g", 1.0).toFloat(), o.optDouble("b", 1.0).toFloat(),
            o.optBoolean("m", false),
            o.optDouble("t", 0.0).toFloat(), o.optDouble("i", 0.0).toFloat(), o.optDouble("h", 0.0).toFloat(),
            shR = o.optDouble("sr", 0.0).toFloat(), shG = o.optDouble("sg", 0.0).toFloat(), shB = o.optDouble("sb", 0.0).toFloat(),
            hiR = o.optDouble("hr", 0.0).toFloat(), hiG = o.optDouble("hg", 0.0).toFloat(), hiB = o.optDouble("hb", 0.0).toFloat(),
            palette = o.optJSONObject("p")?.let { PaletteSel.fromJson(it) }
        )

        // Mỗi bộ lọc có "chất" riêng RÕ RỆT (cân bằng màu, bão hoà, tương phản và nhuộm vùng tối/sáng khác hẳn nhau),
        // để cùng một toạ độ trên bảng chạm vẫn cho ra các ảnh khác nhau.
        val all: List<XpanFilter> = listOf(
            XpanFilter("Original"),
            // Natural: trung thực, tương phản mềm, đen hơi nâng, da đúng màu
            XpanFilter("Natural", contrast = 1.08f, lift = 0.014f, sat = 0.92f, r = 1.01f, b = 0.985f),
            // Portrait: mềm, phẳng, da ấm hơi hồng, bão hoà thấp, vùng sáng ngả hồng đào
            XpanFilter("Portrait", contrast = 0.98f, lift = 0.04f, sat = 0.84f, r = 1.07f, g = 1.0f, b = 0.95f,
                hiR = 9f, hiG = 3f, hiB = 1f, shR = 3f, shG = 0f, shB = -1f),
            // Landscape: tương phản + bão hoà cao, xanh lá / xanh trời nổi, hơi lạnh
            XpanFilter("Landscape", contrast = 1.18f, lift = 0.006f, sat = 1.34f, r = 0.985f, g = 1.04f, b = 1.06f),
            // XPan Chrome: phim chrome – bão hoà thấp, tương phản gắt, bóng đổ xanh lam lạnh, vùng sáng ngả vàng
            XpanFilter("XPan Chrome", contrast = 1.26f, lift = 0.035f, sat = 0.62f, r = 0.98f, g = 1.0f, b = 1.05f,
                shR = -5f, shG = 3f, shB = 11f, hiR = 6f, hiG = 4f, hiB = -4f),
            // Golden Hour: nắng chiều – ấm rất rõ, vùng sáng vàng cam, bóng đổ nâu ấm
            XpanFilter("Golden Hour", contrast = 1.06f, lift = 0.012f, sat = 1.12f, r = 1.11f, g = 1.02f, b = 0.80f,
                hiR = 14f, hiG = 6f, hiB = -12f, shR = 8f, shG = 1f, shB = -8f),
            // Mono: đen trắng tương phản cao
            XpanFilter("Mono", contrast = 1.26f, lift = 0.02f, mono = true),
            // Fuji Film: phim Fujicolor xưa – đen bạc (faded), bóng đổ lục-lam, xanh lá nổi, vùng sáng ngả vàng nhạt
            XpanFilter("Fuji Film", contrast = 1.05f, lift = 0.056f, sat = 1.06f, r = 0.95f, g = 1.07f, b = 1.02f,
                sharp = 0.08f, shR = -4f, shG = 8f, shB = 7f, hiR = 5f, hiG = 4f, hiB = -5f),
            // Leica M9: màu đậm, bão hoà cao, tương phản sâu, đỏ/cam rực, đen chắc, hơi ấm như cảm biến CCD, nét sắc
            XpanFilter("Leica M9", contrast = 1.28f, lift = 0.0f, sat = 1.36f, r = 1.06f, g = 1.0f, b = 0.91f,
                sharp = 0.25f, shR = 4f, shG = 0f, shB = -4f),
            // Vivo Zeiss: trong trẻo, sáng, lạnh rõ, da sạch, cây cỏ tươi, vùng sáng ngả xanh nhạt
            XpanFilter("Vivo Zeiss", contrast = 1.03f, lift = 0.04f, sat = 1.10f, r = 0.94f, g = 1.01f, b = 1.11f,
                sharp = 0.15f, shR = -3f, shG = 1f, shB = 6f, hiR = -3f, hiG = 1f, hiB = 9f)
        )

        /** Ma trận đảo âm bản dùng cho hiệu ứng màn trập. */
        fun invertMatrix(): ColorMatrix = ColorMatrix(
            floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }
}
