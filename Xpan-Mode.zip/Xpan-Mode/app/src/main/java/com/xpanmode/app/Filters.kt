package com.xpanmode.app

import android.graphics.ColorMatrix
import org.json.JSONObject

/**
 * Bộ lọc màu lấy cảm hứng từ phong cách "Natural Colour" của Hasselblad:
 * tương phản mềm, đen hơi nâng, bão hoà vừa phải, tông da trung thực.
 * Cùng một công thức được dùng cho ảnh xuất (LUT từng kênh) và xem trước (ColorMatrix xấp xỉ).
 */
data class XpanFilter(
    val name: String,
    val contrast: Float = 1f,   // 1 = giữ nguyên, >1 = đường cong chữ S mạnh hơn
    val lift: Float = 0f,       // nâng vùng tối (0..0.05)
    val sat: Float = 1f,
    val r: Float = 1f,          // cân bằng màu (gain từng kênh)
    val g: Float = 1f,
    val b: Float = 1f,
    val mono: Boolean = false,
    val temp: Float = 0f,       // -1 (lạnh) .. 1 (ấm)
    val tint: Float = 0f,       // -1 (lục lam) .. 1 (đỏ sậm)
    val sharp: Float = 0f       // 0..1, làm nét sau khi chụp
) {
    // gain hiệu dụng sau khi cộng lạnh/ấm và lục/đỏ sậm
    private val er: Float get() = r * (1f + 0.14f * temp) * (1f + 0.05f * tint)
    private val eg: Float get() = g * (1f - 0.10f * tint)
    private val eb: Float get() = b * (1f - 0.14f * temp) * (1f + 0.05f * tint)

    /** true nếu phần xử lý màu không làm gì (độ nét xử lý riêng). */
    val isIdentity: Boolean
        get() = contrast == 1f && lift == 0f && sat == 1f && r == 1f && g == 1f && b == 1f && !mono &&
            temp == 0f && tint == 0f

    /** Áp thêm phần chỉnh tay (lệch so với bộ lọc này). */
    fun adjusted(a: Adjust): XpanFilter = if (a.isZero) this else copy(
        contrast = (contrast * (1f + a.contrast / 100f * 0.35f)).coerceIn(0.6f, 1.5f),
        sat = (sat * (1f + a.sat / 100f * 0.6f)).coerceIn(0f, 2f),
        temp = (temp + a.temp / 100f).coerceIn(-1.5f, 1.5f),
        tint = (tint + a.tint / 100f).coerceIn(-1.5f, 1.5f),
        sharp = (sharp + a.sharp / 100f).coerceIn(0f, 1f)
    )

    fun toJson(): JSONObject = JSONObject().put("n", name).put("c", contrast.toDouble()).put("l", lift.toDouble())
        .put("s", sat.toDouble()).put("r", r.toDouble()).put("g", g.toDouble()).put("b", b.toDouble())
        .put("m", mono).put("t", temp.toDouble()).put("i", tint.toDouble()).put("h", sharp.toDouble())

    private fun lut(gain: Float): IntArray {
        val a = ((contrast - 1f) * 2.5f).coerceIn(-1f, 1f)
        return IntArray(256) { i ->
            var x = (i / 255f * gain).coerceIn(0f, 1f)
            val s = x * x * (3f - 2f * x)
            x = x * (1f - a) + s * a
            x = lift + x * (1f - lift)
            (x * 255f + 0.5f).toInt().coerceIn(0, 255)
        }
    }

    /** Trả về hàm xử lý một mảng pixel ARGB (dùng cho từng dải ảnh). */
    fun processor(): (IntArray, Int, Int) -> Unit {
        if (isIdentity) return { _, _, _ -> }
        val lr = lut(er)
        val lg = lut(eg)
        val lb = lut(eb)
        val satQ = (sat * 256f).toInt()
        val mono = this.mono
        return { buf, from, to ->
            for (i in from until to) {
                val p = buf[i]
                var rr = lr[(p shr 16) and 255]
                var gg = lg[(p shr 8) and 255]
                var bb = lb[p and 255]
                val l = (rr * 54 + gg * 183 + bb * 19) shr 8
                if (mono) {
                    rr = l; gg = l; bb = l
                } else if (satQ != 256) {
                    rr = (l + (((rr - l) * satQ) shr 8)).coerceIn(0, 255)
                    gg = (l + (((gg - l) * satQ) shr 8)).coerceIn(0, 255)
                    bb = (l + (((bb - l) * satQ) shr 8)).coerceIn(0, 255)
                }
                buf[i] = (p and 0xFF000000.toInt()) or (rr shl 16) or (gg shl 8) or bb
            }
        }
    }

    /** Ma trận xấp xỉ để xem trước trực tiếp trên TextureView. */
    fun previewMatrix(): ColorMatrix {
        val cm = ColorMatrix()
        cm.setSaturation(if (mono) 0f else sat)
        val scale = (1f - lift) * contrast
        val off = 255f * (lift + (1f - lift) * 0.5f * (1f - contrast))
        val m = ColorMatrix(
            floatArrayOf(
                scale * er, 0f, 0f, 0f, off,
                0f, scale * eg, 0f, 0f, off,
                0f, 0f, scale * eb, 0f, off,
                0f, 0f, 0f, 1f, 0f
            )
        )
        cm.postConcat(m)
        return cm
    }

    companion object {
        fun fromJson(o: JSONObject, name: String): XpanFilter = XpanFilter(
            name,
            o.optDouble("c", 1.0).toFloat(), o.optDouble("l", 0.0).toFloat(), o.optDouble("s", 1.0).toFloat(),
            o.optDouble("r", 1.0).toFloat(), o.optDouble("g", 1.0).toFloat(), o.optDouble("b", 1.0).toFloat(),
            o.optBoolean("m", false),
            o.optDouble("t", 0.0).toFloat(), o.optDouble("i", 0.0).toFloat(), o.optDouble("h", 0.0).toFloat()
        )

        val all: List<XpanFilter> = listOf(
            XpanFilter("Original"),
            XpanFilter("Natural", contrast = 1.06f, lift = 0.012f, sat = 0.94f, r = 1.01f, b = 0.985f),
            XpanFilter("Portrait", contrast = 1.02f, lift = 0.02f, sat = 0.92f, r = 1.03f, b = 0.97f),
            XpanFilter("Landscape", contrast = 1.10f, lift = 0.008f, sat = 1.06f, g = 1.01f, b = 1.01f),
            XpanFilter("XPan Chrome", contrast = 1.14f, lift = 0.025f, sat = 0.85f, r = 1.01f, b = 1.02f),
            XpanFilter("Golden Hour", contrast = 1.05f, lift = 0.01f, sat = 1.0f, r = 1.05f, g = 1.01f, b = 0.93f),
            XpanFilter("Mono", contrast = 1.18f, lift = 0.015f, mono = true),
            // Fuji Film: phim Fujicolor thời xưa – đen hơi bạc (faded), bóng đổ ngả lục-lam, xanh lá nổi, bão hoà nhẹ
            XpanFilter("Fuji Film", contrast = 1.08f, lift = 0.032f, sat = 1.08f, r = 0.985f, g = 1.02f, b = 1.015f, temp = -0.04f, tint = -0.14f, sharp = 0.08f),
            // Leica M9: màu đậm đà, bão hoà cao, tương phản sâu, đen chắc, hơi ấm như cảm biến CCD, nét sắc
            XpanFilter("Leica M9", contrast = 1.18f, lift = 0.0f, sat = 1.24f, r = 1.035f, g = 1.0f, b = 0.955f, temp = 0.06f, tint = 0.03f, sharp = 0.25f),
            // Vivo Zeiss: trong trẻo, sáng, hơi lạnh nhẹ, da sạch và cây cỏ tươi, tương phản mềm
            XpanFilter("Vivo Zeiss", contrast = 1.03f, lift = 0.03f, sat = 1.07f, r = 0.995f, g = 1.012f, b = 1.025f, temp = -0.05f, tint = 0f, sharp = 0.15f)
        )

        /** Ma trận đảo âm bản dùng cho hiệu ứng màn trập. */
        fun invertMatrix(): ColorMatrix = ColorMatrix(
            floatArrayOf(
                -1f, 0f, 0f, 0f, 255f,
                0f, -1f, 0f, 0f, 255f,
                0f, 0f, -1f, 0f, 255f,
                0f, 0f, 0f, 1f, 0f
            )
        )
    }
}
