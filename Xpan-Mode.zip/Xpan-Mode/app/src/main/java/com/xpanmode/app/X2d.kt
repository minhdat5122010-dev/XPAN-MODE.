package com.xpanmode.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/** Phím vật lý bên phải màn hình X2D II: viên bo góc tối, mép vát mảnh (đè lên nút ở cột chức năng). */
fun drawX2dKey(c: Canvas, p: Paint, w: Float, h: Float, dn: Float, down: Boolean = false) {
    val light = Theme.light
    val r = min(w, h) * 0.30f
    val ins = 0.8f * dn
    val box = RectF(ins, ins, w - ins, h - ins)
    p.style = Paint.Style.FILL
    p.shader = LinearGradient(
        0f, 0f, 0f, h,
        if (light) intArrayOf(0xFFFAFAFB.toInt(), 0xFFD6D6DC.toInt()) else intArrayOf(0xFF2C2C30.toInt(), 0xFF111113.toInt()),
        null, Shader.TileMode.CLAMP
    )
    c.drawRoundRect(box, r, r, p)
    p.shader = null
    p.style = Paint.Style.STROKE
    p.strokeWidth = 1.1f * dn
    p.shader = LinearGradient(
        0f, 0f, 0f, h,
        if (down) intArrayOf(ORANGE, ORANGE) else if (light) intArrayOf(0xFFFFFFFF.toInt(), 0x55000000) else intArrayOf(0x70FFFFFF, 0x18FFFFFF),
        null, Shader.TileMode.CLAMP
    )
    c.drawRoundRect(box, r, r, p)
    p.shader = null
}

/** Lớp hiển thị trên màn ngắm kiểu X2D II: khung/pin/ISO góc trên, thanh trượt EV bên phải, thanh nét phía dưới, dải thông số. */
class X2DHudView(ctx: Context) : XView(ctx) {
    /** Nguồn EV (chính là EvView đang ẩn): cùng dữ liệu, cùng callback. */
    var evSrc: EvView? = null
    var isoText = "ISO"
    var shutterText = ""
    var apertureText = ""
    var focalText = ""
    var manualExp = false
    /** < 0: lấy nét tự động; 0..1: vị trí nét tay (0 = vô cực, 1 = gần nhất). */
    var focusFrac = -1f
    var battery = 1f
    /** Bánh xoay đang điều khiển: 0 = EV, 1 = nét. */
    var dialMode = 0
    var showFocusSquare = true

    fun refresh() = invalidate()

    private val track = RectF()
    private var dragging = false

    private fun evTrack(): RectF {
        val w = width.toFloat()
        val h = height.toFloat()
        track.set(w - d(30f), h * 0.30f, w - d(14f), h * 0.70f)
        return track
    }

    override fun onDraw(c: Canvas) {
        if (!x2d) return
        val w = width.toFloat()
        val h = height.toFloat()
        val white = Color.WHITE
        p.setShadowLayer(d(2.4f), 0f, d(1f), 0xCC000000.toInt())
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND

        // góc trên trái: biểu tượng khung 4:3
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.5f)
        p.color = white
        val fx = d(16f)
        val fy = d(14f)
        c.drawRoundRect(fx, fy, fx + d(30f), fy + d(22f), d(4f), d(4f), p)
        c.drawRoundRect(fx + d(5f), fy + d(5f), fx + d(25f), fy + d(17f), d(2f), d(2f), p)
        p.style = Paint.Style.FILL
        p.textSize = d(7.5f)
        p.typeface = Typeface.DEFAULT_BOLD
        p.textAlign = Paint.Align.CENTER
        c.drawText("4:3", fx + d(15f), fy + d(14.2f), p)

        // góc trên phải: pin, ISO, AF
        val rx = w - d(14f)
        val bw = d(22f)
        val bh = d(10f)
        val by = d(14f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.3f)
        c.drawRoundRect(rx - bw, by, rx, by + bh, d(2.5f), d(2.5f), p)
        p.style = Paint.Style.FILL
        c.drawRect(rx + d(1f), by + d(3f), rx + d(2.6f), by + bh - d(3f), p)
        val lvl = battery.coerceIn(0.05f, 1f)
        c.drawRoundRect(rx - bw + d(2f), by + d(2f), rx - bw + d(2f) + (bw - d(4f)) * lvl, by + bh - d(2f), d(1f), d(1f), p)
        p.textAlign = Paint.Align.RIGHT
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = d(11.5f)
        c.drawText(isoText, rx, by + bh + d(20f), p)
        p.textSize = d(10f)
        val afTxt = if (focusFrac >= 0f) "MF" else "AF C"
        val afW = p.measureText(afTxt) + d(10f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        c.drawRoundRect(rx - afW, by + bh + d(28f), rx, by + bh + d(44f), d(3f), d(3f), p)
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        c.drawText(afTxt, rx - afW / 2f, by + bh + d(40f), p)

        // ô AF nhỏ ở giữa khung (như màn hình X2D)
        if (showFocusSquare) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(1.2f)
            p.color = 0xCCFFFFFF.toInt()
            val s = d(7f)
            c.drawRect(w / 2f - s, h / 2f - s, w / 2f + s, h / 2f + s, p)
        }

        // thanh trượt EV bên phải: vạch chia, tay nắm tròn, số EV
        val ev = evSrc
        if (ev != null && ev.max > ev.min) {
            val t = evTrack()
            val cx = t.centerX()
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(1.4f)
            p.color = if (dialMode == 0) white else 0xAAFFFFFF.toInt()
            c.drawLine(cx, t.top, cx, t.bottom, p)
            val perEv = if (ev.step > 0f) (1f / ev.step).roundToInt().coerceAtLeast(1) else 1
            val n = (ev.max - ev.min).toFloat()
            for (i in ev.min..ev.max) {
                val y = t.top + (ev.max - i) / n * t.height()
                val len = if (i % perEv == 0) d(7f) else d(3.5f)
                c.drawLine(cx - len, y, cx, y, p)
            }
            val y = t.top + (ev.max - ev.value) / n * t.height()
            p.style = Paint.Style.FILL
            p.color = if (ev.value != 0 || dragging) ORANGE else white
            c.drawCircle(cx, y, d(7f), p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(1.2f)
            p.color = white
            c.drawCircle(cx, y, d(7f), p)
            p.style = Paint.Style.FILL
            p.color = white
            p.textAlign = Paint.Align.RIGHT
            p.textSize = d(11f)
            val v = ev.value * ev.step
            c.drawText(if (ev.value == 0) "0.0" else String.format(Locale.US, "%+.1f", v), cx - d(12f), y + d(4f), p)
        }

        // thanh ngang phía dưới: vị trí nét (MF) hoặc AF
        val bx0 = w * 0.30f
        val bx1 = w * 0.70f
        val byy = h - d(44f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.4f)
        p.color = if (dialMode == 1) white else 0xAAFFFFFF.toInt()
        c.drawLine(bx0, byy, bx1, byy, p)
        for (i in 0..10) {
            val x = bx0 + (bx1 - bx0) * i / 10f
            val len = if (i % 5 == 0) d(6f) else d(3f)
            c.drawLine(x, byy - len, x, byy, p)
        }
        val hx = if (focusFrac >= 0f) bx0 + (bx1 - bx0) * focusFrac.coerceIn(0f, 1f) else (bx0 + bx1) / 2f
        p.style = Paint.Style.FILL
        p.color = if (focusFrac >= 0f) ORANGE else 0x88FFFFFF.toInt()
        c.drawCircle(hx, byy, d(6.5f), p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.color = white
        c.drawCircle(hx, byy, d(6.5f), p)

        // dải thông số: chế độ, khẩu, tốc độ, tiêu cự
        val ty = h - d(14f)
        p.style = Paint.Style.FILL
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = d(12.5f)
        p.color = if (manualExp) ORANGE else white
        p.textAlign = Paint.Align.LEFT
        c.drawText(if (manualExp) "M" else "A", d(16f), ty, p)
        p.color = white
        p.textAlign = Paint.Align.CENTER
        c.drawText(apertureText, w * 0.36f, ty, p)
        c.drawText(shutterText, w * 0.54f, ty, p)
        p.textAlign = Paint.Align.RIGHT
        c.drawText("[ $focalText ]", w - d(16f), ty, p)
        p.typeface = Typeface.DEFAULT
        p.clearShadowLayer()
    }

    /** Chỉ nhận chạm trên thanh EV bên phải; chỗ khác để chạm lọt xuống khung ngắm (lấy nét, zoom). */
    override fun onTouchEvent(e: MotionEvent): Boolean {
        val ev = evSrc ?: return false
        if (!x2d || ev.max <= ev.min) return false
        val t = evTrack()
        if (e.actionMasked == MotionEvent.ACTION_DOWN) {
            if (e.x < t.left - d(22f) || e.x > t.right + d(8f) || e.y < t.top - d(14f) || e.y > t.bottom + d(14f)) return false
            dragging = true
            parent?.requestDisallowInterceptTouchEvent(true)
        }
        if (!dragging) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val f = ((e.y - t.top) / t.height()).coerceIn(0f, 1f)
                val nv = (ev.max - (f * (ev.max - ev.min)).roundToInt()).coerceIn(ev.min, ev.max)
                if (nv != ev.value) { ev.value = nv; ev.onChange?.invoke(nv) }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { dragging = false; invalidate() }
        }
        return true
    }
}

/**
 * Bánh xoay trên tay cầm X2D II: thanh khía ngang ở đầu tay cầm (như bánh xoay thật nhìn từ phía sau).
 * Vuốt ngang để xoay từng nấc (rung "tạch"). Chức năng (EV / lấy nét) chọn trong Cài đặt.
 * Chạm đúp: về mặc định (EV 0 / lấy nét tự động).
 */
class X2DDialView(ctx: Context) : XView(ctx) {
    var onStep: ((Int) -> Unit)? = null
    var onReset: (() -> Unit)? = null
    var label = "EV"
        set(v) { if (field != v) { field = v; invalidate() } }

    private var rot = 0f
    private var downX = 0f
    private var acc = 0f
    private var moved = false
    private var lastTap = 0L
    private val stepPx get() = d(12f)

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        if (!x2d) return
        val w = width.toFloat()
        val h = height.toFloat()
        val light = Theme.light
        val r = h * 0.28f
        val box = RectF(d(1f), d(1f), w - d(1f), h - d(1f))
        // thân trụ: tối dần ở hai mép (độ cong), sáng ở giữa
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, 0f, w, 0f,
            if (light) intArrayOf(0xFF8E8E96.toInt(), 0xFFE6E6EA.toInt(), 0xFF8E8E96.toInt()) else intArrayOf(0xFF0C0C0D.toInt(), 0xFF3C3C41.toInt(), 0xFF0C0C0D.toInt()),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(box, r, r, p)
        p.shader = null
        // khía: các gân dọc phân bố trên mặt trụ, quay theo rot (thu hẹp dần về hai mép)
        c.save()
        c.clipRect(box.left + r * 0.4f, box.top, box.right - r * 0.4f, box.bottom)
        val cx = w / 2f
        val rad = (w / 2f) * 0.95f
        val n = 48
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.1f)
        for (i in 0 until n) {
            val a = Math.toRadians((i * 360.0 / n) + rot)
            val cs = cos(a).toFloat()
            if (cs <= 0.08f) continue
            val x = cx + rad * sin(a).toFloat()
            val al = (cs * 255).toInt().coerceIn(0, 255)
            p.color = ((al / 2) shl 24) or (if (light) 0x202024 else 0x000000)
            c.drawLine(x, h * 0.14f, x, h * 0.86f, p)
            p.color = ((al / 5) shl 24) or 0xFFFFFF
            c.drawLine(x + d(1.2f), h * 0.14f, x + d(1.2f), h * 0.86f, p)
        }
        c.restore()
        // viền sáng mảnh
        p.strokeWidth = d(1f)
        p.color = if (light) 0x66FFFFFF else 0x28FFFFFF
        c.drawRoundRect(box, r, r, p)
        // chip chức năng ở giữa
        p.style = Paint.Style.FILL
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = h * 0.40f
        val tw = p.measureText(label)
        val chipW = tw + h * 0.55f
        val chipH = h * 0.62f
        p.color = 0xE6000000.toInt()
        c.drawRoundRect(cx - chipW / 2f, h / 2f - chipH / 2f, cx + chipW / 2f, h / 2f + chipH / 2f, chipH / 2f, chipH / 2f, p)
        p.color = ORANGE
        p.textAlign = Paint.Align.CENTER
        val fm = p.fontMetrics
        c.drawText(label, cx, h / 2f - (fm.ascent + fm.descent) / 2f, p)
        p.typeface = Typeface.DEFAULT
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; acc = 0f; moved = false
                parent?.requestDisallowInterceptTouchEvent(true)
                animate().cancel()
                animate().scaleX(0.97f).scaleY(0.94f).setDuration(70).start()
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX     // vuốt sang phải = +1 (xoay thuận)
                downX = e.x
                acc += dx
                if (abs(acc) > d(4f)) moved = true
                while (abs(acc) >= stepPx) {
                    val s = if (acc > 0) 1 else -1
                    acc -= s * stepPx
                    rot += s * 7.5f
                    Haptic.click(this)
                    onStep?.invoke(s)
                    invalidate()
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                animate().scaleX(1f).scaleY(1f).setDuration(200).start()
                if (e.actionMasked == MotionEvent.ACTION_UP && !moved) {
                    val now = e.eventTime
                    if (now - lastTap < 380) { lastTap = 0; onReset?.invoke() } else lastTap = now
                }
            }
        }
        return true
    }
}

/**
 * Nút tròn xám trên tay cầm ("bao gồm" cài đặt + flash + sáng/tối): bấm để bung khay ba nút nhỏ ra bên trái, bấm lần nữa để thu lại.
 */
class X2DHubView(ctx: Context) : XView(ctx) {
    var expanded = false
        set(v) { if (field != v) { field = v; animate().cancel(); animate().rotation(if (v) 45f else 0f).setDuration(220).start() } }
    private var down = false

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        if (!x2d) return
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.94f
        val light = Theme.light
        p.style = Paint.Style.FILL
        p.color = if (light) 0xFF9A9AA2.toInt() else 0xFF050506.toInt()
        c.drawCircle(cx, cy, r, p)
        p.shader = RadialGradient(
            cx - r * 0.3f, cy - r * 0.4f, r * 1.5f,
            if (light) intArrayOf(0xFFF4F4F6.toInt(), 0xFFB9B9C0.toInt()) else intArrayOf(0xFF4A4A50.toInt(), 0xFF1A1A1D.toInt()),
            null, Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, r * 0.88f, p)
        p.shader = null
        // bánh răng
        val ink = if (down || expanded) ORANGE else if (light) 0xFF222226.toInt() else 0xFFEDEDF0.toInt()
        p.color = ink
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        val g = r * 0.46f
        p.strokeWidth = g * 0.30f
        c.drawCircle(cx, cy, g, p)
        p.strokeWidth = g * 0.34f
        for (i in 0 until 8) {
            val a = Math.PI * 2 * i / 8
            val ca = cos(a).toFloat()
            val sa = sin(a).toFloat()
            c.drawLine(cx + g * 1.12f * ca, cy + g * 1.12f * sa, cx + g * 1.38f * ca, cy + g * 1.38f * sa, p)
        }
        p.style = Paint.Style.FILL
        p.strokeCap = Paint.Cap.BUTT
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { down = true; invalidate() }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { down = false; invalidate() }
        }
        return super.onTouchEvent(e)
    }
}

/** Lớp phủ nút Album (kiểu X2D): chip ▶ nhỏ ở góc, viền mảnh bo góc. */
class X2DAlbumOverlay(private val dn: Float) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun draw(c: Canvas) {
        val b = bounds
        val r = min(b.width(), b.height()) * 0.30f
        val rf = RectF(b)
        rf.inset(dn, dn)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.4f * dn
        p.color = if (Theme.light) 0x88000000.toInt() else 0x99FFFFFF.toInt()
        c.drawRoundRect(rf, r, r, p)
        // chip ▶
        val cr = min(b.width(), b.height()) * 0.17f
        val cx = b.right - cr * 1.5f
        val cy = b.bottom - cr * 1.5f
        p.style = Paint.Style.FILL
        p.color = 0xB0000000.toInt()
        c.drawCircle(cx, cy, cr, p)
        p.color = Color.WHITE
        val t = Path()
        t.moveTo(cx - cr * 0.28f, cy - cr * 0.45f)
        t.lineTo(cx + cr * 0.5f, cy)
        t.lineTo(cx - cr * 0.28f, cy + cr * 0.45f)
        t.close()
        c.drawPath(t, p)
    }
    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: android.graphics.ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = android.graphics.PixelFormat.TRANSLUCENT
}
