package com.xpanmode.app

import android.graphics.ColorMatrix
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Bảng màu (kiểu Photographic Styles thế hệ 2): chọn một kiểu, rồi chỉnh Tone (trục dọc), Color (trục ngang)
 * và Palette (cường độ hiệu ứng của kiểu). Cả ba bằng 0 → ảnh Standard, không áp gì.
 *
 * Khác bộ lọc: kiểu bảng màu KHÔNG phủ một lớp màu lên cả tấm ảnh mà chỉnh theo vùng:
 *  - vùng da (nhận diện bằng dải hue cam–đỏ + độ bão hoà + độ sáng) được dịch màu riêng (Amber, Cool Rose...);
 *  - vùng tối / vùng sáng được nhuộm màu riêng (Cozy, Dramatic, Ethereal...);
 *  - phần còn lại chỉ chỉnh bão hoà / tương phản / ấm lạnh.
 * Công thức là của app (Apple không công bố công thức thật), nên ra gần giống chứ không trùng.
 */
class PaletteStyle(
    val name: String,
    val vi: String,                 // nhãn tiếng Việt hiện nhỏ trên ô
    val group: Int,                 // 0 = Undertones (theo tông da), 1 = Mood (theo cảm xúc)
    val contrast: Float = 0f,       // + = đường cong chữ S mạnh hơn
    val lift: Float = 0f,           // nâng vùng tối (0..0.06)
    val sat: Float = 0f,            // cộng vào hệ số bão hoà (0.1 = +10%)
    val temp: Float = 0f,           // -1 lạnh .. 1 ấm
    val tint: Float = 0f,           // -1 lục lam .. 1 đỏ sậm
    val tone: Float = 0f,           // -1 tối hơn .. 1 sáng hơn (gamma)
    val skinR: Float = 0f,          // hệ số nhân kênh trên vùng da (0.03 = +3%)
    val skinG: Float = 0f,
    val skinB: Float = 0f,
    val skinSat: Float = 0f,        // đổi bão hoà riêng vùng da
    val shR: Float = 0f,            // cộng vào vùng tối (đơn vị 0..255)
    val shG: Float = 0f,
    val shB: Float = 0f,
    val hiR: Float = 0f,            // cộng vào vùng sáng
    val hiG: Float = 0f,
    val hiB: Float = 0f,
    val mono: Boolean = false,
    /** Màu hiện trên ô: [màu trên, màu dưới]. */
    val accent: IntArray = intArrayOf(0xFFE6E6E6.toInt(), 0xFF8A8A90.toInt())
) {
    companion object {
        val all: List<PaletteStyle> = listOf(
            PaletteStyle("Standard", "Chuẩn", 0),
            // ---- Undertones: chỉnh theo tông da
            PaletteStyle("Amber", "Hổ phách", 0, sat = 0.04f, temp = 0.08f, skinR = 0.04f, skinG = 0.015f, skinB = -0.06f,
                accent = intArrayOf(0xFFFFB14A.toInt(), 0xFFC76A1E.toInt())),
            PaletteStyle("Cool Rose", "Hồng lạnh", 0, temp = -0.08f, tint = 0.05f, skinR = 0.015f, skinG = -0.03f, skinB = 0.035f,
                accent = intArrayOf(0xFFF59AB7.toInt(), 0xFFB46A9C.toInt())),
            PaletteStyle("Gold", "Vàng kim", 0, sat = 0.03f, temp = 0.12f, skinR = 0.03f, skinG = 0.03f, skinB = -0.07f,
                hiR = 4f, hiG = 3f, hiB = -4f,
                accent = intArrayOf(0xFFFFD35C.toInt(), 0xFFD19A1F.toInt())),
            PaletteStyle("Neutral", "Trung tính", 0, temp = -0.02f, skinR = -0.02f, skinB = 0.025f, skinSat = -0.10f,
                accent = intArrayOf(0xFFDCDCDC.toInt(), 0xFFA9A6A0.toInt())),
            PaletteStyle("Rose Gold", "Vàng hồng", 0, temp = 0.03f, tint = 0.04f, skinR = 0.03f, skinG = -0.012f, skinB = 0.006f,
                accent = intArrayOf(0xFFF3B7A6.toInt(), 0xFFC98676.toInt())),
            // ---- Mood: chỉnh theo cảm xúc
            PaletteStyle("Cozy", "Ấm áp", 1, contrast = -0.03f, lift = 0.02f, sat = -0.05f, temp = 0.14f, tone = 0.04f,
                shR = 6f, shG = 2f, shB = -4f,
                accent = intArrayOf(0xFFE9A15A.toInt(), 0xFF8A4B2A.toInt())),
            PaletteStyle("Dramatic", "Kịch tính", 1, contrast = 0.20f, sat = -0.10f, tone = -0.12f,
                shR = -3f, shG = 0f, shB = 6f,
                accent = intArrayOf(0xFF8E8E98.toInt(), 0xFF1E1E26.toInt())),
            PaletteStyle("Ethereal", "Mơ màng", 1, contrast = -0.10f, lift = 0.04f, sat = -0.12f, temp = -0.03f, tone = 0.15f,
                hiR = 4f, hiG = 0f, hiB = 6f,
                accent = intArrayOf(0xFFD9E4FF.toInt(), 0xFFF2D3E6.toInt())),
            PaletteStyle("Luminous", "Rực sáng", 1, contrast = 0.03f, sat = 0.08f, temp = 0.03f, tone = 0.20f,
                accent = intArrayOf(0xFFFFF1B8.toInt(), 0xFFFFB54A.toInt())),
            PaletteStyle("Muted B&W", "Đen trắng dịu", 1, contrast = 0.05f, lift = 0.05f, mono = true,
                accent = intArrayOf(0xFFBFBFC4.toInt(), 0xFF6C6C72.toInt())),
            PaletteStyle("Natural", "Tự nhiên", 1, contrast = 0.04f, sat = -0.04f,
                accent = intArrayOf(0xFF7FD6A0.toInt(), 0xFF4FA3C7.toInt())),
            PaletteStyle("Quiet", "Tĩnh lặng", 1, contrast = -0.05f, lift = 0.02f, sat = -0.25f, temp = -0.04f,
                accent = intArrayOf(0xFFA9B8C4.toInt(), 0xFF78858F.toInt())),
            PaletteStyle("Stark B&W", "Đen trắng gắt", 1, contrast = 0.40f, mono = true,
                accent = intArrayOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt())),
            PaletteStyle("Vibrant", "Rực rỡ", 1, contrast = 0.08f, sat = 0.35f,
                accent = intArrayOf(0xFFFF5F8A.toInt(), 0xFF2EC4F0.toInt()))
        )
    }
}

/** Lựa chọn hiện tại: kiểu + ba thông số (tất cả -100..100, riêng cường độ 0..100). */
data class PaletteSel(
    val style: Int = 0,
    val tone: Int = 0,       // trục dọc của bảng chạm: tối (-) ↔ sáng (+)
    val color: Int = 0,      // trục ngang: nhạt màu (-) ↔ đậm màu (+)
    val strength: Int = 0    // cường độ hiệu ứng của kiểu (Palette)
) {
    private val styleOn: Boolean get() = style in 1 until PaletteStyle.all.size && strength > 0

    /** true = ảnh Standard (không áp gì). */
    val isNeutral: Boolean get() = !styleOn && tone == 0 && color == 0

    fun toJson(): JSONObject = JSONObject().put("s", style).put("t", tone).put("c", color).put("p", strength)

    /** Đặt kiểu mới: về giữa bảng chạm, cường độ mặc định 100 (Standard thì 0). */
    fun withStyle(i: Int): PaletteSel =
        PaletteSel(i.coerceIn(0, PaletteStyle.all.size - 1), 0, 0, if (i <= 0) 0 else 100)

    /** Bộ xử lý một mảng pixel ARGB (dùng cho từng dải ảnh), null nếu là Standard. */
    fun processor(): ((IntArray, Int, Int) -> Unit)? {
        if (isNeutral) return null
        val st = PaletteStyle.all[style.coerceIn(0, PaletteStyle.all.size - 1)]
        val k = if (styleOn) strength / 100f else 0f

        val contrast = st.contrast * k
        val lift = st.lift * k
        val toneTot = (st.tone * k + tone / 100f).coerceIn(-1.4f, 1.4f)
        val satTot = st.sat * k + color / 100f * 0.7f
        val temp = st.temp * k
        val tint = st.tint * k
        val monoAmt = if (st.mono) k else 0f
        val gr = (1f + 0.14f * temp) * (1f + 0.05f * tint)
        val gg = 1f - 0.10f * tint
        val gb = (1f - 0.14f * temp) * (1f + 0.05f * tint)
        val skR = st.skinR * k; val skG = st.skinG * k; val skB = st.skinB * k; val skS = st.skinSat * k
        val hasSkin = skR != 0f || skG != 0f || skB != 0f || skS != 0f
        val shR = st.shR * k; val shG = st.shG * k; val shB = st.shB * k
        val hiR = st.hiR * k; val hiG = st.hiG * k; val hiB = st.hiB * k
        val hasSplit = shR != 0f || shG != 0f || shB != 0f || hiR != 0f || hiG != 0f || hiB != 0f
        val hasGain = temp != 0f || tint != 0f

        // đường cong chung: gamma (Tone) → chữ S (tương phản) → nâng đen
        val a = (contrast * 2.5f).coerceIn(-1f, 1f)
        val gamma = 2f.pow(-0.6f * toneTot)
        val lut = FloatArray(256) { i ->
            var x = (i / 255f).pow(gamma)
            val s = x * x * (3f - 2f * x)
            x = x * (1f - a) + s * a
            x = lift + x * (1f - lift)
            x.coerceIn(0f, 1f) * 255f
        }

        return { buf, from, to ->
            for (i in from until to) {
                val p = buf[i]
                var r = lut[(p shr 16) and 255]
                var g = lut[(p shr 8) and 255]
                var b = lut[p and 255]
                val l = r * 0.2113f + g * 0.7148f + b * 0.0742f

                if (monoAmt > 0f) {
                    r += (l - r) * monoAmt
                    g += (l - g) * monoAmt
                    b += (l - b) * monoAmt
                }
                if (monoAmt < 0.999f && satTot != 0f) {
                    var f = 1f + satTot
                    if (satTot > 0f) {
                        // tăng bão hoà kiểu vibrance: màu đã đậm thì tăng ít hơn
                        val mx = max(r, max(g, b))
                        val mn = min(r, min(g, b))
                        val s = if (mx > 1f) (mx - mn) / mx else 0f
                        f = 1f + satTot * (1f - 0.5f * s)
                    }
                    if (f < 0f) f = 0f
                    r = l + (r - l) * f
                    g = l + (g - l) * f
                    b = l + (b - l) * f
                }
                if (hasGain) { r *= gr; g *= gg; b *= gb }

                if (hasSkin) {
                    val w = skinWeight(r, g, b)
                    if (w > 0f) {
                        r *= 1f + w * skR
                        g *= 1f + w * skG
                        b *= 1f + w * skB
                        if (skS != 0f) {
                            val l2 = r * 0.2113f + g * 0.7148f + b * 0.0742f
                            val f = 1f + w * skS
                            r = l2 + (r - l2) * f
                            g = l2 + (g - l2) * f
                            b = l2 + (b - l2) * f
                        }
                    }
                }
                if (hasSplit) {
                    val ls = (l / 255f).coerceIn(0f, 1f)
                    val ws = (1f - ls) * (1f - ls)
                    val wh = ls * ls
                    r += ws * shR + wh * hiR
                    g += ws * shG + wh * hiG
                    b += ws * shB + wh * hiB
                }
                val ri = (r + 0.5f).toInt().coerceIn(0, 255)
                val gi = (g + 0.5f).toInt().coerceIn(0, 255)
                val bi = (b + 0.5f).toInt().coerceIn(0, 255)
                buf[i] = (p and 0xFF000000.toInt()) or (ri shl 16) or (gi shl 8) or bi
            }
        }
    }

    /**
     * Ma trận xấp xỉ để xem trước trực tiếp: chỉ có phần toàn ảnh (bão hoà, ấm lạnh, tương phản, sáng tối).
     * Phần theo vùng (da, vùng tối/sáng) cần xử lí từng điểm ảnh nên chỉ thấy trên ảnh đã chụp.
     */
    fun previewMatrix(): ColorMatrix? {
        if (isNeutral) return null
        val st = PaletteStyle.all[style.coerceIn(0, PaletteStyle.all.size - 1)]
        val k = if (styleOn) strength / 100f else 0f
        val contrast = 1f + st.contrast * k
        val lift = st.lift * k
        val toneTot = (st.tone * k + tone / 100f).coerceIn(-1.4f, 1.4f)
        val monoAmt = if (st.mono) k else 0f
        val satF = ((1f + st.sat * k + color / 100f * 0.7f) * (1f - monoAmt)).coerceAtLeast(0f)
        val temp = st.temp * k
        val tint = st.tint * k
        val er = (1f + 0.14f * temp) * (1f + 0.05f * tint)
        val eg = 1f - 0.10f * tint
        val eb = (1f - 0.14f * temp) * (1f + 0.05f * tint)

        val cm = ColorMatrix()
        cm.setSaturation(satF)
        val scale = (1f - lift) * contrast
        // gamma 2^(-0.6·tone) làm điểm xám giữa lệch ≈ 0.13·tone
        val off = 255f * (lift + (1f - lift) * 0.5f * (1f - contrast) + 0.13f * toneTot)
        cm.postConcat(
            ColorMatrix(
                floatArrayOf(
                    scale * er, 0f, 0f, 0f, off,
                    0f, scale * eg, 0f, 0f, off,
                    0f, 0f, scale * eb, 0f, off,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        return cm
    }

    companion object {
        fun fromJson(o: JSONObject?): PaletteSel =
            if (o == null) PaletteSel()
            else PaletteSel(o.optInt("s"), o.optInt("t"), o.optInt("c"), o.optInt("p"))

        private fun trap(x: Float, a: Float, b: Float, c: Float, d: Float): Float = when {
            x <= a || x >= d -> 0f
            x < b -> (x - a) / (b - a)
            x <= c -> 1f
            else -> (d - x) / (d - c)
        }

        /**
         * Độ "giống da" của một điểm ảnh, 0..1: hue cam–đỏ (kênh đỏ lớn nhất), bão hoà vừa, không quá tối / cháy.
         * Mịn ở các mép để vùng da chuyển dần sang vùng khác, không bị viền.
         */
        fun skinWeight(r: Float, g: Float, b: Float): Float {
            if (r < g || r < b) return 0f
            val mn = if (g < b) g else b
            val d = r - mn
            if (d < 8f || r < 50f) return 0f
            val hue = 60f * (g - b) / d            // -60..60 (đỏ hơi hồng → cam → vàng)
            val hw = trap(hue, -12f, 2f, 36f, 52f)
            if (hw <= 0f) return 0f
            val sw = trap(d / r, 0.10f, 0.20f, 0.60f, 0.80f)
            if (sw <= 0f) return 0f
            return hw * sw * trap(r, 50f, 100f, 235f, 256f)
        }
    }
}
