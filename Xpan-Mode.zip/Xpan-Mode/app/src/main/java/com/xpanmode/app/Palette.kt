package com.xpanmode.app

import android.graphics.ColorMatrix
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow

/**
 * Bảng màu (kiểu Photographic Styles): danh sách "kiểu" chính là các bộ lọc của app (có sẵn + của tôi),
 * cường độ của kiểu là thanh Palette (Prefs.filterStrength, xem XpanFilter.scaled), còn hai trục của bảng chạm
 * là Tone (sáng/tối) và Color (nhạt/đậm màu) – lưu ở đây và áp SAU bộ lọc.
 * Tone = 0 và Color = 0 thì không làm gì.
 */
data class PaletteSel(
    val tone: Int = 0,    // trục dọc của bảng chạm: tối (-100) ↔ sáng (+100)
    val color: Int = 0    // trục ngang: nhạt màu (-100) ↔ đậm màu (+100)
) {
    val isNeutral: Boolean get() = tone == 0 && color == 0

    fun toJson(): JSONObject = JSONObject().put("t", tone).put("c", color)

    /** Bộ xử lý một mảng pixel ARGB (dùng cho từng dải ảnh), null nếu không chỉnh gì. */
    fun processor(): ((IntArray, Int, Int) -> Unit)? {
        if (isNeutral) return null
        val satTot = color / 100f * 0.7f
        // gamma: Tone dương làm sáng vùng giữa, giữ nguyên đen và trắng
        val gamma = 2f.pow(-0.6f * (tone / 100f))
        val lut = FloatArray(256) { i -> (i / 255f).pow(gamma) * 255f }
        return { buf, from, to ->
            for (i in from until to) {
                val p = buf[i]
                var r = lut[(p shr 16) and 255]
                var g = lut[(p shr 8) and 255]
                var b = lut[p and 255]
                if (satTot != 0f) {
                    val l = r * 0.2113f + g * 0.7148f + b * 0.0742f
                    var f = 1f + satTot
                    if (satTot > 0f) {
                        // tăng bão hoà kiểu vibrance: màu đã đậm thì tăng ít hơn
                        val mx = max(r, max(g, b))
                        val mn = min(r, min(g, b))
                        val s = if (mx > 1f) (mx - mn) / mx else 0f
                        f = 1f + satTot * (1f - 0.5f * s)
                    }
                    if (f < 0f) f = 0f
                    r = l + (r - l) * f
                    g = l + (g - l) * f
                    b = l + (b - l) * f
                }
                val ri = (r + 0.5f).toInt().coerceIn(0, 255)
                val gi = (g + 0.5f).toInt().coerceIn(0, 255)
                val bi = (b + 0.5f).toInt().coerceIn(0, 255)
                buf[i] = (p and 0xFF000000.toInt()) or (ri shl 16) or (gi shl 8) or bi
            }
        }
    }

    /** Ma trận xấp xỉ để xem trước trực tiếp (gamma 2^(-0.6·tone) làm điểm xám giữa lệch ≈ 0.13·tone). */
    fun previewMatrix(): ColorMatrix? {
        if (isNeutral) return null
        val cm = ColorMatrix()
        cm.setSaturation((1f + color / 100f * 0.7f).coerceAtLeast(0f))
        val off = 255f * 0.13f * (tone / 100f)
        cm.postConcat(
            ColorMatrix(
                floatArrayOf(
                    1f, 0f, 0f, 0f, off,
                    0f, 1f, 0f, 0f, off,
                    0f, 0f, 1f, 0f, off,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        return cm
    }

    companion object {
        fun fromJson(o: JSONObject?): PaletteSel = if (o == null) PaletteSel() else PaletteSel(o.optInt("t"), o.optInt("c"))
    }
}
