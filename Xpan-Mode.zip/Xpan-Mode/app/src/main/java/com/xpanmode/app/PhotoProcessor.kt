package com.xpanmode.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.os.Build
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

class Saved(val uri: Uri, val base: String, val thumb: Bitmap?, val big: Bitmap?, val framed: Boolean = false)

data class Caption(val device: String, val fl: Int, val aperture: String, val shutter: String, val iso: Int)

object PhotoProcessor {
    private const val DIR = "Pictures/Xpan-Mode"

    private fun orientTag(rot: Int) = when (rot) {
        90 -> ExifInterface.ORIENTATION_ROTATE_90
        180 -> ExifInterface.ORIENTATION_ROTATE_180
        270 -> ExifInterface.ORIENTATION_ROTATE_270
        else -> ExifInterface.ORIENTATION_NORMAL
    }

    fun defaultDeviceName(): String {
        val man = Build.MANUFACTURER ?: ""
        val model = Build.MODEL ?: ""
        return if (model.startsWith(man, ignoreCase = true)) model else "${man.uppercase(Locale.US)} $model"
    }

    /**
     * Cắt khung 65:24 từ ảnh gốc độ phân giải tối đa (chỉ giải mã đúng vùng cần), áp bộ lọc,
     * lưu JPEG chất lượng 100 kèm EXIF đầy đủ vào Pictures/Xpan-Mode.
     */
    fun errText(t: Throwable): String {
        val top = t.stackTrace.firstOrNull()
        return "${t.javaClass.simpleName}: ${t.message ?: "(không có mô tả)"}" +
            (if (top != null) " @${top.fileName}:${top.lineNumber}" else "")
    }

    fun process(ctx: Context, shot: CameraController.ShotResult, filter: XpanFilter, prefs: Prefs): Saved {
        val m = shot.meta
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val base = "XPAN_$stamp"

        @Suppress("DEPRECATION")
        val dec = BitmapRegionDecoder.newInstance(shot.jpeg.absolutePath, false)
            ?: throw IllegalStateException("Không đọc được ảnh gốc")
        val bw = dec.width
        val bh = dec.height
        val z = m.zoom.coerceAtLeast(1f)
        val vertical = m.rotation == 90 || m.rotation == 270
        // tỉ lệ khung (rộng/cao) trong không gian buffer của cảm biến
        val aspect = if (vertical) 24f / 65f else 65f / 24f
        var cw = bw / z
        var ch = cw / aspect
        if (ch > bh / z) { ch = bh / z; cw = ch * aspect }
        val cwi = (cw.toInt() / 2) * 2
        val chi = (ch.toInt() / 2) * 2
        val left = (bw - cwi) / 2
        val top = (bh - chi) / 2
        val region = Rect(left, top, left + cwi, top + chi)

        var sample = 1
        var bmp: Bitmap
        while (true) {
            try {
                bmp = Bitmap.createBitmap(cwi / sample, chi / sample, Bitmap.Config.ARGB_8888)
                break
            } catch (e: OutOfMemoryError) {
                sample *= 2
                if (sample > 8) throw e
            }
        }
        val proc = filter.processor()
        val opts = BitmapFactory.Options().apply {
            inPreferredConfig = Bitmap.Config.ARGB_8888
            inSampleSize = sample
        }
        // Ít dải lớn (~3) thay vì nhiều dải nhỏ: mỗi lần giải mã vùng JPEG phải đọc lại phần đầu tệp
        val rowsSrc = maxOf(512, ((chi / 3 + 255) / 256) * 256)
        var buf = IntArray(bmp.width * (rowsSrc / sample + 2))
        var y = 0
        val cores = Runtime.getRuntime().availableProcessors().coerceIn(1, 8)
        while (y < chi) {
            val n = minOf(rowsSrc, chi - y)
            val strip = dec.decodeRegion(Rect(left, top + y, left + cwi, top + y + n), opts)
                ?: throw IllegalStateException("decodeRegion trả về null")
            val sw = strip.width
            val sh = strip.height
            if (buf.size < sw * sh) buf = IntArray(sw * sh)
            strip.getPixels(buf, 0, sw, 0, 0, sw, sh)
            strip.recycle()
            // lọc màu song song trên nhiều lõi CPU
            val total = sw * sh
            val chunk = (total + cores - 1) / cores
            val b = buf
            java.util.stream.IntStream.range(0, cores).parallel().forEach { k ->
                val from = k * chunk
                val to = minOf(total, from + chunk)
                if (from < to) proc(b, from, to)
            }
            val dy = y / sample
            val w2 = minOf(sw, bmp.width)
            val h2 = minOf(sh, bmp.height - dy)
            if (h2 > 0) bmp.setPixels(buf, 0, sw, 0, dy, w2, h2)
            y += n
        }
        dec.recycle()
        if (filter.sharp > 0f) sharpen(bmp, filter.sharp * 0.9f)

        // ảnh xem trước nhỏ (đã xoay đúng chiều) lấy thẳng từ bitmap đang có, không phải giải mã lại
        val big = try { scaledUpright(bmp, 1800, m.rotation) } catch (t: Throwable) { null }
        val thumb = try { if (big != null) scaledUpright(big, 256, 0) else null } catch (t: Throwable) { null }

        val out = File(ctx.cacheDir, "$base.jpg")
        FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 98, it) }
        val outW = bmp.width
        val outH = bmp.height
        bmp.recycle()

        writeExif(out, m, outW, outH)
        if (prefs.autoFrame) {
            // Chế độ "ảnh có khung": CHỈ lưu ảnh có khung + watermark, không lưu ảnh không khung
            val dev = prefs.deviceName.ifBlank { defaultDeviceName() }
            val ff = File(ctx.cacheDir, "${base}_frame.jpg")
            try {
                val fb = compose(ctx, Uri.fromFile(out), 4096, dev, prefs.watermark)
                    ?: throw IllegalStateException("Không tạo được ảnh khung")
                try { FileOutputStream(ff).use { fb.compress(Bitmap.CompressFormat.JPEG, 96, it) } } finally { fb.recycle() }
                val furi = saveFile(ctx, ff, "${base}_FRAME.jpg", "image/jpeg")
                return Saved(furi, base, thumb, big, true)
            } finally {
                ff.delete()
                out.delete()
            }
        }
        val uri = saveFile(ctx, out, "$base.jpg", "image/jpeg")
        out.delete()
        return Saved(uri, base, thumb, big)
    }

    /** Các file phụ (ảnh gốc full-frame, DNG) – chạy sau khi ảnh chính đã xong. */
    fun extras(ctx: Context, shot: CameraController.ShotResult, saved: Saved, prefs: Prefs): String? {
        val warns = ArrayList<String>()
        if (prefs.keepOriginal) {
            try { saveFile(ctx, shot.jpeg, "${saved.base}_FULL.jpg", "image/jpeg") }
            catch (t: Throwable) { warns.add("ảnh gốc: " + errText(t)) }
        }
        shot.dng?.let {
            try { saveFile(ctx, it, "${saved.base}.dng", "image/x-adobe-dng") }
            catch (t: Throwable) { warns.add("DNG: " + errText(t)) }
        }
        return if (warns.isEmpty()) null else "Đã lưu ảnh chính, nhưng lỗi " + warns.joinToString("; ")
    }

    /** Làm nét kiểu Laplace theo từng hàng (chỉ giữ 3 hàng trong bộ nhớ, không nhân đôi bitmap). */
    private fun sharpen(bmp: Bitmap, amount: Float) {
        val w = bmp.width
        val h = bmp.height
        if (w < 3 || h < 3 || amount <= 0f) return
        val k = (amount * 256f).toInt()
        var prev = IntArray(w)
        var cur = IntArray(w)
        var next = IntArray(w)
        val out = IntArray(w)
        bmp.getPixels(cur, 0, w, 0, 0, w, 1)
        System.arraycopy(cur, 0, prev, 0, w)
        bmp.getPixels(next, 0, w, 0, 1, w, 1)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val xl = if (x > 0) x - 1 else 0
                val xr = if (x < w - 1) x + 1 else x
                val c = cur[x]
                val u = prev[x]; val d = next[x]; val l = cur[xl]; val r = cur[xr]
                var rr = (c shr 16) and 255; var gg = (c shr 8) and 255; var bb = c and 255
                rr += ((4 * rr - (((u shr 16) and 255) + ((d shr 16) and 255) + ((l shr 16) and 255) + ((r shr 16) and 255))) * k) shr 8
                gg += ((4 * gg - (((u shr 8) and 255) + ((d shr 8) and 255) + ((l shr 8) and 255) + ((r shr 8) and 255))) * k) shr 8
                bb += ((4 * bb - ((u and 255) + (d and 255) + (l and 255) + (r and 255))) * k) shr 8
                out[x] = (c and 0xFF000000.toInt()) or (rr.coerceIn(0, 255) shl 16) or (gg.coerceIn(0, 255) shl 8) or bb.coerceIn(0, 255)
            }
            bmp.setPixels(out, 0, w, 0, y, w, 1)
            val t = prev; prev = cur; cur = next; next = t
            if (y + 2 < h) bmp.getPixels(next, 0, w, 0, y + 2, w, 1) else System.arraycopy(cur, 0, next, 0, w)
        }
    }

    private fun scaledUpright(src: Bitmap, maxW: Int, rot: Int): Bitmap {
        val sw = if (src.width > maxW) maxW else src.width
        val sh = (src.height * sw.toFloat() / src.width).roundToInt().coerceAtLeast(1)
        var b = if (sw == src.width) src else Bitmap.createScaledBitmap(src, sw, sh, true)
        if (rot != 0) {
            val mat = Matrix().apply { postRotate(rot.toFloat()) }
            val r = Bitmap.createBitmap(b, 0, 0, b.width, b.height, mat, true)
            if (r !== b && b !== src) b.recycle()
            b = r
        }
        return b
    }

    private fun writeExif(f: File, m: CameraController.ShotMeta, w: Int, h: Int) {
        val ex = ExifInterface(f)
        ex.setAttribute(ExifInterface.TAG_MAKE, Build.MANUFACTURER)
        ex.setAttribute(ExifInterface.TAG_MODEL, Build.MODEL)
        if (m.aperture > 0f) ex.setAttribute(ExifInterface.TAG_F_NUMBER, String.format(Locale.US, "%.1f", m.aperture))
        if (m.exposureNs > 0) ex.setAttribute(ExifInterface.TAG_EXPOSURE_TIME, String.format(Locale.US, "%.6f", m.exposureNs / 1e9))
        if (m.iso > 0) ex.setAttribute(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, m.iso.toString())
        ex.setAttribute(ExifInterface.TAG_FOCAL_LENGTH, "${(m.focalMm * 1000).toInt()}/1000")
        ex.setAttribute(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, (m.eq35 * m.zoom).roundToInt().toString())
        ex.setAttribute(ExifInterface.TAG_DATETIME_ORIGINAL, SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).format(Date()))
        ex.setAttribute(ExifInterface.TAG_ORIENTATION, orientTag(m.rotation).toString())
        ex.setAttribute(ExifInterface.TAG_SOFTWARE, "Xpan-Mode")
        ex.setAttribute(ExifInterface.TAG_PIXEL_X_DIMENSION, w.toString())
        ex.setAttribute(ExifInterface.TAG_PIXEL_Y_DIMENSION, h.toString())
        ex.saveAttributes()
    }

    fun saveFile(ctx: Context, file: File, name: String, mime: String): Uri {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, mime)
            put(MediaStore.Images.Media.RELATIVE_PATH, DIR)
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val cr = ctx.contentResolver
        val uri = cr.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Không tạo được file trong thư viện")
        val os = cr.openOutputStream(uri, "w")
            ?: cr.openFileDescriptor(uri, "w")?.let { ParcelFileDescriptor.AutoCloseOutputStream(it) }
        if (os == null) {
            cr.delete(uri, null, null)
            throw IOException("MediaStore không mở được luồng ghi cho $name")
        }
        try {
            os.use { o -> FileInputStream(file).use { it.copyTo(o) } }
        } catch (t: Throwable) {
            cr.delete(uri, null, null)
            throw t
        }
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        cr.update(uri, values, null, null)
        return uri
    }

    /** Giải mã ảnh đã xoay đúng chiều theo EXIF, rộng tối đa maxW. */
    fun decodeUpright(ctx: Context, uri: Uri, maxW: Int): Bitmap? {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= maxW) sample *= 2
        val o = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return null
        val ori = cr.openInputStream(uri)?.use {
            ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
        } ?: ExifInterface.ORIENTATION_NORMAL
        val deg = when (ori) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (deg != 0f) {
            val mat = Matrix().apply { postRotate(deg) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, mat, true)
        }
        if (bmp.width > maxW) {
            val nh = (bmp.height * maxW.toFloat() / bmp.width).roundToInt()
            bmp = Bitmap.createScaledBitmap(bmp, maxW, nh, true)
        }
        return bmp
    }

    fun readCaption(ctx: Context, uri: Uri, device: String): Caption {
        var ap = 0.0
        var exp = 0.0
        var iso = 0
        var fl = 0
        ctx.contentResolver.openInputStream(uri)?.use {
            val ex = ExifInterface(it)
            ap = ex.getAttributeDouble(ExifInterface.TAG_F_NUMBER, 0.0)
            exp = ex.getAttributeDouble(ExifInterface.TAG_EXPOSURE_TIME, 0.0)
            iso = ex.getAttributeInt(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, 0)
            fl = ex.getAttributeInt(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, 0)
        }
        val sh = if (exp > 0 && exp < 1) "1/${(1.0 / exp).roundToInt()}" else String.format(Locale.US, "%.1fs", exp)
        val apS = if (ap > 0) String.format(Locale.US, "f/%.1f", ap) else "—"
        return Caption(device, fl, apS, sh, iso)
    }

    /** Ảnh có khung trắng + chữ HASSELBLAD + thông số, giống màn hình xem lại trong video mẫu. */
    fun compose(ctx: Context, uri: Uri, maxW: Int, device: String, style: Int = 0): Bitmap? {
        val photo = decodeUpright(ctx, uri, maxW) ?: return null
        val cap = readCaption(ctx, uri, device)
        return when (style) {
            1 -> composeGallery(ctx, photo, cap)
            2 -> composeStrip(photo, cap)
            3 -> composeOrange(photo, cap)
            else -> composeClassic(photo, cap)
        }
    }

    /** Kiểu 1 "Gallery": viền trắng rộng, logo XPAN góc trên trái, tên máy dưới trái, HASSELBLAD dưới phải. */
    private fun composeGallery(ctx: Context, photo: Bitmap, cap: Caption): Bitmap {
        val pw = photo.width
        val ph = photo.height
        val m = (pw * 0.064f).toInt()
        val top = (pw * 0.125f).toInt()
        val bottom = (pw * 0.131f).toInt()
        val out = Bitmap.createBitmap(pw + 2 * m, ph + top + bottom, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        cv.drawColor(Color.WHITE)
        cv.drawBitmap(photo, m.toFloat(), top.toFloat(), null)
        photo.recycle()
        val tw = out.width.toFloat()
        val pad = tw * 0.027f
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

        val logo = try { BitmapFactory.decodeResource(ctx.resources, R.drawable.xpan_logo_dark) } catch (t: Throwable) { null }
        if (logo != null) {
            val lw = tw * 0.105f
            val lh = lw * logo.height / logo.width
            val cy = top * 0.34f
            cv.drawBitmap(logo, null, android.graphics.RectF(pad, cy - lh / 2f, pad + lw, cy + lh / 2f), p)
            logo.recycle()
        } else {
            p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD_ITALIC)
            p.textSize = tw * 0.03f
            p.color = 0xFF111111.toInt()
            cv.drawText("XPAN", pad, top * 0.5f, p)
        }

        val base = top + ph + bottom * 0.70f
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        p.textSize = tw * 0.0195f
        p.color = 0xFF111111.toInt()
        p.textAlign = Paint.Align.LEFT
        cv.drawText(cap.device, pad, base, p)

        p.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
        p.textSize = tw * 0.0215f
        p.letterSpacing = 0.3f
        p.textAlign = Paint.Align.RIGHT
        cv.drawText("HASSELBLAD", tw - pad, base, p)
        return out
    }

    /** Kiểu 2 "Dải thông số": ảnh tràn viền, dải trắng mỏng bên dưới: tên máy trái; HASSELBLAD + thông số phải. */
    private fun composeStrip(photo: Bitmap, cap: Caption): Bitmap {
        val pw = photo.width
        val ph = photo.height
        val strip = (pw * 0.068f).toInt()
        val out = Bitmap.createBitmap(pw, ph + strip, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        cv.drawColor(Color.WHITE)
        cv.drawBitmap(photo, 0f, 0f, null)
        photo.recycle()
        val w = pw.toFloat()
        val pad = w * 0.022f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        p.textSize = w * 0.0155f
        p.color = 0xFF111111.toInt()
        p.textAlign = Paint.Align.LEFT
        cv.drawText(cap.device, pad, ph + strip / 2f + p.textSize * 0.35f, p)

        p.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
        p.textSize = w * 0.0105f
        p.letterSpacing = 0.25f
        p.textAlign = Paint.Align.RIGHT
        cv.drawText("HASSELBLAD", w - pad, ph + strip * 0.42f, p)

        val spec = "${cap.fl}mm  ${cap.aperture}  ${cap.shutter}${if (cap.shutter.endsWith("s")) "" else "s"}  ISO${cap.iso}"
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        p.textSize = w * 0.0075f
        p.letterSpacing = 0f
        p.color = 0xFF444444.toInt()
        val by = ph + strip * 0.76f
        cv.drawText(spec, w - pad, by, p)
        val tx = w - pad - p.measureText(spec)
        p.color = 0xFFF47B20.toInt()
        cv.drawCircle(tx - w * 0.0085f, by - p.textSize * 0.36f, w * 0.0042f, p)
        return out
    }

    /** Kiểu 3 "Dải cam": ảnh tràn viền, dải cam mỏng bên dưới, chữ trắng căn giữa: tên máy | HASSELBLAD. */
    private fun composeOrange(photo: Bitmap, cap: Caption): Bitmap {
        val pw = photo.width
        val ph = photo.height
        val strip = (pw * 0.042f).toInt()
        val out = Bitmap.createBitmap(pw, ph + strip, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        cv.drawColor(0xFFEF6A1B.toInt())
        cv.drawBitmap(photo, 0f, 0f, null)
        photo.recycle()
        val w = pw.toFloat()
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        p.textSize = w * 0.0155f
        p.letterSpacing = 0.04f
        p.color = Color.WHITE
        p.textAlign = Paint.Align.CENTER
        cv.drawText("${cap.device}  |  HASSELBLAD", w / 2f, ph + strip / 2f + p.textSize * 0.35f, p)
        return out
    }

    /** Kiểu 0 cổ điển: HASSELBLAD giữa trên, tên máy + dòng thông số giữa dưới. */
    private fun composeClassic(photo: Bitmap, cap: Caption): Bitmap {
        val pw = photo.width
        val ph = photo.height
        val m = (pw * 0.012f).toInt()
        val top = (pw * 0.075f).toInt()
        val bottom = (pw * 0.115f).toInt()
        val out = Bitmap.createBitmap(pw + 2 * m, ph + top + bottom, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        cv.drawColor(Color.WHITE)
        cv.drawBitmap(photo, m.toFloat(), top.toFloat(), null)
        photo.recycle()
        val cx = out.width / 2f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)

        p.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
        p.textSize = pw * 0.017f
        p.letterSpacing = 0.4f
        p.color = 0xFF111111.toInt()
        p.textAlign = Paint.Align.CENTER
        cv.drawText("HASSELBLAD", cx, top * 0.62f, p)

        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
        p.letterSpacing = 0f
        p.textSize = pw * 0.0175f
        cv.drawText(cap.device, cx, top + ph + bottom * 0.38f, p)

        val items = listOf(
            "FL" to "${cap.fl}mm", "Aperture" to cap.aperture, "Shutter" to cap.shutter, "ISO" to cap.iso.toString()
        )
        val small = pw * 0.0095f
        p.textSize = small
        p.textAlign = Paint.Align.LEFT
        val gapIn = pw * 0.008f
        val gapOut = pw * 0.022f
        var total = 0f
        for ((a, b) in items) total += p.measureText(a) + gapIn + p.measureText(b)
        total += gapOut * (items.size - 1)
        var x = cx - total / 2f
        val y = top + ph + bottom * 0.64f
        for ((a, b) in items) {
            p.color = 0xFF8A8A8A.toInt()
            cv.drawText(a, x, y, p)
            x += p.measureText(a) + gapIn
            p.color = 0xFF222222.toInt()
            cv.drawText(b, x, y, p)
            x += p.measureText(b) + gapOut
        }
        return out
    }

    fun saveFramed(ctx: Context, uri: Uri, device: String, style: Int = 0): Uri? {
        val bmp = compose(ctx, uri, 4096, device, style) ?: return null
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val f = File(ctx.cacheDir, "frame_$stamp.jpg")
        FileOutputStream(f).use { bmp.compress(Bitmap.CompressFormat.JPEG, 96, it) }
        bmp.recycle()
        val res = saveFile(ctx, f, "XPAN_${stamp}_FRAME.jpg", "image/jpeg")
        f.delete()
        return res
    }
}
