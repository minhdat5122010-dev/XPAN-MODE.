package com.xpanmode.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Biểu tượng của từng dòng cài đặt. */
enum class SIcon { RAW, ORIGINAL, VOLUME, SHUTTER, BEEP, SILENT, DEVICE, LENS, PLAIN, FRAMED, DEV }

/** Ô biểu tượng bo góc, nét cam trên nền cam mờ. */
class SettingIconView(ctx: Context, private val kind: SIcon) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dn = resources.displayMetrics.density
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = 0x26F47B20
        c.drawRoundRect(0f, 0f, w, h, 12f * dn, 12f * dn, p)
        val cx = w / 2f
        val cy = h / 2f
        val u = min(w, h) / 24f           // 1 đơn vị = 1/24 ô
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.7f * dn
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = ORANGE
        when (kind) {
            SIcon.RAW -> {
                c.drawRoundRect(cx - 8 * u, cy - 5.5f * u, cx + 8 * u, cy + 5.5f * u, 2.5f * u, 2.5f * u, p)
                p.style = Paint.Style.FILL
                p.typeface = Typeface.DEFAULT_BOLD
                p.textAlign = Paint.Align.CENTER
                p.textSize = 6.4f * u
                c.drawText("RAW", cx, cy + 2.3f * u, p)
                p.typeface = Typeface.DEFAULT
            }
            SIcon.ORIGINAL -> {
                c.drawRoundRect(cx - 8.5f * u, cy - 6.5f * u, cx + 8.5f * u, cy + 6.5f * u, 2f * u, 2f * u, p)
                p.pathEffect = android.graphics.DashPathEffect(floatArrayOf(2.2f * u, 2f * u), 0f)
                c.drawRect(cx - 4.5f * u, cy - 3f * u, cx + 4.5f * u, cy + 3f * u, p)
                p.pathEffect = null
            }
            SIcon.VOLUME -> {
                // điện thoại nằm ngang + hai phím âm lượng ở cạnh trên
                c.drawRoundRect(cx - 8 * u, cy - 4.5f * u, cx + 8 * u, cy + 6 * u, 2.5f * u, 2.5f * u, p)
                c.drawLine(cx - 3.5f * u, cy - 7.5f * u, cx - 3.5f * u, cy - 4.5f * u, p)
                c.drawLine(cx + 0.5f * u, cy - 7.5f * u, cx + 0.5f * u, cy - 4.5f * u, p)
                c.drawCircle(cx + 4.8f * u, cy + 0.8f * u, 1.3f * u, p)
            }
            SIcon.SHUTTER -> {
                // thân máy ảnh + ống kính
                c.drawRoundRect(cx - 8.5f * u, cy - 4.5f * u, cx + 8.5f * u, cy + 6.5f * u, 2.5f * u, 2.5f * u, p)
                c.drawLine(cx - 3f * u, cy - 4.5f * u, cx - 1.8f * u, cy - 7f * u, p)
                c.drawLine(cx - 1.8f * u, cy - 7f * u, cx + 1.8f * u, cy - 7f * u, p)
                c.drawLine(cx + 1.8f * u, cy - 7f * u, cx + 3f * u, cy - 4.5f * u, p)
                c.drawCircle(cx, cy + 1f * u, 3.4f * u, p)
            }
            SIcon.BEEP -> {
                // ô lấy nét + sóng âm
                val a = 4.5f * u
                val l = 2.6f * u
                val x0 = cx - 7f * u; val x1 = cx + 3f * u
                val y0 = cy - 5f * u; val y1 = cy + 5f * u
                c.drawLine(x0, y0 + l, x0, y0, p); c.drawLine(x0, y0, x0 + l, y0, p)
                c.drawLine(x1 - l, y0, x1, y0, p); c.drawLine(x1, y0, x1, y0 + l, p)
                c.drawLine(x0, y1 - l, x0, y1, p); c.drawLine(x0, y1, x0 + l, y1, p)
                c.drawLine(x1 - l, y1, x1, y1, p); c.drawLine(x1, y1, x1, y1 - l, p)
                p.style = Paint.Style.FILL
                c.drawCircle((x0 + x1) / 2f, cy, 1.1f * u, p)
                p.style = Paint.Style.STROKE
                val r = RectF(cx + 4f * u - a * 0.6f, cy - a, cx + 4f * u + a * 0.6f + 2 * u, cy + a)
                c.drawArc(r, -50f, 100f, false, p)
            }
            SIcon.SILENT -> {
                // chuông có gạch chéo
                path.reset()
                path.moveTo(cx - 6f * u, cy + 4f * u)
                path.lineTo(cx + 6f * u, cy + 4f * u)
                path.lineTo(cx + 4.4f * u, cy + 2.2f * u)
                path.lineTo(cx + 4.4f * u, cy - 1.5f * u)
                path.cubicTo(cx + 4.4f * u, cy - 6.5f * u, cx - 4.4f * u, cy - 6.5f * u, cx - 4.4f * u, cy - 1.5f * u)
                path.lineTo(cx - 4.4f * u, cy + 2.2f * u)
                path.close()
                c.drawPath(path, p)
                c.drawArc(RectF(cx - 1.8f * u, cy + 3f * u, cx + 1.8f * u, cy + 7f * u), 20f, 140f, false, p)
                c.drawLine(cx - 7f * u, cy - 7f * u, cx + 7f * u, cy + 7f * u, p)
            }
            SIcon.DEVICE -> {
                c.drawRoundRect(cx - 5f * u, cy - 8f * u, cx + 5f * u, cy + 8f * u, 2.5f * u, 2.5f * u, p)
                c.drawLine(cx - 1.5f * u, cy + 6f * u, cx + 1.5f * u, cy + 6f * u, p)
                p.strokeWidth = 1.3f * dn
                c.drawLine(cx - 2.6f * u, cy - 4f * u, cx + 2.6f * u, cy - 4f * u, p)
                c.drawLine(cx - 2.6f * u, cy - 1f * u, cx + 1f * u, cy - 1f * u, p)
            }
            SIcon.LENS -> {
                c.drawCircle(cx, cy, 8f * u, p)
                c.drawCircle(cx, cy, 4.2f * u, p)
                for (i in 0 until 6) {
                    val a = Math.toRadians(i * 60.0)
                    c.drawLine(
                        cx + 4.2f * u * cos(a).toFloat(), cy + 4.2f * u * sin(a).toFloat(),
                        cx + 8f * u * cos(a + 0.5).toFloat(), cy + 8f * u * sin(a + 0.5).toFloat(), p
                    )
                }
            }
            SIcon.DEV -> {
                // biểu tượng mã nguồn: < / >
                path.reset()
                path.moveTo(cx - 3.5f * u, cy - 5f * u)
                path.lineTo(cx - 8f * u, cy)
                path.lineTo(cx - 3.5f * u, cy + 5f * u)
                c.drawPath(path, p)
                path.reset()
                path.moveTo(cx + 3.5f * u, cy - 5f * u)
                path.lineTo(cx + 8f * u, cy)
                path.lineTo(cx + 3.5f * u, cy + 5f * u)
                c.drawPath(path, p)
                c.drawLine(cx + 1.8f * u, cy - 6f * u, cx - 1.8f * u, cy + 6f * u, p)
            }
            SIcon.PLAIN, SIcon.FRAMED -> {
                c.drawRoundRect(cx - 8f * u, cy - 6.5f * u, cx + 8f * u, cy + 6.5f * u, 2f * u, 2f * u, p)
                path.reset()
                path.moveTo(cx - 8f * u, cy + 4f * u)
                path.lineTo(cx - 3f * u, cy - 1.5f * u)
                path.lineTo(cx + 1f * u, cy + 2.5f * u)
                path.lineTo(cx + 3.5f * u, cy)
                path.lineTo(cx + 8f * u, cy + 4.5f * u)
                c.drawPath(path, p)
            }
        }
    }
}

/** Mũi tên quay lại: vẽ bằng nét để nằm đúng tâm nút (ký tự "‹" của font luôn bị lệch). */
class SettingsBackView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dn = resources.displayMetrics.density

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.2f * dn
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = Theme.ink
        val a = 6f * dn
        val path = Path()
        path.moveTo(cx + a * 0.45f, cy - a)
        path.lineTo(cx - a * 0.55f, cy)
        path.lineTo(cx + a * 0.45f, cy + a)
        c.drawPath(path, p)
    }
}

/** Công tắc dạng viên thuốc: cam khi bật, núm trắng trượt mượt. */
class SettingToggle(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dn = resources.displayMetrics.density
    private var pos = 0f
    private var anim: ValueAnimator? = null
    var checked = false
        private set

    fun setChecked(v: Boolean, animate: Boolean = true) {
        checked = v
        anim?.cancel()
        if (!animate) { pos = if (v) 1f else 0f; invalidate(); return }
        anim = ValueAnimator.ofFloat(pos, if (v) 1f else 0f).apply {
            duration = 160
            interpolator = DecelerateInterpolator()
            addUpdateListener { pos = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val off = if (Theme.light) 0x33000000 else 0x44FFFFFF
        val a = pos
        p.style = Paint.Style.FILL
        p.color = blend(off, ORANGE, a)
        c.drawRoundRect(0f, 0f, w, h, h / 2f, h / 2f, p)
        val r = h / 2f - 3f * dn
        val x = h / 2f + (w - h) * a
        p.color = 0x33000000
        c.drawCircle(x, h / 2f + 1f * dn, r, p)
        p.color = Color.WHITE
        c.drawCircle(x, h / 2f, r, p)
    }

    private fun blend(c1: Int, c2: Int, t: Float): Int {
        fun ch(s: Int) = (((c1 shr s) and 255) + ((((c2 shr s) and 255) - ((c1 shr s) and 255)) * t)).toInt().coerceIn(0, 255)
        return (ch(24) shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }
}

/** Hình minh hoạ nhỏ cho kiểu lưu ảnh: ảnh trơn hoặc ảnh có khung trắng + dòng thông số. */
class SavePreviewView(ctx: Context, private val framed: Boolean) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dn = resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 8f * dn
        var l = 0f; var t = 0f; var rr = w; var b = h
        p.style = Paint.Style.FILL
        if (framed) {
            p.color = 0xFFF4F4F4.toInt()
            c.drawRoundRect(0f, 0f, w, h, r, r, p)
            l = w * 0.07f; t = h * 0.09f; rr = w - l; b = h * 0.76f
        }
        // "ảnh": bầu trời chuyển sắc + đồi
        val ph = RectF(l, t, rr, b)
        p.shader = LinearGradient(0f, t, 0f, b, 0xFFF6B26B.toInt(), 0xFF3C2A3E.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(ph, if (framed) 3f * dn else r, if (framed) 3f * dn else r, p)
        p.shader = null
        c.save()
        c.clipRect(ph)
        p.color = 0xFF1C1520.toInt()
        val hill = Path()
        hill.moveTo(l, b)
        hill.lineTo(l, b - (b - t) * 0.25f)
        hill.quadTo(l + (rr - l) * 0.35f, b - (b - t) * 0.6f, l + (rr - l) * 0.62f, b - (b - t) * 0.28f)
        hill.quadTo(l + (rr - l) * 0.85f, b - (b - t) * 0.12f, rr, b - (b - t) * 0.32f)
        hill.lineTo(rr, b)
        hill.close()
        c.drawPath(hill, p)
        p.color = 0xFFFFE2B0.toInt()
        c.drawCircle(l + (rr - l) * 0.72f, t + (b - t) * 0.3f, (b - t) * 0.12f, p)
        c.restore()
        if (framed) {
            // watermark thông số
            p.color = 0xFF55555A.toInt()
            c.drawRoundRect(l, h * 0.83f, l + w * 0.34f, h * 0.83f + 3f * dn, 2f * dn, 2f * dn, p)
            p.color = 0xFFA0A0A6.toInt()
            c.drawRoundRect(l, h * 0.83f + 7f * dn, l + w * 0.52f, h * 0.83f + 9.5f * dn, 2f * dn, 2f * dn, p)
            p.color = ORANGE
            c.drawCircle(rr - 4f * dn, h * 0.83f + 2f * dn, 2.6f * dn, p)
        }
    }
}

/** Hình minh hoạ cho hiệu ứng chụp: 0 = loát ảnh (âm bản + ảnh bay về album), 1 = màn chập (màn hình nháy đen một phát). */
class FxPreviewView(ctx: Context, private val style: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dn = resources.displayMetrics.density
    private val clip = Path()

    private fun photo(c: Canvas, r: RectF, negative: Boolean) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, r.top, 0f, r.bottom,
            if (negative) 0xFF0A4D94.toInt() else 0xFFF6B26B.toInt(),
            if (negative) 0xFFC3D5C1.toInt() else 0xFF3C2A3E.toInt(), Shader.TileMode.CLAMP
        )
        c.drawRect(r, p)
        p.shader = null
        c.save()
        c.clipRect(r)
        p.color = if (negative) 0xFFE3EADF.toInt() else 0xFF1C1520.toInt()
        val hill = Path()
        val w = r.width()
        val h = r.height()
        hill.moveTo(r.left, r.bottom)
        hill.lineTo(r.left, r.bottom - h * 0.25f)
        hill.quadTo(r.left + w * 0.35f, r.bottom - h * 0.6f, r.left + w * 0.62f, r.bottom - h * 0.28f)
        hill.quadTo(r.left + w * 0.85f, r.bottom - h * 0.12f, r.right, r.bottom - h * 0.32f)
        hill.lineTo(r.right, r.bottom)
        hill.close()
        c.drawPath(hill, p)
        c.restore()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 8f * dn
        p.style = Paint.Style.FILL
        p.color = if (Theme.light) 0xFFE9E9ED.toInt() else 0xFF0C0C0E.toInt()
        c.drawRoundRect(0f, 0f, w, h, r, r, p)
        clip.reset()
        clip.addRoundRect(0f, 0f, w, h, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        if (style == 0) {
            // khung đóng băng âm bản + thumbnail nhỏ ở góc: ảnh "bay về" album
            photo(c, RectF(w * 0.06f, h * 0.14f, w * 0.72f, h * 0.86f), true)
            val th = RectF(w * 0.78f, h * 0.58f, w * 0.94f, h * 0.58f + w * 0.16f)
            p.color = 0xFFF47B20.toInt()
            c.drawRoundRect(th.left - 2f * dn, th.top - 2f * dn, th.right + 2f * dn, th.bottom + 2f * dn, 5f * dn, 5f * dn, p)
            photo(c, th, false)
            p.style = Paint.Style.STROKE
            p.strokeWidth = 1.6f * dn
            p.strokeCap = Paint.Cap.ROUND
            p.color = 0xFFF47B20.toInt()
            val arc = Path()
            arc.moveTo(w * 0.60f, h * 0.30f)
            arc.quadTo(w * 0.80f, h * 0.18f, w * 0.86f, h * 0.50f)
            c.drawPath(arc, p)
            p.style = Paint.Style.FILL
        } else {
            val ph = RectF(w * 0.06f, h * 0.14f, w * 0.94f, h * 0.86f)
            photo(c, ph, false)
            // màn hình nháy đen một phát
            p.color = 0xE6040404.toInt()
            c.drawRect(ph, p)
            // 3 chấm: chụp liên tiếp
            p.color = 0xFFF47B20.toInt()
            for (i in 0 until 3) c.drawCircle(w * 0.44f + i * 9f * dn, h * 0.93f, 2.2f * dn, p)
        }
        c.restore()
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * dn
        p.color = if (Theme.light) 0x22000000 else 0x24FFFFFF
        c.drawRoundRect(0.5f * dn, 0.5f * dn, w - 0.5f * dn, h - 0.5f * dn, r, r, p)
    }
}

/** Hình minh hoạ nhỏ cho từng kiểu dấu chìm (0 cổ điển, 1 Gallery, 2 Dải thông số, 3 Logo + tên máy, 4 Chỉ logo). */
class WatermarkPreviewView(ctx: Context, private val style: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dn = resources.displayMetrics.density
    private val clip = Path()

    private fun photo(c: Canvas, r: RectF) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, r.top, 0f, r.bottom, 0xFFF6B26B.toInt(), 0xFF3C2A3E.toInt(), Shader.TileMode.CLAMP)
        c.drawRect(r, p)
        p.shader = null
        c.save()
        c.clipRect(r)
        p.color = 0xFF1C1520.toInt()
        val hill = Path()
        val w = r.width()
        val h = r.height()
        hill.moveTo(r.left, r.bottom)
        hill.lineTo(r.left, r.bottom - h * 0.25f)
        hill.quadTo(r.left + w * 0.35f, r.bottom - h * 0.6f, r.left + w * 0.62f, r.bottom - h * 0.28f)
        hill.quadTo(r.left + w * 0.85f, r.bottom - h * 0.12f, r.right, r.bottom - h * 0.32f)
        hill.lineTo(r.right, r.bottom)
        hill.close()
        c.drawPath(hill, p)
        p.color = 0xFFFFE2B0.toInt()
        c.drawCircle(r.left + w * 0.72f, r.top + h * 0.3f, h * 0.12f, p)
        c.restore()
    }

    private fun bar(c: Canvas, l: Float, t: Float, w: Float, h: Float, color: Int) {
        p.style = Paint.Style.FILL
        p.color = color
        c.drawRoundRect(l, t, l + w, t + h, h / 2f, h / 2f, p)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = 8f * dn
        p.style = Paint.Style.FILL
        p.color = if (style == 0) 0xFFF4F4F4.toInt() else Color.WHITE
        c.drawRoundRect(0f, 0f, w, h, r, r, p)
        clip.reset()
        clip.addRoundRect(0f, 0f, w, h, r, r, Path.Direction.CW)
        when (style) {
            0 -> {
                photo(c, RectF(w * 0.07f, h * 0.2f, w * 0.93f, h * 0.72f))
                bar(c, w * 0.36f, h * 0.07f, w * 0.28f, 3f * dn, 0xFF222226.toInt())
                bar(c, w * 0.34f, h * 0.80f, w * 0.32f, 3f * dn, 0xFF55555A.toInt())
                bar(c, w * 0.26f, h * 0.80f + 8f * dn, w * 0.48f, 2.5f * dn, 0xFFA0A0A6.toInt())
            }
            1 -> {
                photo(c, RectF(w * 0.06f, h * 0.25f, w * 0.94f, h * 0.76f))
                bar(c, w * 0.06f, h * 0.09f, w * 0.15f, 4f * dn, 0xFF111114.toInt())      // logo XPAN
                bar(c, w * 0.06f, h * 0.86f, w * 0.30f, 3f * dn, 0xFF44444A.toInt())      // tên máy
                bar(c, w * 0.70f, h * 0.86f, w * 0.24f, 3.5f * dn, 0xFF111114.toInt())    // HASSELBLAD
            }
            3 -> {
                // ảnh tràn hết, chữ nằm ngay trong ảnh (không dải nền)
                c.save()
                c.clipPath(clip)
                photo(c, RectF(0f, 0f, w, h))
                c.restore()
                bar(c, w * 0.20f, h * 0.88f, w * 0.30f, 3f * dn, 0xE6FFFFFF.toInt())      // tên máy
                bar(c, w * 0.53f, h * 0.875f, w * 0.0075f, 6f * dn, 0xE6FFFFFF.toInt())   // vạch ngăn
                bar(c, w * 0.57f, h * 0.88f, w * 0.23f, 3.4f * dn, 0xFFFFFFFF.toInt())    // logo
            }
            4 -> {
                c.save()
                c.clipPath(clip)
                photo(c, RectF(0f, 0f, w, h))
                c.restore()
                bar(c, w * 0.33f, h * 0.80f, w * 0.34f, 3.6f * dn, 0xFFFFFFFF.toInt())    // logo HASSELBLAD
                bar(c, w * 0.40f, h * 0.80f + 8f * dn, w * 0.20f, 1.8f * dn, 0xE6FFFFFF.toInt()) // Create to Inspire
            }
            else -> {
                c.save()
                c.clipPath(clip)
                photo(c, RectF(0f, 0f, w, h * 0.78f))
                c.restore()
                bar(c, w * 0.05f, h * 0.855f, w * 0.26f, 4f * dn, 0xFF111114.toInt())     // tên máy
                bar(c, w * 0.66f, h * 0.835f, w * 0.29f, 3f * dn, 0xFF111114.toInt())     // HASSELBLAD
                bar(c, w * 0.70f, h * 0.835f + 6.5f * dn, w * 0.25f, 2f * dn, 0xFFA0A0A6.toInt())
                p.style = Paint.Style.FILL
                p.color = ORANGE
                c.drawCircle(w * 0.675f, h * 0.835f + 7.5f * dn, 1.8f * dn, p)
            }
        }
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * dn
        p.color = 0x1F000000
        c.drawRoundRect(0.5f * dn, 0.5f * dn, w - 0.5f * dn, h - 0.5f * dn, r, r, p)
    }
}

/**
 * Màn hình Cài đặt riêng, cuộn dọc, phủ kín màn hình. Khi mở, MainActivity tạm dừng camera + bỏ giữ sáng màn hình để tiết kiệm pin.
 * Mỗi dòng gồm biểu tượng, tên, mô tả ngắn và công tắc; kiểu lưu ảnh có hình minh hoạ để chọn trực quan.
 */
class SettingsView(ctx: Context, private val prefs: Prefs, private val lensReport: () -> String) : FrameLayout(ctx) {
    var onClosed: (() -> Unit)? = null
    val isOpen: Boolean get() = visibility == VISIBLE

    private val dn = resources.displayMetrics.density
    private var nameEdit: EditText? = null
    private var safe = 0

    init {
        isClickable = true
        visibility = GONE
    }

    fun setSafe(l: Int, r: Int) {
        safe = maxOf(l, r)
        setPadding(safe, 0, safe, 0)
    }

    private fun dp(v: Float) = (v * dn).toInt()
    private val bg get() = if (Theme.light) 0xFFF1F1F4.toInt() else 0xFF0B0B0D.toInt()
    private val cardBg get() = if (Theme.light) Color.WHITE else 0xFF18181B.toInt()
    private val hair get() = if (Theme.light) 0x1F000000 else 0x24FFFFFF
    private val sub get() = if (Theme.light) 0xFF6C6C74.toInt() else 0xFF9C9CA4.toInt()

    private fun rounded(color: Int, r: Float, strokeW: Float = 0f, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = r * dn
        if (strokeW > 0f) setStroke((strokeW * dn).toInt().coerceAtLeast(1), stroke)
    }

    fun show() {
        removeAllViews()
        setBackgroundColor(bg)
        build()
        animate().cancel()
        alpha = 0f
        visibility = VISIBLE
        animate().alpha(1f).setDuration(180).start()
    }

    fun hide() {
        if (!isOpen) return
        prefs.deviceName = nameEdit?.text?.toString()?.trim() ?: prefs.deviceName
        animate().cancel()
        animate().alpha(0f).setDuration(140).withEndAction {
            visibility = GONE
            alpha = 1f
            removeAllViews()
            nameEdit = null
            onClosed?.invoke()
        }.start()
    }

    // ------------------------------------------------------------------ dựng giao diện

    private fun build() {
        val top = LinearLayout(context)
        top.orientation = LinearLayout.VERTICAL
        addView(top, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        // thanh tiêu đề
        val bar = LinearLayout(context)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(14f), dp(8f), dp(14f), dp(8f))
        val back = SettingsBackView(context)
        back.background = rounded(if (Theme.light) 0x14000000 else 0x22FFFFFF, 20f, 1f, hair)
        back.setOnClickListener { hide() }
        back.pressFeedback(0.9f, false)
        bar.addView(back, LinearLayout.LayoutParams(dp(40f), dp(40f)))
        val titles = LinearLayout(context)
        titles.orientation = LinearLayout.VERTICAL
        titles.setPadding(dp(12f), 0, 0, 0)
        val t1 = TextView(context)
        t1.text = "Cài đặt"
        t1.textSize = 19f
        t1.typeface = Typeface.DEFAULT_BOLD
        t1.setTextColor(Theme.ink)
        titles.addView(t1)
        val t2 = TextView(context)
        t2.text = "Camera tạm dừng khi mở cài đặt để tiết kiệm pin"
        t2.textSize = 11.5f
        t2.setTextColor(sub)
        titles.addView(t2)
        bar.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val done = TextView(context)
        done.text = "Xong"
        done.textSize = 14f
        done.typeface = Typeface.DEFAULT_BOLD
        done.setTextColor(Color.WHITE)
        done.gravity = Gravity.CENTER
        done.background = rounded(ORANGE, 20f)
        done.setPadding(dp(18f), 0, dp(18f), 0)
        done.setOnClickListener { hide() }
        done.pressFeedback(0.92f, false)
        bar.addView(done, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40f)))
        top.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val sv = ScrollView(context)
        sv.isVerticalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        val wrap = FrameLayout(context)
        val col = LinearLayout(context)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14f), dp(4f), dp(14f), dp(80f))
        val maxW = dp(620f)
        val avail = resources.displayMetrics.widthPixels - 2 * safe
        wrap.addView(col, FrameLayout.LayoutParams(min(maxW, avail), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL))
        sv.addView(wrap, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        top.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // --- Chụp & lưu ảnh
        section(col, "CHỤP & LƯU ẢNH")
        val c1 = card(col)
        toggleRow(c1, SIcon.RAW, "Lưu thêm file RAW (DNG)", "Chỉ hoạt động nếu ống kính hỗ trợ RAW. Tốn thêm dung lượng.", prefs.saveRaw) { prefs.saveRaw = it }
        divider(c1)
        toggleRow(c1, SIcon.ORIGINAL, "Giữ ảnh gốc full-frame", "Lưu thêm bản không cắt 65:24, không áp bộ lọc.", prefs.keepOriginal) { prefs.keepOriginal = it }

        val label = TextView(context)
        label.text = "Ảnh tự lưu sau khi chụp"
        label.textSize = 14f
        label.typeface = Typeface.DEFAULT_BOLD
        label.setTextColor(Theme.ink)
        label.setPadding(dp(4f), dp(16f), 0, dp(2f))
        col.addView(label)
        val hint = TextView(context)
        hint.text = "Chọn 1 kiểu — chạm vào hình để đổi"
        hint.textSize = 11.5f
        hint.setTextColor(sub)
        hint.setPadding(dp(4f), 0, 0, dp(8f))
        col.addView(hint)
        saveChoice(col)

        // --- Điều khiển & âm thanh
        section(col, "ĐIỀU KHIỂN & ÂM THANH")
        val c2 = card(col)
        toggleRow(c2, SIcon.VOLUME, "Phím âm lượng để chụp", "Nhấn tăng hoặc giảm âm lượng như nút chụp thật.", prefs.volumeShutter) { prefs.volumeShutter = it }
        divider(c2)
        toggleRow(c2, SIcon.SHUTTER, "Âm thanh màn trập cổ điển", "Phát tiếng “tách” khi chụp.", prefs.sound) { prefs.sound = it }
        divider(c2)
        toggleRow(c2, SIcon.BEEP, "Tiếng “tách” khi lấy nét xong", "Âm thanh khoá nét như máy ảnh cơ.", prefs.focusSound) { prefs.focusSound = it }
        divider(c2)
        toggleRow(c2, SIcon.SILENT, "Im lặng theo chế độ máy", "Tắt mọi âm thanh khi điện thoại ở chế độ im lặng hoặc rung.", prefs.respectSilent) { prefs.respectSilent = it }

        // --- Khung ảnh
        section(col, "KHUNG ẢNH")
        val c3 = card(col)
        val devRow = row(c3, SIcon.DEVICE, "Tên máy trên khung ảnh", "Hiện ở dòng thông số của ảnh có khung. Để trống sẽ dùng tên mặc định.")
        val et = EditText(context)
        et.inputType = InputType.TYPE_CLASS_TEXT
        et.setSingleLine()
        et.hint = PhotoProcessor.defaultDeviceName()
        et.setText(prefs.deviceName)
        et.textSize = 14f
        et.setTextColor(Theme.ink)
        et.setHintTextColor(sub)
        et.background = rounded(if (Theme.light) 0x0D000000 else 0x1AFFFFFF, 10f, 1f, hair)
        et.setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
        nameEdit = et
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(14f), 0, dp(14f), dp(14f))
        c3.addView(et, lp)
        devRow.alpha = 1f

        // --- Thông tin ống kính (thu gọn)
        section(col, "THIẾT BỊ")
        val c4 = card(col)
        val lensRow = row(c4, SIcon.LENS, "Thông tin ống kính", "Chạm để xem thông số các camera sau của máy.")
        val chevron = TextView(context)
        chevron.text = "▾"
        chevron.textSize = 16f
        chevron.setTextColor(sub)
        (lensRow as LinearLayout).addView(chevron)
        val rep = TextView(context)
        rep.typeface = Typeface.MONOSPACE
        rep.textSize = 10.5f
        rep.setTextColor(sub)
        rep.text = lensReport()
        rep.visibility = GONE
        rep.setPadding(dp(16f), 0, dp(16f), dp(14f))
        c4.addView(rep)
        lensRow.setOnClickListener {
            val open = rep.visibility != VISIBLE
            rep.visibility = if (open) VISIBLE else GONE
            chevron.text = if (open) "▴" else "▾"
        }

        // --- Nhà phát triển (dưới cùng)
        section(col, "NHÀ PHÁT TRIỂN")
        val c5 = card(col)
        toggleRow(
            c5, SIcon.DEV, "Chế độ nhà phát triển",
            "Thử nghiệm cho HQ ghép khung: chọn khung nét nhất làm gốc, khung nét đóng góp nhiều hơn, và làm nét kiểu khử nhoè (Richardson-Lucy) thay cho unsharp mask. Chậm hơn. Tắt = làm nét như cũ. Ảnh chụp ở chế độ này có đuôi _DEV để so sánh.",
            prefs.devMode
        ) { prefs.devMode = it }

        val foot = TextView(context)
        foot.text = "Xpan-Mode"
        foot.textSize = 11f
        foot.gravity = Gravity.CENTER
        foot.setTextColor(sub)
        foot.setPadding(0, dp(20f), 0, 0)
        col.addView(foot)
        val credit = TextView(context)
        credit.text = "App Design by Yume. System"
        credit.textSize = 11.5f
        credit.letterSpacing = 0.04f
        credit.gravity = Gravity.CENTER
        credit.setTextColor(sub)
        credit.setPadding(0, dp(4f), 0, 0)
        col.addView(credit)
        val ver = TextView(context)
        ver.text = "Version " + (try { context.packageManager.getPackageInfo(context.packageName, 0).versionName } catch (_: Throwable) { null } ?: "")
        ver.textSize = 11f
        ver.letterSpacing = 0.04f
        ver.gravity = Gravity.CENTER
        ver.setTextColor(sub)
        ver.alpha = 0.8f
        ver.setPadding(0, dp(2f), 0, 0)
        col.addView(ver)
    }

    private fun section(parent: LinearLayout, title: String) {
        val t = TextView(context)
        t.text = title
        t.textSize = 11f
        t.typeface = Typeface.DEFAULT_BOLD
        t.letterSpacing = 0.14f
        t.setTextColor(ORANGE)
        t.setPadding(dp(4f), dp(20f), 0, dp(8f))
        parent.addView(t)
    }

    private fun card(parent: LinearLayout): LinearLayout {
        val c = LinearLayout(context)
        c.orientation = LinearLayout.VERTICAL
        c.background = rounded(cardBg, 16f, 1f, hair)
        parent.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return c
    }

    private fun divider(parent: LinearLayout) {
        val v = View(context)
        v.setBackgroundColor(hair)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
        lp.setMargins(dp(70f), 0, 0, 0)
        parent.addView(v, lp)
    }

    /** Dòng cơ bản: biểu tượng + tên + mô tả (trả về LinearLayout ngang để gắn thêm công tắc / mũi tên). */
    private fun row(parent: LinearLayout, icon: SIcon, title: String, desc: String): View {
        val r = LinearLayout(context)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(14f), dp(12f), dp(14f), dp(12f))
        r.addView(SettingIconView(context, icon), LinearLayout.LayoutParams(dp(42f), dp(42f)))
        val tx = LinearLayout(context)
        tx.orientation = LinearLayout.VERTICAL
        tx.setPadding(dp(14f), 0, dp(10f), 0)
        val a = TextView(context)
        a.text = title
        a.textSize = 15f
        a.typeface = Typeface.DEFAULT_BOLD
        a.setTextColor(Theme.ink)
        tx.addView(a)
        val b = TextView(context)
        b.text = desc
        b.textSize = 12f
        b.setTextColor(sub)
        b.setPadding(0, dp(2f), 0, 0)
        tx.addView(b)
        r.addView(tx, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        parent.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return r
    }

    private fun toggleRow(parent: LinearLayout, icon: SIcon, title: String, desc: String, value: Boolean, set: (Boolean) -> Unit) {
        val r = row(parent, icon, title, desc) as LinearLayout
        val tg = SettingToggle(context)
        tg.setChecked(value, false)
        r.addView(tg, LinearLayout.LayoutParams(dp(48f), dp(28f)))
        r.setOnClickListener {
            val n = !tg.checked
            tg.setChecked(n)
            set(n)
            it.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
        }
    }

    /** Hai ô minh hoạ cạnh nhau: ảnh không khung / ảnh có khung + watermark. */
    private fun saveChoice(parent: LinearLayout) {
        val rowL = LinearLayout(context)
        rowL.orientation = LinearLayout.HORIZONTAL
        val opts = ArrayList<Pair<LinearLayout, Boolean>>()
        fun refresh() {
            for ((box, framed) in opts) {
                val sel = framed == prefs.autoFrame
                box.background = rounded(cardBg, 16f, if (sel) 2f else 1f, if (sel) ORANGE else hair)
            }
        }
        fun option(framed: Boolean, title: String, desc: String) {
            val box = LinearLayout(context)
            box.orientation = LinearLayout.VERTICAL
            box.setPadding(dp(12f), dp(12f), dp(12f), dp(12f))
            box.addView(SavePreviewView(context, framed), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(86f)))
            val a = TextView(context)
            a.text = title
            a.textSize = 14f
            a.typeface = Typeface.DEFAULT_BOLD
            a.setTextColor(Theme.ink)
            a.setPadding(0, dp(10f), 0, 0)
            box.addView(a)
            val b = TextView(context)
            b.text = desc
            b.textSize = 11.5f
            b.setTextColor(sub)
            b.setPadding(0, dp(2f), 0, 0)
            box.addView(b)
            box.setOnClickListener {
                prefs.autoFrame = framed
                refresh()
                it.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
            }
            box.pressFeedback(0.97f, false)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (framed) lp.leftMargin = dp(10f)
            rowL.addView(box, lp)
            opts.add(box to framed)
        }
        option(false, "Ảnh không khung", "Chỉ ảnh đã cắt 65:24, sạch, không chữ.")
        option(true, "Ảnh có khung", "Viền trắng kèm watermark thông số máy.")
        refresh()
        parent.addView(rowL, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }
}
