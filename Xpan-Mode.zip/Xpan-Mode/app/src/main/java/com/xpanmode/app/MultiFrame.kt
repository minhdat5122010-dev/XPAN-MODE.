package com.xpanmode.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * HQ ghép nhiều khung: máy không cho chụp 50MP nên chụp liên tiếp N khung 12,6MP, căn chỉnh (tay run tạo ra lệch dưới 1 điểm ảnh),
 * rồi "shift-and-add" lên lưới 2× độ phân giải. Chi tiết thật được thu thêm từ các khung lệch nhau, nhiễu giảm; vùng chuyển động
 * (ghost) bị giảm trọng số nên không bị bóng ma. Không phải 50MP thật nhưng sắc và sạch hơn hẳn một khung đơn rồi crop.
 *
 * Bản này: căn chỉnh Lucas-Kanade dưới điểm ảnh (sai ~0,01 px thay vì ~0,08 px), giải mã + căn chỉnh các khung song song,
 * và cộng dồn ĐỘ SÁNG ở lưới 2× còn MÀU ở lưới 1× (JPEG vốn chỉ có màu 4:2:0 nên không mất chi tiết) để nhanh hơn.
 */
object MultiFrame {
    private const val SCALE = 2
    /** Độ chi tiết tối thiểu của mảng dùng để căn chỉnh (nhiễu phẳng ≤ ~4,5; ảnh có chi tiết ≥ ~12). */
    private const val TEX_MIN = 3f
    /** Số khung thực sự được ghép trong lần merge gần nhất (khung hỏng bị bỏ). */
    @Volatile var lastUsed = 0
    /** Thời gian (ms) giải mã + căn chỉnh và cộng dồn/hoàn thiện của lần merge gần nhất, để báo cho người dùng. */
    @Volatile var lastAlignMs = 0L
    @Volatile var lastFuseMs = 0L

    /** Trọng số Catmull-Rom cho 4 điểm quanh vị trí lẻ t (0..1). */
    private fun cr(t: Float, out: FloatArray, o: Int) {
        val t2 = t * t
        val t3 = t2 * t
        out[o] = -0.5f * t3 + t2 - 0.5f * t
        out[o + 1] = 1.5f * t3 - 2.5f * t2 + 1f
        out[o + 2] = -1.5f * t3 + 2f * t2 + 0.5f * t
        out[o + 3] = 0.5f * t3 - 0.5f * t2
    }

    /**
     * Nhân Gauss (σ≈0,72 điểm ảnh ra) để "rải" mỗi mẫu lên 4×4 điểm ảnh lưới 2×. Trước đây rải song tuyến 2×2: khi tay giữ yên
     * (lệch ~0) mỗi điểm ảnh gốc rơi đúng vào một khối 2×2 -> ảnh 2× thực chất là nhân đôi điểm ảnh (nearest) -> vỡ ô vuông khi zoom.
     * Bảng theo phần lẻ lượng tử hoá 1/KQ, mỗi hàng 4 trọng số đã chuẩn hoá tổng = 1.
     */
    private const val KQ = 32
    private val KTAB = FloatArray(KQ * 4).also { t ->
        val two = 2f * 0.72f * 0.72f
        for (q in 0 until KQ) {
            val f = q.toFloat() / KQ
            var sum = 0f
            for (j in 0..3) {
                val d = (j - 1) - f
                val v = Math.exp((-d * d / two).toDouble()).toFloat()
                t[q * 4 + j] = v; sum += v
            }
            for (j in 0..3) t[q * 4 + j] /= sum
        }
    }

    /** Khử nhiễu màu: bán kính (điểm ảnh gốc), trọng số không gian và trọng số theo chênh lệch độ sáng (giữ ranh giới màu thật). */
    private const val CR = 4
    private val CSW = FloatArray(2 * CR + 1) { Math.exp((-(it - CR) * (it - CR) / (2.0 * 2.5 * 2.5))).toFloat() }
    private val CRW = FloatArray(256) { Math.exp((-(it * it) / (2.0 * 20.0 * 20.0))).toFloat() }

    internal fun luma(p: Int): Int = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8

    private fun decode(path: String, region: Rect): IntArray {
        @Suppress("DEPRECATION")
        val dec = BitmapRegionDecoder.newInstance(path, false) ?: throw IllegalStateException("Không đọc được khung")
        try {
            val o = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val b = dec.decodeRegion(region, o) ?: throw IllegalStateException("decodeRegion null")
            val w = b.width
            val h = b.height
            val out = IntArray(w * h)
            b.getPixels(out, 0, w, 0, 0, w, h)
            b.recycle()
            return out
        } finally {
            dec.recycle()
        }
    }

    /** Ảnh xám thu nhỏ s lần (trung bình khối s×s). */
    internal fun lumaDown(px: IntArray, w: Int, h: Int, s: Int, gain: Float = 1f): FloatArray {
        val lw = w / s
        val lh = h / s
        val out = FloatArray(lw * lh)
        val inv = gain / (s * s)
        for (y in 0 until lh) for (x in 0 until lw) {
            var sum = 0
            for (j in 0 until s) {
                val row = (y * s + j) * w + x * s
                for (i in 0 until s) sum += luma(px[row + i])
            }
            out[y * lw + x] = sum * inv
        }
        return out
    }

    /**
     * Bước thô: độ lệch nguyên (theo điểm ảnh gốc, bội của 4) của `cur` so với `ref`: cur(x+dx, y+dy) ≈ ref(x, y).
     * SAD trên ảnh thu nhỏ 4 lần (lw×lh là kích thước ảnh thu nhỏ).
     */
    internal fun coarse(refS: FloatArray, curS: FloatArray, lw: Int, lh: Int): IntArray {
        val s = 4
        val r = 12
        val m = r + 2
        var best = Float.MAX_VALUE
        var bx = 0
        var by = 0
        for (sy in -r..r) for (sx in -r..r) {
            var sad = 0f
            var n = 0
            var y = m
            while (y < lh - m) {
                var x = m
                while (x < lw - m) {
                    sad += abs(refS[y * lw + x] - curS[(y + sy) * lw + x + sx])
                    n++
                    x += 3
                }
                y += 3
            }
            if (n > 0) {
                sad /= n
                // ưu tiên nhẹ độ lệch nhỏ để khung phẳng/ít chi tiết không nhảy lung tung
                sad += (abs(sx) + abs(sy)) * 0.02f
                if (sad < best) { best = sad; bx = sx; by = sy }
            }
        }
        return intArrayOf(bx * s, by * s)
    }

    /** Độ sáng trung bình khối step×step của vùng (x0,y0,pw,ph) (toạ độ ngoài ảnh được kẹp về mép). Kết quả (pw/step)×(ph/step). */
    private fun patch(px: IntArray, w: Int, h: Int, x0: Int, y0: Int, pw: Int, ph: Int, step: Int, gain: Float = 1f): FloatArray {
        val ow = pw / step
        val oh = ph / step
        val out = FloatArray(ow * oh)
        val inv = gain / (step * step * 256f)
        for (j in 0 until oh) {
            for (i in 0 until ow) {
                var sum = 0
                for (b in 0 until step) {
                    val yy = (y0 + j * step + b).coerceIn(0, h - 1)
                    for (a in 0 until step) {
                        val xx = (x0 + i * step + a).coerceIn(0, w - 1)
                        val p = px[yy * w + xx]
                        sum += ((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29
                    }
                }
                out[j * ow + i] = sum * inv
            }
        }
        return out
    }

    /** Làm mờ nhị thức 5 điểm (σ≈1) theo hai chiều. */
    private fun blur5(a: FloatArray, w: Int, h: Int): FloatArray {
        val k0 = 1f / 16f
        val k1 = 4f / 16f
        val k2 = 6f / 16f
        val tmp = FloatArray(w * h)
        for (y in 0 until h) {
            val ro = y * w
            for (x in 0 until w) {
                val xm2 = (x - 2).coerceAtLeast(0)
                val xm1 = (x - 1).coerceAtLeast(0)
                val xp1 = (x + 1).coerceAtMost(w - 1)
                val xp2 = (x + 2).coerceAtMost(w - 1)
                tmp[ro + x] = k0 * a[ro + xm2] + k1 * a[ro + xm1] + k2 * a[ro + x] + k1 * a[ro + xp1] + k0 * a[ro + xp2]
            }
        }
        val out = FloatArray(w * h)
        for (y in 0 until h) {
            val rm2 = (y - 2).coerceAtLeast(0) * w
            val rm1 = (y - 1).coerceAtLeast(0) * w
            val r0 = y * w
            val rp1 = (y + 1).coerceAtMost(h - 1) * w
            val rp2 = (y + 2).coerceAtMost(h - 1) * w
            for (x in 0 until w) {
                out[r0 + x] = k0 * tmp[rm2 + x] + k1 * tmp[rm1 + x] + k2 * tmp[r0 + x] + k1 * tmp[rp1 + x] + k0 * tmp[rp2 + x]
            }
        }
        return out
    }

    /** Độ giàu chi tiết của mảng: trị riêng nhỏ nhất của ma trận gradient trung bình (cao = có cạnh theo cả hai hướng). */
    private fun texture(p: FloatArray, pw: Int, ph: Int): Float {
        var a = 0.0
        var b = 0.0
        var c = 0.0
        for (y in 1 until ph - 1) {
            val r = y * pw
            for (x in 1 until pw - 1) {
                val gx = (p[r + x + 1] - p[r + x - 1]) * 0.5f
                val gy = (p[r + pw + x] - p[r - pw + x]) * 0.5f
                a += (gx * gx).toDouble()
                b += (gx * gy).toDouble()
                c += (gy * gy).toDouble()
            }
        }
        val n = (pw * ph).toDouble()
        a /= n; b /= n; c /= n
        val tr = a + c
        val det = a * c - b * b
        val disc = max(tr * tr / 4.0 - det, 0.0)
        return (tr / 2.0 - sqrt(disc)).toFloat()
    }

    /**
     * Lucas-Kanade (ngược, chỉ dịch tịnh tiến). p: mảng tham chiếu pw×ph; q: mảng hiện tại có viền m mỗi phía, (pw+2m)×(ph+2m).
     * Tìm (ox, oy) sao cho q(x+m+ox, y+m+oy) ≈ p(x, y), bắt đầu từ (o0x, o0y). Trả null nếu mảng không đủ chi tiết.
     */
    private fun lk(p: FloatArray, pw: Int, ph: Int, q: FloatArray, m: Int, o0x: Float, o0y: Float): FloatArray? {
        val qw = pw + 2 * m
        val qh = ph + 2 * m
        val gxs = FloatArray(pw * ph)
        val gys = FloatArray(pw * ph)
        var hxx = 0.0
        var hxy = 0.0
        var hyy = 0.0
        for (y in 1 until ph - 1) {
            val r = y * pw
            for (x in 1 until pw - 1) {
                val gx = (p[r + x + 1] - p[r + x - 1]) * 0.5f
                val gy = (p[r + pw + x] - p[r - pw + x]) * 0.5f
                gxs[r + x] = gx
                gys[r + x] = gy
                hxx += (gx * gx).toDouble()
                hxy += (gx * gy).toDouble()
                hyy += (gy * gy).toDouble()
            }
        }
        val det = hxx * hyy - hxy * hxy
        if (det < 1.0) return null
        var ox = o0x
        var oy = o0y
        val maxX = qw - 1.001f
        val maxY = qh - 1.001f
        for (iter in 0 until 10) {
            var bx = 0.0
            var by = 0.0
            for (y in 1 until ph - 1) {
                val yy = (y + m + oy).coerceIn(0f, maxY)
                val y0 = yy.toInt()
                val fy = yy - y0
                val r = y * pw
                for (x in 1 until pw - 1) {
                    val xx = (x + m + ox).coerceIn(0f, maxX)
                    val x0 = xx.toInt()
                    val fx = xx - x0
                    val i = y0 * qw + x0
                    val v = (q[i] * (1f - fx) + q[i + 1] * fx) * (1f - fy) + (q[i + qw] * (1f - fx) + q[i + qw + 1] * fx) * fy
                    val e = v - p[r + x]
                    bx += (gxs[r + x] * e).toDouble()
                    by += (gys[r + x] * e).toDouble()
                }
            }
            val dx = ((hyy * bx - hxy * by) / det).toFloat().coerceIn(-1f, 1f)
            val dy = ((-hxy * bx + hxx * by) / det).toFloat().coerceIn(-1f, 1f)
            ox -= dx
            oy -= dy
            if (abs(dx) < 0.005f && abs(dy) < 0.005f) break
        }
        return floatArrayOf(ox, oy)
    }

    /**
     * Tinh chỉnh độ lệch thô `init` thành độ lệch dưới điểm ảnh: chọn mảng nhiều chi tiết nhất trong 3 mảng ngang giữa ảnh,
     * chạy LK ở nửa độ phân giải rồi ở độ phân giải đầy đủ (làm mờ nhẹ). Bất kỳ bước nào không đáng tin thì giữ kết quả của bước trước.
     */
    internal fun refine(base: IntArray, cur: IntArray, w: Int, h: Int, init: IntArray, gain: Float = 1f): FloatArray {
        val fallback = floatArrayOf(init[0].toFloat(), init[1].toFloat())
        val pw = (min(512, w / 3) / 4) * 4
        val ph = (min(384, h * 2 / 3) / 4) * 4
        if (pw < 64 || ph < 64) return fallback
        val y0 = (h - ph) / 2
        var bestX = -1
        var bestS = -1f
        var bestP2: FloatArray? = null
        for (c in 1..3) {
            val x0 = (w / 4 * c - pw / 2).coerceIn(0, w - pw)
            val p2 = patch(base, w, h, x0, y0, pw, ph, 2, gain)
            val s = texture(p2, pw / 2, ph / 2)
            if (s > bestS) { bestS = s; bestX = x0; bestP2 = p2 }
        }
        val p2 = bestP2
        // ngưỡng chi tiết tỉ lệ gain²: ảnh tối được nhân sáng để căn chỉnh thì nhiễu cũng nhân theo
        if (p2 == null || bestS < TEX_MIN * gain * gain) return fallback
        val x0 = bestX

        // nửa độ phân giải
        val m2 = 6
        val ix2 = init[0]
        val iy2 = init[1]
        val q2 = patch(cur, w, h, x0 + ix2 - 2 * m2, y0 + iy2 - 2 * m2, pw + 4 * m2, ph + 4 * m2, 2, gain)
        val r2 = lk(p2, pw / 2, ph / 2, q2, m2, 0f, 0f) ?: return fallback
        if (abs(r2[0]) > 5f || abs(r2[1]) > 5f) return fallback
        val sx = ix2 + 2f * r2[0]
        val sy = iy2 + 2f * r2[1]

        // độ phân giải đầy đủ
        val m1 = 8
        val ix1 = Math.round(sx)
        val iy1 = Math.round(sy)
        val p1 = blur5(patch(base, w, h, x0, y0, pw, ph, 1, gain), pw, ph)
        val q1 = blur5(patch(cur, w, h, x0 + ix1 - m1, y0 + iy1 - m1, pw + 2 * m1, ph + 2 * m1, 1, gain), pw + 2 * m1, ph + 2 * m1)
        val r1 = lk(p1, pw, ph, q1, m1, sx - ix1, sy - iy1) ?: return floatArrayOf(sx, sy)
        if (abs(r1[0] - (sx - ix1)) > 1.5f || abs(r1[1] - (sy - iy1)) > 1.5f) return floatArrayOf(sx, sy)
        return floatArrayOf(ix1 + r1[0], iy1 + r1[1])
    }

    /**
     * Ghép các khung (khung đầu là khung gốc) trong vùng `region` thành bitmap độ phân giải 2×, rồi chạy bộ lọc `proc` từng dải.
     * Độ sáng cộng dồn ở lưới 2×, màu (hiệu B−Y, R−Y) cộng dồn ở lưới 1× rồi nội suy song tuyến lên 2×.
     * Ném lỗi (kể cả OOM) để nơi gọi quay về chế độ một khung.
     */
    /** Số luồng tối đa cho ghép/làm nét. PhotoProcessor đặt 8 cho HQ RAW (chấp nhận nóng hơn để nhanh), 4 cho các chế độ khác. Máy ít nhân hơn thì tự dùng đúng số nhân có. */
    @Volatile var coreCap = 4

    fun merge(paths: List<String>, region: Rect, progress: ((Int) -> Unit)? = null, proc: (IntArray, Int, Int) -> Unit): Bitmap {
        val t0 = SystemClock.elapsedRealtime()
        val w = region.width()
        val h = region.height()
        val base = decode(paths[0], region)
        val baseS = lumaDown(base, w, h, 4)
        val n = paths.size - 1
        val decoded = arrayOfNulls<IntArray>(n)
        val shiftsArr = arrayOfNulls<FloatArray>(n)
        val doneFrames = AtomicInteger(0)
        if (n > 0) {
            // giải mã + căn chỉnh các khung phụ song song (tối đa 2 luồng để không đỉnh bộ nhớ)
            val pool = Executors.newFixedThreadPool(min(2, n))
            try {
                val futs = ArrayList<java.util.concurrent.Future<*>>()
                for (i in 1..n) {
                    futs.add(pool.submit(Runnable {
                        try {
                            val f = decode(paths[i], region)
                            val c = coarse(baseS, lumaDown(f, w, h, 4), w / 4, h / 4)
                            val sh = refine(base, f, w, h, c)
                            // lệch quá xa = rung/chuyển động mạnh: bỏ khung để khỏi nát chi tiết
                            if (abs(sh[0]) <= 24f && abs(sh[1]) <= 24f) {
                                decoded[i - 1] = f
                                shiftsArr[i - 1] = sh
                            }
                        } catch (_: Throwable) {
                            // bỏ khung hỏng (kể cả thiếu bộ nhớ ở khung này)
                        }
                        progress?.invoke(15 * doneFrames.incrementAndGet() / paths.size)
                    }))
                }
                for (f in futs) f.get()
            } finally {
                pool.shutdown()
            }
        }
        val tAligned = SystemClock.elapsedRealtime()

        // khung 0 = gốc (lệch 0), các khung sau theo độ lệch đã ước lượng
        val all = ArrayList<IntArray>()
        all.add(base)
        val shx = ArrayList<Float>()
        val shy = ArrayList<Float>()
        shx.add(0f); shy.add(0f)
        for (k in 0 until n) {
            val f = decoded[k] ?: continue
            val s = shiftsArr[k] ?: continue
            all.add(f); shx.add(s[0]); shy.add(s[1])
        }
        lastUsed = all.size
        val nf = all.size
        val sx = FloatArray(nf) { shx[it] }
        val sy = FloatArray(nf) { shy[it] }
        val baseL = ByteArray(w * h)
        for (i in 0 until w * h) baseL[i] = luma(base[i]).toByte()

        val ow = w * SCALE
        val oh = h * SCALE
        val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val band = 96
        val bands = (oh + band - 1) / band
        val cores = Runtime.getRuntime().availableProcessors().coerceIn(1, coreCap)
        val outLock = Any()
        val lambda = 0.2f
        val done = AtomicInteger(0)
        // trọng số nội suy theo cột: bicubic Catmull-Rom cho độ sáng, song tuyến (phần lẻ cxf) cho màu (tính một lần)
        val bxi = IntArray(ow)
        val bxw = FloatArray(ow * 4)
        val cxf = FloatArray(ow)
        for (i in 0 until ow) {
            val rx = ((i - 0.5f) / SCALE).coerceIn(0f, (w - 1).toFloat())
            val ix = rx.toInt()
            bxi[i] = ix
            cxf[i] = rx - ix
            cr(rx - ix, bxw, i * 4)
        }
        val crRows = band / SCALE + 8 + 2 * CR

        java.util.stream.IntStream.range(0, cores).parallel().forEach { core ->
            val accY = FloatArray(ow * band)
            val accW = FloatArray(ow * band)
            val accCb = FloatArray(w * crRows)
            val accCr = FloatArray(w * crRows)
            val accCw = FloatArray(w * crRows)
            val tCb = FloatArray(w * crRows)
            val tCr = FloatArray(w * crRows)
            val dCb = FloatArray(w * crRows)
            val dCr = FloatArray(w * crRows)
            val px = IntArray(ow * band)
            val rowY = Array(crRows) { FloatArray(ow) }
            val rowCb = Array(crRows) { FloatArray(ow) }
            val rowCr = Array(crRows) { FloatArray(ow) }
            val yline = FloatArray(w)
            var bi = core
            while (bi < bands) {
                val y0 = bi * band
                val y1 = min(oh, y0 + band)
                val bh = y1 - y0
                // các hàng ảnh gốc (lưới 1×) cần cho dải này
                val rb = max(0, ((y0 - 0.5f) / SCALE).toInt() - 1)
                val re = min(h - 1, ((y1 - 1 - 0.5f) / SCALE).toInt() + 2)
                val nr = re - rb + 1
                // vùng màu có thêm viền CR hàng mỗi phía để lọc khử nhiễu màu không bị cụt ở mép dải
                val rbA = max(0, rb - CR)
                val reA = min(h - 1, re + CR)
                val nrA = reA - rbA + 1
                java.util.Arrays.fill(accY, 0, ow * bh, 0f)
                java.util.Arrays.fill(accW, 0, ow * bh, 0f)
                java.util.Arrays.fill(accCb, 0, w * nrA, 0f)
                java.util.Arrays.fill(accCr, 0, w * nrA, 0f)
                java.util.Arrays.fill(accCw, 0, w * nrA, 0f)
                for (k in 0 until nf) {
                    val fpx = all[k]
                    val dx = sx[k]
                    val dy = sy[k]
                    val rdx = Math.round(dx)
                    val rdy = Math.round(dy)
                    // điểm ảnh nguồn (x,y) -> toạ độ gốc (x-dx, y-dy) -> lưới ra: o = 2*r + 0.5
                    val yLo = max(0, min(((y0 - 4 - 0.5f) / SCALE + dy).toInt() - 1, rbA + rdy))
                    val yHi = min(h - 1, max(((y1 + 3 - 0.5f) / SCALE + dy).toInt() + 1, reA + rdy))
                    for (y in yLo..yHi) {
                        val oyf = SCALE * (y - dy) + 0.5f
                        val oy = Math.floor(oyf.toDouble()).toInt()
                        val fy = oyf - oy
                        val lumaRow = !(oy + 2 < y0 || oy - 1 >= y1)
                        val qy = (fy * KQ).toInt().coerceIn(0, KQ - 1)
                        val byp = y - rdy
                        val chromaRow = byp in rbA..reA
                        if (!lumaRow && !chromaRow) continue
                        val crow = (byp - rbA) * w
                        for (x in 0 until w) {
                            val p = fpx[y * w + x]
                            val bxp = x - rdx
                            // giảm trọng số vùng khác khung gốc (chuyển động) để không bị bóng ma
                            var wt = 1f
                            if (k > 0) {
                                if (bxp in 0 until w && byp in 0 until h) {
                                    val d = (luma(p) - (baseL[byp * w + bxp].toInt() and 255)).toFloat()
                                    wt = 1f / (1f + (d * d) / 576f)   // ~24 mức xám: vượt ngưỡng này là coi như chuyển động
                                } else wt = 0.4f
                            }
                            val r = ((p shr 16) and 255).toFloat()
                            val g = ((p shr 8) and 255).toFloat()
                            val b = (p and 255).toFloat()
                            val yv = 0.299f * r + 0.587f * g + 0.114f * b
                            if (lumaRow) {
                                val oxf = SCALE * (x - dx) + 0.5f
                                // sàn nhanh: với số nguyên âm cho phần lẻ = 1 thay vì 0 — trọng số nội suy vẫn như nhau
                                val ox = oxf.toInt() - (if (oxf < 0f) 1 else 0)
                                val fx = oxf - ox
                                val qx = (fx * KQ).toInt().coerceIn(0, KQ - 1)
                                for (jy in 0..3) {
                                    val yy = oy - 1 + jy
                                    if (yy < y0 || yy >= y1) continue
                                    val wy = wt * KTAB[qy * 4 + jy]
                                    val rowI = (yy - y0) * ow
                                    for (jx in 0..3) {
                                        val xx = ox - 1 + jx
                                        if (xx < 0 || xx >= ow) continue
                                        val ww = wy * KTAB[qx * 4 + jx]
                                        val idx = rowI + xx
                                        accY[idx] += yv * ww
                                        accW[idx] += ww
                                    }
                                }
                            }
                            if (chromaRow && bxp in 0 until w) {
                                val ci = crow + bxp
                                accCb[ci] += (b - yv) * wt
                                accCr[ci] += (r - yv) * wt
                                accCw[ci] += wt
                            }
                        }
                    }
                }
                // chuẩn hoá màu 1× (khung gốc luôn góp trọng số 1 nên mẫu số ≥ 1)
                for (i in 0 until w * nrA) {
                    val cw = accCw[i]
                    accCb[i] /= cw
                    accCr[i] /= cw
                }
                // KHỬ NHIỄU MÀU: lọc song phương tách hai chiều trên Cb/Cr ở lưới 1×, dẫn hướng bằng độ sáng khung gốc.
                // Camera đã bị tắt khử nhiễu khi chụp ghép nên màu còn lốm đốm; ghép 5 khung chưa đủ làm sạch.
                for (r in 0 until nrA) {
                    val ro = r * w
                    val gro = (rbA + r) * w
                    for (x in 0 until w) {
                        val gc = baseL[gro + x].toInt() and 255
                        var sb = 0f; var sr = 0f; var sw = 0f
                        for (d in -CR..CR) {
                            val xx = (x + d).coerceIn(0, w - 1)
                            val gv = baseL[gro + xx].toInt() and 255
                            val wg = CSW[d + CR] * CRW[abs(gv - gc)]
                            sb += accCb[ro + xx] * wg
                            sr += accCr[ro + xx] * wg
                            sw += wg
                        }
                        tCb[ro + x] = sb / sw
                        tCr[ro + x] = sr / sw
                    }
                }
                for (srow in rb..re) {
                    val r0 = srow - rbA
                    val o = (srow - rb) * w
                    for (x in 0 until w) {
                        val gc = baseL[srow * w + x].toInt() and 255
                        var sb = 0f; var sr = 0f; var sw = 0f
                        for (d in -CR..CR) {
                            val rr = (r0 + d).coerceIn(0, nrA - 1)
                            val gv = baseL[(rbA + rr) * w + x].toInt() and 255
                            val wg = CSW[d + CR] * CRW[abs(gv - gc)]
                            sb += tCb[rr * w + x] * wg
                            sr += tCr[rr * w + x] * wg
                            sw += wg
                        }
                        dCb[o + x] = sb / sw
                        dCr[o + x] = sr / sw
                    }
                }
                // hoàn thiện: độ sáng gốc phóng 2× bằng bicubic (lấp lỗ), màu 1× nội suy song tuyến ngang lên 2×
                for (srow in rb..re) {
                    val ro = srow * w
                    val co = (srow - rb) * w
                    for (x in 0 until w) {
                        val q = base[ro + x]
                        yline[x] = 0.299f * ((q shr 16) and 255) + 0.587f * ((q shr 8) and 255) + 0.114f * (q and 255)
                    }
                    val ry = rowY[srow - rb]
                    val rcb = rowCb[srow - rb]
                    val rcr = rowCr[srow - rb]
                    for (i in 0 until ow) {
                        val c0 = bxi[i] - 1
                        var yy = 0f
                        for (k in 0..3) {
                            val col = (c0 + k).coerceIn(0, w - 1)
                            yy += yline[col] * bxw[i * 4 + k]
                        }
                        ry[i] = yy
                        val ia = bxi[i]
                        val ib = if (ia + 1 < w) ia + 1 else ia
                        val f = cxf[i]
                        rcb[i] = dCb[co + ia] * (1f - f) + dCb[co + ib] * f
                        rcr[i] = dCr[co + ia] * (1f - f) + dCr[co + ib] * f
                    }
                }
                val wy = FloatArray(4)
                for (j in 0 until bh) {
                    val oy = y0 + j
                    val rYv = ((oy - 0.5f) / SCALE).coerceIn(0f, (h - 1).toFloat())
                    val iy = rYv.toInt()
                    val fyv = rYv - iy
                    cr(fyv, wy, 0)
                    val i0 = (iy - 1).coerceIn(0, h - 1) - rb
                    val i1 = iy.coerceIn(0, h - 1) - rb
                    val i2 = (iy + 1).coerceIn(0, h - 1) - rb
                    val i3 = (iy + 2).coerceIn(0, h - 1) - rb
                    val y0r = rowY[i0]; val y1r = rowY[i1]; val y2r = rowY[i2]; val y3r = rowY[i3]
                    val cb1 = rowCb[i1]; val cb2 = rowCb[i2]
                    val cr1 = rowCr[i1]; val cr2 = rowCr[i2]
                    for (i in 0 until ow) {
                        val yb = (y0r[i] * wy[0] + y1r[i] * wy[1] + y2r[i] * wy[2] + y3r[i] * wy[3]).coerceIn(0f, 255f)
                        val idx = j * ow + i
                        val yv = (accY[idx] + lambda * yb) / (accW[idx] + lambda)
                        val cbv = cb1[i] * (1f - fyv) + cb2[i] * fyv
                        val crv = cr1[i] * (1f - fyv) + cr2[i] * fyv
                        val r = (yv + crv + 0.5f).toInt().coerceIn(0, 255)
                        val g = (yv - 0.5094f * crv - 0.1942f * cbv + 0.5f).toInt().coerceIn(0, 255)
                        val b = (yv + cbv + 0.5f).toInt().coerceIn(0, 255)
                        px[idx] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                }
                proc(px, 0, ow * bh)
                synchronized(outLock) { out.setPixels(px, 0, ow, 0, y0, ow, bh) }
                progress?.invoke(15 + 85 * done.incrementAndGet() / bands)
                bi += cores
            }
        }
        val t1 = SystemClock.elapsedRealtime()
        lastAlignMs = tAligned - t0
        lastFuseMs = t1 - tAligned
        return out
    }

    private val K7 = floatArrayOf(1f / 64f, 6f / 64f, 15f / 64f, 20f / 64f, 15f / 64f, 6f / 64f, 1f / 64f)
    /** Nhân Gauss hẹp (σ≈0,8): làm nét ở tần số cao nhất để lấy lại chi tiết mịn mà nhân rộng K7 không với tới. */
    val K_FINE = floatArrayOf(0.0002f, 0.0220f, 0.2282f, 0.4992f, 0.2282f, 0.0220f, 0.0002f)

    /**
     * Làm nét cạnh có chọn lọc (unsharp mask trên ĐỘ SÁNG, có cổng): chỉ khuếch đại phần chênh lệch lớn (cạnh, nét chữ), phần chênh
     * nhỏ (nhiễu, vân nén JPEG) gần như không bị khuếch đại -> sắc hơn mà không vỡ hạt. Không làm mịn nên không làm mờ chi tiết.
     * Trả về bitmap mới (hết bộ nhớ thì trả ảnh gốc).
     */
    /**
     * Khử nhiễu màu cho ảnh 1 khung (không đụng độ sáng): lọc song phương tách hai chiều trên Cb/Cr, dẫn hướng bằng độ sáng,
     * nên chỗ phẳng hết đốm màu còn ranh giới màu thật (chữ, cạnh) giữ nguyên. Ảnh phân giải cao thì lấy mẫu thưa hơn.
     */
    fun denoiseChroma(bmp: Bitmap) {
        val w = bmp.width
        val h = bmp.height
        val step = (w / 3000).coerceAtLeast(1)
        val halo = CR * step
        val sh = 32
        val strips = (h + sh - 1) / sh
        java.util.stream.IntStream.range(0, strips).parallel().forEach { si ->
            val y0 = si * sh
            val y1 = min(h, y0 + sh)
            val ya = max(0, y0 - halo)
            val yb = min(h, y1 + halo)
            val nrA = yb - ya
            val pix = IntArray(w * nrA)
            synchronized(bmp) { bmp.getPixels(pix, 0, w, 0, ya, w, nrA) }
            val yy = IntArray(w * nrA)
            val cb = FloatArray(w * nrA)
            val cr = FloatArray(w * nrA)
            for (i in pix.indices) {
                val p = pix[i]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                val y = (299 * r + 587 * g + 114 * b) / 1000
                yy[i] = y
                cb[i] = (b - y).toFloat()
                cr[i] = (r - y).toFloat()
            }
            val tCb = FloatArray(w * nrA)
            val tCr = FloatArray(w * nrA)
            for (r in 0 until nrA) {
                val ro = r * w
                for (x in 0 until w) {
                    val gc = yy[ro + x]
                    var sb = 0f; var sr = 0f; var sw = 0f
                    for (d in -CR..CR) {
                        val xx = (x + d * step).coerceIn(0, w - 1)
                        val wg = CSW[d + CR] * CRW[abs(yy[ro + xx] - gc)]
                        sb += cb[ro + xx] * wg
                        sr += cr[ro + xx] * wg
                        sw += wg
                    }
                    tCb[ro + x] = sb / sw
                    tCr[ro + x] = sr / sw
                }
            }
            val out = IntArray(w * (y1 - y0))
            for (row in y0 until y1) {
                val r0 = row - ya
                for (x in 0 until w) {
                    val gc = yy[r0 * w + x]
                    var sb = 0f; var sr = 0f; var sw = 0f
                    for (d in -CR..CR) {
                        val rr = (r0 + d * step).coerceIn(0, nrA - 1)
                        val wg = CSW[d + CR] * CRW[abs(yy[rr * w + x] - gc)]
                        sb += tCb[rr * w + x] * wg
                        sr += tCr[rr * w + x] * wg
                        sw += wg
                    }
                    val y = gc
                    val nr = (y + sr / sw).toInt().coerceIn(0, 255)
                    val nb = (y + sb / sw).toInt().coerceIn(0, 255)
                    val ng = ((y * 1000 - 299 * nr - 114 * nb) / 587).coerceIn(0, 255)
                    out[(row - y0) * w + x] = (pix[r0 * w + x] and (0xFF shl 24)) or (nr shl 16) or (ng shl 8) or nb
                }
            }
            synchronized(bmp) { bmp.setPixels(out, 0, w, 0, y0, w, y1 - y0) }
        }
    }

    /**
     * Khử sương mù NHẸ (kiểu kênh tối): ước lượng "màn sương" từ giá trị nhỏ nhất của R/G/B theo ô lớn rồi làm mượt,
     * trừ bớt ánh sáng nền ra khỏi từng điểm ảnh. Độ mạnh tối đa ~omega (rất nhẹ), t không xuống dưới 0,8,
     * và vùng sáng gần trắng được giảm tác dụng để tường trắng/bầu trời không bị tối đi.
     */
    fun dehaze(bmp: Bitmap, omega: Float = 0.18f) {
        val w = bmp.width
        val h = bmp.height
        val cell = max(8, w / 300)
        val gw = (w + cell - 1) / cell
        val gh = (h + cell - 1) / cell
        val dark = FloatArray(gw * gh) { 255f }
        val hist = IntArray(256)
        var samples = 0L
        // lượt 1: kênh tối theo ô + biểu đồ độ sáng lấy mẫu thưa (để tìm ánh sáng nền A)
        val band = cell * 8
        val px = IntArray(w * band)
        var y0 = 0
        while (y0 < h) {
            val n = min(band, h - y0)
            bmp.getPixels(px, 0, w, 0, y0, w, n)
            for (yy in 0 until n) {
                val gy = (y0 + yy) / cell
                val ro = yy * w
                val sampleRow = (yy and 3) == 0
                for (x in 0 until w) {
                    val p = px[ro + x]
                    val r = (p shr 16) and 255
                    val g = (p shr 8) and 255
                    val b = p and 255
                    val mn = min(r, min(g, b))
                    val ci = gy * gw + x / cell
                    if (mn < dark[ci]) dark[ci] = mn.toFloat()
                    if (sampleRow && (x and 3) == 0) {
                        hist[(299 * r + 587 * g + 114 * b) / 1000]++
                        samples++
                    }
                }
            }
            y0 += n
        }
        var acc = 0L
        var aLevel = 255
        val target = (samples * 0.005).toLong()
        for (v in 255 downTo 0) { acc += hist[v]; if (acc >= target) { aLevel = v; break } }
        val atm = aLevel.toFloat().coerceIn(190f, 255f)
        // làm mượt bản đồ sương: min 3×3 rồi hai lần trung bình 3×3
        fun filt(src: FloatArray, useMin: Boolean): FloatArray {
            val dst = FloatArray(src.size)
            for (gy in 0 until gh) for (gx in 0 until gw) {
                var s = if (useMin) 1e9f else 0f
                var c = 0
                for (dy in -1..1) for (dx in -1..1) {
                    val yy = (gy + dy).coerceIn(0, gh - 1)
                    val xx = (gx + dx).coerceIn(0, gw - 1)
                    val v = src[yy * gw + xx]
                    if (useMin) { if (v < s) s = v } else { s += v; c++ }
                }
                dst[gy * gw + gx] = if (useMin) s else s / c
            }
            return dst
        }
        val veil = filt(filt(filt(dark, true), false), false)

        // lượt 2: áp dụng, song song theo dải hàng
        val sh = 32
        val strips = (h + sh - 1) / sh
        java.util.stream.IntStream.range(0, strips).parallel().forEach { si ->
            val ys = si * sh
            val n = min(sh, h - ys)
            val buf = IntArray(w * n)
            synchronized(bmp) { bmp.getPixels(buf, 0, w, 0, ys, w, n) }
            for (yy in 0 until n) {
                val fy = ((ys + yy) + 0.5f) / cell - 0.5f
                val y1 = Math.floor(fy.toDouble()).toInt()
                val ty = fy - y1
                val ya = y1.coerceIn(0, gh - 1)
                val yb = (y1 + 1).coerceIn(0, gh - 1)
                val ro = yy * w
                for (x in 0 until w) {
                    val fx = (x + 0.5f) / cell - 0.5f
                    val x1 = Math.floor(fx.toDouble()).toInt()
                    val tx = fx - x1
                    val xa = x1.coerceIn(0, gw - 1)
                    val xb = (x1 + 1).coerceIn(0, gw - 1)
                    val v0 = veil[ya * gw + xa] * (1f - tx) + veil[ya * gw + xb] * tx
                    val v1 = veil[yb * gw + xa] * (1f - tx) + veil[yb * gw + xb] * tx
                    val v = v0 * (1f - ty) + v1 * ty
                    val p = buf[ro + x]
                    val r = (p shr 16) and 255
                    val g = (p shr 8) and 255
                    val b = p and 255
                    val l = (299 * r + 587 * g + 114 * b) / 1000
                    val hp = when {
                        l <= 190 -> 1f
                        l >= 245 -> 0f
                        else -> { val u = (245 - l) / 55f; u * u * (3f - 2f * u) }
                    }
                    val t = (1f - omega * hp * (v / atm)).coerceAtLeast(0.8f)
                    val nr = ((r - atm) / t + atm).toInt().coerceIn(0, 255)
                    val ng = ((g - atm) / t + atm).toInt().coerceIn(0, 255)
                    val nb = ((b - atm) / t + atm).toInt().coerceIn(0, 255)
                    buf[ro + x] = (p and (0xFF shl 24)) or (nr shl 16) or (ng shl 8) or nb
                }
            }
            synchronized(bmp) { bmp.setPixels(buf, 0, w, 0, ys, w, n) }
        }
    }

    /** Căn chỉnh toàn khung (dịch tịnh tiến) của mọi khung so với khung 0; tách hàm riêng để giải phóng bộ nhớ khung gốc trước khi xếp chồng. */
    private fun alignAll(paths: List<String>, region: Rect, progress: ((Int) -> Unit)?): Triple<FloatArray, FloatArray, BooleanArray> {
        val w = region.width()
        val h = region.height()
        val n = paths.size
        val sx = FloatArray(n)
        val sy = FloatArray(n)
        val ok = BooleanArray(n)
        ok[0] = true
        val base = decode(paths[0], region)
        val baseS = lumaDown(base, w, h, 4)
        for (i in 1 until n) {
            try {
                val f = decode(paths[i], region)
                val c = coarse(baseS, lumaDown(f, w, h, 4), w / 4, h / 4)
                val sh = refine(base, f, w, h, c)
                if (abs(sh[0]) <= 24f && abs(sh[1]) <= 24f) { sx[i] = sh[0]; sy[i] = sh[1]; ok[i] = true }
            } catch (_: Throwable) {
            }
            progress?.invoke(25 * i / n)
        }
        return Triple(sx, sy, ok)
    }

    /**
     * VỆT SÁNG (phơi sáng dài giả lập): căn chỉnh các khung chụp liên tiếp về khung đầu (nền đứng yên giữ nét, rung tay được bù),
     * rồi xếp chồng theo từng dải ngang để tiết kiệm bộ nhớ:
     *  - nền tĩnh = trung bình các khung (giảm nhiễu ~√N, chi tiết rõ);
     *  - vật chuyển động để lại vệt mờ phía sau (trung bình);
     *  - nguồn sáng chuyển động mạnh (đèn xe, đèn pin...) được "lighten" giữ nguyên độ sáng thành vệt sáng thay vì bị loãng.
     */
    fun trail(paths: List<String>, region: Rect, progress: ((Int) -> Unit)? = null, proc: (IntArray, Int, Int) -> Unit): Bitmap {
        val t0 = SystemClock.elapsedRealtime()
        val w = region.width()
        val h = region.height()
        val (sx, sy, ok) = alignAll(paths, region, progress)
        val idx = ArrayList<Int>()
        for (i in paths.indices) if (ok[i]) idx.add(i)
        if (idx.size < 3) throw IllegalStateException("Không đủ khung căn chỉnh được cho vệt sáng")
        lastUsed = idx.size
        lastAlignMs = SystemClock.elapsedRealtime() - t0
        val nf = idx.size
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val M = 28
        val bandRows = ((h + 5) / 6).coerceAtLeast(64)
        var y0 = 0
        var bandsDone = 0
        val bands = (h + bandRows - 1) / bandRows
        while (y0 < h) {
            val y1 = min(h, y0 + bandRows)
            val bh = y1 - y0
            val ya = max(0, y0 - M)
            val yb = min(h, y1 + M)
            val sumR = IntArray(w * bh)
            val sumG = IntArray(w * bh)
            val sumB = IntArray(w * bh)
            val maxP = IntArray(w * bh)
            val maxL = IntArray(w * bh) { -1 }
            for (k in idx) {
                val f = decode(paths[k], Rect(region.left, region.top + ya, region.right, region.top + yb))
                val rows = yb - ya
                val ox = Math.floor(sx[k].toDouble()).toInt()
                val oy = Math.floor(sy[k].toDouble()).toInt()
                val fx = sx[k] - ox
                val fy = sy[k] - oy
                val w00 = (1f - fx) * (1f - fy)
                val w01 = fx * (1f - fy)
                val w10 = (1f - fx) * fy
                val w11 = fx * fy
                java.util.stream.IntStream.range(0, bh).parallel().forEach { r ->
                    val gy = y0 + r
                    val ra = (gy + oy - ya).coerceIn(0, rows - 1)
                    val rb = (gy + oy + 1 - ya).coerceIn(0, rows - 1)
                    val o = r * w
                    for (x in 0 until w) {
                        val xa = (x + ox).coerceIn(0, w - 1)
                        val xb = (x + ox + 1).coerceIn(0, w - 1)
                        val p00 = f[ra * w + xa]; val p01 = f[ra * w + xb]
                        val p10 = f[rb * w + xa]; val p11 = f[rb * w + xb]
                        val r8 = (((p00 shr 16) and 255) * w00 + ((p01 shr 16) and 255) * w01 + ((p10 shr 16) and 255) * w10 + ((p11 shr 16) and 255) * w11 + 0.5f).toInt()
                        val g8 = (((p00 shr 8) and 255) * w00 + ((p01 shr 8) and 255) * w01 + ((p10 shr 8) and 255) * w10 + ((p11 shr 8) and 255) * w11 + 0.5f).toInt()
                        val b8 = ((p00 and 255) * w00 + (p01 and 255) * w01 + (p10 and 255) * w10 + (p11 and 255) * w11 + 0.5f).toInt()
                        val i = o + x
                        sumR[i] += r8; sumG[i] += g8; sumB[i] += b8
                        val l = (77 * r8 + 150 * g8 + 29 * b8) shr 8
                        if (l > maxL[i]) { maxL[i] = l; maxP[i] = (r8 shl 16) or (g8 shl 8) or b8 }
                    }
                }
            }
            val band = IntArray(w * bh)
            val inv = 1f / nf
            java.util.stream.IntStream.range(0, bh).parallel().forEach { r ->
                val o = r * w
                for (x in 0 until w) {
                    val i = o + x
                    val mr = sumR[i] * inv
                    val mg = sumG[i] * inv
                    val mb = sumB[i] * inv
                    val meanL = (77f * mr + 150f * mg + 29f * mb) / 256f
                    val d = maxL[i] - meanL
                    // chỉ nguồn sáng chênh hẳn so với trung bình mới thành vệt sáng; nhiễu/nền tĩnh (d nhỏ) giữ trung bình sạch
                    val u = ((d - 40f) / 70f).coerceIn(0f, 1f)
                    val wgt = u * u * (3f - 2f * u) * 0.92f
                    val mp = maxP[i]
                    val nr = (mr * (1f - wgt) + ((mp shr 16) and 255) * wgt + 0.5f).toInt().coerceIn(0, 255)
                    val ng = (mg * (1f - wgt) + ((mp shr 8) and 255) * wgt + 0.5f).toInt().coerceIn(0, 255)
                    val nb = (mb * (1f - wgt) + (mp and 255) * wgt + 0.5f).toInt().coerceIn(0, 255)
                    band[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
                }
            }
            proc(band, 0, band.size)
            out.setPixels(band, 0, w, 0, y0, w, bh)
            y0 = y1
            bandsDone++
            progress?.invoke(25 + 74 * bandsDone / bands)
        }
        lastFuseMs = SystemClock.elapsedRealtime() - t0 - lastAlignMs
        return out
    }

    /** Ước lượng độ nhiễu (σ, thang 0-255) theo Immerkær trên vài dải ngang; bỏ qua điểm có cạnh mạnh. */
    private fun estimateNoise(bmp: Bitmap): Float {
        val w = bmp.width
        val h = bmp.height
        val bh = 24
        if (w < 8 || h < bh + 2) return 3f
        val bands = 6
        val px = IntArray(w * bh)
        val lum = IntArray(w * bh)
        var sum = 0.0
        var cnt = 0L
        for (k in 0 until bands) {
            val y0 = (((h - bh) * (k + 0.5f)) / bands).toInt().coerceIn(0, h - bh)
            bmp.getPixels(px, 0, w, 0, y0, w, bh)
            for (i in px.indices) {
                val p = px[i]
                lum[i] = (299 * ((p shr 16) and 255) + 587 * ((p shr 8) and 255) + 114 * (p and 255)) / 1000
            }
            for (y in 1 until bh - 1) {
                var x = 1
                while (x < w - 1) {
                    val i = y * w + x
                    val v = lum[i - w - 1] - 2 * lum[i - w] + lum[i - w + 1] -
                        2 * lum[i - 1] + 4 * lum[i] - 2 * lum[i + 1] +
                        lum[i + w - 1] - 2 * lum[i + w] + lum[i + w + 1]
                    val a = abs(v)
                    if (a < 90) { sum += a; cnt++ }
                    x += 2
                }
            }
        }
        if (cnt == 0L) return 3f
        return (Math.sqrt(Math.PI / 2.0) * sum / (6.0 * cnt)).toFloat().coerceIn(1.5f, 9f)
    }

    /**
     * Khử nhiễu độ sáng giữ chi tiết: lọc song phương (độ rộng theo mức nhiễu ước lượng) rồi "coring" phần dư:
     * phần dư nhỏ (hạt) bị nén mạnh, phần dư lớn (cạnh, vân, nét chữ) giữ nguyên. Chỉ đổi độ sáng, màu không đổi.
     */
    fun denoiseLuma(bmp: Bitmap, strength: Float = 1f) {
        val w = bmp.width
        val h = bmp.height
        // strength > 1: khử nhiễu mạnh hơn (ảnh thiếu sáng bị nhân sáng nên hạt thô hơn); 1 = như cũ
        val sg = (estimateNoise(bmp) * strength).coerceAtMost(12f)
        val R = 3
        val sp = FloatArray(2 * R + 1) { Math.exp((-((it - R) * (it - R)) / (2.0 * 1.6 * 1.6))).toFloat() }
        val sr = (sg * 2.6f).coerceIn(8f, 28f)
        val rw = FloatArray(256) { Math.exp((-(it * it) / (2.0 * sr * sr))).toFloat() }
        val t1 = sg * 0.8f
        val t2 = sg * 3.2f
        val floorK = 0.1f
        val sh = 32
        val strips = (h + sh - 1) / sh
        java.util.stream.IntStream.range(0, strips).parallel().forEach { si ->
            val y0 = si * sh
            val y1 = min(h, y0 + sh)
            val ya = max(0, y0 - R)
            val yb = min(h, y1 + R)
            val nrA = yb - ya
            val pix = IntArray(w * nrA)
            synchronized(bmp) { bmp.getPixels(pix, 0, w, 0, ya, w, nrA) }
            val yy = IntArray(w * nrA)
            for (i in pix.indices) {
                val p = pix[i]
                yy[i] = (299 * ((p shr 16) and 255) + 587 * ((p shr 8) and 255) + 114 * (p and 255)) / 1000
            }
            val tY = FloatArray(w * nrA)
            for (r in 0 until nrA) {
                val ro = r * w
                for (x in 0 until w) {
                    val gc = yy[ro + x]
                    var s = 0f; var sw = 0f
                    for (d in -R..R) {
                        val xx = (x + d).coerceIn(0, w - 1)
                        val v = yy[ro + xx]
                        val wg = sp[d + R] * rw[abs(v - gc)]
                        s += v * wg
                        sw += wg
                    }
                    tY[ro + x] = s / sw
                }
            }
            val out = IntArray(w * (y1 - y0))
            for (row in y0 until y1) {
                val r0 = row - ya
                for (x in 0 until w) {
                    val gc = yy[r0 * w + x]
                    var s = 0f; var sw = 0f
                    for (d in -R..R) {
                        val rr = (r0 + d).coerceIn(0, nrA - 1)
                        val wg = sp[d + R] * rw[abs(yy[rr * w + x] - gc)]
                        s += tY[rr * w + x] * wg
                        sw += wg
                    }
                    val den = s / sw
                    val res = gc - den
                    val a = abs(res)
                    val k = when {
                        a <= t1 -> floorK
                        a >= t2 -> 1f
                        else -> { val u = (a - t1) / (t2 - t1); floorK + (1f - floorK) * u * u * (3f - 2f * u) }
                    }
                    val delta = Math.round(den + res * k - gc)
                    val p = pix[r0 * w + x]
                    val nr = (((p shr 16) and 255) + delta).coerceIn(0, 255)
                    val ng = (((p shr 8) and 255) + delta).coerceIn(0, 255)
                    val nb = ((p and 255) + delta).coerceIn(0, 255)
                    out[(row - y0) * w + x] = (p and (0xFF shl 24)) or (nr shl 16) or (ng shl 8) or nb
                }
            }
            synchronized(bmp) { bmp.setPixels(out, 0, w, 0, y0, w, y1 - y0) }
        }
    }

    fun refine(src: Bitmap, amount: Float = 1.0f, thr: Float = 8f, kern: FloatArray = K7): Bitmap {
        val w = src.width
        val h = src.height
        val out = try { Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) } catch (t: OutOfMemoryError) { return src }
        val strip = 96
        val strips = (h + strip - 1) / strip
        val cores = Runtime.getRuntime().availableProcessors().coerceIn(1, coreCap)
        val lock = Any()
        val k0 = kern[0]; val k1 = kern[1]; val k2 = kern[2]; val k3 = kern[3]
        java.util.stream.IntStream.range(0, cores).parallel().forEach { core ->
            val inp = IntArray(w * (strip + 6))
            val hb = FloatArray(w * (strip + 6))
            val lum = IntArray(w * (strip + 6))
            val res = IntArray(w * strip)
            var si = core
            while (si < strips) {
                val y0 = si * strip
                val y1 = min(h, y0 + strip)
                val bh = y1 - y0
                val r0 = max(0, y0 - 3)
                val r1 = min(h, y1 + 3)
                val nr = r1 - r0
                src.getPixels(inp, 0, w, 0, r0, w, nr)
                for (i in 0 until nr * w) lum[i] = luma(inp[i])
                // làm mờ ngang (nhị thức 7 điểm): phần giữa không cần kẹp chỉ số, chỉ hai mép mới kẹp
                for (r in 0 until nr) {
                    val ro = r * w
                    for (x in 0 until w) {
                        if (x >= 3 && x < w - 3) {
                            val o = ro + x
                            hb[o] = k0 * (lum[o - 3] + lum[o + 3]) + k1 * (lum[o - 2] + lum[o + 2]) + k2 * (lum[o - 1] + lum[o + 1]) + k3 * lum[o]
                        } else {
                            var acc = 0f
                            for (k in 0..6) acc += kern[k] * lum[ro + (x + k - 3).coerceIn(0, w - 1)]
                            hb[ro + x] = acc
                        }
                    }
                }
                for (j in 0 until bh) {
                    val ry = y0 + j - r0
                    // sáu hàng lân cận (kẹp ở mép ảnh) tính một lần cho cả hàng
                    val a0 = (ry - 3).coerceIn(0, nr - 1) * w
                    val a1 = (ry - 2).coerceIn(0, nr - 1) * w
                    val a2 = (ry - 1).coerceIn(0, nr - 1) * w
                    val a3 = ry * w
                    val a4 = (ry + 1).coerceIn(0, nr - 1) * w
                    val a5 = (ry + 2).coerceIn(0, nr - 1) * w
                    val a6 = (ry + 3).coerceIn(0, nr - 1) * w
                    for (x in 0 until w) {
                        val bl = k0 * (hb[a0 + x] + hb[a6 + x]) + k1 * (hb[a1 + x] + hb[a5 + x]) +
                            k2 * (hb[a2 + x] + hb[a4 + x]) + k3 * hb[a3 + x]
                        val c = inp[a3 + x]
                        val dl = lum[a3 + x] - bl
                        val ad = if (dl < 0f) -dl else dl
                        val add = amount * dl * (ad / (ad + thr))
                        val r = (((c shr 16) and 255) + add).toInt().coerceIn(0, 255)
                        val g = (((c shr 8) and 255) + add).toInt().coerceIn(0, 255)
                        val bch = ((c and 255) + add).toInt().coerceIn(0, 255)
                        res[j * w + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bch
                    }
                }
                synchronized(lock) { out.setPixels(res, 0, w, 0, y0, w, bh) }
                si += cores
            }
        }
        return out
    }
}
