package com.xpanmode.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * HQ ghép nhiều khung: máy không cho chụp 50MP nên chụp liên tiếp N khung 12,6MP, căn chỉnh (tay run tạo ra lệch dưới 1 điểm ảnh),
 * rồi "shift-and-add" lên lưới 2× độ phân giải. Chi tiết thật được thu thêm từ các khung lệch nhau, nhiễu giảm; vùng chuyển động
 * (ghost) bị giảm trọng số nên không bị bóng ma. Không phải 50MP thật nhưng sắc và sạch hơn hẳn một khung đơn rồi crop.
 *
 * Bản này: căn chỉnh Lucas-Kanade dưới điểm ảnh (sai ~0,01 px thay vì ~0,08 px), giải mã + căn chỉnh các khung song song,
 * và cộng dồn ĐỘ SÁNG ở lưới 2× còn MÀU ở lưới 1× (JPEG vốn chỉ có màu 4:2:0 nên không mất chi tiết) để nhanh hơn.
 */
object MultiFrame {
    private const val SCALE = 2
    /** Độ chi tiết tối thiểu của mảng dùng để căn chỉnh (nhiễu phẳng ≤ ~4,5; ảnh có chi tiết ≥ ~12). */
    private const val TEX_MIN = 3f
    /** Số khung thực sự được ghép trong lần merge gần nhất (khung hỏng bị bỏ). */
    @Volatile var lastUsed = 0
    /** Thời gian (ms) giải mã + căn chỉnh và cộng dồn/hoàn thiện của lần merge gần nhất, để báo cho người dùng. */
    @Volatile var lastAlignMs = 0L
    @Volatile var lastFuseMs = 0L

    /** Trọng số Catmull-Rom cho 4 điểm quanh vị trí lẻ t (0..1). */
    private fun cr(t: Float, out: FloatArray, o: Int) {
        val t2 = t * t
        val t3 = t2 * t
        out[o] = -0.5f * t3 + t2 - 0.5f * t
        out[o + 1] = 1.5f * t3 - 2.5f * t2 + 1f
        out[o + 2] = -1.5f * t3 + 2f * t2 + 0.5f * t
        out[o + 3] = 0.5f * t3 - 0.5f * t2
    }

    private fun luma(p: Int): Int = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8

    private fun decode(path: String, region: Rect): IntArray {
        @Suppress("DEPRECATION")
        val dec = BitmapRegionDecoder.newInstance(path, false) ?: throw IllegalStateException("Không đọc được khung")
        try {
            val o = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val b = dec.decodeRegion(region, o) ?: throw IllegalStateException("decodeRegion null")
            val w = b.width
            val h = b.height
            val out = IntArray(w * h)
            b.getPixels(out, 0, w, 0, 0, w, h)
            b.recycle()
            return out
        } finally {
            dec.recycle()
        }
    }

    /** Ảnh xám thu nhỏ s lần (trung bình khối s×s). */
    private fun lumaDown(px: IntArray, w: Int, h: Int, s: Int): FloatArray {
        val lw = w / s
        val lh = h / s
        val out = FloatArray(lw * lh)
        for (y in 0 until lh) for (x in 0 until lw) {
            var sum = 0
            for (j in 0 until s) {
                val row = (y * s + j) * w + x * s
                for (i in 0 until s) sum += luma(px[row + i])
            }
            out[y * lw + x] = sum.toFloat() / (s * s)
        }
        return out
    }

    /**
     * Bước thô: độ lệch nguyên (theo điểm ảnh gốc, bội của 4) của `cur` so với `ref`: cur(x+dx, y+dy) ≈ ref(x, y).
     * SAD trên ảnh thu nhỏ 4 lần (lw×lh là kích thước ảnh thu nhỏ).
     */
    private fun coarse(refS: FloatArray, curS: FloatArray, lw: Int, lh: Int): IntArray {
        val s = 4
        val r = 12
        val m = r + 2
        var best = Float.MAX_VALUE
        var bx = 0
        var by = 0
        for (sy in -r..r) for (sx in -r..r) {
            var sad = 0f
            var n = 0
            var y = m
            while (y < lh - m) {
                var x = m
                while (x < lw - m) {
                    sad += abs(refS[y * lw + x] - curS[(y + sy) * lw + x + sx])
                    n++
                    x += 3
                }
                y += 3
            }
            if (n > 0) {
                sad /= n
                // ưu tiên nhẹ độ lệch nhỏ để khung phẳng/ít chi tiết không nhảy lung tung
                sad += (abs(sx) + abs(sy)) * 0.02f
                if (sad < best) { best = sad; bx = sx; by = sy }
            }
        }
        return intArrayOf(bx * s, by * s)
    }

    /** Độ sáng trung bình khối step×step của vùng (x0,y0,pw,ph) (toạ độ ngoài ảnh được kẹp về mép). Kết quả (pw/step)×(ph/step). */
    private fun patch(px: IntArray, w: Int, h: Int, x0: Int, y0: Int, pw: Int, ph: Int, step: Int): FloatArray {
        val ow = pw / step
        val oh = ph / step
        val out = FloatArray(ow * oh)
        val inv = 1f / (step * step * 256f)
        for (j in 0 until oh) {
            for (i in 0 until ow) {
                var sum = 0
                for (b in 0 until step) {
                    val yy = (y0 + j * step + b).coerceIn(0, h - 1)
                    for (a in 0 until step) {
                        val xx = (x0 + i * step + a).coerceIn(0, w - 1)
                        val p = px[yy * w + xx]
                        sum += ((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29
                    }
                }
                out[j * ow + i] = sum * inv
            }
        }
        return out
    }

    /** Làm mờ nhị thức 5 điểm (σ≈1) theo hai chiều. */
    private fun blur5(a: FloatArray, w: Int, h: Int): FloatArray {
        val k0 = 1f / 16f
        val k1 = 4f / 16f
        val k2 = 6f / 16f
        val tmp = FloatArray(w * h)
        for (y in 0 until h) {
            val ro = y * w
            for (x in 0 until w) {
                val xm2 = (x - 2).coerceAtLeast(0)
                val xm1 = (x - 1).coerceAtLeast(0)
                val xp1 = (x + 1).coerceAtMost(w - 1)
                val xp2 = (x + 2).coerceAtMost(w - 1)
                tmp[ro + x] = k0 * a[ro + xm2] + k1 * a[ro + xm1] + k2 * a[ro + x] + k1 * a[ro + xp1] + k0 * a[ro + xp2]
            }
        }
        val out = FloatArray(w * h)
        for (y in 0 until h) {
            val rm2 = (y - 2).coerceAtLeast(0) * w
            val rm1 = (y - 1).coerceAtLeast(0) * w
            val r0 = y * w
            val rp1 = (y + 1).coerceAtMost(h - 1) * w
            val rp2 = (y + 2).coerceAtMost(h - 1) * w
            for (x in 0 until w) {
                out[r0 + x] = k0 * tmp[rm2 + x] + k1 * tmp[rm1 + x] + k2 * tmp[r0 + x] + k1 * tmp[rp1 + x] + k0 * tmp[rp2 + x]
            }
        }
        return out
    }

    /** Độ giàu chi tiết của mảng: trị riêng nhỏ nhất của ma trận gradient trung bình (cao = có cạnh theo cả hai hướng). */
    private fun texture(p: FloatArray, pw: Int, ph: Int): Float {
        var a = 0.0
        var b = 0.0
        var c = 0.0
        for (y in 1 until ph - 1) {
            val r = y * pw
            for (x in 1 until pw - 1) {
                val gx = (p[r + x + 1] - p[r + x - 1]) * 0.5f
                val gy = (p[r + pw + x] - p[r - pw + x]) * 0.5f
                a += (gx * gx).toDouble()
                b += (gx * gy).toDouble()
                c += (gy * gy).toDouble()
            }
        }
        val n = (pw * ph).toDouble()
        a /= n; b /= n; c /= n
        val tr = a + c
        val det = a * c - b * b
        val disc = max(tr * tr / 4.0 - det, 0.0)
        return (tr / 2.0 - sqrt(disc)).toFloat()
    }

    /**
     * Lucas-Kanade (ngược, chỉ dịch tịnh tiến). p: mảng tham chiếu pw×ph; q: mảng hiện tại có viền m mỗi phía, (pw+2m)×(ph+2m).
     * Tìm (ox, oy) sao cho q(x+m+ox, y+m+oy) ≈ p(x, y), bắt đầu từ (o0x, o0y). Trả null nếu mảng không đủ chi tiết.
     */
    private fun lk(p: FloatArray, pw: Int, ph: Int, q: FloatArray, m: Int, o0x: Float, o0y: Float): FloatArray? {
        val qw = pw + 2 * m
        val qh = ph + 2 * m
        val gxs = FloatArray(pw * ph)
        val gys = FloatArray(pw * ph)
        var hxx = 0.0
        var hxy = 0.0
        var hyy = 0.0
        for (y in 1 until ph - 1) {
            val r = y * pw
            for (x in 1 until pw - 1) {
                val gx = (p[r + x + 1] - p[r + x - 1]) * 0.5f
                val gy = (p[r + pw + x] - p[r - pw + x]) * 0.5f
                gxs[r + x] = gx
                gys[r + x] = gy
                hxx += (gx * gx).toDouble()
                hxy += (gx * gy).toDouble()
                hyy += (gy * gy).toDouble()
            }
        }
        val det = hxx * hyy - hxy * hxy
        if (det < 1.0) return null
        var ox = o0x
        var oy = o0y
        val maxX = qw - 1.001f
        val maxY = qh - 1.001f
        for (iter in 0 until 10) {
            var bx = 0.0
            var by = 0.0
            for (y in 1 until ph - 1) {
                val yy = (y + m + oy).coerceIn(0f, maxY)
                val y0 = yy.toInt()
                val fy = yy - y0
                val r = y * pw
                for (x in 1 until pw - 1) {
                    val xx = (x + m + ox).coerceIn(0f, maxX)
                    val x0 = xx.toInt()
                    val fx = xx - x0
                    val i = y0 * qw + x0
                    val v = (q[i] * (1f - fx) + q[i + 1] * fx) * (1f - fy) + (q[i + qw] * (1f - fx) + q[i + qw + 1] * fx) * fy
                    val e = v - p[r + x]
                    bx += (gxs[r + x] * e).toDouble()
                    by += (gys[r + x] * e).toDouble()
                }
            }
            val dx = ((hyy * bx - hxy * by) / det).toFloat().coerceIn(-1f, 1f)
            val dy = ((-hxy * bx + hxx * by) / det).toFloat().coerceIn(-1f, 1f)
            ox -= dx
            oy -= dy
            if (abs(dx) < 0.005f && abs(dy) < 0.005f) break
        }
        return floatArrayOf(ox, oy)
    }

    /**
     * Tinh chỉnh độ lệch thô `init` thành độ lệch dưới điểm ảnh: chọn mảng nhiều chi tiết nhất trong 3 mảng ngang giữa ảnh,
     * chạy LK ở nửa độ phân giải rồi ở độ phân giải đầy đủ (làm mờ nhẹ). Bất kỳ bước nào không đáng tin thì giữ kết quả của bước trước.
     */
    private fun refine(base: IntArray, cur: IntArray, w: Int, h: Int, init: IntArray): FloatArray {
        val fallback = floatArrayOf(init[0].toFloat(), init[1].toFloat())
        val pw = (min(512, w / 3) / 4) * 4
        val ph = (min(384, h * 2 / 3) / 4) * 4
        if (pw < 64 || ph < 64) return fallback
        val y0 = (h - ph) / 2
        var bestX = -1
        var bestS = -1f
        var bestP2: FloatArray? = null
        for (c in 1..3) {
            val x0 = (w / 4 * c - pw / 2).coerceIn(0, w - pw)
            val p2 = patch(base, w, h, x0, y0, pw, ph, 2)
            val s = texture(p2, pw / 2, ph / 2)
            if (s > bestS) { bestS = s; bestX = x0; bestP2 = p2 }
        }
        val p2 = bestP2
        if (p2 == null || bestS < TEX_MIN) return fallback
        val x0 = bestX

        // nửa độ phân giải
        val m2 = 6
        val ix2 = init[0]
        val iy2 = init[1]
        val q2 = patch(cur, w, h, x0 + ix2 - 2 * m2, y0 + iy2 - 2 * m2, pw + 4 * m2, ph + 4 * m2, 2)
        val r2 = lk(p2, pw / 2, ph / 2, q2, m2, 0f, 0f) ?: return fallback
        if (abs(r2[0]) > 5f || abs(r2[1]) > 5f) return fallback
        val sx = ix2 + 2f * r2[0]
        val sy = iy2 + 2f * r2[1]

        // độ phân giải đầy đủ
        val m1 = 8
        val ix1 = Math.round(sx)
        val iy1 = Math.round(sy)
        val p1 = blur5(patch(base, w, h, x0, y0, pw, ph, 1), pw, ph)
        val q1 = blur5(patch(cur, w, h, x0 + ix1 - m1, y0 + iy1 - m1, pw + 2 * m1, ph + 2 * m1, 1), pw + 2 * m1, ph + 2 * m1)
        val r1 = lk(p1, pw, ph, q1, m1, sx - ix1, sy - iy1) ?: return floatArrayOf(sx, sy)
        if (abs(r1[0] - (sx - ix1)) > 1.5f || abs(r1[1] - (sy - iy1)) > 1.5f) return floatArrayOf(sx, sy)
        return floatArrayOf(ix1 + r1[0], iy1 + r1[1])
    }

    /**
     * Ghép các khung (khung đầu là khung gốc) trong vùng `region` thành bitmap độ phân giải 2×, rồi chạy bộ lọc `proc` từng dải.
     * Độ sáng cộng dồn ở lưới 2×, màu (hiệu B−Y, R−Y) cộng dồn ở lưới 1× rồi nội suy song tuyến lên 2×.
     * Ném lỗi (kể cả OOM) để nơi gọi quay về chế độ một khung.
     */
    fun merge(paths: List<String>, region: Rect, progress: ((Int) -> Unit)? = null, proc: (IntArray, Int, Int) -> Unit): Bitmap {
        val t0 = SystemClock.elapsedRealtime()
        val w = region.width()
        val h = region.height()
        val base = decode(paths[0], region)
        val baseS = lumaDown(base, w, h, 4)
        val n = paths.size - 1
        val decoded = arrayOfNulls<IntArray>(n)
        val shiftsArr = arrayOfNulls<FloatArray>(n)
        val doneFrames = AtomicInteger(0)
        if (n > 0) {
            // giải mã + căn chỉnh các khung phụ song song (tối đa 2 luồng để không đỉnh bộ nhớ)
            val pool = Executors.newFixedThreadPool(min(2, n))
            try {
                val futs = ArrayList<java.util.concurrent.Future<*>>()
                for (i in 1..n) {
                    futs.add(pool.submit(Runnable {
                        try {
                            val f = decode(paths[i], region)
                            val c = coarse(baseS, lumaDown(f, w, h, 4), w / 4, h / 4)
                            val sh = refine(base, f, w, h, c)
                            // lệch quá xa = rung/chuyển động mạnh: bỏ khung để khỏi nát chi tiết
                            if (abs(sh[0]) <= 24f && abs(sh[1]) <= 24f) {
                                decoded[i - 1] = f
                                shiftsArr[i - 1] = sh
                            }
                        } catch (_: Throwable) {
                            // bỏ khung hỏng (kể cả thiếu bộ nhớ ở khung này)
                        }
                        progress?.invoke(15 * doneFrames.incrementAndGet() / paths.size)
                    }))
                }
                for (f in futs) f.get()
            } finally {
                pool.shutdown()
            }
        }
        val tAligned = SystemClock.elapsedRealtime()

        // khung 0 = gốc (lệch 0), các khung sau theo độ lệch đã ước lượng
        val all = ArrayList<IntArray>()
        all.add(base)
        val shx = ArrayList<Float>()
        val shy = ArrayList<Float>()
        shx.add(0f); shy.add(0f)
        for (k in 0 until n) {
            val f = decoded[k] ?: continue
            val s = shiftsArr[k] ?: continue
            all.add(f); shx.add(s[0]); shy.add(s[1])
        }
        lastUsed = all.size
        val nf = all.size
        val sx = FloatArray(nf) { shx[it] }
        val sy = FloatArray(nf) { shy[it] }
        val baseL = ByteArray(w * h)
        for (i in 0 until w * h) baseL[i] = luma(base[i]).toByte()

        val ow = w * SCALE
        val oh = h * SCALE
        val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val band = 96
        val bands = (oh + band - 1) / band
        val cores = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
        val outLock = Any()
        val lambda = 0.2f
        val done = AtomicInteger(0)
        // trọng số nội suy theo cột: bicubic Catmull-Rom cho độ sáng, song tuyến (phần lẻ cxf) cho màu (tính một lần)
        val bxi = IntArray(ow)
        val bxw = FloatArray(ow * 4)
        val cxf = FloatArray(ow)
        for (i in 0 until ow) {
            val rx = ((i - 0.5f) / SCALE).coerceIn(0f, (w - 1).toFloat())
            val ix = rx.toInt()
            bxi[i] = ix
            cxf[i] = rx - ix
            cr(rx - ix, bxw, i * 4)
        }
        val crRows = band / SCALE + 8

        java.util.stream.IntStream.range(0, cores).parallel().forEach { core ->
            val accY = FloatArray(ow * band)
            val accW = FloatArray(ow * band)
            val accCb = FloatArray(w * crRows)
            val accCr = FloatArray(w * crRows)
            val accCw = FloatArray(w * crRows)
            val px = IntArray(ow * band)
            val rowY = Array(crRows) { FloatArray(ow) }
            val rowCb = Array(crRows) { FloatArray(ow) }
            val rowCr = Array(crRows) { FloatArray(ow) }
            val yline = FloatArray(w)
            var bi = core
            while (bi < bands) {
                val y0 = bi * band
                val y1 = min(oh, y0 + band)
                val bh = y1 - y0
                // các hàng ảnh gốc (lưới 1×) cần cho dải này
                val rb = max(0, ((y0 - 0.5f) / SCALE).toInt() - 1)
                val re = min(h - 1, ((y1 - 1 - 0.5f) / SCALE).toInt() + 2)
                val nr = re - rb + 1
                java.util.Arrays.fill(accY, 0, ow * bh, 0f)
                java.util.Arrays.fill(accW, 0, ow * bh, 0f)
                java.util.Arrays.fill(accCb, 0, w * nr, 0f)
                java.util.Arrays.fill(accCr, 0, w * nr, 0f)
                java.util.Arrays.fill(accCw, 0, w * nr, 0f)
                for (k in 0 until nf) {
                    val fpx = all[k]
                    val dx = sx[k]
                    val dy = sy[k]
                    val rdx = Math.round(dx)
                    val rdy = Math.round(dy)
                    // điểm ảnh nguồn (x,y) -> toạ độ gốc (x-dx, y-dy) -> lưới ra: o = 2*r + 0.5
                    val yLo = max(0, min(((y0 - 2 - 0.5f) / SCALE + dy).toInt() - 1, rb + rdy))
                    val yHi = min(h - 1, max(((y1 + 1 - 0.5f) / SCALE + dy).toInt() + 1, re + rdy))
                    for (y in yLo..yHi) {
                        val oyf = SCALE * (y - dy) + 0.5f
                        val oy = Math.floor(oyf.toDouble()).toInt()
                        val fy = oyf - oy
                        val lumaRow = !(oy + 1 < y0 || oy >= y1)
                        val byp = y - rdy
                        val chromaRow = byp in rb..re
                        if (!lumaRow && !chromaRow) continue
                        val crow = (byp - rb) * w
                        for (x in 0 until w) {
                            val p = fpx[y * w + x]
                            val bxp = x - rdx
                            // giảm trọng số vùng khác khung gốc (chuyển động) để không bị bóng ma
                            var wt = 1f
                            if (k > 0) {
                                if (bxp in 0 until w && byp in 0 until h) {
                                    val d = (luma(p) - (baseL[byp * w + bxp].toInt() and 255)).toFloat()
                                    wt = 1f / (1f + (d * d) / 576f)   // ~24 mức xám: vượt ngưỡng này là coi như chuyển động
                                } else wt = 0.4f
                            }
                            val r = ((p shr 16) and 255).toFloat()
                            val g = ((p shr 8) and 255).toFloat()
                            val b = (p and 255).toFloat()
                            val yv = 0.299f * r + 0.587f * g + 0.114f * b
                            if (lumaRow) {
                                val oxf = SCALE * (x - dx) + 0.5f
                                // sàn nhanh: với số nguyên âm cho phần lẻ = 1 thay vì 0 — trọng số nội suy vẫn như nhau
                                val ox = oxf.toInt() - (if (oxf < 0f) 1 else 0)
                                val fx = oxf - ox
                                for (jy in 0..1) {
                                    val yy = oy + jy
                                    if (yy < y0 || yy >= y1) continue
                                    val wy = if (jy == 0) 1f - fy else fy
                                    for (jx in 0..1) {
                                        val xx = ox + jx
                                        if (xx < 0 || xx >= ow) continue
                                        val ww = wt * wy * (if (jx == 0) 1f - fx else fx)
                                        val idx = (yy - y0) * ow + xx
                                        accY[idx] += yv * ww
                                        accW[idx] += ww
                                    }
                                }
                            }
                            if (chromaRow && bxp in 0 until w) {
                                val ci = crow + bxp
                                accCb[ci] += (b - yv) * wt
                                accCr[ci] += (r - yv) * wt
                                accCw[ci] += wt
                            }
                        }
                    }
                }
                // chuẩn hoá màu 1× (khung gốc luôn góp trọng số 1 nên mẫu số ≥ 1)
                for (i in 0 until w * nr) {
                    val cw = accCw[i]
                    accCb[i] /= cw
                    accCr[i] /= cw
                }
                // hoàn thiện: độ sáng gốc phóng 2× bằng bicubic (lấp lỗ), màu 1× nội suy song tuyến ngang lên 2×
                for (srow in rb..re) {
                    val ro = srow * w
                    val co = (srow - rb) * w
                    for (x in 0 until w) {
                        val q = base[ro + x]
                        yline[x] = 0.299f * ((q shr 16) and 255) + 0.587f * ((q shr 8) and 255) + 0.114f * (q and 255)
                    }
                    val ry = rowY[srow - rb]
                    val rcb = rowCb[srow - rb]
                    val rcr = rowCr[srow - rb]
                    for (i in 0 until ow) {
                        val c0 = bxi[i] - 1
                        var yy = 0f
                        for (k in 0..3) {
                            val col = (c0 + k).coerceIn(0, w - 1)
                            yy += yline[col] * bxw[i * 4 + k]
                        }
                        ry[i] = yy
                        val ia = bxi[i]
                        val ib = if (ia + 1 < w) ia + 1 else ia
                        val f = cxf[i]
                        rcb[i] = accCb[co + ia] * (1f - f) + accCb[co + ib] * f
                        rcr[i] = accCr[co + ia] * (1f - f) + accCr[co + ib] * f
                    }
                }
                val wy = FloatArray(4)
                for (j in 0 until bh) {
                    val oy = y0 + j
                    val rYv = ((oy - 0.5f) / SCALE).coerceIn(0f, (h - 1).toFloat())
                    val iy = rYv.toInt()
                    val fyv = rYv - iy
                    cr(fyv, wy, 0)
                    val i0 = (iy - 1).coerceIn(0, h - 1) - rb
                    val i1 = iy.coerceIn(0, h - 1) - rb
                    val i2 = (iy + 1).coerceIn(0, h - 1) - rb
                    val i3 = (iy + 2).coerceIn(0, h - 1) - rb
                    val y0r = rowY[i0]; val y1r = rowY[i1]; val y2r = rowY[i2]; val y3r = rowY[i3]
                    val cb1 = rowCb[i1]; val cb2 = rowCb[i2]
                    val cr1 = rowCr[i1]; val cr2 = rowCr[i2]
                    for (i in 0 until ow) {
                        val yb = (y0r[i] * wy[0] + y1r[i] * wy[1] + y2r[i] * wy[2] + y3r[i] * wy[3]).coerceIn(0f, 255f)
                        val idx = j * ow + i
                        val yv = (accY[idx] + lambda * yb) / (accW[idx] + lambda)
                        val cbv = cb1[i] * (1f - fyv) + cb2[i] * fyv
                        val crv = cr1[i] * (1f - fyv) + cr2[i] * fyv
                        val r = (yv + crv + 0.5f).toInt().coerceIn(0, 255)
                        val g = (yv - 0.5094f * crv - 0.1942f * cbv + 0.5f).toInt().coerceIn(0, 255)
                        val b = (yv + cbv + 0.5f).toInt().coerceIn(0, 255)
                        px[idx] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                }
                proc(px, 0, ow * bh)
                synchronized(outLock) { out.setPixels(px, 0, ow, 0, y0, ow, bh) }
                progress?.invoke(15 + 85 * done.incrementAndGet() / bands)
                bi += cores
            }
        }
        val t1 = SystemClock.elapsedRealtime()
        lastAlignMs = tAligned - t0
        lastFuseMs = t1 - tAligned
        return out
    }

    private val K7 = floatArrayOf(1f / 64f, 6f / 64f, 15f / 64f, 20f / 64f, 15f / 64f, 6f / 64f, 1f / 64f)

    /**
     * Làm nét cạnh có chọn lọc (unsharp mask trên ĐỘ SÁNG, có cổng): chỉ khuếch đại phần chênh lệch lớn (cạnh, nét chữ), phần chênh
     * nhỏ (nhiễu, vân nén JPEG) gần như không bị khuếch đại -> sắc hơn mà không vỡ hạt. Không làm mịn nên không làm mờ chi tiết.
     * Trả về bitmap mới (hết bộ nhớ thì trả ảnh gốc).
     */
    fun refine(src: Bitmap, amount: Float = 0.9f, thr: Float = 8f): Bitmap {
        val w = src.width
        val h = src.height
        val out = try { Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) } catch (t: OutOfMemoryError) { return src }
        val strip = 96
        val strips = (h + strip - 1) / strip
        val cores = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
        val lock = Any()
        val k0 = K7[0]; val k1 = K7[1]; val k2 = K7[2]; val k3 = K7[3]
        java.util.stream.IntStream.range(0, cores).parallel().forEach { core ->
            val inp = IntArray(w * (strip + 6))
            val hb = FloatArray(w * (strip + 6))
            val lum = IntArray(w * (strip + 6))
            val res = IntArray(w * strip)
            var si = core
            while (si < strips) {
                val y0 = si * strip
                val y1 = min(h, y0 + strip)
                val bh = y1 - y0
                val r0 = max(0, y0 - 3)
                val r1 = min(h, y1 + 3)
                val nr = r1 - r0
                src.getPixels(inp, 0, w, 0, r0, w, nr)
                for (i in 0 until nr * w) lum[i] = luma(inp[i])
                // làm mờ ngang (nhị thức 7 điểm): phần giữa không cần kẹp chỉ số, chỉ hai mép mới kẹp
                for (r in 0 until nr) {
                    val ro = r * w
                    for (x in 0 until w) {
                        if (x >= 3 && x < w - 3) {
                            val o = ro + x
                            hb[o] = k0 * (lum[o - 3] + lum[o + 3]) + k1 * (lum[o - 2] + lum[o + 2]) + k2 * (lum[o - 1] + lum[o + 1]) + k3 * lum[o]
                        } else {
                            var acc = 0f
                            for (k in 0..6) acc += K7[k] * lum[ro + (x + k - 3).coerceIn(0, w - 1)]
                            hb[ro + x] = acc
                        }
                    }
                }
                for (j in 0 until bh) {
                    val ry = y0 + j - r0
                    // sáu hàng lân cận (kẹp ở mép ảnh) tính một lần cho cả hàng
                    val a0 = (ry - 3).coerceIn(0, nr - 1) * w
                    val a1 = (ry - 2).coerceIn(0, nr - 1) * w
                    val a2 = (ry - 1).coerceIn(0, nr - 1) * w
                    val a3 = ry * w
                    val a4 = (ry + 1).coerceIn(0, nr - 1) * w
                    val a5 = (ry + 2).coerceIn(0, nr - 1) * w
                    val a6 = (ry + 3).coerceIn(0, nr - 1) * w
                    for (x in 0 until w) {
                        val bl = k0 * (hb[a0 + x] + hb[a6 + x]) + k1 * (hb[a1 + x] + hb[a5 + x]) +
                            k2 * (hb[a2 + x] + hb[a4 + x]) + k3 * hb[a3 + x]
                        val c = inp[a3 + x]
                        val dl = lum[a3 + x] - bl
                        val ad = if (dl < 0f) -dl else dl
                        val add = amount * dl * (ad / (ad + thr))
                        val r = (((c shr 16) and 255) + add).toInt().coerceIn(0, 255)
                        val g = (((c shr 8) and 255) + add).toInt().coerceIn(0, 255)
                        val bch = ((c and 255) + add).toInt().coerceIn(0, 255)
                        res[j * w + x] = (0xFF shl 24) or (r shl 16) or (g shl 8) or bch
                    }
                }
                synchronized(lock) { out.setPixels(res, 0, w, 0, y0, w, bh) }
                si += cores
            }
        }
        return out
    }
}
