package com.xpanmode.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * HQ ghép nhiều khung: máy không cho chụp 50MP nên chụp liên tiếp N khung 12,6MP, căn chỉnh (tay run tạo ra lệch dưới 1 điểm ảnh),
 * rồi "shift-and-add" lên lưới 2× độ phân giải. Chi tiết thật được thu thêm từ các khung lệch nhau, nhiễu giảm; vùng chuyển động
 * (ghost) bị giảm trọng số nên không bị bóng ma. Không phải 50MP thật nhưng sắc và sạch hơn hẳn một khung đơn rồi crop.
 */
object MultiFrame {
    private const val SCALE = 2
    /** Số khung thực sự được ghép trong lần merge gần nhất (khung hỏng bị bỏ). */
    @Volatile var lastUsed = 0

    /** Trọng số Catmull-Rom cho 4 điểm quanh vị trí lẻ t (0..1). */
    private fun cr(t: Float, out: FloatArray, o: Int) {
        val t2 = t * t
        val t3 = t2 * t
        out[o] = -0.5f * t3 + t2 - 0.5f * t
        out[o + 1] = 1.5f * t3 - 2.5f * t2 + 1f
        out[o + 2] = -1.5f * t3 + 2f * t2 + 0.5f * t
        out[o + 3] = 0.5f * t3 - 0.5f * t2
    }

    private fun luma(p: Int): Int = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8

    private fun decode(path: String, region: Rect): IntArray {
        @Suppress("DEPRECATION")
        val dec = BitmapRegionDecoder.newInstance(path, false) ?: throw IllegalStateException("Không đọc được khung")
        try {
            val o = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val b = dec.decodeRegion(region, o) ?: throw IllegalStateException("decodeRegion null")
            val w = b.width
            val h = b.height
            val out = IntArray(w * h)
            b.getPixels(out, 0, w, 0, 0, w, h)
            b.recycle()
            return out
        } finally {
            dec.recycle()
        }
    }

    /** Ảnh xám thu nhỏ s lần (trung bình khối s×s). */
    private fun lumaDown(px: IntArray, w: Int, h: Int, s: Int): FloatArray {
        val lw = w / s
        val lh = h / s
        val out = FloatArray(lw * lh)
        for (y in 0 until lh) for (x in 0 until lw) {
            var sum = 0
            for (j in 0 until s) {
                val row = (y * s + j) * w + x * s
                for (i in 0 until s) sum += luma(px[row + i])
            }
            out[y * lw + x] = sum.toFloat() / (s * s)
        }
        return out
    }

    /**
     * Độ lệch (dx, dy) của `cur` so với `ref` theo điểm ảnh gốc, có phần lẻ: cur(x+dx, y+dy) ≈ ref(x, y).
     * Thô: SAD trên ảnh thu nhỏ 4 lần; tinh: SAD ở độ phân giải đầy đủ trên mảng giữa ảnh rồi nội suy parabol.
     */
    private fun estimate(ref: IntArray, cur: IntArray, w: Int, h: Int, refS: FloatArray, curS: FloatArray): FloatArray {
        val s = 4
        val lw = w / s
        val lh = h / s
        val r = 12
        val m = r + 2
        var best = Float.MAX_VALUE
        var bx = 0
        var by = 0
        for (sy in -r..r) for (sx in -r..r) {
            var sad = 0f
            var n = 0
            var y = m
            while (y < lh - m) {
                var x = m
                while (x < lw - m) {
                    sad += abs(refS[y * lw + x] - curS[(y + sy) * lw + x + sx])
                    n++
                    x += 3
                }
                y += 3
            }
            if (n > 0) {
                sad /= n
                // ưu tiên nhẹ độ lệch nhỏ để khung phẳng/ít chi tiết không nhảy lung tung
                sad += (abs(sx) + abs(sy)) * 0.02f
                if (sad < best) { best = sad; bx = sx; by = sy }
            }
        }
        val cx0 = bx * s
        val cy0 = by * s
        // tinh chỉnh ở độ phân giải đầy đủ quanh (cx0, cy0), ±4 điểm ảnh
        val pw = min(320, w / 2 - 20)
        val ph = min(240, h / 2 - 20)
        val ccx = w / 2
        val ccy = h / 2
        val fr = 4
        val sads = Array(2 * fr + 1) { FloatArray(2 * fr + 1) }
        var fBest = Float.MAX_VALUE
        var fx = 0
        var fy = 0
        for (dy in -fr..fr) for (dx in -fr..fr) {
            val ox = cx0 + dx
            val oy = cy0 + dy
            var sad = 0L
            var y = ccy - ph
            while (y < ccy + ph) {
                val yy = y + oy
                if (yy < 0 || yy >= h) { y++; continue }
                var x = ccx - pw
                while (x < ccx + pw) {
                    val xx = x + ox
                    if (xx in 0 until w) sad += abs(luma(ref[y * w + x]) - luma(cur[yy * w + xx]))
                    x += 1
                }
                y += 1
            }
            val v = sad.toFloat()
            sads[dy + fr][dx + fr] = v
            if (v < fBest) { fBest = v; fx = dx; fy = dy }
        }
        fun sub(a: Float, b: Float, c: Float): Float {
            val d = a - 2f * b + c
            return if (d <= 1e-6f) 0f else (0.5f * (a - c) / d).coerceIn(-0.5f, 0.5f)
        }
        val ix = fx + fr
        val iy = fy + fr
        val subX = if (ix in 1 until 2 * fr) sub(sads[iy][ix - 1], sads[iy][ix], sads[iy][ix + 1]) else 0f
        val subY = if (iy in 1 until 2 * fr) sub(sads[iy - 1][ix], sads[iy][ix], sads[iy + 1][ix]) else 0f
        return floatArrayOf(cx0 + fx + subX, cy0 + fy + subY)
    }

    /**
     * Ghép các khung (khung đầu là khung gốc) trong vùng `region` thành bitmap độ phân giải 2×, rồi chạy bộ lọc `proc` từng dải.
     * Ném lỗi (kể cả OOM) để nơi gọi quay về chế độ một khung.
     */
    fun merge(paths: List<String>, region: Rect, progress: ((Int) -> Unit)? = null, proc: (IntArray, Int, Int) -> Unit): Bitmap {
        val w = region.width()
        val h = region.height()
        val base = decode(paths[0], region)
        val baseS = lumaDown(base, w, h, 4)
        val frames = ArrayList<IntArray>()
        val shifts = ArrayList<FloatArray>()
        for (i in 1 until paths.size) {
            try {
                val f = decode(paths[i], region)
                val sh = estimate(base, f, w, h, baseS, lumaDown(f, w, h, 4))
                if (abs(sh[0]) > 24f || abs(sh[1]) > 24f) continue   // lệch quá xa = rung/chuyển động mạnh: bỏ khung để khỏi nát chi tiết
                frames.add(f)
                shifts.add(sh)
                progress?.invoke(15 * i / paths.size)
            } catch (_: Exception) {
                // bỏ khung hỏng
            }
        }
        lastUsed = 1 + frames.size
        val ow = w * SCALE
        val oh = h * SCALE
        val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val band = 96
        val bands = (oh + band - 1) / band
        val cores = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
        val outLock = Any()
        val lambda = 0.2f
        val done = java.util.concurrent.atomic.AtomicInteger(0)
        // trọng số nội suy bicubic Catmull-Rom theo cột (tính một lần)
        val bxi = IntArray(ow)
        val bxw = FloatArray(ow * 4)
        for (i in 0 until ow) {
            val rx = ((i - 0.5f) / SCALE).coerceIn(0f, (w - 1).toFloat())
            val ix = rx.toInt()
            bxi[i] = ix
            cr(rx - ix, bxw, i * 4)
        }

        // khung 0 = gốc (lệch 0), các khung sau theo `shifts`
        val all = ArrayList<IntArray>().also { it.add(base); it.addAll(frames) }
        val sx = FloatArray(all.size)
        val sy = FloatArray(all.size)
        for (k in 1 until all.size) { sx[k] = shifts[k - 1][0]; sy[k] = shifts[k - 1][1] }

        java.util.stream.IntStream.range(0, cores).parallel().forEach { core ->
            val accR = FloatArray(ow * band)
            val accG = FloatArray(ow * band)
            val accB = FloatArray(ow * band)
            val accW = FloatArray(ow * band)
            val px = IntArray(ow * band)
            val hrows = Array(band / SCALE + 8) { FloatArray(ow * 3) }
            var bi = core
            while (bi < bands) {
                val y0 = bi * band
                val y1 = min(oh, y0 + band)
                val bh = y1 - y0
                java.util.Arrays.fill(accR, 0, ow * bh, 0f)
                java.util.Arrays.fill(accG, 0, ow * bh, 0f)
                java.util.Arrays.fill(accB, 0, ow * bh, 0f)
                java.util.Arrays.fill(accW, 0, ow * bh, 0f)
                for (k in all.indices) {
                    val fpx = all[k]
                    val dx = sx[k]
                    val dy = sy[k]
                    // điểm ảnh nguồn (x,y) -> toạ độ gốc (x-dx, y-dy) -> lưới ra: o = 2*r + 0.5
                    val ymin = max(0, ((y0 - 2 - 0.5f) / SCALE + dy).toInt() - 1)
                    val ymax = min(h - 1, ((y1 + 1 - 0.5f) / SCALE + dy).toInt() + 1)
                    val rdx = Math.round(dx)
                    val rdy = Math.round(dy)
                    for (y in ymin..ymax) {
                        val oyf = SCALE * (y - dy) + 0.5f
                        val oy = Math.floor(oyf.toDouble()).toInt()
                        val fy = oyf - oy
                        if (oy + 1 < y0 || oy >= y1) continue
                        for (x in 0 until w) {
                            val p = fpx[y * w + x]
                            // giảm trọng số vùng khác khung gốc (chuyển động) để không bị bóng ma
                            var wt = 1f
                            if (k > 0) {
                                val bxp = x - rdx
                                val byp = y - rdy
                                if (bxp in 0 until w && byp in 0 until h) {
                                    val d = (luma(p) - luma(base[byp * w + bxp])).toFloat()
                                    wt = 1f / (1f + (d * d) / 576f)   // ~24 mức xám: vượt ngưỡng này là coi như chuyển động
                                } else wt = 0.4f
                            }
                            val oxf = SCALE * (x - dx) + 0.5f
                            val ox = Math.floor(oxf.toDouble()).toInt()
                            val fx = oxf - ox
                            val r = ((p shr 16) and 255).toFloat()
                            val g = ((p shr 8) and 255).toFloat()
                            val b = (p and 255).toFloat()
                            for (jy in 0..1) {
                                val yy = oy + jy
                                if (yy < y0 || yy >= y1) continue
                                val wy = if (jy == 0) 1f - fy else fy
                                for (jx in 0..1) {
                                    val xx = ox + jx
                                    if (xx < 0 || xx >= ow) continue
                                    val ww = wt * wy * (if (jx == 0) 1f - fx else fx)
                                    val idx = (yy - y0) * ow + xx
                                    accR[idx] += r * ww
                                    accG[idx] += g * ww
                                    accB[idx] += b * ww
                                    accW[idx] += ww
                                }
                            }
                        }
                    }
                }
                // hoàn thiện: trộn với ảnh gốc phóng 2× bằng nội suy bicubic (mượt, không vỡ ô vuông như song tuyến) để lấp lỗ
                val rb = max(0, ((y0 - 0.5f) / SCALE).toInt() - 1)
                val re = min(h - 1, ((y1 - 1 - 0.5f) / SCALE).toInt() + 2)
                for (sy in rb..re) {
                    val row = hrows[sy - rb]
                    val ro = sy * w
                    for (i in 0 until ow) {
                        val c0 = bxi[i] - 1
                        var r = 0f; var g = 0f; var b = 0f
                        for (k in 0..3) {
                            val col = (c0 + k).coerceIn(0, w - 1)
                            val q = base[ro + col]
                            val wk = bxw[i * 4 + k]
                            r += ((q shr 16) and 255) * wk
                            g += ((q shr 8) and 255) * wk
                            b += (q and 255) * wk
                        }
                        row[i * 3] = r; row[i * 3 + 1] = g; row[i * 3 + 2] = b
                    }
                }
                val wy = FloatArray(4)
                for (j in 0 until bh) {
                    val oy = y0 + j
                    val ry = ((oy - 0.5f) / SCALE).coerceIn(0f, (h - 1).toFloat())
                    val iy = ry.toInt()
                    cr(ry - iy, wy, 0)
                    val r0 = hrows[(iy - 1).coerceIn(0, h - 1) - rb]
                    val r1 = hrows[iy.coerceIn(0, h - 1) - rb]
                    val r2 = hrows[(iy + 1).coerceIn(0, h - 1) - rb]
                    val r3 = hrows[(iy + 2).coerceIn(0, h - 1) - rb]
                    for (i in 0 until ow) {
                        val o3 = i * 3
                        val br = (r0[o3] * wy[0] + r1[o3] * wy[1] + r2[o3] * wy[2] + r3[o3] * wy[3]).coerceIn(0f, 255f)
                        val bg = (r0[o3 + 1] * wy[0] + r1[o3 + 1] * wy[1] + r2[o3 + 1] * wy[2] + r3[o3 + 1] * wy[3]).coerceIn(0f, 255f)
                        val bb = (r0[o3 + 2] * wy[0] + r1[o3 + 2] * wy[1] + r2[o3 + 2] * wy[2] + r3[o3 + 2] * wy[3]).coerceIn(0f, 255f)
                        val idx = j * ow + i
                        val den = accW[idx] + lambda
                        val r = ((accR[idx] + lambda * br) / den).toInt().coerceIn(0, 255)
                        val g = ((accG[idx] + lambda * bg) / den).toInt().coerceIn(0, 255)
                        val b = ((accB[idx] + lambda * bb) / den).toInt().coerceIn(0, 255)
                        px[idx] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                }
                proc(px, 0, ow * bh)
                synchronized(outLock) { out.setPixels(px, 0, ow, 0, y0, ow, bh) }
                progress?.invoke(15 + 85 * done.incrementAndGet() / bands)
                bi += cores
            }
        }
        return out
    }

    /**
     * Làm mịn + làm nét có chọn lọc (kiểu bộ lọc Lee): vùng phẳng/nhiễu được làm mịn về trung bình cục bộ, còn cạnh và chi tiết
     * được khuếch đại (G > 1) nên nét hơn mà không "vỡ hạt" như làm nét đều. Trả về bitmap mới (hết bộ nhớ thì trả ảnh gốc).
     */
    fun refine(src: Bitmap, amount: Float = 0.7f, s2: Float = 38f): Bitmap {
        val w = src.width
        val h = src.height
        val out = try { Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) } catch (t: OutOfMemoryError) { return src }
        val strip = 96
        val strips = (h + strip - 1) / strip
        val cores = Runtime.getRuntime().availableProcessors().coerceIn(1, 4)
        val lock = Any()
        java.util.stream.IntStream.range(0, cores).parallel().forEach { core ->
            val inp = IntArray(w * (strip + 2))
            val res = IntArray(w * strip)
            var si = core
            while (si < strips) {
                val y0 = si * strip
                val y1 = min(h, y0 + strip)
                val bh = y1 - y0
                val r0 = max(0, y0 - 1)
                val r1 = min(h, y1 + 1)
                val nr = r1 - r0
                src.getPixels(inp, 0, w, 0, r0, w, nr)
                for (j in 0 until bh) {
                    val ry = y0 + j - r0
                    val ru = max(0, ry - 1) * w
                    val rc = ry * w
                    val rd = min(nr - 1, ry + 1) * w
                    for (x in 0 until w) {
                        val xl = if (x > 0) x - 1 else 0
                        val xr = if (x < w - 1) x + 1 else x
                        var sr = 0; var sg = 0; var sb = 0; var sl = 0; var sl2 = 0
                        var ri = 0
                        while (ri < 3) {
                            val row = if (ri == 0) ru else if (ri == 1) rc else rd
                            var xi = 0
                            while (xi < 3) {
                                val xx = if (xi == 0) xl else if (xi == 1) x else xr
                                val q = inp[row + xx]
                                val r = (q shr 16) and 255
                                val g = (q shr 8) and 255
                                val b = q and 255
                                sr += r; sg += g; sb += b
                                val l = (r * 77 + g * 150 + b * 29) shr 8
                                sl += l; sl2 += l * l
                                xi++
                            }
                            ri++
                        }
                        val mr = sr / 9f; val mg = sg / 9f; val mb = sb / 9f
                        val ml = sl / 9f
                        val v = (sl2 / 9f - ml * ml).coerceAtLeast(0f)
                        val gain = v / (v + s2) * (1f + amount)
                        val c = inp[rc + x]
                        val cr = (c shr 16) and 255; val cg = (c shr 8) and 255; val cb = c and 255
                        val orr = (mr + (cr - mr) * gain).toInt().coerceIn(0, 255)
                        val og = (mg + (cg - mg) * gain).toInt().coerceIn(0, 255)
                        val ob = (mb + (cb - mb) * gain).toInt().coerceIn(0, 255)
                        res[j * w + x] = (0xFF shl 24) or (orr shl 16) or (og shl 8) or ob
                    }
                }
                synchronized(lock) { out.setPixels(res, 0, w, 0, y0, w, bh) }
                si += cores
            }
        }
        return out
    }
}
