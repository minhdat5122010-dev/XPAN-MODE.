package com.xpanmode.app

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.Random
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Âm thanh tự tổng hợp (không cần file âm thanh): tiếng màn trập "tách-tách" và tiếng "bíp" khi lấy nét xong.
 * Phát qua luồng media nên vẫn nghe được khi máy để chế độ im lặng (chỉ cần âm lượng media > 0).
 */
class SoundFx {
    private val sr = 44100
    private var shutter: AudioTrack? = make(shutterPcm())
    private var focus: AudioTrack? = make(focusPcm())

    private fun make(pcm: ShortArray): AudioTrack? = try {
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sr)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(pcm.size * 2)
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        t.write(pcm, 0, pcm.size)
        t
    } catch (e: Exception) { null }

    private fun shutterPcm(): ShortArray {
        val total = (sr * 0.17).toInt()
        val a = FloatArray(total)
        val rnd = Random(7)
        fun burst(startMs: Int, lenMs: Int, amp: Float, freq: Float) {
            val s = sr * startMs / 1000
            val n = sr * lenMs / 1000
            for (i in 0 until n) {
                if (s + i >= total) break
                val env = exp(-i / (n * 0.22f))
                val noise = rnd.nextFloat() * 2f - 1f
                val tone = sin(2.0 * PI * freq * i / sr).toFloat()
                a[s + i] += amp * env * (0.7f * noise + 0.5f * tone)
            }
        }
        burst(0, 40, 0.85f, 1500f)
        burst(66, 52, 0.65f, 900f)
        return ShortArray(total) { (a[it].coerceIn(-1f, 1f) * 30000).toInt().toShort() }
    }

    private fun focusPcm(): ShortArray {
        val n = (sr * 0.09).toInt()
        return ShortArray(n) {
            val att = minOf(1f, it / (sr * 0.006f))
            val dec = minOf(1f, (n - it) / (sr * 0.03f))
            (sin(2.0 * PI * 2300.0 * it / sr).toFloat() * att * dec * 0.55f * 32000).toInt().toShort()
        }
    }

    private fun replay(t: AudioTrack?) {
        if (t == null) return
        try {
            t.stop()
            t.reloadStaticData()
            t.play()
        } catch (e: Exception) { }
    }

    fun playShutter() = replay(shutter)
    fun playFocus() = replay(focus)

    fun release() {
        try { shutter?.release() } catch (e: Exception) { }
        try { focus?.release() } catch (e: Exception) { }
        shutter = null
        focus = null
    }
}
