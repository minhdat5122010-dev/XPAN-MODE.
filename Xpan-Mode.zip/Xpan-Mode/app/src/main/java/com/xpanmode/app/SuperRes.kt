package com.xpanmode.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import android.os.SystemClock
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Multi-frame Super Resolution (MFSR) cổ điển — KHÔNG dùng AI/ML. Thay cho "căn chỉnh tịnh tiến toàn khung + shift-and-add đều trọng số"
 * của [MultiFrame.merge] (vẫn giữ nguyên làm phương án dự phòng).
 *
 * Quy trình:
 *  1. Giải mã N khung JPEG; đo độ nhiễu (hàm nhiễu theo mức sáng, Immerkaer) và độ nét cục bộ (năng lượng gradient theo ô 64px).
 *  2. Chọn khung tham chiếu = khung nét nhất (không mặc định khung đầu).
 *  3. Căn chỉnh: Lucas-Kanade KIM TỰ THÁP 4 mức, ước lượng chuyển động theo LƯỚI Ô (không chỉ một vector toàn khung) nên bắt được
 *     parallax / xoay nhẹ / méo; mỗi ô giải LK ngược lặp có trọng số bền vững (IRLS), độ dịch là số thực (dưới điểm ảnh).
 *  4. Độ tin cậy mỗi ô: độ giàu chi tiết (trị riêng nhỏ nhất của tensor cấu trúc) + sai số photometric sau căn chỉnh
 *     + kiểm tra Forward-Backward (luồng xuôi rồi ngược phải về đúng chỗ cũ). Ô đủ chi tiết mà không khớp = chuyển động/che khuất -> loại.
 *  5. Dựng lưới 2×: mỗi mẫu của mỗi khung được "rải" (Gaussian splatting) lên lưới ra tại vị trí THỰC (toạ độ gốc − luồng), không làm tròn.
 *     Độ sáng cộng dồn trong không gian TUYẾN TÍNH (sRGB -> linear), đã bù chênh phơi sáng giữa các khung.
 *  6. Trọng số mỗi mẫu = độ tin cậy luồng × độ nét cục bộ × độ nhiễu khung × trọng số bền vững theo sai số photometric
 *     (Geman-McClure; khoảng dung sai lấy theo hàm nhiễu tại mức sáng đó + gradient của tham chiếu). Vùng chuyển động => các khung phụ
 *     trọng số ~0, chỉ còn khung tham chiếu (không bóng ma). Vùng thiếu dữ liệu được kéo về nội suy bicubic của tham chiếu (chính quy hoá,
 *     không bịa chi tiết).
 *  7. Hậu xử lý theo dải: khử nhiễu 3×3 theo hạng nhiễu còn lại (chỉ mạnh ở nơi ít mẫu) -> khử tích chập Richardson-Lucy NHẸ trong không
 *     gian tuyến tính (3 vòng, PSF Gauss σ nhỏ = chỉ phục hồi một phần) -> chặn cực trị cục bộ (chống ringing/halo) -> giảm mức theo lượng dữ liệu.
 *  8. Màu (Cr/Cg/Cb so với độ sáng) cộng dồn ở lưới 1× (JPEG 4:2:0 nên không mất chi tiết) rồi khử nhiễu màu song phương.
 *
 * Ném IllegalStateException (hoặc lỗi bộ nhớ) khi dữ liệu không đủ tin cậy để nơi gọi quay về [MultiFrame.merge].
 */
object SuperRes {
    /** Công tắc cho nhà phát triển. false = luôn dùng thuật toán cũ. */
    const val ENABLED = true
    /** Hệ số phóng đại lưới ra. 5 khung chỉ đủ cơ sở cho ~√5 ≈ 2,2× nên cố định 2× (xem [maxSupportedScale]). */
    const val SCALE = 2

    @Volatile var lastReport = ""

    /** Hệ số phóng đại tối đa có cơ sở dữ liệu: ~floor(√số khung hữu dụng); 3× cần ≥9 khung có pha dưới điểm ảnh đa dạng. */
    fun maxSupportedScale(usableFrames: Int): Int = max(1, sqrt(usableFrames.toFloat()).toInt())

    // ---------------------------------------------------------------- tham số
    private const val TILE = 64            // ô đo độ nét (điểm ảnh gốc)
    private const val BAND = 96            // số hàng ra mỗi dải xử lý
    private const val MARG = 16            // hàng đệm mỗi phía cho khử tích chập + khử nhiễu
    private const val LAMBDA = 0.10f       // chính quy hoá về nội suy bicubic của tham chiếu
    private const val SPLAT_SIGMA = 0.5f  // σ nhân rải (điểm ảnh RA)
    private const val DECONV_SIGMA = 1.0f // σ PSF khử tích chập (điểm ảnh RA): nhỏ có chủ đích -> chỉ phục hồi một phần
    private const val DECONV_ITERS = 3
    private const val DECONV_AMOUNT = 1.0f
    private const val CR = 4               // bán kính khử nhiễu màu

    // ---------------------------------------------------------------- bảng tra
    private val LIN = FloatArray(256) {
        val c = it / 255.0
        (if (c <= 0.04045) c / 12.92 else Math.pow((c + 0.055) / 1.055, 2.4)).toFloat()
    }
    private const val ENC_N = 8192
    private val ENC = FloatArray(ENC_N + 1) {
        val l = it.toDouble() / ENC_N
        (255.0 * (if (l <= 0.0031308) 12.92 * l else 1.055 * Math.pow(l, 1.0 / 2.4) - 0.055)).toFloat()
    }
    private const val DEC_N = 1024
    private val DEC = FloatArray(DEC_N + 1) {
        val c = it.toDouble() / DEC_N
        (if (c <= 0.04045) c / 12.92 else Math.pow((c + 0.055) / 1.055, 2.4)).toFloat()
    }

    /** tuyến tính [0,1] -> sRGB [0,255] */
    private fun enc(l: Float): Float {
        val t = (if (l < 0f) 0f else if (l > 1f) 1f else l) * ENC_N
        val i = t.toInt()
        if (i >= ENC_N) return ENC[ENC_N]
        return ENC[i] + (ENC[i + 1] - ENC[i]) * (t - i)
    }

    /** sRGB [0,255] -> tuyến tính [0,1] */
    private fun dec(g: Float): Float {
        val t = (if (g < 0f) 0f else if (g > 255f) 255f else g) * (DEC_N / 255f)
        val i = t.toInt()
        if (i >= DEC_N) return DEC[DEC_N]
        return DEC[i] + (DEC[i + 1] - DEC[i]) * (t - i)
    }

    private const val KQ = 32
    private val KTAB = FloatArray(KQ * 4).also { t ->
        val two = 2f * SPLAT_SIGMA * SPLAT_SIGMA
        for (q in 0 until KQ) {
            val f = q.toFloat() / KQ
            var sum = 0f
            for (j in 0..3) {
                val d = (j - 1) - f
                val v = Math.exp((-d * d / two).toDouble()).toFloat()
                t[q * 4 + j] = v; sum += v
            }
            for (j in 0..3) t[q * 4 + j] /= sum
        }
    }
    private val PSF5 = FloatArray(5).also { k ->
        var s = 0f
        for (i in 0..4) { val d = (i - 2).toFloat(); k[i] = Math.exp((-d * d / (2f * DECONV_SIGMA * DECONV_SIGMA)).toDouble()).toFloat(); s += k[i] }
        for (i in 0..4) k[i] /= s
    }
    private val CSW = FloatArray(2 * CR + 1) { Math.exp((-(it - CR) * (it - CR) / (2.0 * 2.5 * 2.5))).toFloat() }
    private val CRW = FloatArray(256) { Math.exp((-(it * it) / (2.0 * 20.0 * 20.0))).toFloat() }
    /** Khử nhiễu màu mạnh hơn cho ảnh thiếu sáng (nhiễu màu lốm đốm nặng): cửa sổ range rộng hơn. */
    private val CRW_N = FloatArray(256) { Math.exp((-(it * it) / (2.0 * 36.0 * 36.0))).toFloat() }
    /** Chế độ thiếu sáng: độ sáng trung vị (tuyến tính) mà ảnh được nâng tới; ~0,09 ≈ sRGB 82/255 — vẫn ra cảnh đêm, không bị "ngày hoá". */
    private const val NIGHT_TARGET = 0.09f
    private const val NIGHT_MAX_LIFT = 3.5f

    private fun cr(t: Float, out: FloatArray, o: Int) {
        val t2 = t * t
        val t3 = t2 * t
        out[o] = -0.5f * t3 + t2 - 0.5f * t
        out[o + 1] = 1.5f * t3 - 2.5f * t2 + 1f
        out[o + 2] = -1.5f * t3 + 2f * t2 + 0.5f * t
        out[o + 3] = 0.5f * t3 - 0.5f * t2
    }

    private fun lumaI(p: Int): Int = (((p shr 16) and 255) * 77 + ((p shr 8) and 255) * 150 + (p and 255) * 29) shr 8

    // ---------------------------------------------------------------- cấu trúc dữ liệu
    private class Pyr(val w: IntArray, val h: IntArray, val p: Array<FloatArray>)

    /** Trường chuyển động trên lưới ô. Ô (i,j) phủ cửa sổ [i*step, i*step+win); tâm ô = win/2 + i*step. Luồng: cur(x+f) ≈ ref(x). */
    private class Field(val w: Int, val h: Int, winReq: Int, val step: Int) {
        val win = min(winReq, min(w, h))
        val gw = max(1, (w - win) / step + 1)
        val gh = max(1, (h - win) / step + 1)
        val fx = FloatArray(gw * gh)
        val fy = FloatArray(gw * gh)
        val conf = FloatArray(gw * gh)
        val tex = FloatArray(gw * gh)
        val gm = FloatArray(gw * gh)
        val res = FloatArray(gw * gh)
        val fb = FloatArray(gw * gh) { 1f }
        val ok = BooleanArray(gw * gh)
        var minFy = 0f
        var maxFy = 0f

        fun cx(i: Int) = win * 0.5f + i * step
        fun cy(j: Int) = win * 0.5f + j * step

        /** Nội suy song tuyến luồng tại toạ độ liên tục (xl, yl) của mức này. */
        fun sample(xl: Float, yl: Float, out: FloatArray) {
            val u = ((xl - win * 0.5f) / step).coerceIn(0f, (gw - 1).toFloat())
            val v = ((yl - win * 0.5f) / step).coerceIn(0f, (gh - 1).toFloat())
            val i0 = min(u.toInt(), max(gw - 2, 0))
            val j0 = min(v.toInt(), max(gh - 2, 0))
            val i1 = min(i0 + 1, gw - 1)
            val j1 = min(j0 + 1, gh - 1)
            val tx = u - i0
            val ty = v - j0
            val a = j0 * gw + i0
            val b = j0 * gw + i1
            val c = j1 * gw + i0
            val d = j1 * gw + i1
            out[0] = (fx[a] * (1f - tx) + fx[b] * tx) * (1f - ty) + (fx[c] * (1f - tx) + fx[d] * tx) * ty
            out[1] = (fy[a] * (1f - tx) + fy[b] * tx) * (1f - ty) + (fy[c] * (1f - tx) + fy[d] * tx) * ty
        }

        /** Giá trị nhỏ nhất của mảng `arr` trên 4 ô quanh (xl, yl) (bảo thủ: một ô xấu lan sang ô kề). */
        fun minAround(arr: FloatArray, xl: Float, yl: Float): Float {
            val u = ((xl - win * 0.5f) / step).coerceIn(0f, (gw - 1).toFloat())
            val v = ((yl - win * 0.5f) / step).coerceIn(0f, (gh - 1).toFloat())
            val i0 = min(u.toInt(), max(gw - 2, 0))
            val j0 = min(v.toInt(), max(gh - 2, 0))
            val i1 = min(i0 + 1, gw - 1)
            val j1 = min(j0 + 1, gh - 1)
            return min(min(arr[j0 * gw + i0], arr[j0 * gw + i1]), min(arr[j1 * gw + i0], arr[j1 * gw + i1]))
        }

        fun finish() {
            var lo = Float.MAX_VALUE
            var hi = -Float.MAX_VALUE
            for (v in fy) { if (v < lo) lo = v; if (v > hi) hi = v }
            minFy = lo; maxFy = hi
        }
    }

    private class Noise(val sigma: Float, val nlf: FloatArray)

    private class FrameInfo(val px: IntArray, val noise: Noise, val tileE: FloatArray, val score: Float)

    private class Aligned(val field: Field?, val gain: Float, val usable: Boolean, val goodFrac: Float, val phx: Float, val phy: Float)

    // ---------------------------------------------------------------- ảnh cơ bản
    private fun decode(path: String, region: Rect): IntArray {
        @Suppress("DEPRECATION")
        val dec = BitmapRegionDecoder.newInstance(path, false) ?: throw IllegalStateException("Không đọc được khung")
        try {
            val o = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val b = dec.decodeRegion(region, o) ?: throw IllegalStateException("decodeRegion null")
            val w = b.width
            val h = b.height
            val out = IntArray(w * h)
            b.getPixels(out, 0, w, 0, 0, w, h)
            b.recycle()
            return out
        } finally {
            dec.recycle()
        }
    }

    private fun lumaF(px: IntArray, w: Int, h: Int): FloatArray {
        val out = FloatArray(w * h)
        for (i in 0 until w * h) {
            val p = px[i]
            out[i] = 0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)
        }
        return out
    }

    /** Thu nhỏ 2× bằng nhân (1,3,3,1)/8 tách hai chiều; ra (w/2)×(h/2). */
    private fun down2(src: FloatArray, w: Int, h: Int): FloatArray {
        val ow = w / 2
        val oh = h / 2
        val tmp = FloatArray(ow * h)
        for (y in 0 until h) {
            val r = y * w
            for (x in 0 until ow) {
                val a = (2 * x - 1).coerceAtLeast(0)
                val d = (2 * x + 2).coerceAtMost(w - 1)
                tmp[y * ow + x] = (src[r + a] + 3f * src[r + 2 * x] + 3f * src[r + 2 * x + 1] + src[r + d]) * 0.125f
            }
        }
        val out = FloatArray(ow * oh)
        for (y in 0 until oh) {
            val a = (2 * y - 1).coerceAtLeast(0) * ow
            val b = (2 * y) * ow
            val c = (2 * y + 1) * ow
            val d = (2 * y + 2).coerceAtMost(h - 1) * ow
            for (x in 0 until ow) out[y * ow + x] = (tmp[a + x] + 3f * tmp[b + x] + 3f * tmp[c + x] + tmp[d + x]) * 0.125f
        }
        return out
    }

    /** Làm mờ [1 2 1]/4 hai chiều TẠI CHỖ (giảm nhiễu trước khi lấy gradient để căn chỉnh). */
    private fun blur121InPlace(a: FloatArray, w: Int, h: Int) {
        val row = FloatArray(w)
        for (y in 0 until h) {
            val r = y * w
            for (x in 0 until w) row[x] = a[r + x]
            for (x in 0 until w) {
                val l = row[(x - 1).coerceAtLeast(0)]
                val rr = row[(x + 1).coerceAtMost(w - 1)]
                a[r + x] = 0.25f * l + 0.5f * row[x] + 0.25f * rr
            }
        }
        val prev = FloatArray(w)
        for (x in 0 until w) prev[x] = a[x]
        for (y in 0 until h) {
            val r = y * w
            val rn = min(y + 1, h - 1) * w
            for (x in 0 until w) {
                val cur = a[r + x]
                a[r + x] = 0.25f * prev[x] + 0.5f * cur + 0.25f * a[rn + x]
                prev[x] = cur
            }
        }
    }

    /** Kim tự tháp: mức 0 = ảnh đã làm mờ nhẹ (dùng cho LK), các mức sau thu nhỏ 2×. Huỷ `l0` (dùng lại làm mức 0). */
    private fun buildPyr(l0: FloatArray, w: Int, h: Int, levels: Int): Pyr {
        val ws = IntArray(levels)
        val hs = IntArray(levels)
        val ps = arrayOfNulls<FloatArray>(levels)
        ws[0] = w; hs[0] = h
        if (levels > 1) {
            ps[1] = down2(l0, w, h)
            ws[1] = w / 2; hs[1] = h / 2
        }
        blur121InPlace(l0, w, h)
        ps[0] = l0
        for (l in 2 until levels) {
            ps[l] = down2(ps[l - 1]!!, ws[l - 1], hs[l - 1])
            ws[l] = ws[l - 1] / 2; hs[l] = hs[l - 1] / 2
        }
        return Pyr(ws, hs, Array(levels) { ps[it]!! })
    }

    // ---------------------------------------------------------------- nhiễu + độ nét
    /** Hàm nhiễu theo mức sáng (Immerkaer trên điểm không có cạnh mạnh): σ toàn ảnh và σ(Y) cho Y=0..255. */
    private fun noiseProfile(l: FloatArray, w: Int, h: Int): Noise {
        val sum = DoubleArray(16)
        val cnt = LongArray(16)
        var y = 1
        while (y < h - 1) {
            var x = 1
            while (x < w - 1) {
                val i = y * w + x
                val v = l[i - w - 1] - 2f * l[i - w] + l[i - w + 1] -
                    2f * l[i - 1] + 4f * l[i] - 2f * l[i + 1] +
                    l[i + w - 1] - 2f * l[i + w] + l[i + w + 1]
                val a = abs(v)
                if (a < 90f) {
                    val b = (l[i] / 16f).toInt().coerceIn(0, 15)
                    sum[b] += a.toDouble(); cnt[b]++
                }
                x += 2
            }
            y += 3
        }
        val k = Math.sqrt(Math.PI / 2.0) / 6.0
        var ts = 0.0
        var tc = 0L
        for (b in 0 until 16) { ts += sum[b]; tc += cnt[b] }
        val gs = if (tc > 0) (k * ts / tc).toFloat().coerceIn(1.2f, 9f) else 3f
        val bs = FloatArray(16)
        val has = BooleanArray(16)
        for (b in 0 until 16) {
            if (cnt[b] >= 300) { bs[b] = (k * sum[b] / cnt[b]).toFloat().coerceIn(1f, 12f); has[b] = true }
        }
        for (b in 0 until 16) {
            if (has[b]) continue
            var best = -1
            var bd = 99
            for (c in 0 until 16) if (has[c] && abs(c - b) < bd) { bd = abs(c - b); best = c }
            bs[b] = if (best >= 0) bs[best] else gs
        }
        val lut = FloatArray(256) { bs[it / 16] }
        return Noise(gs, lut)
    }

    private fun tileEnergy(l1: FloatArray, w1: Int, h1: Int, tw: Int, th: Int): FloatArray {
        val sum = DoubleArray(tw * th)
        val cnt = IntArray(tw * th)
        val t1 = TILE / 2
        for (y in 1 until h1 - 1) {
            val r = y * w1
            val tr = min(y / t1, th - 1) * tw
            for (x in 1 until w1 - 1) {
                val gx = (l1[r + x + 1] - l1[r + x - 1]) * 0.5f
                val gy = (l1[r + w1 + x] - l1[r - w1 + x]) * 0.5f
                val idx = tr + min(x / t1, tw - 1)
                sum[idx] += (gx * gx + gy * gy).toDouble()
                cnt[idx]++
            }
        }
        return FloatArray(tw * th) { if (cnt[it] > 0) (sum[it] / cnt[it]).toFloat() else 0f }
    }

    private fun analyze(path: String, region: Rect, w: Int, h: Int, tw: Int, th: Int): FrameInfo {
        val px = decode(path, region)
        if (px.size != w * h) throw IllegalStateException("Kích thước khung không khớp")
        val l0 = lumaF(px, w, h)
        val noise = noiseProfile(l0, w, h)
        val l1 = down2(l0, w, h)
        val te = tileEnergy(l1, w / 2, h / 2, tw, th)
        val sorted = te.copyOf()
        java.util.Arrays.sort(sorted)
        var s = 0.0
        val half = max(1, sorted.size / 2)
        for (i in sorted.size - half until sorted.size) s += sorted[i].toDouble()
        // trừ phần năng lượng do nhiễu (gradient trung tâm trên ảnh đã thu nhỏ 2×: ≈ σ²/8)
        val score = (s / half).toFloat() - noise.sigma * noise.sigma * 0.125f
        return FrameInfo(px, noise, te, score)
    }

    // ---------------------------------------------------------------- Lucas-Kanade kim tự tháp theo ô
    /** Dịch nguyên toàn cục (điểm ảnh của mức đỉnh): cur(x+dx, y+dy) ≈ ref(x, y). SAD thưa, hơi ưu tiên dịch nhỏ. */
    private fun globalShift(ref: FloatArray, cur: FloatArray, w: Int, h: Int, r: Int): IntArray {
        val m = r + 1
        var best = Float.MAX_VALUE
        var bx = 0
        var by = 0
        if (w <= 2 * m + 4 || h <= 2 * m + 4) return intArrayOf(0, 0)
        for (sy in -r..r) for (sx in -r..r) {
            var sad = 0f
            var n = 0
            var y = m
            while (y < h - m) {
                var x = m
                while (x < w - m) {
                    sad += abs(ref[y * w + x] - cur[(y + sy) * w + x + sx])
                    n++
                    x += 2
                }
                y += 2
            }
            if (n > 0) {
                sad = sad / n + (abs(sx) + abs(sy)) * 0.02f
                if (sad < best) { best = sad; bx = sx; by = sy }
            }
        }
        return intArrayOf(bx, by)
    }

    /**
     * Giải LK ngược (tịnh tiến) độc lập cho từng ô: tìm f sao cho B(x+f) ≈ A(x) trong cửa sổ của ô.
     * Khởi tạo từ luồng của mức thô hơn (nội suy), lặp Gauss-Newton với trọng số bền vững 1/(1+(e/c)²); giới hạn độ lệch so với khởi tạo
     * (maxDev) để một ô không "chạy" khỏi nghiệm hợp lý. Ô thiếu chi tiết (tex < texThr) giữ nguyên giá trị khởi tạo và ok=false.
     */
    private fun solveLevel(
        A: FloatArray, B: FloatArray, w: Int, h: Int, f: Field, prev: Field?, gx0: Float, gy0: Float,
        robustC: Float, maxDev: Float, texThr: Float, iters: Int
    ) {
        val win = f.win
        val n = (win - 2) * (win - 2)
        val gxs = FloatArray(win * win)
        val gys = FloatArray(win * win)
        val tmp = FloatArray(2)
        val maxU = w - 1.001f
        val maxV = h - 1.001f
        val rc2 = robustC * robustC
        for (j in 0 until f.gh) {
            for (i in 0 until f.gw) {
                val c = j * f.gw + i
                val x0 = i * f.step
                val y0 = j * f.step
                var ox: Float
                var oy: Float
                if (prev != null) {
                    prev.sample((x0 + win * 0.5f) * 0.5f, (y0 + win * 0.5f) * 0.5f, tmp)
                    ox = tmp[0] * 2f; oy = tmp[1] * 2f
                } else { ox = gx0; oy = gy0 }
                val ix0 = ox
                val iy0 = oy
                f.fx[c] = ox; f.fy[c] = oy; f.ok[c] = false; f.res[c] = -1f
                var hxx = 0.0
                var hxy = 0.0
                var hyy = 0.0
                var gsum = 0.0
                for (yy in 1 until win - 1) {
                    val r = (y0 + yy) * w + x0
                    val lr = yy * win
                    for (xx in 1 until win - 1) {
                        val gx = (A[r + xx + 1] - A[r + xx - 1]) * 0.5f
                        val gy = (A[r + w + xx] - A[r - w + xx]) * 0.5f
                        gxs[lr + xx] = gx; gys[lr + xx] = gy
                        hxx += (gx * gx).toDouble(); hxy += (gx * gy).toDouble(); hyy += (gy * gy).toDouble()
                        gsum += sqrt(gx * gx + gy * gy).toDouble()
                    }
                }
                val tr = hxx + hyy
                val det0 = hxx * hyy - hxy * hxy
                val lmin = (tr / 2.0 - Math.sqrt(max(tr * tr / 4.0 - det0, 0.0))) / n
                f.tex[c] = lmin.toFloat()
                f.gm[c] = (gsum / n).toFloat()
                if (lmin < texThr) continue

                var good = true
                var sres = 0.0
                var cnt = 0
                var iter = 0
                while (iter < iters) {
                    var bx = 0.0
                    var by = 0.0
                    var axx = 0.0
                    var axy = 0.0
                    var ayy = 0.0
                    sres = 0.0
                    cnt = 0
                    for (yy in 1 until win - 1) {
                        val v = y0 + yy + oy
                        if (v < 0f || v > maxV) continue
                        val vy = v.toInt()
                        val ty = v - vy
                        val lr = yy * win
                        val r = (y0 + yy) * w + x0
                        for (xx in 1 until win - 1) {
                            val u = x0 + xx + ox
                            if (u < 0f || u > maxU) continue
                            val ux = u.toInt()
                            val tx = u - ux
                            val q = vy * w + ux
                            val value = (B[q] * (1f - tx) + B[q + 1] * tx) * (1f - ty) + (B[q + w] * (1f - tx) + B[q + w + 1] * tx) * ty
                            val e = value - A[r + xx]
                            val wr = 1f / (1f + e * e / rc2)
                            val gx = gxs[lr + xx]
                            val gy = gys[lr + xx]
                            val wgx = wr * gx
                            val wgy = wr * gy
                            bx += (wgx * e).toDouble()
                            by += (wgy * e).toDouble()
                            axx += (wgx * gx).toDouble()
                            axy += (wgx * gy).toDouble()
                            ayy += (wgy * gy).toDouble()
                            sres += abs(e).toDouble()
                            cnt++
                        }
                    }
                    if (cnt < n / 2) { good = false; break }
                    val det = axx * ayy - axy * axy
                    if (det < 1e-6 * n) break
                    val dx = ((ayy * bx - axy * by) / det).toFloat().coerceIn(-2f, 2f)
                    val dy = ((-axy * bx + axx * by) / det).toFloat().coerceIn(-2f, 2f)
                    ox -= dx
                    oy -= dy
                    iter++
                    if (abs(ox - ix0) > maxDev || abs(oy - iy0) > maxDev) { good = false; break }
                    if (abs(dx) < 0.01f && abs(dy) < 0.01f) break
                }
                if (good) {
                    f.fx[c] = ox; f.fy[c] = oy; f.ok[c] = true
                    f.res[c] = if (cnt > 0) (sres / cnt).toFloat() else -1f
                } else {
                    f.fx[c] = ix0; f.fy[c] = iy0
                }
            }
        }
    }

    /** Ô không đáng tin lấy luồng trung bình của các ô đáng tin lân cận (lan dần); ô cô lập dùng giá trị toàn cục. */
    private fun fillUnreliable(f: Field, defX: Float, defY: Float) {
        val gw = f.gw
        val gh = f.gh
        val rel = f.ok.copyOf()
        var any = false
        for (v in rel) if (v) { any = true; break }
        if (!any) {
            for (c in 0 until gw * gh) { f.fx[c] = defX; f.fy[c] = defY }
            return
        }
        val newX = FloatArray(gw * gh)
        val newY = FloatArray(gw * gh)
        val marked = BooleanArray(gw * gh)
        var pass = 0
        while (pass < gw + gh) {
            var changed = false
            java.util.Arrays.fill(marked, false)
            for (j in 0 until gh) for (i in 0 until gw) {
                val c = j * gw + i
                if (rel[c]) continue
                var sx = 0f
                var sy = 0f
                var m = 0
                for (dj in -1..1) for (di in -1..1) {
                    val jj = j + dj
                    val ii = i + di
                    if (jj < 0 || jj >= gh || ii < 0 || ii >= gw) continue
                    val cc = jj * gw + ii
                    if (rel[cc]) { sx += f.fx[cc]; sy += f.fy[cc]; m++ }
                }
                if (m > 0) { newX[c] = sx / m; newY[c] = sy / m; marked[c] = true; changed = true }
            }
            if (!changed) break
            for (c in 0 until gw * gh) if (marked[c]) { f.fx[c] = newX[c]; f.fy[c] = newY[c]; rel[c] = true }
            pass++
        }
    }

    /** Luồng từ thô đến mịn: trả mảng trường theo mức (chỉ minLevel..đỉnh khác null). A là tham chiếu, B là ảnh bị căn: B(x+f) ≈ A(x). */
    private fun flowPyr(A: Pyr, B: Pyr, minLevel: Int, g0x: Int, g0y: Int, sigma: Float, texThr: Float): Array<Field?> {
        val top = A.p.size - 1
        val fields = arrayOfNulls<Field>(A.p.size)
        for (l in top downTo minLevel) {
            val w = A.w[l]
            val h = A.h[l]
            val win: Int
            val step: Int
            when {
                l >= 2 -> { win = 24; step = 12 }
                l == 1 -> { win = 32; step = 16 }
                else -> { win = 48; step = 24 }
            }
            val f = Field(w, h, win, step)
            val sc = (1 shl (top - l)).toFloat()
            val prevF = if (l == top) null else fields[l + 1]
            val rc = if (l > 0) max(14f, 4f * sigma) else max(8f, 3f * sigma + 4f)
            val dev = if (l == top) 6f else if (l == 0) 2.5f else 3f
            solveLevel(A.p[l], B.p[l], w, h, f, prevF, g0x.toFloat(), g0y.toFloat(), rc, dev, texThr, if (l >= 1) 8 else 6)
            fillUnreliable(f, g0x * sc, g0y * sc)
            fields[l] = f
        }
        return fields
    }

    /** Kiểm tra Forward-Backward ở mức 1: luồng xuôi f rồi luồng ngược b tại điểm đến phải thoả f + b ≈ 0. */
    private fun forwardBackward(fw: Field, bw: Field) {
        val tmp = FloatArray(2)
        for (j in 0 until fw.gh) for (i in 0 until fw.gw) {
            val c = j * fw.gw + i
            if (!fw.ok[c]) { fw.fb[c] = 1f; continue }
            val px = fw.cx(i) + fw.fx[c]
            val py = fw.cy(j) + fw.fy[c]
            if (px < 0f || py < 0f || px > fw.w || py > fw.h) { fw.fb[c] = 0.5f; continue }
            bw.sample(px, py, tmp)
            val ex = fw.fx[c] + tmp[0]
            val ey = fw.fy[c] + tmp[1]
            val err = sqrt(ex * ex + ey * ey)
            fw.fb[c] = ((1f - err) / 0.65f).coerceIn(0f, 1f)
        }
    }

    /** Độ tin cậy cuối cùng của từng ô mức 0; trả (tỉ lệ ô đủ chi tiết mà căn chỉnh tốt, số ô đủ chi tiết). */
    private fun finalizeConf(f0: Field, f1: Field?, sigma: Float, texThr: Float): FloatArray {
        var textured = 0
        var good = 0
        for (j in 0 until f0.gh) for (i in 0 until f0.gw) {
            val c = j * f0.gw + i
            var cf: Float
            if (f0.tex[c] < texThr) {
                cf = 0.7f                       // vùng phẳng: sai lệch nhỏ không nhìn thấy; kiểm tra photometric từng điểm vẫn chạy khi trộn
            } else {
                textured++
                if (!f0.ok[c]) cf = 0f
                else {
                    val rho = f0.res[c] / (1.2f * sigma + 0.35f * f0.gm[c] + 1f)
                    val cp = (1f - (rho - 1f) / 1.5f).coerceIn(0f, 1f)
                    val fbc = if (f1 != null) f1.minAround(f1.fb, f0.cx(i) * 0.5f, f0.cy(j) * 0.5f) else 1f
                    cf = cp * fbc
                }
                if (cf < 0.12f) cf = 0f
                if (cf >= 0.5f) good++
            }
            f0.conf[c] = cf
        }
        f0.finish()
        return floatArrayOf(good.toFloat(), textured.toFloat())
    }

    private fun linLuma(p: Int): Float =
        0.2126f * LIN[(p shr 16) and 255] + 0.7152f * LIN[(p shr 8) and 255] + 0.0722f * LIN[p and 255]

    /** Hệ số phơi sáng (tuyến tính) tham chiếu/hiện tại từ các điểm lấy mẫu thưa nơi luồng đáng tin, tránh vùng cháy/tối. */
    private fun exposureGain(ref: IntArray, cur: IntArray, w: Int, h: Int, f: Field): Float {
        val tmp = FloatArray(2)
        var sr = 0.0
        var sc = 0.0
        var y = 5
        while (y < h - 5) {
            var x = 5
            while (x < w - 5) {
                f.sample(x + 0.5f, y + 0.5f, tmp)
                val cx = Math.round(x + tmp[0])
                val cy = Math.round(y + tmp[1])
                if (cx in 0 until w && cy in 0 until h) {
                    val a = linLuma(ref[y * w + x])
                    val b = linLuma(cur[cy * w + cx])
                    if (a in 0.03f..0.85f && b in 0.03f..0.85f && b / a in 0.5f..2f) { sr += a.toDouble(); sc += b.toDouble() }
                }
                x += 7
            }
            y += 7
        }
        if (sc <= 1e-6 || sr <= 1e-6) return 1f
        return (sr / sc).toFloat().coerceIn(0.8f, 1.25f)
    }

    // ---------------------------------------------------------------- tiện ích dải
    private fun blur5H(src: FloatArray, dst: FloatArray, ow: Int, rows: Int) {
        val k0 = PSF5[0]; val k1 = PSF5[1]; val k2 = PSF5[2]
        for (r in 0 until rows) {
            val o = r * ow
            for (x in 0 until ow) {
                val a = src[o + (x - 2).coerceAtLeast(0)]
                val b = src[o + (x - 1).coerceAtLeast(0)]
                val d = src[o + (x + 1).coerceAtMost(ow - 1)]
                val e = src[o + (x + 2).coerceAtMost(ow - 1)]
                dst[o + x] = k0 * (a + e) + k1 * (b + d) + k2 * src[o + x]
            }
        }
    }

    private fun blur5V(src: FloatArray, dst: FloatArray, ow: Int, rows: Int) {
        val k0 = PSF5[0]; val k1 = PSF5[1]; val k2 = PSF5[2]
        for (r in 0 until rows) {
            val a = (r - 2).coerceAtLeast(0) * ow
            val b = (r - 1).coerceAtLeast(0) * ow
            val c = r * ow
            val d = (r + 1).coerceAtMost(rows - 1) * ow
            val e = (r + 2).coerceAtMost(rows - 1) * ow
            for (x in 0 until ow) dst[c + x] = k0 * (src[a + x] + src[e + x]) + k1 * (src[b + x] + src[d + x]) + k2 * src[c + x]
        }
    }

    private fun axis(n: Int, g: Int, win: Int, step: Int, iOut: IntArray, tOut: FloatArray) {
        for (x in 0 until n) {
            val u = ((x + 0.5f - win * 0.5f) / step).coerceIn(0f, (g - 1).toFloat())
            val i0 = min(u.toInt(), max(g - 2, 0))
            iOut[x] = i0
            tOut[x] = u - i0
        }
    }

    // ---------------------------------------------------------------- chương trình chính
    /**
     * Ghép các khung trong vùng `region` thành bitmap 2× rồi chạy bộ lọc `proc` từng dải. Cùng chữ ký với [MultiFrame.merge].
     * Ném lỗi (kể cả OOM) khi không đủ dữ liệu tin cậy để nơi gọi quay về thuật toán cũ.
     */
    fun merge(paths: List<String>, region: Rect, progress: ((Int) -> Unit)? = null, night: Boolean = false, proc: (IntArray, Int, Int) -> Unit): Bitmap {
        val t0 = SystemClock.elapsedRealtime()
        val w = region.width()
        val h = region.height()
        val n = paths.size
        if (n < 2) throw IllegalStateException("Cần ít nhất 2 khung")
        if (w < 256 || h < 256) throw IllegalStateException("Vùng ghép quá nhỏ")
        val tw = (w + TILE - 1) / TILE
        val th = (h + TILE - 1) / TILE

        // ---- bước 1: giải mã + đo nhiễu/độ nét (2 luồng)
        val infos = arrayOfNulls<FrameInfo>(n)
        val done1 = AtomicInteger(0)
        run {
            val pool = Executors.newFixedThreadPool(min(2, n))
            try {
                val futs = ArrayList<Future<*>>()
                for (i in 0 until n) {
                    futs.add(pool.submit(Runnable {
                        try { infos[i] = analyze(paths[i], region, w, h, tw, th) } catch (_: Throwable) { }
                        progress?.invoke(6 * done1.incrementAndGet() / n)
                    }))
                }
                for (f in futs) f.get()
            } finally { pool.shutdown() }
        }
        val valid = ArrayList<Int>()
        for (i in 0 until n) if (infos[i] != null) valid.add(i)
        if (valid.size < 2) throw IllegalStateException("Không đủ khung hợp lệ")

        // ---- bước 2: chọn khung tham chiếu nét nhất
        val refIdx = valid.maxByOrNull { infos[it]!!.score } ?: valid[0]
        val refInfo = infos[refIdx]!!
        val sigma = refInfo.noise.sigma
        val texThr = max(6f, 1.5f * sigma * sigma)

        var levels = 1
        while (levels < 4 && (min(w, h) shr levels) >= 64) levels++
        val top = levels - 1

        // ---- bước 3-4: căn chỉnh theo ô + độ tin cậy (2 luồng)
        val aligned = arrayOfNulls<Aligned>(n)
        val refPyr = buildPyr(lumaF(refInfo.px, w, h), w, h, levels)
        val others = valid.filter { it != refIdx }
        val done2 = AtomicInteger(0)
        run {
            val pool = Executors.newFixedThreadPool(min(2, others.size))
            try {
                val futs = ArrayList<Future<*>>()
                for (k in others) {
                    futs.add(pool.submit(Runnable {
                        try {
                            val cur = infos[k]!!
                            val curPyr = buildPyr(lumaF(cur.px, w, h), w, h, levels)
                            val g = globalShift(refPyr.p[top], curPyr.p[top], refPyr.w[top], refPyr.h[top], 10)
                            val fw = flowPyr(refPyr, curPyr, 0, g[0], g[1], sigma, texThr)
                            val bw = if (top >= 1) flowPyr(curPyr, refPyr, 1, -g[0], -g[1], sigma, texThr) else null
                            val f0 = fw[0]!!
                            val f1 = if (top >= 1) fw[1] else null
                            if (f1 != null && bw != null) forwardBackward(f1, bw[1]!!)
                            val st = finalizeConf(f0, f1, sigma, texThr)
                            val goodFrac = if (st[1] > 0f) st[0] / st[1] else 1f
                            val usable = !(st[1] >= 12f && goodFrac < 0.25f)
                            val gain = if (usable) exposureGain(refInfo.px, cur.px, w, h, f0) else 1f
                            // pha dưới điểm ảnh trung vị của các ô tin cậy (để đánh giá độ đa dạng lấy mẫu)
                            val xs = ArrayList<Float>()
                            val ys = ArrayList<Float>()
                            for (c in 0 until f0.gw * f0.gh) if (f0.conf[c] >= 0.5f && f0.tex[c] >= texThr) { xs.add(f0.fx[c]); ys.add(f0.fy[c]) }
                            xs.sort(); ys.sort()
                            val mx = if (xs.isEmpty()) 0f else xs[xs.size / 2]
                            val my = if (ys.isEmpty()) 0f else ys[ys.size / 2]
                            aligned[k] = Aligned(f0, gain, usable, goodFrac, mx - Math.floor(mx.toDouble()).toFloat(), my - Math.floor(my.toDouble()).toFloat())
                        } catch (_: Throwable) { }
                        progress?.invoke(6 + 14 * done2.incrementAndGet() / others.size)
                    }))
                }
                for (f in futs) f.get()
            } finally { pool.shutdown() }
        }

        val used = ArrayList<Int>()
        used.add(refIdx)
        for (k in others) { val a = aligned[k]; if (a != null && a.usable) used.add(k) }
        if (used.size < 2) throw IllegalStateException("Không khung phụ nào căn chỉnh đủ tin cậy")
        val nf = used.size
        val tAligned = SystemClock.elapsedRealtime()

        val pxs = Array(nf) { infos[used[it]]!!.px }
        val fields = arrayOfNulls<Field>(nf)
        val gains = FloatArray(nf) { 1f }
        for (i in 1 until nf) { fields[i] = aligned[used[i]]!!.field; gains[i] = aligned[used[i]]!!.gain }
        val gg = FloatArray(nf) { Math.pow(gains[it].toDouble(), 1.0 / 2.2).toFloat() }
        var sMin = Float.MAX_VALUE
        for (i in 0 until nf) sMin = min(sMin, infos[used[i]]!!.noise.sigma)
        val noiseW = FloatArray(nf) { val r = sMin / infos[used[it]]!!.noise.sigma; (r * r).coerceIn(0.5f, 1f) }
        val tiles = tw * th
        val eMax = FloatArray(tiles)
        for (i in 0 until nf) { val te = infos[used[i]]!!.tileE; for (t in 0 until tiles) if (te[t] > eMax[t]) eMax[t] = te[t] }
        val sharpW = Array(nf) { i ->
            val te = infos[used[i]]!!.tileE
            FloatArray(tiles) { t -> sqrt((te[t] + 2f) / (eMax[t] + 2f)).coerceIn(0.4f, 1f) }
        }
        val nlf = refInfo.noise.nlf
        // thống kê báo cáo
        var phaseMask = 1
        for (i in 1 until nf) {
            val a = aligned[used[i]]!!
            phaseMask = phaseMask or (1 shl ((if (a.phx >= 0.5f) 1 else 0) + 2 * (if (a.phy >= 0.5f) 1 else 0)))
        }
        val phaseBins = Integer.bitCount(phaseMask)
        var relSum = 0f
        for (i in 1 until nf) { relSum += aligned[used[i]]!!.goodFrac }
        // giải phóng khung bị loại + kim tự tháp
        for (i in 0 until n) if (!used.contains(i)) infos[i] = null

        val baseL = ByteArray(w * h)
        val refPx = pxs[0]
        for (i in 0 until w * h) baseL[i] = lumaI(refPx[i]).toByte()
        // THIẾU SÁNG: hệ số nâng vùng tối (đường cong kiểu Reinhard y·g/(1+(g−1)y): 0→0, 1→1, nên vùng sáng/đèn không cháy thêm).
        // g lấy từ độ sáng trung vị của khung tham chiếu; chỉ nâng khi ảnh thật sự tối, tối đa NIGHT_MAX_LIFT.
        var liftG = 1f
        if (night) {
            val hist = IntArray(256)
            var cntH = 0
            var hi = 0
            while (hi < w * h) { hist[baseL[hi].toInt() and 255]++; cntH++; hi += 7 }
            var acc = 0
            var med = 0
            for (v in 0..255) { acc += hist[v]; if (acc * 2 >= cntH) { med = v; break } }
            val mlin = max(dec(med.toFloat()), 0.004f)
            liftG = (NIGHT_TARGET / mlin).coerceIn(1f, NIGHT_MAX_LIFT)
        }
        val crw = if (night) CRW_N else CRW
        // thử nghiệm mô phỏng: khử nhiễu mạnh hơn / khử tích chập nhẹ hơn làm MẤT chi tiết mà không giảm nhiễu đáng kể -> giữ như ảnh thường;
        // riêng phần nâng vùng tối khuếch đại nhiễu nên nới cửa sổ khử nhiễu theo hệ số nâng
        val dnK = 2.2f * (1f + 0.35f * (liftG - 1f))
        val dAmount = DECONV_AMOUNT

        // ---- bước 5-8: dựng lưới 2× theo dải
        val ow = w * SCALE
        val oh = h * SCALE
        val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val bands = (oh + BAND - 1) / BAND
        val cores = Runtime.getRuntime().availableProcessors().coerceIn(1, if (night) 2 else 3)
        val outLock = Any()
        val doneB = AtomicInteger(0)
        val bxi = IntArray(ow)
        val bxw = FloatArray(ow * 4)
        val cxf = FloatArray(ow)
        for (i in 0 until ow) {
            val rx = ((i - 0.5f) / SCALE).coerceIn(0f, (w - 1).toFloat())
            val ix = rx.toInt()
            bxi[i] = ix
            cxf[i] = rx - ix
            cr(rx - ix, bxw, i * 4)
        }
        val xi0 = arrayOfNulls<IntArray>(nf)
        val xt = arrayOfNulls<FloatArray>(nf)
        for (k in 1 until nf) {
            val fl = fields[k]!!
            val a = IntArray(w)
            val t = FloatArray(w)
            axis(w, fl.gw, fl.win, fl.step, a, t)
            xi0[k] = a; xt[k] = t
        }
        val bufRows = BAND + 2 * MARG
        val crRows = bufRows / SCALE + 12 + 2 * CR

        java.util.stream.IntStream.range(0, cores).parallel().forEach { core ->
            val accY = FloatArray(ow * bufRows)
            val accW = FloatArray(ow * bufRows)
            val bYg = FloatArray(ow * bufRows)
            val bI = FloatArray(ow * bufRows)
            val bE = FloatArray(ow * bufRows)
            val bS = FloatArray(ow * bufRows)
            val accC = Array(3) { FloatArray(w * crRows) }
            val accCw = FloatArray(w * crRows)
            val tC = Array(3) { FloatArray(w * crRows) }
            val dC = Array(3) { FloatArray(w * crRows) }
            val px = IntArray(ow * BAND)
            val rowY = Array(crRows) { FloatArray(ow) }
            val rowC = Array(3) { Array(crRows) { FloatArray(ow) } }
            val lline = FloatArray(w)
            val cline = Array(3) { FloatArray(w) }
            val wy = FloatArray(4)
            val flowTmp = FloatArray(2)
            var bi = core
            while (bi < bands) {
                val y0 = bi * BAND
                val y1 = min(oh, y0 + BAND)
                val bh = y1 - y0
                val y0m = max(0, y0 - MARG)
                val y1m = min(oh, y1 + MARG)
                val bhm = y1m - y0m
                val rb = max(0, ((y0m - 0.5f) / SCALE).toInt() - 1)
                val re = min(h - 1, ((y1m - 1 - 0.5f) / SCALE).toInt() + 2)
                val rbA = max(0, rb - CR)
                val reA = min(h - 1, re + CR)
                val nrA = reA - rbA + 1
                java.util.Arrays.fill(accY, 0, ow * bhm, 0f)
                java.util.Arrays.fill(accW, 0, ow * bhm, 0f)
                for (c in 0..2) java.util.Arrays.fill(accC[c], 0, w * nrA, 0f)
                java.util.Arrays.fill(accCw, 0, w * nrA, 0f)

                for (k in 0 until nf) {
                    val fpx = pxs[k]
                    val fld = fields[k]
                    val minFy = fld?.minFy ?: 0f
                    val maxFy = fld?.maxFy ?: 0f
                    val yLoL = Math.floor(((y0m - 3f) / SCALE + minFy).toDouble()).toInt() - 1
                    val yHiL = ceil((y1m + 1f) / SCALE + maxFy).toInt() + 1
                    val yLoC = rbA + Math.floor(minFy.toDouble()).toInt() - 1
                    val yHiC = reA + ceil(maxFy).toInt() + 1
                    val yLo = max(0, min(yLoL, yLoC))
                    val yHi = min(h - 1, max(yHiL, yHiC))
                    val sw = sharpW[k]
                    val nw = noiseW[k]
                    val gn = gains[k]
                    val ggk = gg[k]
                    val gw = fld?.gw ?: 1
                    val xi = xi0[k]
                    val xtk = xt[k]
                    for (y in yLo..yHi) {
                        var j0 = 0
                        var j1 = 0
                        var tj = 0f
                        if (fld != null) {
                            val v = ((y + 0.5f - fld.win * 0.5f) / fld.step).coerceIn(0f, (fld.gh - 1).toFloat())
                            j0 = min(v.toInt(), max(fld.gh - 2, 0))
                            j1 = min(j0 + 1, fld.gh - 1)
                            tj = v - j0
                        }
                        val tileRow = min(y shr 6, th - 1) * tw
                        for (x in 0 until w) {
                            var fxv = 0f
                            var fyv = 0f
                            var cf = 1f
                            if (fld != null && xi != null && xtk != null) {
                                val i0 = xi[x]
                                val i1 = if (i0 + 1 < gw) i0 + 1 else i0
                                val tx = xtk[x]
                                val a = j0 * gw + i0
                                val b = j0 * gw + i1
                                val c = j1 * gw + i0
                                val d = j1 * gw + i1
                                fxv = (fld.fx[a] * (1f - tx) + fld.fx[b] * tx) * (1f - tj) + (fld.fx[c] * (1f - tx) + fld.fx[d] * tx) * tj
                                fyv = (fld.fy[a] * (1f - tx) + fld.fy[b] * tx) * (1f - tj) + (fld.fy[c] * (1f - tx) + fld.fy[d] * tx) * tj
                                cf = min(min(fld.conf[a], fld.conf[b]), min(fld.conf[c], fld.conf[d]))
                                if (cf <= 0.001f) continue
                            }
                            val rx = x - fxv
                            val ry = y - fyv
                            val oyf = SCALE * ry + 0.5f
                            val oy = Math.floor(oyf.toDouble()).toInt()
                            val lumaRow = !(oy + 2 < y0m || oy - 1 >= y1m)
                            val byp = Math.round(ry)
                            val bxp = Math.round(rx)
                            val chromaOk = byp in rbA..reA && bxp in 0 until w
                            if (!lumaRow && !chromaOk) continue
                            val p = fpx[y * w + x]
                            val r8 = (p shr 16) and 255
                            val g8 = (p shr 8) and 255
                            val b8 = p and 255
                            var wt = sw[tileRow + min(x shr 6, tw - 1)] * nw
                            if (k > 0) {
                                // sai số photometric so với tham chiếu (nội suy song tuyến) -> trọng số bền vững Geman-McClure
                                val rxc = rx.coerceIn(0f, w - 1.001f)
                                val ryc = ry.coerceIn(0f, h - 1.001f)
                                val ix = rxc.toInt()
                                val iy = ryc.toInt()
                                val ax = rxc - ix
                                val ay = ryc - iy
                                val q = iy * w + ix
                                val b00 = (baseL[q].toInt() and 255).toFloat()
                                val b10 = (baseL[q + 1].toInt() and 255).toFloat()
                                val b01 = (baseL[q + w].toInt() and 255).toFloat()
                                val b11 = (baseL[q + w + 1].toInt() and 255).toFloat()
                                val rg = (b00 * (1f - ax) + b10 * ax) * (1f - ay) + (b01 * (1f - ax) + b11 * ax) * ay
                                val d = lumaI(p) * ggk - rg
                                val gxr = abs(b10 - b00 + b11 - b01) * 0.5f
                                val gyr = abs(b01 - b00 + b11 - b10) * 0.5f
                                val gmx = if (gxr > gyr) gxr else gyr
                                val sg = nlf[rg.toInt().coerceIn(0, 255)]
                                val t2 = (1.6f * sg) * (1.6f * sg) + (0.5f * gmx) * (0.5f * gmx) + 4f
                                val qq = 1f + d * d / t2
                                wt *= cf / (qq * qq)
                            }
                            if (wt < 1e-4f) continue
                            val ylinOwn = 0.2126f * LIN[r8] + 0.7152f * LIN[g8] + 0.0722f * LIN[b8]
                            if (lumaRow) {
                                val ylin = ylinOwn * gn
                                val oxf = SCALE * rx + 0.5f
                                val ox = Math.floor(oxf.toDouble()).toInt()
                                val fy = oyf - oy
                                val fx = oxf - ox
                                val qy = (fy * KQ).toInt().coerceIn(0, KQ - 1)
                                val qx = (fx * KQ).toInt().coerceIn(0, KQ - 1)
                                for (jy in 0..3) {
                                    val yy = oy - 1 + jy
                                    if (yy < y0m || yy >= y1m) continue
                                    val wyy = wt * KTAB[qy * 4 + jy]
                                    val rowI = (yy - y0m) * ow
                                    for (jx in 0..3) {
                                        val xx = ox - 1 + jx
                                        if (xx < 0 || xx >= ow) continue
                                        val ww = wyy * KTAB[qx * 4 + jx]
                                        val idx = rowI + xx
                                        accY[idx] += ylin * ww
                                        accW[idx] += ww
                                    }
                                }
                            }
                            if (chromaOk) {
                                val ye = enc(ylinOwn)
                                val ci = (byp - rbA) * w + bxp
                                accC[0][ci] += (r8 - ye) * ggk * wt
                                accC[1][ci] += (g8 - ye) * ggk * wt
                                accC[2][ci] += (b8 - ye) * ggk * wt
                                accCw[ci] += wt
                            }
                        }
                    }
                }

                // chuẩn hoá màu 1×
                for (i in 0 until w * nrA) {
                    val cw = if (accCw[i] > 1e-3f) accCw[i] else 1e-3f
                    accC[0][i] /= cw; accC[1][i] /= cw; accC[2][i] /= cw
                }
                // khử nhiễu màu song phương tách hai chiều, dẫn hướng bằng độ sáng tham chiếu
                for (r in 0 until nrA) {
                    val ro = r * w
                    val gro = (rbA + r) * w
                    for (x in 0 until w) {
                        val gc = baseL[gro + x].toInt() and 255
                        var s0 = 0f; var s1 = 0f; var s2 = 0f; var sw = 0f
                        for (d in -CR..CR) {
                            val xx = (x + d).coerceIn(0, w - 1)
                            val gv = baseL[gro + xx].toInt() and 255
                            val wg = CSW[d + CR] * crw[abs(gv - gc)]
                            s0 += accC[0][ro + xx] * wg; s1 += accC[1][ro + xx] * wg; s2 += accC[2][ro + xx] * wg
                            sw += wg
                        }
                        tC[0][ro + x] = s0 / sw; tC[1][ro + x] = s1 / sw; tC[2][ro + x] = s2 / sw
                    }
                }
                for (srow in rb..re) {
                    val r0 = srow - rbA
                    val o = (srow - rb) * w
                    for (x in 0 until w) {
                        val gc = baseL[srow * w + x].toInt() and 255
                        var s0 = 0f; var s1 = 0f; var s2 = 0f; var sw = 0f
                        for (d in -CR..CR) {
                            val rr = (r0 + d).coerceIn(0, nrA - 1)
                            val gv = baseL[(rbA + rr) * w + x].toInt() and 255
                            val wg = CSW[d + CR] * crw[abs(gv - gc)]
                            s0 += tC[0][rr * w + x] * wg; s1 += tC[1][rr * w + x] * wg; s2 += tC[2][rr * w + x] * wg
                            sw += wg
                        }
                        dC[0][o + x] = s0 / sw; dC[1][o + x] = s1 / sw; dC[2][o + x] = s2 / sw
                    }
                }
                // hàng tham chiếu: độ sáng tuyến tính nội suy bicubic ngang lên 2× (tiên nghiệm), màu nội suy song tuyến ngang
                for (srow in rb..re) {
                    val ro = srow * w
                    val co = (srow - rb) * w
                    for (x in 0 until w) lline[x] = linLuma(refPx[ro + x])
                    val ry = rowY[srow - rb]
                    for (i in 0 until ow) {
                        val c0 = bxi[i] - 1
                        var yy = 0f
                        for (kk in 0..3) yy += lline[(c0 + kk).coerceIn(0, w - 1)] * bxw[i * 4 + kk]
                        ry[i] = yy
                        val ia = bxi[i]
                        val ib = if (ia + 1 < w) ia + 1 else ia
                        val f = cxf[i]
                        for (c in 0..2) rowC[c][srow - rb][i] = dC[c][co + ia] * (1f - f) + dC[c][co + ib] * f
                    }
                }
                // hợp nhất độ sáng: (Σ w·y + λ·bicubic) / (Σ w + λ) -> tuyến tính; đồng thời sang sRGB
                for (j in 0 until bhm) {
                    val oyg = y0m + j
                    val rYv = ((oyg - 0.5f) / SCALE).coerceIn(0f, (h - 1).toFloat())
                    val iy = rYv.toInt()
                    val fyv = rYv - iy
                    cr(fyv, wy, 0)
                    val i0 = (iy - 1).coerceIn(0, h - 1) - rb
                    val i1 = iy.coerceIn(0, h - 1) - rb
                    val i2 = (iy + 1).coerceIn(0, h - 1) - rb
                    val i3 = (iy + 2).coerceIn(0, h - 1) - rb
                    val a0 = rowY[i0]; val a1 = rowY[i1]; val a2 = rowY[i2]; val a3 = rowY[i3]
                    for (i in 0 until ow) {
                        val yb = (a0[i] * wy[0] + a1[i] * wy[1] + a2[i] * wy[2] + a3[i] * wy[3]).coerceIn(0f, 1f)
                        val idx = j * ow + i
                        val yl = (accY[idx] + LAMBDA * yb) / (accW[idx] + LAMBDA)
                        accY[idx] = yl
                        bYg[idx] = enc(yl)
                    }
                }
                // khử nhiễu 3×3 theo hạng nhiễu còn lại: σ_sau ≈ σ(Y)/√(4·ΣW); khoảng range = 2,2·σ_sau => chỉ mạnh ở nơi ít mẫu, giữ cạnh/kết cấu
                for (j in 0 until bhm) {
                    val ro = j * ow
                    val interiorRow = j >= 1 && j < bhm - 1
                    for (i in 0 until ow) {
                        val idx = ro + i
                        if (!interiorRow || i < 1 || i >= ow - 1) { bI[idx] = accY[idx]; continue }
                        val c = bYg[idx]
                        val neff = 4f * accW[idx]
                        val sAfter = nlf[c.toInt().coerceIn(0, 255)] / sqrt(if (neff > 1f) neff else 1f)
                        val inv2 = 1f / (dnK * sAfter * dnK * sAfter)
                        var s = c
                        var sw = 1f
                        for (dj in -1..1) for (di in -1..1) {
                            if (dj == 0 && di == 0) continue
                            val v = bYg[idx + dj * ow + di]
                            val dd = v - c
                            val q = 1f + dd * dd * inv2
                            val sp = if (dj == 0 || di == 0) 0.5f else 0.35f
                            val wgt = sp / (q * q)
                            s += v * wgt; sw += wgt
                        }
                        bI[idx] = dec(s / sw)
                    }
                }
                // khử tích chập Richardson-Lucy (tuyến tính, PSF nhỏ, DECONV_ITERS vòng)
                System.arraycopy(bI, 0, bE, 0, ow * bhm)
                for (rlIter in 0 until DECONV_ITERS) {
                    blur5H(bE, bS, ow, bhm); blur5V(bS, accY, ow, bhm)
                    for (i in 0 until ow * bhm) accY[i] = bI[i] / (accY[i] + 1e-4f)
                    blur5H(accY, bS, ow, bhm); blur5V(bS, accY, ow, bhm)
                    for (i in 0 until ow * bhm) bE[i] *= accY[i]
                }
                // chặn cực trị cục bộ (chống ringing/halo) + giảm mức theo lượng dữ liệu, rồi về sRGB
                for (j in 0 until bhm) {
                    val ja = max(0, j - 1) * ow
                    val jb = j * ow
                    val jc = min(bhm - 1, j + 1) * ow
                    for (i in 0 until ow) {
                        val ia = max(0, i - 1)
                        val ic = min(ow - 1, i + 1)
                        var mn = bI[jb + i]
                        var mx = mn
                        for (rr in 0..2) {
                            val ro = if (rr == 0) ja else if (rr == 1) jb else jc
                            for (cc in 0..2) {
                                val v = bI[ro + (if (cc == 0) ia else if (cc == 1) i else ic)]
                                if (v < mn) mn = v
                                if (v > mx) mx = v
                            }
                        }
                        val slack = 0.12f * (mx - mn)
                        val idx = jb + i
                        var e = bE[idx]
                        if (e < mn - slack) e = mn - slack
                        if (e > mx + slack) e = mx + slack
                        val dataC = (accW[idx] / 0.6f).coerceIn(0f, 1f)
                        val s = dAmount * dataC * dataC
                        val v = bI[idx] + s * (e - bI[idx])
                        if (liftG > 1.001f) {
                            val v2 = v * liftG / (1f + (liftG - 1f) * v)
                            val yo = enc(v)
                            val yn = enc(v2)
                            bYg[idx] = yn
                            // màu cũng được nâng theo (một phần) để vùng sáng lên không bị xám
                            bS[idx] = 1f + 0.6f * ((yn + 6f) / (yo + 6f) - 1f).coerceIn(0f, 1.5f)
                        } else bYg[idx] = enc(v)
                    }
                }
                // hoàn thiện RGB các hàng trung tâm (bỏ hàng đệm)
                val off = y0 - y0m
                for (j in off until off + bh) {
                    val oyg = y0m + j
                    val rYv = ((oyg - 0.5f) / SCALE).coerceIn(0f, (h - 1).toFloat())
                    val iy = rYv.toInt()
                    val fyv = rYv - iy
                    val i1 = iy.coerceIn(0, h - 1) - rb
                    val i2 = (iy + 1).coerceIn(0, h - 1) - rb
                    val c0a = rowC[0][i1]; val c0b = rowC[0][i2]
                    val c1a = rowC[1][i1]; val c1b = rowC[1][i2]
                    val c2a = rowC[2][i1]; val c2b = rowC[2][i2]
                    val ro = j * ow
                    val po = (j - off) * ow
                    for (i in 0 until ow) {
                        val ye = bYg[ro + i]
                        val cs = if (liftG > 1.001f) bS[ro + i] else 1f
                        val cR = (c0a[i] * (1f - fyv) + c0b[i] * fyv) * cs
                        val cG = (c1a[i] * (1f - fyv) + c1b[i] * fyv) * cs
                        val cB = (c2a[i] * (1f - fyv) + c2b[i] * fyv) * cs
                        val r = (ye + cR + 0.5f).toInt().coerceIn(0, 255)
                        val g = (ye + cG + 0.5f).toInt().coerceIn(0, 255)
                        val b = (ye + cB + 0.5f).toInt().coerceIn(0, 255)
                        px[po + i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                }
                proc(px, 0, ow * bh)
                synchronized(outLock) { out.setPixels(px, 0, ow, 0, y0, ow, bh) }
                progress?.invoke(20 + 80 * doneB.incrementAndGet() / bands)
                bi += cores
            }
        }
        val t1 = SystemClock.elapsedRealtime()
        MultiFrame.lastUsed = nf
        MultiFrame.lastAlignMs = tAligned - t0
        MultiFrame.lastFuseMs = t1 - tAligned
        val tag = if (night) "SR-NIGHT(lift " + "%.2f".format(liftG) + ")" else "SR"
        lastReport = tag + ": ref=" + refIdx + " dùng " + nf + "/" + n + " khung, tin cậy TB " + "%.0f".format(100f * relSum / max(1, nf - 1)) + "%, " +
            "pha dưới điểm ảnh " + phaseBins + "/4, σ=" + "%.1f".format(sigma) + ", căn " + (tAligned - t0) + "ms, ghép " + (t1 - tAligned) + "ms"
        android.util.Log.i("XpanSR", lastReport)
        return out
    }
}
