package com.xpanmode.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Rect
import java.util.stream.IntStream
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * LUNA HDR: ghép nhiều khung phơi sáng khác nhau (chuẩn / tối / sáng) bằng "exposure fusion" (Mertens):
 * mỗi điểm ảnh của mỗi khung được chấm điểm theo độ tương phản, độ bão hoà và độ "vừa sáng"; các khung được trộn theo
 * kim tự tháp Laplace nên không có quầng sáng ở ranh giới, màu giữ đúng như máy xử lí (không cần biết đường cong của ISP).
 * Khung đầu tiên là khung chuẩn (đo sáng của máy) và là khung gốc để căn chỉnh.
 */
object LunaHdr {
    @Volatile var lastUsed = 0

    private fun par(n: Int, f: (Int) -> Unit) {
        IntStream.range(0, n).parallel().forEach { f(it) }
    }

    private fun decode(path: String, region: Rect): IntArray {
        @Suppress("DEPRECATION")
        val dec = BitmapRegionDecoder.newInstance(path, false) ?: throw IllegalStateException("Không đọc được khung")
        try {
            val o = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888 }
            val b = dec.decodeRegion(region, o) ?: throw IllegalStateException("decodeRegion null")
            val w = b.width
            val h = b.height
            val out = IntArray(w * h)
            b.getPixels(out, 0, w, 0, 0, w, h)
            b.recycle()
            return out
        } finally {
            dec.recycle()
        }
    }

    /** Chuẩn hoá về trung bình 128, độ lệch chuẩn 40: so khớp được hai khung khác độ sáng. */
    private fun norm(a: FloatArray): FloatArray {
        var s = 0.0
        for (v in a) s += v
        val m = (s / a.size).toFloat()
        var q = 0.0
        for (v in a) q += (v - m) * (v - m)
        val sd = max(1f, sqrt(q / a.size).toFloat())
        val k = 40f / sd
        return FloatArray(a.size) { (a[it] - m) * k + 128f }
    }

    /** Tinh chỉnh độ lệch thô `c` (bội 4) xuống độ lệch nguyên điểm ảnh: SAD trên mảng giữa ảnh, đã chuẩn hoá độ sáng. */
    private fun fine(ref: IntArray, cur: IntArray, w: Int, h: Int, c: IntArray): IntArray {
        val pw = (min(640, w / 2) / 2) * 2
        val ph = (min(480, h / 2) / 2) * 2
        if (pw < 64 || ph < 64) return c
        val x0 = (w - pw) / 2
        val y0 = (h - ph) / 2
        val n = (pw / 2) * (ph / 2)
        fun grab(img: IntArray, ox: Int, oy: Int): FloatArray {
            val o = FloatArray(n)
            var k = 0
            var y = 0
            while (y < ph) {
                val yy = (y0 + oy + y).coerceIn(0, h - 1)
                var x = 0
                while (x < pw) {
                    val xx = (x0 + ox + x).coerceIn(0, w - 1)
                    o[k++] = MultiFrame.luma(img[yy * w + xx]).toFloat()
                    x += 2
                }
                y += 2
            }
            return norm(o)
        }
        val rp = grab(ref, 0, 0)
        var best = Float.MAX_VALUE
        var bx = c[0]
        var by = c[1]
        val r = 5
        for (dy in -r..r) for (dx in -r..r) {
            val ox = c[0] + dx
            val oy = c[1] + dy
            val cp = grab(cur, ox, oy)
            var sad = 0f
            for (i in 0 until n) sad += abs(rp[i] - cp[i])
            sad /= n
            sad += (abs(dx) + abs(dy)) * 0.02f
            if (sad < best) { best = sad; bx = ox; by = oy }
        }
        return intArrayOf(bx, by)
    }

    private fun shifted(cur: IntArray, w: Int, h: Int, dx: Int, dy: Int): IntArray {
        if (dx == 0 && dy == 0) return cur
        val out = IntArray(w * h)
        par(h) { y ->
            val sy = (y + dy).coerceIn(0, h - 1)
            for (x in 0 until w) out[y * w + x] = cur[sy * w + (x + dx).coerceIn(0, w - 1)]
        }
        return out
    }

    // ---- kim tự tháp

    private fun down(src: FloatArray, sw: Int, sh: Int): FloatArray {
        val dw = (sw + 1) / 2
        val dh = (sh + 1) / 2
        val tmp = FloatArray(dw * sh)
        par(sh) { y ->
            val row = y * sw
            for (xo in 0 until dw) {
                val x = xo * 2
                val a = src[row + (x - 2).coerceIn(0, sw - 1)]
                val b = src[row + (x - 1).coerceIn(0, sw - 1)]
                val c = src[row + x.coerceIn(0, sw - 1)]
                val d = src[row + (x + 1).coerceIn(0, sw - 1)]
                val e = src[row + (x + 2).coerceIn(0, sw - 1)]
                tmp[y * dw + xo] = (a + 4f * b + 6f * c + 4f * d + e) * (1f / 16f)
            }
        }
        val out = FloatArray(dw * dh)
        par(dh) { yo ->
            val y = yo * 2
            val r0 = (y - 2).coerceIn(0, sh - 1) * dw
            val r1 = (y - 1).coerceIn(0, sh - 1) * dw
            val r2 = y.coerceIn(0, sh - 1) * dw
            val r3 = (y + 1).coerceIn(0, sh - 1) * dw
            val r4 = (y + 2).coerceIn(0, sh - 1) * dw
            for (x in 0 until dw)
                out[yo * dw + x] = (tmp[r0 + x] + 4f * tmp[r1 + x] + 6f * tmp[r2 + x] + 4f * tmp[r3 + x] + tmp[r4 + x]) * (1f / 16f)
        }
        return out
    }

    private fun up(src: FloatArray, sw: Int, sh: Int, dw: Int, dh: Int): FloatArray {
        val x0 = IntArray(dw)
        val x1 = IntArray(dw)
        val fx = FloatArray(dw)
        for (x in 0 until dw) {
            val sx = ((x + 0.5f) * sw / dw - 0.5f).coerceIn(0f, (sw - 1).toFloat())
            val i = sx.toInt()
            x0[x] = i
            x1[x] = min(i + 1, sw - 1)
            fx[x] = sx - i
        }
        val out = FloatArray(dw * dh)
        par(dh) { y ->
            val sy = ((y + 0.5f) * sh / dh - 0.5f).coerceIn(0f, (sh - 1).toFloat())
            val j = sy.toInt()
            val j1 = min(j + 1, sh - 1)
            val fy = sy - j
            val ra = j * sw
            val rb = j1 * sw
            for (x in 0 until dw) {
                val f = fx[x]
                val a = src[ra + x0[x]] * (1f - f) + src[ra + x1[x]] * f
                val b = src[rb + x0[x]] * (1f - f) + src[rb + x1[x]] * f
                out[y * dw + x] = a * (1f - fy) + b * fy
            }
        }
        return out
    }

    /**
     * Ghép các khung (khung đầu = khung chuẩn) trong vùng `region` thành ảnh cùng kích thước vùng, rồi chạy bộ lọc màu `proc`.
     * Ném lỗi (kể cả hết bộ nhớ) để nơi gọi quay về ảnh một khung.
     */
    fun merge(paths: List<String>, region: Rect, progress: ((Int) -> Unit)? = null, proc: (IntArray, Int, Int) -> Unit): Bitmap {
        val w = region.width()
        val h = region.height()
        val ref = decode(paths[0], region)
        val refS = norm(MultiFrame.lumaDown(ref, w, h, 4))
        val frames = ArrayList<IntArray>()
        frames.add(ref)
        for (i in 1 until paths.size) {
            try {
                val f = decode(paths[i], region)
                val c = MultiFrame.coarse(refS, norm(MultiFrame.lumaDown(f, w, h, 4)), w / 4, h / 4)
                val s = fine(ref, f, w, h, c)
                // lệch quá xa = rung mạnh: bỏ khung
                if (abs(s[0]) <= 40 && abs(s[1]) <= 40) frames.add(shifted(f, w, h, s[0], s[1]))
            } catch (_: Throwable) {
            }
            progress?.invoke(20 * i / paths.size)
        }
        if (frames.size < 2) throw IllegalStateException("HDR: không đủ khung căn được")
        lastUsed = frames.size
        val nf = frames.size
        val n = w * h

        // ---- trọng số từng khung (tương phản × bão hoà × độ vừa sáng)
        val wt = Array(nf) { FloatArray(n) }
        for (i in 0 until nf) {
            val px = frames[i]
            val lum = FloatArray(n)
            par(h) { y ->
                for (x in 0 until w) {
                    val p = px[y * w + x]
                    lum[y * w + x] = (0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)) * (1f / 255f)
                }
            }
            val out = wt[i]
            par(h) { y ->
                val ya = max(0, y - 1) * w
                val yb = min(h - 1, y + 1) * w
                for (x in 0 until w) {
                    val k = y * w + x
                    val xa = max(0, x - 1)
                    val xb = min(w - 1, x + 1)
                    val lap = abs(4f * lum[k] - lum[ya + x] - lum[yb + x] - lum[y * w + xa] - lum[y * w + xb])
                    val p = px[k]
                    val r = ((p shr 16) and 255) * (1f / 255f)
                    val g = ((p shr 8) and 255) * (1f / 255f)
                    val b = (p and 255) * (1f / 255f)
                    val m = (r + g + b) * (1f / 3f)
                    val sat = sqrt(((r - m) * (r - m) + (g - m) * (g - m) + (b - m) * (b - m)) * (1f / 3f))
                    val e = exp(-15f * ((r - 0.5f) * (r - 0.5f) + (g - 0.5f) * (g - 0.5f) + (b - 0.5f) * (b - 0.5f)))
                    out[k] = (lap + 0.01f) * sqrt(sat + 0.01f) * (e + 1e-4f)
                }
            }
            progress?.invoke(20 + 10 * (i + 1) / nf)
        }
        par(h) { y ->
            for (x in 0 until w) {
                val k = y * w + x
                var s = 0f
                for (i in 0 until nf) s += wt[i][k]
                if (s < 1e-12f) { for (i in 0 until nf) wt[i][k] = 1f / nf }
                else { val inv = 1f / s; for (i in 0 until nf) wt[i][k] *= inv }
            }
        }

        // ---- kích thước các tầng + kim tự tháp Gauss của trọng số
        var levels = 1
        run {
            var mw = w
            var mh = h
            while (levels < 7 && min(mw, mh) >= 48) { mw = (mw + 1) / 2; mh = (mh + 1) / 2; levels++ }
        }
        val lw = IntArray(levels)
        val lh = IntArray(levels)
        lw[0] = w; lh[0] = h
        for (l in 1 until levels) { lw[l] = (lw[l - 1] + 1) / 2; lh[l] = (lh[l - 1] + 1) / 2 }
        val wp = Array(nf) { i ->
            val pyr = arrayOfNulls<FloatArray>(levels)
            pyr[0] = wt[i]
            for (l in 1 until levels) pyr[l] = down(pyr[l - 1]!!, lw[l - 1], lh[l - 1])
            pyr
        }
        progress?.invoke(40)

        // ---- trộn từng kênh màu theo kim tự tháp Laplace
        val result = IntArray(n)
        java.util.Arrays.fill(result, -0x1000000)
        for (c in 0 until 3) {
            val sh = 16 - 8 * c
            val res = Array(levels) { FloatArray(lw[it] * lh[it]) }
            for (i in 0 until nf) {
                val px = frames[i]
                val ch = FloatArray(n)
                par(h) { y -> for (x in 0 until w) ch[y * w + x] = ((px[y * w + x] shr sh) and 255) * (1f / 255f) }
                val gp = arrayOfNulls<FloatArray>(levels)
                gp[0] = ch
                for (l in 1 until levels) gp[l] = down(gp[l - 1]!!, lw[l - 1], lh[l - 1])
                for (l in 0 until levels) {
                    val g = gp[l]!!
                    val wl = wp[i][l]!!
                    val r = res[l]
                    if (l == levels - 1) {
                        for (k in r.indices) r[k] += wl[k] * g[k]
                    } else {
                        val u = up(gp[l + 1]!!, lw[l + 1], lh[l + 1], lw[l], lh[l])
                        for (k in r.indices) r[k] += wl[k] * (g[k] - u[k])
                    }
                }
                progress?.invoke(40 + (c * nf + i + 1) * 50 / (3 * nf))
            }
            var cur = res[levels - 1]
            for (l in levels - 2 downTo 0) {
                val u = up(cur, lw[l + 1], lh[l + 1], lw[l], lh[l])
                val r = res[l]
                for (k in r.indices) u[k] += r[k]
                cur = u
            }
            val outC = cur
            par(h) { y ->
                for (x in 0 until w) {
                    val k = y * w + x
                    val v = (outC[k].coerceIn(0f, 1f) * 255f + 0.5f).toInt()
                    result[k] = result[k] or (v shl sh)
                }
            }
        }

        // ---- hoàn thiện: đường cong S nhẹ (exposure fusion hay bị phẳng) + bão hoà nhẹ, rồi bộ lọc màu của người dùng
        par(h) { y ->
            for (x in 0 until w) {
                val k = y * w + x
                val p = result[k]
                var r = ((p shr 16) and 255) * (1f / 255f)
                var g = ((p shr 8) and 255) * (1f / 255f)
                var b = (p and 255) * (1f / 255f)
                val l = 0.299f * r + 0.587f * g + 0.114f * b
                val l2 = l + S_CURVE * (l * l * (3f - 2f * l) - l)
                val gain = if (l > 1e-4f) l2 / l else 1f
                r *= gain; g *= gain; b *= gain
                val l3 = 0.299f * r + 0.587f * g + 0.114f * b
                r = l3 + (r - l3) * SAT
                g = l3 + (g - l3) * SAT
                b = l3 + (b - l3) * SAT
                val ri = (r.coerceIn(0f, 1f) * 255f + 0.5f).toInt()
                val gi = (g.coerceIn(0f, 1f) * 255f + 0.5f).toInt()
                val bi = (b.coerceIn(0f, 1f) * 255f + 0.5f).toInt()
                result[k] = -0x1000000 or (ri shl 16) or (gi shl 8) or bi
            }
        }
        val cores = Runtime.getRuntime().availableProcessors().coerceIn(1, MultiFrame.coreCap)
        val chunk = (n + cores - 1) / cores
        par(cores) { t ->
            val from = t * chunk
            val to = min(n, from + chunk)
            if (from < to) proc(result, from, to)
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(result, 0, w, 0, 0, w, h)
        progress?.invoke(100)
        return bmp
    }

    /** Độ mạnh đường cong S (0 = giữ nguyên) và hệ số bão hoà sau ghép. */
    private const val S_CURVE = 0.30f
    private const val SAT = 1.08f
}
