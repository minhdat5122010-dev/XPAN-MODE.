package com.xpanmode.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import kotlin.math.min

/**
 * Thẻ chọn bộ lọc trong tay cầm X2D II: thanh màu + tên bộ lọc + phụ đề, viền cam, mũi tên ở bên phải.
 * Bấm thẻ (mũi tên) để xổ / thu danh sách bộ lọc ([X2dFilterPopup]); mũi tên quay 180° có animation.
 */
class X2dFilterCard(ctx: Context) : XView(ctx) {
    private var name = "Original"
    private var caption = ""
    private var accent: IntArray = intArrayOf(0xFFB9B9B9.toInt(), 0xFF6F6F6F.toInt())
    private var chev = 0f
    private var chevAnim: ValueAnimator? = null
    private var down = false

    /** Danh sách đang xổ: mũi tên quay lên. */
    var open = false
        set(v) {
            if (field == v) return
            field = v
            chevAnim?.cancel()
            chevAnim = ValueAnimator.ofFloat(chev, if (v) 1f else 0f).apply {
                duration = 220
                interpolator = DecelerateInterpolator(1.6f)
                addUpdateListener { chev = it.animatedValue as Float; invalidate() }
                start()
            }
        }

    var onToggle: (() -> Unit)? = null

    init {
        isClickable = true
        setOnClickListener { onToggle?.invoke() }
    }

    fun setItem(n: String, c: String, a: IntArray) {
        name = n; caption = c
        if (a.isNotEmpty()) accent = a
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val box = RectF(d(1.6f), d(1.6f), w - d(1.6f), h - d(1.6f))
        val r = d(13f)
        p.style = Paint.Style.FILL
        p.setShadowLayer(d(4f), 0f, d(2f), 0x88000000.toInt())
        p.color = X2dPalette.pick(0xFF232325.toInt(), 0xFF16211D.toInt())
        c.drawRoundRect(box, r, r, p)
        p.clearShadowLayer()
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(if (down) 2.2f else 1.6f)
        p.color = ORANGE
        c.drawRoundRect(box, r, r, p)
        // thanh màu đặc trưng của bộ lọc
        val bx = box.left + d(11f)
        val top = box.top + d(10f)
        val bot = box.bottom - d(10f)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, top, 0f, bot, accent[0], accent[accent.size - 1], Shader.TileMode.CLAMP)
        c.drawRoundRect(bx, top, bx + d(4f), bot, d(2f), d(2f), p)
        p.shader = null
        // tên + phụ đề (tự co cho vừa)
        val tx = bx + d(13f)
        val avail = box.right - d(36f) - tx
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.DEFAULT_BOLD
        p.color = Color.WHITE
        p.textSize = min(h * 0.30f, d(14f))
        var mw = p.measureText(name)
        if (mw > avail) p.textSize *= avail / mw
        c.drawText(name, tx, h * 0.46f, p)
        p.typeface = Typeface.DEFAULT
        p.color = ORANGE
        p.textSize = min(h * 0.24f, d(11.5f))
        mw = p.measureText(caption)
        if (mw > avail) p.textSize *= avail / mw
        c.drawText(caption, tx, h * 0.76f, p)
        // mũi tên (quay 180° khi danh sách đang xổ)
        val cx = box.right - d(20f)
        val cy = h / 2f
        c.save()
        c.rotate(chev * 180f, cx, cy)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = d(2.2f)
        p.color = Color.WHITE
        val path = Path()
        path.moveTo(cx - d(6f), cy - d(3f))
        path.lineTo(cx, cy + d(3.5f))
        path.lineTo(cx + d(6f), cy - d(3f))
        c.drawPath(path, p)
        c.restore()
        p.style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true; invalidate()
                animate().cancel()
                animate().scaleX(0.96f).scaleY(0.94f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                down = false; invalidate()
                animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()
            }
        }
        return super.onTouchEvent(e)
    }
}

private fun cardBg(dn: Float, radiusDp: Float): GradientDrawable = GradientDrawable().apply {
    cornerRadius = radiusDp * dn
    setColor(X2dPalette.pick(0xF01E1E20.toInt(), 0xF0121B18.toInt()))
    setStroke((1.2f * dn).toInt(), 0x44FFFFFF)
}

/**
 * Danh sách bộ lọc xổ xuống ngay dưới [X2dFilterCard]: dùng lại [PalettePanel] ở chế độ chỉ có danh sách.
 * Xổ ra (trượt xuống + phóng từ mép trên + hiện dần) và thu lại có animation; chọn bộ lọc xong danh sách vẫn mở
 * để thử tiếp, đóng bằng cách bấm lại mũi tên ở thẻ.
 */
class X2dFilterPopup(ctx: Context) : FrameLayout(ctx) {
    val panel = PalettePanel(ctx)
    private val dn = resources.displayMetrics.density
    var shown = false
        private set

    init {
        panel.setParts(showList = true, showPad = false)
        addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        visibility = GONE
        isClickable = true
        clipChildren = true
        refreshStyle()
        outlineProvider = ViewOutlineProvider.BACKGROUND
        clipToOutline = true
    }

    fun refreshStyle() {
        background = cardBg(dn, 14f)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        pivotX = w / 2f
        pivotY = 0f
    }

    fun show() {
        if (shown) return
        shown = true
        animate().cancel()
        visibility = VISIBLE
        alpha = 0f
        scaleX = 0.96f
        scaleY = 0.84f
        translationY = -8f * dn
        animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f).setDuration(200)
            .setInterpolator(DecelerateInterpolator(1.8f)).start()
        panel.scrollToSelected()
    }

    fun hide(animated: Boolean = true) {
        if (!shown && visibility != VISIBLE) return
        shown = false
        animate().cancel()
        if (animated) {
            animate().alpha(0f).scaleX(0.97f).scaleY(0.88f).translationY(-6f * dn).setDuration(150)
                .setInterpolator(DecelerateInterpolator(1.4f))
                .withEndAction { if (!shown) { visibility = GONE; alpha = 1f; scaleX = 1f; scaleY = 1f; translationY = 0f } }
                .start()
        } else {
            visibility = GONE; alpha = 1f; scaleX = 1f; scaleY = 1f; translationY = 0f
        }
    }
}

/**
 * Thẻ bảng màu (chạm Tone × Color + thanh Palette) nổi ở góc dưới phải màn ngắm khi mở chế độ bộ lọc;
 * dùng lại [PalettePanel] ở chế độ chỉ có bảng chạm + thanh cường độ. Hiện / ẩn có animation (phóng từ góc dưới phải).
 */
class X2dPaletteCard(ctx: Context) : FrameLayout(ctx) {
    val panel = PalettePanel(ctx)
    private val dn = resources.displayMetrics.density
    private var shownNow = false

    init {
        panel.setParts(showList = false, showPad = true, showRow = false)
        val pd = (8f * dn).toInt()
        setPadding(pd, pd, pd, (2f * dn).toInt())
        addView(panel, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        visibility = GONE
        isClickable = true
        refreshStyle()
        outlineProvider = ViewOutlineProvider.BACKGROUND
        clipToOutline = true
    }

    fun refreshStyle() {
        background = cardBg(dn, 16f)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        pivotX = w.toFloat()
        pivotY = h.toFloat()
        // chiều cao bảng chạm = phần còn lại sau khi trừ lề + thanh Palette (30dp) + khoảng đệm trên (6dp)
        panel.setPadHeight((h - (8f + 2f + 30f + 6f) * dn).toInt().coerceAtLeast((40f * dn).toInt()))
    }

    fun show() {
        if (shownNow) return
        shownNow = true
        animate().cancel()
        visibility = VISIBLE
        alpha = 0f
        scaleX = 0.86f
        scaleY = 0.86f
        animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(230).setInterpolator(DecelerateInterpolator(1.8f)).start()
    }

    fun hide(animated: Boolean = true) {
        if (!shownNow && visibility != VISIBLE) return
        shownNow = false
        animate().cancel()
        if (animated) {
            animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(150).setInterpolator(DecelerateInterpolator(1.4f))
                .withEndAction { if (!shownNow) { visibility = GONE; alpha = 1f; scaleX = 1f; scaleY = 1f } }.start()
        } else {
            visibility = GONE; alpha = 1f; scaleX = 1f; scaleY = 1f
        }
    }
}
