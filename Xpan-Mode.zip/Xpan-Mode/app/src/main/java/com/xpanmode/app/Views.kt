package com.xpanmode.app

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Matrix
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.view.TextureView
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.roundToInt

const val ORANGE = 0xFFF47B20.toInt()

abstract class XView(ctx: Context) : View(ctx) {
    var classic: Boolean = true
        set(v) { field = v; invalidate() }
    protected val p = Paint(Paint.ANTI_ALIAS_FLAG)
    protected fun d(v: Float): Float = v * resources.displayMetrics.density
}

/** Vẽ các vạch khía (knurling) tròn kiểu núm kim loại. */
fun drawKnurl(c: Canvas, p: Paint, cx: Float, cy: Float, r0: Float, r1: Float, count: Int, color: Int, width: Float) {
    p.style = Paint.Style.STROKE
    p.strokeWidth = width
    p.color = color
    p.shader = null
    for (i in 0 until count) {
        val a = (2.0 * Math.PI * i / count)
        val ca = cos(a).toFloat()
        val sa = sin(a).toFloat()
        c.drawLine(cx + r0 * ca, cy + r0 * sa, cx + r1 * ca, cy + r1 * sa, p)
    }
}

/** Thân máy cơ: da giả, tấm kim loại phay xước, vít, viền chrome quanh khung ngắm, chữ khắc, logo. */
class DecorView(ctx: Context) : XView(ctx) {
    val vf = RectF()
    var safeL = 0f
    private val logoFace = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
    private val leather: BitmapShader by lazy {
        val n = 96
        val bmp = Bitmap.createBitmap(n, n, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        cv.drawColor(0xFF1A1A1C.toInt())
        val rnd = java.util.Random(11)
        val q = Paint(Paint.ANTI_ALIAS_FLAG)
        repeat(520) {
            val x = 2f + rnd.nextFloat() * (n - 4f)
            val y = 2f + rnd.nextFloat() * (n - 4f)
            val r = 0.8f + rnd.nextFloat() * 1.3f
            q.color = if (rnd.nextBoolean()) 0x66000000 else 0x1EFFFFFF
            cv.drawCircle(x, y, r, q)
        }
        val sh = BitmapShader(bmp, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
        val m = Matrix()
        m.setScale(resources.displayMetrics.density * 0.7f, resources.displayMetrics.density * 0.7f)
        sh.setLocalMatrix(m)
        sh
    }

    private fun screw(c: Canvas, x: Float, y: Float, r: Float) {
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(x - r * 0.3f, y - r * 0.3f, r * 1.3f, 0xFFD6D6DA.toInt(), 0xFF4A4A4F.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(x, y, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.28f
        p.color = 0xFF16161A.toInt()
        c.save()
        c.rotate(35f, x, y)
        c.drawLine(x - r * 0.7f, y, x + r * 0.7f, y, p)
        c.restore()
        p.strokeWidth = d(0.8f)
        p.color = 0x66000000
        c.drawCircle(x, y, r, p)
    }

    private fun plate(c: Canvas, poly: Path, edge: Path, y0: Float, y1: Float, lightFirst: Boolean) {
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, y0, 0f, y1,
            if (lightFirst) 0xFF4A4A4F.toInt() else 0xFF2A2A2E.toInt(),
            if (lightFirst) 0xFF2A2A2E.toInt() else 0xFF4A4A4F.toInt(),
            Shader.TileMode.CLAMP
        )
        c.drawPath(poly, p)
        p.shader = null
        // vân phay xước
        c.save()
        c.clipPath(poly)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(0.6f)
        p.color = 0x0EFFFFFF
        var y = minOf(y0, y1)
        val yEnd = maxOf(y0, y1)
        while (y < yEnd) { c.drawLine(0f, y, width.toFloat(), y, p); y += d(2.6f) }
        c.restore()
        // mép chrome + bóng đổ
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.4f)
        p.color = 0xFF85858C.toInt()
        c.drawPath(edge, p)
        c.save()
        c.translate(0f, if (lightFirst) d(1.6f) else -d(1.6f))
        p.color = 0xFF050506.toInt()
        c.drawPath(edge, p)
        c.restore()
    }

    override fun onDraw(c: Canvas) {
        if (!classic) return
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = vf.centerX()

        // da giả
        p.style = Paint.Style.FILL
        p.shader = leather
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null

        val half = w * 0.16f
        val k = w * 0.03f
        // ---- tấm kim loại phía trên
        val tb = minOf(h * 0.125f, vf.top - d(20f)).coerceAtLeast(h * 0.06f)
        val tn = minOf(tb + h * 0.025f, vf.top - d(14f)).coerceAtLeast(tb)
        val top = Path()
        top.moveTo(0f, 0f); top.lineTo(w, 0f); top.lineTo(w, tb); top.lineTo(cx + half + k, tb)
        top.lineTo(cx + half, tn); top.lineTo(cx - half, tn); top.lineTo(cx - half - k, tb); top.lineTo(0f, tb); top.close()
        val topEdge = Path()
        topEdge.moveTo(0f, tb); topEdge.lineTo(cx - half - k, tb); topEdge.lineTo(cx - half, tn)
        topEdge.lineTo(cx + half, tn); topEdge.lineTo(cx + half + k, tb); topEdge.lineTo(w, tb)
        plate(c, top, topEdge, 0f, tn, true)

        // ---- tấm kim loại phía dưới
        val bt = maxOf(h * 0.875f, vf.bottom + d(20f)).coerceAtMost(h * 0.97f)
        val bn = (bt - h * 0.025f).coerceAtLeast(vf.bottom + d(14f)).coerceAtMost(bt)
        val bot = Path()
        bot.moveTo(0f, h); bot.lineTo(w, h); bot.lineTo(w, bt); bot.lineTo(cx + half + k, bt)
        bot.lineTo(cx + half, bn); bot.lineTo(cx - half, bn); bot.lineTo(cx - half - k, bt); bot.lineTo(0f, bt); bot.close()
        val botEdge = Path()
        botEdge.moveTo(0f, bt); botEdge.lineTo(cx - half - k, bt); botEdge.lineTo(cx - half, bn)
        botEdge.lineTo(cx + half, bn); botEdge.lineTo(cx + half + k, bt); botEdge.lineTo(w, bt)
        plate(c, bot, botEdge, h, bn, false)

        // ---- viền chrome quanh khung ngắm
        val o = d(10f)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, vf.top - o, 0f, vf.bottom + o,
            intArrayOf(0xFF9A9AA0.toInt(), 0xFF45454A.toInt(), 0xFF2A2A2E.toInt(), 0xFF70707A.toInt()),
            floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(vf.left - o, vf.top - o, vf.right + o, vf.bottom + o, d(11f), d(11f), p)
        p.shader = null
        p.color = 0xFF050506.toInt()
        c.drawRoundRect(vf.left - d(4f), vf.top - d(4f), vf.right + d(4f), vf.bottom + d(4f), d(7f), d(7f), p)

        // ---- logo khắc trên tấm trên
        val ly = tb / 2f
        val txt = "HASSELBLAD"
        p.typeface = logoFace
        p.textSize = minOf(h * 0.052f, tb * 0.46f)
        p.letterSpacing = 0.28f
        p.textAlign = Paint.Align.CENTER
        val tw = p.measureText(txt)
        val ph = p.textSize * 0.9f
        p.style = Paint.Style.FILL
        p.color = 0xFF121214.toInt()
        c.drawRoundRect(cx - tw / 2 - d(12f), ly - ph, cx + tw / 2 + d(12f), ly + ph, d(4f), d(4f), p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1f)
        p.color = 0xFF5A5A60.toInt()
        c.drawRoundRect(cx - tw / 2 - d(12f), ly - ph, cx + tw / 2 + d(12f), ly + ph, d(4f), d(4f), p)
        p.style = Paint.Style.FILL
        p.color = 0xFFD6D6DA.toInt()
        c.drawText(txt, cx, ly + p.textSize * 0.33f, p)

        // ---- chữ khắc trên tấm dưới
        val by = (bn + h) / 2f
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        p.textSize = minOf(h * 0.034f, (h - bn) * 0.3f)
        p.letterSpacing = 0.32f
        val eng = "XPAN  ·  65:24"
        p.color = 0xFF060607.toInt()
        c.drawText(eng, cx + d(1f), by + p.textSize * 0.35f + d(1f), p)
        p.color = 0xFFA9A9AF.toInt()
        c.drawText(eng, cx, by + p.textSize * 0.35f, p)
        p.typeface = Typeface.DEFAULT
        p.letterSpacing = 0f
        p.textAlign = Paint.Align.LEFT

        // ---- vít
        val sr = d(5f)
        screw(c, w - w * 0.03f, tb / 2f, sr)
        screw(c, w * 0.03f, by, sr)
        screw(c, w - w * 0.03f, by, sr)
    }
}

/** Các vạch góc / cạnh của khung ngắm + viền mờ (giao diện tối giản) hoặc tối dần phía dưới (Hasselblad). */
class FrameOverlayView(ctx: Context) : XView(ctx) {
    private val path = Path()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        if (classic) {
            p.shader = LinearGradient(0f, h * 0.72f, 0f, h, 0x00000000, 0xB0000000.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, h * 0.72f, w, h, p)
            p.shader = null
        } else {
            val e = 0xFF000000.toInt()
            val z = 0x00000000
            val fx = w * 0.022f
            val fy = h * 0.07f
            p.shader = LinearGradient(0f, 0f, fx, 0f, e, z, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, fx, h, p)
            p.shader = LinearGradient(w, 0f, w - fx, 0f, e, z, Shader.TileMode.CLAMP); c.drawRect(w - fx, 0f, w, h, p)
            p.shader = LinearGradient(0f, 0f, 0f, fy, e, z, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, w, fy, p)
            p.shader = LinearGradient(0f, h, 0f, h - fy, e, z, Shader.TileMode.CLAMP); c.drawRect(0f, h - fy, w, h, p)
            p.shader = null
        }
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = d(if (classic) 1.6f else 2.4f)
        p.color = if (classic) 0xE6FFFFFF.toInt() else 0xFFD8D8D8.toInt()
        val ins = if (classic) d(10f) else d(12f)
        val len = w * 0.045f
        val r = if (classic) d(4f) else d(10f)
        path.reset()
        path.moveTo(ins, ins + len); path.lineTo(ins, ins + r)
        path.quadTo(ins, ins, ins + r, ins); path.lineTo(ins + len, ins)
        for (sx in floatArrayOf(1f, -1f)) for (sy in floatArrayOf(1f, -1f)) {
            c.save(); c.scale(sx, sy, w / 2f, h / 2f); c.drawPath(path, p); c.restore()
        }
        val top = if (classic) arrayOf(0.17f to 0.28f, 0.44f to 0.64f) else arrayOf(0.10f to 0.13f, 0.45f to 0.65f)
        val bot = if (classic) arrayOf(0.085f to 0.13f, 0.29f to 0.40f, 0.69f to 0.76f)
        else arrayOf(0.14f to 0.17f, 0.30f to 0.32f, 0.82f to 0.90f)
        for ((a, b) in top) c.drawLine(w * a, ins, w * b, ins, p)
        for ((a, b) in bot) c.drawLine(w * a, h - ins, w * b, h - ins, p)
        val side = arrayOf(0.22f to 0.32f, 0.62f to 0.74f)
        for ((a, b) in side) {
            c.drawLine(ins, h * a, ins, h * b, p)
            c.drawLine(w - ins, h * a, w - ins, h * b, p)
        }
    }
}

/** Khung lấy nét: hiện khi chạm, đổi màu khi bắt nét xong (xanh = nét, đỏ = không nét) rồi tự ẩn. */
class FocusBoxView(ctx: Context) : XView(ctx) {
    private var fx = 0f
    private var fy = 0f
    private var scale = 1f
    private var shown = false
    private var color = Color.WHITE
    private var anim: ValueAnimator? = null
    private val autoHide = Runnable { fadeOut() }

    init { visibility = GONE }

    fun showAt(x: Float, y: Float) {
        removeCallbacks(autoHide)
        animate().cancel()
        fx = x; fy = y
        color = Color.WHITE
        shown = true
        alpha = 1f
        visibility = VISIBLE
        anim?.cancel()
        anim = ValueAnimator.ofFloat(1.3f, 1f).apply {
            duration = 220
            addUpdateListener { scale = it.animatedValue as Float; invalidate() }
            start()
        }
        postDelayed(autoHide, 3500)
    }

    fun lock(ok: Boolean) {
        if (!shown) return
        removeCallbacks(autoHide)
        color = if (ok) 0xFF7CFF8A.toInt() else 0xFFFF6A5A.toInt()
        invalidate()
        postDelayed(autoHide, 450)
    }

    private fun fadeOut() {
        animate().alpha(0f).setDuration(220).withEndAction {
            shown = false
            visibility = GONE
            alpha = 1f
        }.start()
    }

    override fun onDraw(c: Canvas) {
        if (!shown) return
        val half = min(width, height) * 0.17f * scale
        val len = half * 0.45f
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.6f)
        p.color = color
        val l = fx - half; val r = fx + half; val t = fy - half; val b = fy + half
        c.drawLine(l, t, l + len, t, p); c.drawLine(l, t, l, t + len, p)
        c.drawLine(r, t, r - len, t, p); c.drawLine(r, t, r, t + len, p)
        c.drawLine(l, b, l + len, b, p); c.drawLine(l, b, l, b - len, p)
        c.drawLine(r, b, r - len, b, p); c.drawLine(r, b, r, b - len, p)
    }
}

/** Thanh bù sáng bên trái: vuốt dọc để đổi EV. */
class EvView(ctx: Context) : XView(ctx) {
    var min = 0
        set(v) { field = v; invalidate() }
    var max = 0
        set(v) { field = v; invalidate() }
    var step = 0f
    var value = 0
        set(v) { field = v; invalidate() }
    var onChange: ((Int) -> Unit)? = null
    private var downY = 0f
    private var downVal = 0

    override fun onDraw(c: Canvas) {
        if (max <= min) return
        val h = height.toFloat()
        val pad = d(8f)
        val n = (max - min).toFloat()
        val perEv = if (step > 0f) (1f / step).roundToInt().coerceAtLeast(1) else 1
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.4f)
        p.color = Color.WHITE
        for (i in min..max) {
            val y = pad + (max - i) / n * (h - 2 * pad)
            val len = if (i % perEv == 0) d(14f) else d(5f)
            c.drawLine(d(4f), y, d(4f) + len, y, p)
        }
        val y = pad + (max - value) / n * (h - 2 * pad)
        p.style = Paint.Style.FILL
        val tri = Path()
        tri.moveTo(d(22f), y); tri.lineTo(d(32f), y - d(6f)); tri.lineTo(d(32f), y + d(6f)); tri.close()
        c.drawPath(tri, p)
        val ev = value * step
        val label = if (value == 0) "0.0" else String.format(Locale.US, "%+.1f", ev)
        p.textSize = d(14f)
        p.textAlign = Paint.Align.LEFT
        c.drawText(label, d(38f), y + d(5f), p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downY = e.y; downVal = value
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                if (max > min) {
                    val per = (height - 2 * d(8f)) / (max - min)
                    val nv = (downVal - ((e.y - downY) / per).roundToInt()).coerceIn(min, max)
                    if (nv != value) { value = nv; onChange?.invoke(nv) }
                }
            }
        }
        return true
    }
}

/** Thang zoom bên phải (giao diện Hasselblad): 0,6 · 1 · 2 · 3× */
class ZoomLadderView(ctx: Context) : XView(ctx) {
    var labels: List<String> = emptyList()
        set(v) { field = v; invalidate(); requestLayout() }
    var selected = 0
        set(v) { field = v; invalidate() }
    var onSelect: ((Int) -> Unit)? = null

    override fun onDraw(c: Canvas) {
        val n = labels.size
        if (n == 0) return
        val cellH = height.toFloat() / n
        val cx = width / 2f
        p.textAlign = Paint.Align.CENTER
        for (k in 0 until n) {
            val idx = n - 1 - k
            val cy = (k + 0.5f) * cellH
            val sel = idx == selected
            if (sel) {
                p.style = Paint.Style.FILL
                p.color = 0x66000000
                c.drawCircle(cx, cy, d(20f), p)
            }
            p.style = Paint.Style.FILL
            p.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            p.textSize = d(if (sel) 16f else 15f)
            p.color = if (sel) ORANGE else Color.WHITE
            val txt = if (sel) labels[idx] + "×" else labels[idx]
            c.drawText(txt, cx, cy + d(5.5f), p)
        }
        p.typeface = Typeface.DEFAULT
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP && labels.isNotEmpty()) {
            val n = labels.size
            val k = (e.y / height * n).toInt().coerceIn(0, n - 1)
            onSelect?.invoke(n - 1 - k)
            performClick()
        }
        return true
    }
}

/** Các nút tiêu cự ở giữa dưới (giao diện tối giản): 14 · 23mm · 65 · 135 */
class LensPillsView(ctx: Context) : XView(ctx) {
    var labels: List<String> = emptyList()
        set(v) { field = v; invalidate(); requestLayout() }
    var selected = 0
        set(v) { field = v; invalidate() }
    var onSelect: ((Int) -> Unit)? = null

    fun pillSize() = d(38f)
    fun gap() = d(10f)

    override fun onDraw(c: Canvas) {
        val n = labels.size
        if (n == 0) return
        val s = pillSize()
        val r = s / 2f
        val cy = height / 2f
        p.textAlign = Paint.Align.CENTER
        for (i in 0 until n) {
            val cx = r + i * (s + gap())
            p.style = Paint.Style.FILL
            p.color = 0xCC0B0B0B.toInt()
            c.drawCircle(cx, cy, r, p)
            val sel = i == selected
            p.color = if (sel) ORANGE else Color.WHITE
            p.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            if (sel) {
                p.textSize = d(12f)
                c.drawText(labels[i], cx, cy - d(1f), p)
                p.textSize = d(9f)
                c.drawText("mm", cx, cy + d(10f), p)
            } else {
                p.textSize = d(12f)
                c.drawText(labels[i], cx, cy + d(4.5f), p)
            }
        }
        p.typeface = Typeface.DEFAULT
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_UP && labels.isNotEmpty()) {
            val i = (e.x / (pillSize() + gap())).toInt().coerceIn(0, labels.size - 1)
            onSelect?.invoke(i)
            performClick()
        }
        return true
    }
}

class ShutterButton(ctx: Context) : XView(ctx) {
    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.96f
        p.style = Paint.Style.FILL
        if (classic) {
            // vòng kim loại khía + đế tối + nút bấm lõm
            p.color = 0x88000000.toInt()
            c.drawCircle(cx, cy + d(2f), r, p)
            p.shader = SweepGradient(
                cx, cy,
                intArrayOf(0xFFC9C9CE.toInt(), 0xFF5B5B60.toInt(), 0xFFE2E2E6.toInt(), 0xFF4B4B50.toInt(), 0xFFC9C9CE.toInt()), null
            )
            c.drawCircle(cx, cy, r, p)
            p.shader = null
            drawKnurl(c, p, cx, cy, r * 0.86f, r * 0.97f, 72, 0x66000000, d(1.2f))
            p.style = Paint.Style.FILL
            p.color = 0xFF1A1A1D.toInt()
            c.drawCircle(cx, cy, r * 0.80f, p)
            p.shader = RadialGradient(cx - r * 0.2f, cy - r * 0.3f, r, 0xFFFFFFFF.toInt(), 0xFFB9B9BD.toInt(), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r * 0.72f, p)
            p.shader = null
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(1.2f)
            p.color = 0x55FFFFFF
            c.drawCircle(cx, cy, r * 0.58f, p)
        } else {
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(4f)
            p.color = Color.WHITE
            c.drawCircle(cx, cy, r - d(2f), p)
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(0f, cy - r, 0f, cy + r, 0xFFF68A2E.toInt(), 0xFFE96A12.toInt(), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r - d(7f), p)
            p.shader = null
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().scaleX(0.92f).scaleY(0.92f).setDuration(70).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animate().scaleX(1f).scaleY(1f).setDuration(110).start()
        }
        return super.onTouchEvent(e)
    }
}

/** Nút bộ lọc: huy hiệu "Original" (Hasselblad) hoặc biểu tượng cuộn phim (tối giản). */
class FilterButtonView(ctx: Context) : XView(ctx) {
    var label: String = "Original"
        set(v) { field = v; invalidate() }

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (classic) {
            p.style = Paint.Style.FILL
            p.color = 0xFF0E0E10.toInt()
            c.drawRoundRect(0f, 0f, w, h, d(14f), d(14f), p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(1f)
            p.color = 0xFF3A3A3D.toInt()
            c.drawRoundRect(0f, 0f, w, h, d(14f), d(14f), p)
            p.strokeWidth = d(2f)
            p.shader = LinearGradient(
                w * 0.1f, 0f, w * 0.9f, 0f,
                intArrayOf(0x00F47B20, ORANGE, 0xFFFFC040.toInt(), ORANGE, 0x00F47B20),
                null, Shader.TileMode.CLAMP
            )
            c.drawLine(w * 0.1f, h * 0.2f, w * 0.9f, h * 0.2f, p)
            c.drawLine(w * 0.1f, h * 0.8f, w * 0.9f, h * 0.8f, p)
            p.shader = null
            p.style = Paint.Style.FILL
            p.color = Color.WHITE
            p.typeface = Typeface.DEFAULT_BOLD
            p.textAlign = Paint.Align.CENTER
            p.textSize = h * 0.23f
            val fm = p.fontMetrics
            c.drawText(label, w / 2f, h / 2f - (fm.ascent + fm.descent) / 2f, p)
            p.typeface = Typeface.DEFAULT
        } else {
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(1.8f)
            p.color = Color.WHITE
            c.drawRoundRect(w * 0.1f, h * 0.27f, w * 0.9f, h * 0.73f, d(3f), d(3f), p)
            p.style = Paint.Style.FILL
            val hole = w * 0.06f
            for (i in 0 until 5) {
                val x = w * (0.2f + i * 0.15f)
                c.drawRect(x, h * 0.31f, x + hole, h * 0.31f + hole, p)
                c.drawRect(x, h * 0.69f - hole, x + hole, h * 0.69f, p)
            }
        }
    }
}

/** Nút chuyển giao diện (⇄) và nút cài đặt: núm kim loại khía (Hasselblad) hoặc biểu tượng phẳng (tối giản). */
class IconButtonView(ctx: Context, private val kind: Int) : XView(ctx) {
    companion object {
        const val GEAR = 0
        const val TOGGLE = 1
    }

    init { isClickable = true }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().scaleX(0.93f).scaleY(0.93f).setDuration(60).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animate().scaleX(1f).scaleY(1f).setDuration(100).start()
        }
        return super.onTouchEvent(e)
    }

    private fun symbol(c: Canvas, cx: Float, cy: Float, r: Float) {
        if (kind == GEAR) {
            // biểu tượng lá khẩu độ
            p.strokeWidth = r * 0.07f
            c.drawCircle(cx, cy, r * 0.42f, p)
            for (i in 0 until 6) {
                val a1 = Math.toRadians(i * 60.0)
                val a2 = Math.toRadians(i * 60.0 + 62.0)
                c.drawLine(
                    cx + r * 0.42f * cos(a1).toFloat(), cy + r * 0.42f * sin(a1).toFloat(),
                    cx + r * 0.16f * cos(a2).toFloat(), cy + r * 0.16f * sin(a2).toFloat(), p
                )
            }
        } else {
            p.strokeWidth = r * 0.085f
            val y1 = cy - r * 0.17f
            val y2 = cy + r * 0.17f
            val x0 = cx - r * 0.4f
            val x1 = cx + r * 0.4f
            val a = r * 0.14f
            c.drawLine(x0, y1, x1, y1, p)
            c.drawLine(x1, y1, x1 - a, y1 - a, p)
            c.drawLine(x1, y1, x1 - a, y1 + a, p)
            c.drawLine(x1, y2, x0, y2, p)
            c.drawLine(x0, y2, x0 + a, y2 - a, p)
            c.drawLine(x0, y2, x0 + a, y2 + a, p)
        }
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f
        p.strokeCap = Paint.Cap.ROUND
        if (classic) {
            p.style = Paint.Style.FILL
            p.color = 0x88000000.toInt()
            c.drawCircle(cx, cy + d(1.5f), r * 0.97f, p)
            p.shader = SweepGradient(
                cx, cy,
                intArrayOf(0xFFCFCFD4.toInt(), 0xFF56565B.toInt(), 0xFFE6E6EA.toInt(), 0xFF46464B.toInt(), 0xFFCFCFD4.toInt()), null
            )
            c.drawCircle(cx, cy, r * 0.97f, p)
            p.shader = null
            drawKnurl(c, p, cx, cy, r * 0.80f, r * 0.95f, 40, 0x77000000, d(1.2f))
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(0f, cy - r, 0f, cy + r, 0xFF34343A.toInt(), 0xFF141417.toInt(), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r * 0.70f, p)
            p.shader = null
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(1f)
            p.color = 0x55FFFFFF
            c.drawCircle(cx, cy, r * 0.70f, p)
            // biểu tượng khắc (bóng tối + nét sáng)
            p.style = Paint.Style.STROKE
            p.color = 0xFF050506.toInt()
            symbol(c, cx + d(0.8f), cy + d(0.8f), r)
            p.color = 0xFFE4E4E8.toInt()
            symbol(c, cx, cy, r)
        } else {
            p.style = Paint.Style.FILL
            p.color = 0x33FFFFFF
            c.drawCircle(cx, cy, r * 0.95f, p)
            p.style = Paint.Style.STROKE
            p.color = Color.WHITE
            symbol(c, cx, cy, r)
        }
    }
}

/** Hiệu ứng màn trập: đảo âm bản → xám phẳng → mờ dần về ảnh. */
class ShutterFxView(ctx: Context) : View(ctx) {
    private var greyAlpha = 0f

    override fun onDraw(c: Canvas) {
        if (greyAlpha > 0f) c.drawColor(Color.argb((greyAlpha * 255).toInt(), 124, 124, 126))
    }

    fun play(setInvert: (Boolean) -> Unit, onReveal: () -> Unit) {
        greyAlpha = 0f
        invalidate()
        setInvert(true)
        postDelayed({
            setInvert(false)
            greyAlpha = 0.94f
            invalidate()
        }, 140)
        postDelayed({
            onReveal()
            ValueAnimator.ofFloat(0.94f, 0f).apply {
                duration = 320
                addUpdateListener { greyAlpha = it.animatedValue as Float; invalidate() }
                start()
            }
        }, 520)
    }
}


class LensFxNode(val title: String, val sub: String, val ratio: String, val eq: Float)

/**
 * Hiệu ứng chuyển ống kính: làm mờ khung ngắm, thanh nối Ultra Wide → Wide → Telephoto với vòng cam
 * chạy từ ống kính cũ sang mới, hình nón góc nhìn (FOV) co/giãn theo tiêu cự, và tên ống kính đổi chéo.
 */
class LensSwitchView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dn = resources.displayMetrics.density
    private var nodes: List<LensFxNode> = emptyList()
    private var from = 0
    private var to = 0
    private var sharp: Bitmap? = null
    private var blur: Bitmap? = null
    private var bgFilter: ColorFilter? = null
    private var blurA = 0f
    private var prog = 0f
    private var anim: ValueAnimator? = null
    private var blurAnim: ValueAnimator? = null
    private val argb = ArgbEvaluator()
    private val cone = Path()

    private fun d(v: Float) = v * dn

    fun start(n: List<LensFxNode>, fromIdx: Int, toIdx: Int, frame: Bitmap?, filter: ColorFilter?) {
        animate().cancel()
        anim?.cancel()
        blurAnim?.cancel()
        nodes = n
        from = fromIdx.coerceIn(0, (n.size - 1).coerceAtLeast(0))
        to = toIdx.coerceIn(0, (n.size - 1).coerceAtLeast(0))
        sharp = frame
        blur = frame?.let { makeBlur(it) }
        bgFilter = filter
        blurA = 0f
        prog = 0f
        alpha = 1f
        visibility = VISIBLE
        blurAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 280
            addUpdateListener { blurA = it.animatedValue as Float; invalidate() }
            start()
        }
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 800
            startDelay = 140
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { prog = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun hide() {
        animate().alpha(0f).setDuration(320).withEndAction {
            visibility = GONE
            sharp = null
            blur = null
            alpha = 1f
        }.start()
    }

    private fun makeBlur(src: Bitmap): Bitmap {
        val sw = max(16, src.width / 16)
        val sh = max(8, src.height / 16)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        repeat(3) { boxBlur(px, sw, sh, 2) }
        val out = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, sw, 0, 0, sw, sh)
        return out
    }

    private fun boxBlur(px: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(px.size)
        for (y in 0 until h) for (x in 0 until w) {
            var rr = 0; var g = 0; var b = 0; var cnt = 0
            for (k in -r..r) {
                val c = px[y * w + (x + k).coerceIn(0, w - 1)]
                rr += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255; cnt++
            }
            tmp[y * w + x] = (0xFF shl 24) or ((rr / cnt) shl 16) or ((g / cnt) shl 8) or (b / cnt)
        }
        for (y in 0 until h) for (x in 0 until w) {
            var rr = 0; var g = 0; var b = 0; var cnt = 0
            for (k in -r..r) {
                val c = tmp[(y + k).coerceIn(0, h - 1) * w + x]
                rr += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255; cnt++
            }
            px[y * w + x] = (0xFF shl 24) or ((rr / cnt) shl 16) or ((g / cnt) shl 8) or (b / cnt)
        }
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
    private fun mix(a: Int, b: Int, t: Float) = argb.evaluate(t.coerceIn(0f, 1f), a, b) as Int

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rect = RectF(0f, 0f, w, h)
        p.style = Paint.Style.FILL
        p.colorFilter = bgFilter
        sharp?.let { p.alpha = ((1f - blurA) * 255).toInt(); c.drawBitmap(it, null, rect, p) }
        blur?.let { p.alpha = (blurA * 255).toInt(); c.drawBitmap(it, null, rect, p) }
        p.colorFilter = null
        p.alpha = 255
        p.color = Color.argb((blurA * 120).toInt(), 0, 0, 0)
        c.drawRect(rect, p)
        if (nodes.isEmpty()) return

        val n = nodes.size
        val ep = prog
        val cx = w / 2f
        val trackY = h * 0.60f
        val gap = min(w * 0.2f, d(120f))
        fun nx(i: Int) = cx + (i - (n - 1) / 2f) * gap
        val pos = lerp(nx(from), nx(to), ep)
        val ui = blurA

        // đường thanh
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = d(2f)
        p.color = Color.argb((90 * ui).toInt(), 255, 255, 255)
        c.drawLine(nx(0), trackY, nx(n - 1), trackY, p)
        p.color = Color.argb((255 * ui).toInt(), 244, 123, 32)
        c.drawLine(nx(from), trackY, pos, trackY, p)

        // các nút ống kính
        p.textAlign = Paint.Align.CENTER
        for (i in 0 until n) {
            val act = (1f - abs(pos - nx(i)) / gap).coerceIn(0f, 1f)
            val r = d(9f) + d(5f) * act
            p.style = Paint.Style.FILL
            p.color = Color.argb((200 * ui).toInt(), 16, 16, 16)
            c.drawCircle(nx(i), trackY, r, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(2f)
            p.color = (mix(0xFFFFFFFF.toInt(), ORANGE, act) and 0x00FFFFFF) or ((255 * ui).toInt() shl 24)
            c.drawCircle(nx(i), trackY, r, p)
            p.style = Paint.Style.FILL
            p.typeface = Typeface.DEFAULT_BOLD
            p.textSize = h * 0.042f + h * 0.01f * act
            p.color = (mix(0xFFFFFFFF.toInt(), ORANGE, act) and 0x00FFFFFF) or ((255 * ui).toInt() shl 24)
            c.drawText(nodes[i].ratio + "×", nx(i), trackY + r + h * 0.065f, p)
        }

        // vòng cam di chuyển + quầng sáng
        p.style = Paint.Style.FILL
        for (k in 3 downTo 1) {
            p.color = Color.argb((38 * ui).toInt(), 244, 123, 32)
            c.drawCircle(pos, trackY, d(12f) + d(8f) * k, p)
        }
        p.color = Color.argb((255 * ui).toInt(), 244, 123, 32)
        c.drawCircle(pos, trackY, d(7f), p)

        // hình nón góc nhìn (FOV) co giãn theo tiêu cự
        val aFrom = atan(18f / nodes[from].eq.coerceAtLeast(1f))
        val aTo = atan(18f / nodes[to].eq.coerceAtLeast(1f))
        val a = lerp(aFrom, aTo, ep)
        val deg = Math.toDegrees(a.toDouble()).toFloat()
        val apexY = h * 0.47f
        val len = h * 0.22f
        val lx = cx - len * sin(a)
        val rx = cx + len * sin(a)
        val ty = apexY - len * cos(a)
        val arc = RectF(cx - len, apexY - len, cx + len, apexY + len)
        cone.reset()
        cone.moveTo(cx, apexY)
        cone.lineTo(lx, ty)
        cone.arcTo(arc, -90f - deg, 2f * deg)
        cone.close()
        p.style = Paint.Style.FILL
        p.color = Color.argb((45 * ui).toInt(), 244, 123, 32)
        c.drawPath(cone, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(2f)
        p.color = Color.argb((230 * ui).toInt(), 255, 255, 255)
        c.drawLine(cx, apexY, lx, ty, p)
        c.drawLine(cx, apexY, rx, ty, p)
        p.color = Color.argb((255 * ui).toInt(), 244, 123, 32)
        p.strokeWidth = d(2.6f)
        c.drawArc(arc, -90f - deg, 2f * deg, false, p)
        p.style = Paint.Style.FILL
        p.color = Color.argb((255 * ui).toInt(), 255, 255, 255)
        c.drawCircle(cx, apexY, d(4f), p)

        // tên ống kính: đổi chéo giữa cũ và mới
        val fromA = (1f - ((ep - 0.30f) * 4f)).coerceIn(0f, 1f)
        val toA = ((ep - 0.40f) * 4f).coerceIn(0f, 1f)
        p.style = Paint.Style.FILL
        p.typeface = Typeface.DEFAULT_BOLD
        p.letterSpacing = 0.12f
        p.textSize = h * 0.07f
        p.color = Color.argb((255 * fromA * ui).toInt(), 255, 255, 255)
        c.drawText(nodes[from].title, cx, h * 0.84f, p)
        p.color = Color.argb((255 * toA * ui).toInt(), 255, 255, 255)
        c.drawText(nodes[to].title, cx, h * 0.84f, p)
        p.letterSpacing = 0f
        p.typeface = Typeface.DEFAULT
        p.textSize = h * 0.045f
        p.color = Color.argb((230 * fromA * ui).toInt(), 204, 204, 204)
        c.drawText(nodes[from].sub, cx, h * 0.93f, p)
        p.color = Color.argb((230 * toA * ui).toInt(), 204, 204, 204)
        c.drawText(nodes[to].sub, cx, h * 0.93f, p)
    }
}

/** Màn hình xem lại: nền trắng, chữ HASSELBLAD, ảnh và thông số máy. */
class ReviewView(ctx: Context) : FrameLayout(ctx) {
    private val img = ImageView(ctx)
    var onClose: (() -> Unit)? = null
    var onSaveFrame: (() -> Unit)? = null
    var onOpen: (() -> Unit)? = null

    init {
        val dn = resources.displayMetrics.density
        setBackgroundColor(Color.WHITE)
        isClickable = true
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        addView(img, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        fun btn(t: String, a: () -> Unit) {
            val tv = TextView(ctx)
            tv.text = t
            tv.textSize = 13f
            tv.setTextColor(0xFF333333.toInt())
            tv.setPadding((12 * dn).toInt(), (8 * dn).toInt(), (12 * dn).toInt(), (8 * dn).toInt())
            tv.setOnClickListener { a() }
            row.addView(tv)
        }
        btn("Lưu ảnh khung") { onSaveFrame?.invoke() }
        btn("Thư viện") { onOpen?.invoke() }
        btn("✕") { onClose?.invoke() }
        val lp = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END)
        lp.setMargins(0, (6 * dn).toInt(), (10 * dn).toInt(), 0)
        addView(row, lp)
        visibility = GONE
    }

    fun show(b: android.graphics.Bitmap) {
        img.setImageBitmap(b)
        visibility = VISIBLE
    }

    fun hide() {
        visibility = GONE
        img.setImageDrawable(null)
    }
}

/** Bố cục chính: sắp xếp lại toàn bộ control theo hai giao diện. */
class CameraLayout(ctx: Context) : ViewGroup(ctx) {
    val decor = DecorView(ctx)
    val texture = TextureView(ctx)
    val freeze = ImageView(ctx)
    val frame = FrameOverlayView(ctx)
    val focusBox = FocusBoxView(ctx)
    val fx = ShutterFxView(ctx)
    val lensFx = LensSwitchView(ctx)
    val ev = EvView(ctx)
    val ladder = ZoomLadderView(ctx)
    val pills = LensPillsView(ctx)
    val tray = HorizontalScrollView(ctx)
    val trayRow = LinearLayout(ctx)
    val shutter = ShutterButton(ctx)
    val thumb = ImageView(ctx)
    val filterBtn = FilterButtonView(ctx)
    val toggle = IconButtonView(ctx, IconButtonView.TOGGLE)
    val gear = IconButtonView(ctx, IconButtonView.GEAR)

    private val vf = RectF()
    private var safeL = 0
    private var safeR = 0
    private val dn = resources.displayMetrics.density

    var classic: Boolean = true
        set(v) { field = v; applyMode() }

    init {
        tray.isHorizontalScrollBarEnabled = false
        trayRow.orientation = LinearLayout.HORIZONTAL
        tray.addView(trayRow)
        tray.visibility = GONE
        freeze.scaleType = ImageView.ScaleType.FIT_XY
        freeze.visibility = GONE
        lensFx.visibility = GONE
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.clipToOutline = true
        thumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, 6f * dn)
            }
        }
        thumb.foreground = GradientDrawable().apply {
            setStroke((2 * dn).toInt(), 0x99FFFFFF.toInt())
            cornerRadius = 6f * dn
        }
        thumb.isClickable = true
        for (v in listOf<View>(decor, texture, freeze, frame, focusBox, fx, lensFx, ev, ladder, pills, tray, shutter, thumb, filterBtn, toggle, gear)) {
            addView(v)
        }
        applyMode()
    }

    fun setSafe(l: Int, r: Int) {
        safeL = l; safeR = r
        decor.safeL = l.toFloat()
        requestLayout()
    }

    private fun applyMode() {
        setBackgroundColor(if (classic) 0xFF1B1B1D.toInt() else Color.BLACK)
        for (v in listOf<XView>(decor, frame, focusBox, ev, ladder, pills, shutter, filterBtn, toggle, gear)) v.classic = classic
        ladder.visibility = if (classic) VISIBLE else GONE
        pills.visibility = if (classic) GONE else VISIBLE
        requestLayout()
        invalidate()
    }

    private fun place(v: View, l: Float, t: Float, r: Float, b: Float) {
        val li = l.toInt(); val ti = t.toInt(); val ri = r.toInt(); val bi = b.toInt()
        v.measure(MeasureSpec.makeMeasureSpec(ri - li, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(bi - ti, MeasureSpec.EXACTLY))
        v.layout(li, ti, ri, bi)
    }

    private fun placeC(v: View, cx: Float, cy: Float, w: Float, h: Float) =
        place(v, cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = (r - l).toFloat()
        val h = (b - t).toFloat()
        if (w <= 0f || h <= 0f) return
        val ax = safeL.toFloat()
        val aw = w - safeL - safeR
        val vfW = if (classic) aw * 0.835f else aw * 0.89f
        val vfH = vfW * 24f / 65f
        val vfL = if (classic) ax + aw * 0.008f else ax + (aw - vfW) / 2f
        val vfT = (h - vfH) / 2f
        vf.set(vfL, vfT, vfL + vfW, vfT + vfH)
        decor.vf.set(vf)

        place(decor, 0f, 0f, w, h)
        place(texture, vf.left, vf.top, vf.right, vf.bottom)
        place(freeze, vf.left, vf.top, vf.right, vf.bottom)
        place(frame, vf.left, vf.top, vf.right, vf.bottom)
        place(focusBox, vf.left, vf.top, vf.right, vf.bottom)
        place(fx, vf.left, vf.top, vf.right, vf.bottom)
        place(lensFx, vf.left, vf.top, vf.right, vf.bottom)

        val btn = h * 0.095f
        placeC(toggle, ax + aw * 0.045f, h * 0.072f, btn, btn)
        placeC(gear, ax + aw * 0.045f + btn * 1.3f, h * 0.072f, btn, btn)

        placeC(tray, vf.centerX(), vf.top + dn * 26f, vfW * 0.8f, dn * 40f)

        val evH = vfH * 0.55f
        if (classic) {
            val cx = ax + aw * 0.943f
            placeC(shutter, cx, h * 0.5f, h * 0.19f, h * 0.19f)
            placeC(filterBtn, cx, h * 0.215f, aw * 0.075f, h * 0.095f)
            placeC(thumb, cx, h * 0.8f, h * 0.115f, h * 0.115f)
            val n = ladder.labels.size
            val lh = min(vfH * 0.9f, n * dn * 52f).coerceAtLeast(dn * 52f)
            placeC(ladder, vf.right - dn * 34f, vf.centerY(), dn * 56f, lh)
            place(ev, vf.left + vfW * 0.02f, vf.centerY() - evH * 0.35f, vf.left + vfW * 0.02f + dn * 90f, vf.centerY() - evH * 0.35f + evH)
        } else {
            val cx = vf.right - vfW * 0.087f
            placeC(shutter, cx, vf.centerY(), h * 0.19f, h * 0.19f)
            placeC(filterBtn, cx, vf.top + vfH * 0.18f, h * 0.085f, h * 0.085f)
            placeC(thumb, cx, vf.bottom - vfH * 0.17f, h * 0.13f, h * 0.13f)
            val n = pills.labels.size
            val pw = if (n == 0) dn * 40f else n * pills.pillSize() + (n - 1) * pills.gap()
            placeC(pills, vf.centerX(), vf.bottom - vfH * 0.12f, pw, pills.pillSize() + dn * 4f)
            place(ev, vf.left + vfW * 0.04f, vf.centerY() - evH * 0.5f, vf.left + vfW * 0.04f + dn * 90f, vf.centerY() - evH * 0.5f + evH)
        }
    }
}
