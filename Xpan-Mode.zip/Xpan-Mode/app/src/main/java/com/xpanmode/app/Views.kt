package com.xpanmode.app

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Matrix
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.view.TextureView
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.roundToInt

const val ORANGE = 0xFFF47B20.toInt()

/** Phản hồi chạm chung: nhấn xuống thì co lại (kèm rung nhẹ), thả ra thì nảy về — không chặn sự kiện click. */
fun View.pressFeedback(down: Float = 0.92f, haptic: Boolean = true) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                v.animate().cancel()
                v.animate().scaleX(down).scaleY(down).setDuration(80).setInterpolator(DecelerateInterpolator()).start()
                if (haptic) v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()
        }
        false
    }
}

/** "Nảy" nhẹ một view (dùng khi chọn / đổi giá trị). */
fun View.pop(peak: Float = 1.12f) {
    animate().cancel()
    animate().scaleX(peak).scaleY(peak).setDuration(90).setInterpolator(DecelerateInterpolator()).withEndAction {
        animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(3f)).start()
    }.start()
}

/** Chủ đề giao diện dùng chung: false = tối (mặc định), true = trắng. Các view đọc trực tiếp khi vẽ. */
object Theme {
    @JvmStatic var light = false
    val bgFull: Int get() = if (light) 0xFFF6F6F8.toInt() else Color.BLACK
    val bgClassic: Int get() = if (light) 0xFFE4E4E8.toInt() else 0xFF1F1F21.toInt()
    /** Màu chữ / biểu tượng đặt trên nền giao diện (không phải trên ảnh). */
    val ink: Int get() = if (light) 0xFF1B1B1E.toInt() else Color.WHITE
}

abstract class XView(ctx: Context) : View(ctx) {
    var classic: Boolean = true
        set(v) { field = v; invalidate() }
    protected val p = Paint(Paint.ANTI_ALIAS_FLAG)
    protected fun d(v: Float): Float = v * resources.displayMetrics.density
}

/** Giao diện máy ảnh tối giản: nền xám đen phẳng, đường kẻ mảnh có vát góc, nhãn HASSELBLAD, viền đen quanh khung ngắm. */
class DecorView(ctx: Context) : XView(ctx) {
    val vf = RectF()
    var safeL = 0f
    var safeR = 0f
    private val logoFace = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
    private val line = Path()

    /** Đường kẻ: chạy ngang, vát xuống (hoặc lên) quanh nhãn rồi chạy tiếp tới mép phải. */
    private fun hud(c: Canvas, x0: Float, y: Float, cx: Float, half: Float, k: Float, depth: Float, w: Float) {
        line.reset()
        line.moveTo(x0, y)
        line.lineTo(cx - half - k, y)
        line.lineTo(cx - half, y + depth)
        line.lineTo(cx + half, y + depth)
        line.lineTo(cx + half + k, y)
        line.lineTo(w, y)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        c.save()
        c.translate(0f, d(1.2f))
        p.color = if (Theme.light) 0xFFFFFFFF.toInt() else 0xFF08080A.toInt()
        c.drawPath(line, p)
        c.restore()
        p.color = if (Theme.light) 0xFFB4B4BB.toInt() else 0xFF5A5A60.toInt()
        c.drawPath(line, p)
    }

    private fun screw(c: Canvas, x: Float, y: Float, r: Float) {
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            x - r * 0.3f, y - r * 0.3f, r * 1.3f,
            if (Theme.light) 0xFFFFFFFF.toInt() else 0xFFD6D6DA.toInt(),
            if (Theme.light) 0xFF9A9AA2.toInt() else 0xFF4A4A4F.toInt(), Shader.TileMode.CLAMP
        )
        c.drawCircle(x, y, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.28f
        p.color = if (Theme.light) 0xFF6A6A71.toInt() else 0xFF16161A.toInt()
        c.save()
        c.rotate(35f, x, y)
        c.drawLine(x - r * 0.7f, y, x + r * 0.7f, y, p)
        c.restore()
        p.strokeWidth = d(0.8f)
        p.color = 0x66000000
        c.drawCircle(x, y, r, p)
    }

    override fun onDraw(c: Canvas) {
        if (!classic) return
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = vf.centerX()
        val ax = safeL
        val aw = w - safeL - safeR

        // nền phẳng
        c.drawColor(Theme.bgClassic)

        val half = w * 0.16f
        val k = w * 0.03f
        val depth = h * 0.06f
        val by = h * 0.085f                  // trục ngang của hàng nút phía trên
        val btn = h * 0.095f
        val tx = ax + btn * 0.72f + d(8f)    // tâm nút ở góc trái (cài đặt phía trên, đổi chế độ phía dưới)
        // đường kẻ trên: bắt đầu sau 2 nút (cài đặt, đổi sáng/tối); đường kẻ dưới đối xứng
        val x0 = tx + btn * 1.3f + btn * 0.75f
        hud(c, x0, by, cx, half, k, depth, w)
        hud(c, x0, h - by, cx, half, k, -depth, w)

        // viền đen bo góc quanh khung ngắm
        val o = d(5f)
        val ch = d(2.2f)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, vf.top - o - ch, 0f, vf.bottom + o + ch,
            if (Theme.light) intArrayOf(0xFFFFFFFF.toInt(), 0xFFD6D6DC.toInt(), 0xFFA8A8AF.toInt(), 0xFFEFEFF2.toInt())
            else intArrayOf(0xFFB4B4BA.toInt(), 0xFF55555A.toInt(), 0xFF2E2E32.toInt(), 0xFF84848A.toInt()),
            floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(vf.left - o - ch, vf.top - o - ch, vf.right + o + ch, vf.bottom + o + ch, d(14f), d(14f), p)
        p.shader = null
        p.color = 0xFF000000.toInt()
        c.drawRoundRect(vf.left - o, vf.top - o, vf.right + o, vf.bottom + o, d(12f), d(12f), p)

        // chữ khắc XPAN · 65:24 ở giữa phía dưới (dưới đường vát)
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        p.textSize = h * 0.034f
        p.letterSpacing = 0.32f
        p.textAlign = Paint.Align.CENTER
        p.color = if (Theme.light) 0xFF8A8A92.toInt() else 0xFFA9A9AF.toInt()
        c.drawText("XPAN  ·  65:24", cx, h - by + p.textSize * 0.35f, p)
        p.typeface = Typeface.DEFAULT
        p.letterSpacing = 0f

        // nhãn HASSELBLAD
        val txt = "HASSELBLAD"
        p.typeface = logoFace
        p.textSize = minOf(h * 0.052f, h * 0.06f)
        p.letterSpacing = 0.28f
        p.textAlign = Paint.Align.CENTER
        val tw = p.measureText(txt)
        val ph = p.textSize * 0.9f
        p.style = Paint.Style.FILL
        val bl = cx - tw / 2 - d(12f)
        val br = cx + tw / 2 + d(12f)
        p.shader = LinearGradient(0f, by - ph, 0f, by + ph, if (Theme.light) 0xFFFFFFFF.toInt() else 0xFF4A4A4E.toInt(), if (Theme.light) 0xFFD6D6DB.toInt() else 0xFF2A2A2D.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(bl, by - ph, br, by + ph, d(4f), d(4f), p)
        p.shader = null
        // vân phay xước
        c.save()
        c.clipRect(bl, by - ph, br, by + ph)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(0.5f)
        p.color = if (Theme.light) 0x16000000 else 0x10FFFFFF
        var yy = by - ph
        while (yy < by + ph) { c.drawLine(bl, yy, br, yy, p); yy += d(2.2f) }
        c.restore()
        // mép chrome
        p.shader = LinearGradient(0f, by - ph, 0f, by + ph, if (Theme.light) 0xFFFFFFFF.toInt() else 0xFFA8A8AE.toInt(), if (Theme.light) 0xFF9A9AA2.toInt() else 0xFF45454A.toInt(), Shader.TileMode.CLAMP)
        p.strokeWidth = d(1.1f)
        c.drawRoundRect(bl, by - ph, br, by + ph, d(4f), d(4f), p)
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = if (Theme.light) 0xFF26262A.toInt() else 0xFFF2F2F2.toInt()
        c.drawText(txt, cx, by + p.textSize * 0.33f, p)
        p.typeface = Typeface.DEFAULT
        p.letterSpacing = 0f
        p.textAlign = Paint.Align.LEFT

        // vít kim loại góc phải dưới (góc trái dưới là nút đổi chế độ)
        screw(c, w - w * 0.03f, h - by, d(4.5f))
    }
}

/** Viền đen mờ dần quanh khung ngắm (giao diện toàn màn). Dùng chung cho khung và cho hiệu ứng chuyển ống kính để hai bên liền mạch. */
fun drawEdgeFade(c: Canvas, p: Paint, w: Float, h: Float) {
    val bg = Theme.bgFull
    val e = bg or 0xFF000000.toInt()
    val z = bg and 0x00FFFFFF
    val fx = w * 0.009f
    val fy = h * 0.03f
    p.style = Paint.Style.FILL
    p.shader = LinearGradient(0f, 0f, fx, 0f, e, z, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, fx, h, p)
    p.shader = LinearGradient(w, 0f, w - fx, 0f, e, z, Shader.TileMode.CLAMP); c.drawRect(w - fx, 0f, w, h, p)
    p.shader = LinearGradient(0f, 0f, 0f, fy, e, z, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, w, fy, p)
    p.shader = LinearGradient(0f, h, 0f, h - fy, e, z, Shader.TileMode.CLAMP); c.drawRect(0f, h - fy, w, h, p)
    p.shader = null
}

/**
 * Nút tròn xám trong mờ của giao diện ngắm rộng (theo ảnh mẫu): mặt xám đậm hơi trong, chuyển sắc rất nhẹ,
 * chỉ có một đường viền sáng cực mảnh. Không blur, không bóng nên rất nhẹ máy.
 */
fun drawGlassDisc(c: Canvas, p: Paint, cx: Float, cy: Float, r: Float, dn: Float) {
    val oldStyle = p.style
    val oldW = p.strokeWidth
    p.style = Paint.Style.FILL
    p.shader = LinearGradient(
        0f, cy - r, 0f, cy + r,
        if (Theme.light) intArrayOf(0xF2F6F6F8.toInt(), 0xF2E2E2E7.toInt()) else intArrayOf(0xDC505055.toInt(), 0xD2404044.toInt()),
        null, Shader.TileMode.CLAMP
    )
    c.drawCircle(cx, cy, r, p)
    p.shader = null
    p.style = Paint.Style.STROKE
    p.strokeWidth = 0.8f * dn
    p.color = if (Theme.light) 0x22000000 else 0x24FFFFFF
    c.drawCircle(cx, cy, r - 0.4f * dn, p)
    p.style = oldStyle
    p.strokeWidth = oldW
}

/** Nút tròn của giao diện Hasselblad theo ảnh mẫu: mặt tối bóng chuyển sắc, viền vát mảnh và một vòng chỉ mờ bên trong. */
fun drawRefButton(c: Canvas, p: Paint, cx: Float, cy: Float, r: Float, dn: Float) {
    val light = Theme.light
    val body = r * 0.94f
    p.style = Paint.Style.FILL
    p.color = if (light) 0x26000000 else 0x80000000.toInt()
    c.drawCircle(cx, cy + r * 0.04f, body, p)
    p.shader = LinearGradient(
        0f, cy - body, 0f, cy + body,
        if (light) intArrayOf(0xFFFAFAFB.toInt(), 0xFFD9D9DF.toInt()) else intArrayOf(0xFF2E2E32.toInt(), 0xFF131315.toInt()),
        null, Shader.TileMode.CLAMP
    )
    c.drawCircle(cx, cy, body, p)
    p.shader = null
    p.style = Paint.Style.STROKE
    p.strokeWidth = 1.2f * dn
    p.shader = LinearGradient(
        0f, cy - body, 0f, cy + body,
        if (light) intArrayOf(0xFFFFFFFF.toInt(), 0x66000000) else intArrayOf(0x66FFFFFF, 0x1AFFFFFF),
        null, Shader.TileMode.CLAMP
    )
    c.drawCircle(cx, cy, body - 0.6f * dn, p)
    p.shader = null
    p.strokeWidth = 0.8f * dn
    p.color = if (light) 0x14000000 else 0x12FFFFFF
    c.drawCircle(cx, cy, body * 0.84f, p)
}

/**
 * Núm kim loại gia công cho giao diện giả máy ảnh: đế tối, vành khía (knurled) quanh mép, mặt vát phay xước,
 * lòng chảo lõm ở giữa và đường chỉ mảnh sáng/tối như đồ cơ khí thật.
 */
fun drawMetalKnob(c: Canvas, p: Paint, cx: Float, cy: Float, r: Float, dn: Float) {
    val light = Theme.light
    val body = r * 0.93f
    p.style = Paint.Style.FILL
    // bóng đổ rất gọn dưới núm
    p.color = if (light) 0x30000000 else 0x66000000
    c.drawCircle(cx, cy + r * 0.04f, body, p)
    // mặt vát phay xước (sweep nhiều dải sáng/tối)
    p.shader = SweepGradient(
        cx, cy,
        if (light) intArrayOf(
            0xFFFAFAFB.toInt(), 0xFFB6B6BE.toInt(), 0xFFF2F2F4.toInt(), 0xFF9D9DA7.toInt(), 0xFFEDEDF0.toInt(),
            0xFFB0B0B8.toInt(), 0xFFF8F8FA.toInt(), 0xFF9A9AA4.toInt(), 0xFFFAFAFB.toInt()
        ) else intArrayOf(
            0xFFD6D6DB.toInt(), 0xFF4A4A50.toInt(), 0xFFB9B9BF.toInt(), 0xFF3A3A3F.toInt(), 0xFFCDCDD2.toInt(),
            0xFF47474D.toInt(), 0xFFC4C4CA.toInt(), 0xFF3C3C41.toInt(), 0xFFD6D6DB.toInt()
        ), null
    )
    c.drawCircle(cx, cy, body, p)
    p.shader = null
    // vành khía
    p.style = Paint.Style.STROKE
    p.strokeWidth = 0.9f * dn
    val n = 56
    for (i in 0 until n) {
        val a = Math.PI * 2 * i / n
        val ca = cos(a).toFloat()
        val sa = sin(a).toFloat()
        p.color = if (i % 2 == 0) (if (light) 0x55000000 else 0x88000000.toInt()) else (if (light) 0x66FFFFFF else 0x30FFFFFF)
        c.drawLine(cx + body * 0.885f * ca, cy + body * 0.885f * sa, cx + body * 0.985f * ca, cy + body * 0.985f * sa, p)
    }
    // viền ngoài: sáng trên, tối dưới
    p.strokeWidth = 1.1f * dn
    p.shader = LinearGradient(
        0f, cy - body, 0f, cy + body,
        if (light) intArrayOf(0xFFFFFFFF.toInt(), 0xFF7E7E88.toInt()) else intArrayOf(0xFFE8E8EC.toInt(), 0xFF202024.toInt()),
        null, Shader.TileMode.CLAMP
    )
    c.drawCircle(cx, cy, body - 0.5f * dn, p)
    p.shader = null
    // khe tối giữa vành khía và lòng chảo
    val dish = body * 0.80f
    p.strokeWidth = 1.2f * dn
    p.color = if (light) 0x66000000 else 0xAA000000.toInt()
    c.drawCircle(cx, cy, dish + 0.6f * dn, p)
    // lòng chảo lõm: tối ở trên, sáng ở dưới
    p.style = Paint.Style.FILL
    p.shader = LinearGradient(
        0f, cy - dish, 0f, cy + dish,
        if (light) intArrayOf(0xFFD3D3D9.toInt(), 0xFFFBFBFC.toInt()) else intArrayOf(0xFF161619.toInt(), 0xFF3B3B40.toInt()),
        null, Shader.TileMode.CLAMP
    )
    c.drawCircle(cx, cy, dish, p)
    p.shader = null
    // đường chỉ sáng mảnh trong lòng chảo
    p.style = Paint.Style.STROKE
    p.strokeWidth = 0.8f * dn
    p.color = if (light) 0x99FFFFFF.toInt() else 0x22FFFFFF
    c.drawCircle(cx, cy, dish - 1.2f * dn, p)
}

/** Các vạch góc / cạnh của khung ngắm + viền mờ (giao diện tối giản) hoặc tối dần phía dưới (Hasselblad). */
class FrameOverlayView(ctx: Context) : XView(ctx) {
    private val path = Path()
    /** Khi chụp: ẩn các vạch khung nhưng GIỮ viền mờ/bo góc để ảnh đóng băng trông liền mạch với khung ngắm. */
    var linesHidden = false
        set(v) { field = v; invalidate() }
    /** Lưới bố cục 3×3 (chia ba theo cả hai chiều). Tự ẩn cùng các vạch khung khi đang chụp. */
    var grid = false
        set(v) { if (field != v) { field = v; invalidate() } }
    /** Ghi chú góc trái trên khi chụp ở chế độ HQ. */
    var hqNote = false
    /** Chữ ghi chú góc trên-trái khung ngắm khi hqNote bật. */
    var hqNoteText = "Shot with LUNA Quality"
        set(v) { if (field != v) { field = v; invalidate() } }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        if (classic) {
            p.shader = LinearGradient(0f, h * 0.72f, 0f, h, 0x00000000, 0xB0000000.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, h * 0.72f, w, h, p)
            p.shader = null
        } else {
            drawEdgeFade(c, p, w, h)
        }
        if (linesHidden) return
        if (grid) {
            // hai đường dọc + hai đường ngang chia khung làm 3 phần; một lớp bóng tối mờ bên dưới để đọc được trên cả nền sáng
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.BUTT
            val x1 = w / 3f
            val x2 = w * 2f / 3f
            val y1 = h / 3f
            val y2 = h * 2f / 3f
            for ((col, sw) in listOf(0x55000000 to d(2.2f), 0xB3FFFFFF.toInt() to d(1f))) {
                p.strokeWidth = sw
                p.color = col
                c.drawLine(x1, 0f, x1, h, p)
                c.drawLine(x2, 0f, x2, h, p)
                c.drawLine(0f, y1, w, y1, p)
                c.drawLine(0f, y2, w, y2, p)
            }
        }
        if (hqNote) {
            p.style = Paint.Style.FILL
            p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.ITALIC)
            p.textSize = d(10f)
            p.textAlign = Paint.Align.LEFT
            p.letterSpacing = 0.03f
            p.setShadowLayer(d(2.5f), 0f, d(1f), 0xCC000000.toInt())
            p.color = 0xF2FFFFFF.toInt()
            c.drawText(hqNoteText, d(if (classic) 22f else 26f), d(if (classic) 28f else 32f), p)
            p.clearShadowLayer()
            p.letterSpacing = 0f
            p.typeface = Typeface.DEFAULT
        }
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        val ins = if (classic) d(10f) else d(12f)
        val len = w * 0.045f
        val r = if (classic) d(4f) else d(10f)
        val top = if (classic) arrayOf(0.17f to 0.28f, 0.44f to 0.64f) else arrayOf(0.10f to 0.13f, 0.45f to 0.65f)
        val bot = if (classic) arrayOf(0.085f to 0.13f, 0.29f to 0.40f, 0.69f to 0.76f)
        else arrayOf(0.14f to 0.17f, 0.30f to 0.32f, 0.82f to 0.90f)
        val side = arrayOf(0.22f to 0.32f, 0.62f to 0.74f)
        val baseW = d(if (classic) 1.6f else 2.4f)
        // giao diện trắng: vẽ thêm một lớp viền sáng mờ bên dưới để vạch vẫn đọc được trên cả ảnh tối lẫn sáng
        val passes = if (Theme.light && !classic) listOf(0x99FFFFFF.toInt() to baseW + d(3f), 0xFF26262A.toInt() to baseW)
        else listOf((if (classic) 0xE6FFFFFF.toInt() else 0xFFD8D8D8.toInt()) to baseW)
        for ((col, sw) in passes) {
            p.strokeWidth = sw
            p.color = col
            path.reset()
            path.moveTo(ins, ins + len); path.lineTo(ins, ins + r)
            path.quadTo(ins, ins, ins + r, ins); path.lineTo(ins + len, ins)
            for (sx in floatArrayOf(1f, -1f)) for (sy in floatArrayOf(1f, -1f)) {
                c.save(); c.scale(sx, sy, w / 2f, h / 2f); c.drawPath(path, p); c.restore()
            }
            for ((a, b) in top) c.drawLine(w * a, ins, w * b, ins, p)
            for ((a, b) in bot) c.drawLine(w * a, h - ins, w * b, h - ins, p)
            for ((a, b) in side) {
                c.drawLine(ins, h * a, ins, h * b, p)
                c.drawLine(w - ins, h * a, w - ins, h * b, p)
            }
        }
    }
}

/** Khung lấy nét: hiện khi chạm, đổi màu khi bắt nét xong (xanh = nét, đỏ = không nét) rồi tự ẩn. */
class FocusBoxView(ctx: Context) : XView(ctx) {
    private var fx = 0f
    private var fy = 0f
    private var scale = 1f
    private var shown = false
    private var color = Color.WHITE
    private var anim: ValueAnimator? = null
    private val autoHide = Runnable { fadeOut() }

    init { visibility = GONE }

    fun showAt(x: Float, y: Float) {
        removeCallbacks(autoHide)
        animate().cancel()
        fx = x; fy = y
        color = Color.WHITE
        shown = true
        alpha = 1f
        visibility = VISIBLE
        anim?.cancel()
        anim = ValueAnimator.ofFloat(1.3f, 1f).apply {
            duration = 220
            addUpdateListener { scale = it.animatedValue as Float; invalidate() }
            start()
        }
        postDelayed(autoHide, 3500)
    }

    fun lock(ok: Boolean) {
        if (!shown) return
        removeCallbacks(autoHide)
        color = if (ok) 0xFF7CFF8A.toInt() else 0xFFFF6A5A.toInt()
        anim?.cancel()
        anim = ValueAnimator.ofFloat(1f, 0.82f).apply {
            duration = 130
            repeatCount = 1
            repeatMode = ValueAnimator.REVERSE
            interpolator = DecelerateInterpolator()
            addUpdateListener { scale = it.animatedValue as Float; invalidate() }
            start()
        }
        invalidate()
        postDelayed(autoHide, 450)
    }

    private fun fadeOut() {
        animate().alpha(0f).setDuration(220).withEndAction {
            shown = false
            visibility = GONE
            alpha = 1f
        }.start()
    }

    override fun onDraw(c: Canvas) {
        if (!shown) return
        val half = min(width, height) * 0.17f * scale
        val len = half * 0.45f
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.6f)
        p.color = color
        val l = fx - half; val r = fx + half; val t = fy - half; val b = fy + half
        c.drawLine(l, t, l + len, t, p); c.drawLine(l, t, l, t + len, p)
        c.drawLine(r, t, r - len, t, p); c.drawLine(r, t, r, t + len, p)
        c.drawLine(l, b, l + len, b, p); c.drawLine(l, b, l, b - len, p)
        c.drawLine(r, b, r - len, b, p); c.drawLine(r, b, r, b - len, p)
    }
}

/** Thanh bù sáng bên trái: vuốt dọc để đổi EV. */
class EvView(ctx: Context) : XView(ctx) {
    var min = 0
        set(v) { field = v; invalidate() }
    var max = 0
        set(v) { field = v; invalidate() }
    var step = 0f
    var value = 0
        set(v) { field = v; invalidate() }
    var onChange: ((Int) -> Unit)? = null
    private var downY = 0f
    private var downVal = 0

    override fun onDraw(c: Canvas) {
        if (max <= min) return
        val h = height.toFloat()
        val pad = d(8f)
        val n = (max - min).toFloat()
        val perEv = if (step > 0f) (1f / step).roundToInt().coerceAtLeast(1) else 1
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.4f)
        p.color = Color.WHITE
        if (Theme.light) p.setShadowLayer(d(2.5f), 0f, 0f, 0xAA000000.toInt())
        for (i in min..max) {
            val y = pad + (max - i) / n * (h - 2 * pad)
            val len = if (i % perEv == 0) d(14f) else d(5f)
            c.drawLine(d(4f), y, d(4f) + len, y, p)
        }
        val y = pad + (max - value) / n * (h - 2 * pad)
        p.style = Paint.Style.FILL
        val tri = Path()
        tri.moveTo(d(22f), y); tri.lineTo(d(32f), y - d(6f)); tri.lineTo(d(32f), y + d(6f)); tri.close()
        c.drawPath(tri, p)
        val ev = value * step
        val label = if (value == 0) "0.0" else String.format(Locale.US, "%+.1f", ev)
        p.textSize = d(14f)
        p.textAlign = Paint.Align.LEFT
        c.drawText(label, d(38f), y + d(5f), p)
        p.clearShadowLayer()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downY = e.y; downVal = value
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                if (max > min) {
                    val per = (height - 2 * d(8f)) / (max - min)
                    val nv = (downVal - ((e.y - downY) / per).roundToInt()).coerceIn(min, max)
                    if (nv != value) { value = nv; onChange?.invoke(nv) }
                }
            }
        }
        return true
    }
}

/**
 * Nhận diện thao tác VUỐT DỌC trên vùng chọn tiêu cự (khác với chạm để chọn ống kính).
 * onMove nhận quãng đã vuốt LÊN tính bằng px (âm = vuốt xuống), đo từ lúc bắt đầu vuốt.
 */
class ZoomDrag(private val view: View) {
    var onStart: (() -> Unit)? = null
    var onMove: ((Float) -> Unit)? = null
    var onEnd: (() -> Unit)? = null
    var dragging = false
        private set
    private var downX = 0f
    private var downY = 0f
    private var startY = 0f
    private val slop = ViewConfiguration.get(view.context).scaledTouchSlop * 1.6f

    fun down(x: Float, y: Float) { downX = x; downY = y; dragging = false }

    /** true nếu đang vuốt (khi đó không coi là chạm chọn). */
    fun move(x: Float, y: Float): Boolean {
        if (!dragging) {
            val dy = abs(y - downY)
            if (dy < slop || dy < abs(x - downX)) return false
            dragging = true
            startY = y
            view.parent?.requestDisallowInterceptTouchEvent(true)
            view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onStart?.invoke()
        }
        onMove?.invoke(startY - y)
        return true
    }

    /** Trả về true nếu vừa kết thúc một lần vuốt. */
    fun end(): Boolean {
        val was = dragging
        dragging = false
        if (was) onEnd?.invoke()
        return was
    }
}

/** Bong bóng hiện giá trị thu phóng khi đang vuốt (vd: 1,7×  ·  41mm), tự mờ đi sau khi thả tay. */
class ZoomReadoutView(ctx: Context) : XView(ctx) {
    private var text = ""
    private val hideRun = Runnable {
        animate().alpha(0f).setDuration(220).withEndAction { visibility = GONE; alpha = 1f }.start()
    }

    init { visibility = GONE }

    fun show(t: String) {
        removeCallbacks(hideRun)
        animate().cancel()
        alpha = 1f
        visibility = VISIBLE
        if (t != text) { text = t; invalidate() }
    }

    fun hideSoon(delay: Long = 700L) {
        removeCallbacks(hideRun)
        postDelayed(hideRun, delay)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.color = if (Theme.light) 0xEEFFFFFF.toInt() else 0xCC0B0B0B.toInt()
        c.drawRoundRect(0f, 0f, w, h, h / 2f, h / 2f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.color = ORANGE
        c.drawRoundRect(d(0.6f), d(0.6f), w - d(0.6f), h - d(0.6f), h / 2f, h / 2f, p)
        p.style = Paint.Style.FILL
        p.color = ORANGE
        p.typeface = Typeface.DEFAULT_BOLD
        p.textAlign = Paint.Align.CENTER
        p.textSize = d(13.5f)
        val fm = p.fontMetrics
        c.drawText(text, w / 2f, h / 2f - (fm.ascent + fm.descent) / 2f, p)
        p.typeface = Typeface.DEFAULT
    }
}

/** Thang zoom bên phải (giao diện Hasselblad): 0,6 · 1 · 2 · 3× */
class ZoomLadderView(ctx: Context) : XView(ctx) {
    var labels: List<String> = emptyList()
        set(v) { field = v; invalidate(); requestLayout() }
    var selected = 0
        set(v) { field = v; slideTo(v.toFloat()) }
    var onSelect: ((Int) -> Unit)? = null
    /** Khi đang thu phóng liên tục (không đúng mốc): hiện số tỉ lệ thực thay cho nhãn của mốc đang chọn. */
    var liveLabel: String? = null
        set(v) { if (field != v) { field = v; invalidate() } }
    val zoomDrag = ZoomDrag(this)

    private var selPos = 0f
    private var selAnim: ValueAnimator? = null
    private var pressed = -1

    private fun slideTo(t: Float) {
        selAnim?.cancel()
        selAnim = ValueAnimator.ofFloat(selPos, t).apply {
            duration = 240
            interpolator = OvershootInterpolator(0.9f)
            addUpdateListener { selPos = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun idxAt(y: Float): Int {
        val n = labels.size
        val k = (y / height * n).toInt().coerceIn(0, n - 1)
        return n - 1 - k
    }

    override fun onDraw(c: Canvas) {
        val n = labels.size
        if (n == 0) return
        val cellH = height.toFloat() / n
        val cx = width / 2f
        p.textAlign = Paint.Align.CENTER
        // vòng nền trượt theo lựa chọn
        val sy = (n - 1 - selPos + 0.5f) * cellH
        p.style = Paint.Style.FILL
        p.color = 0x66000000
        c.drawCircle(cx, sy, d(20f), p)
        for (k in 0 until n) {
            val idx = n - 1 - k
            val cy = (k + 0.5f) * cellH
            val sel = idx == selected
            val sc = if (idx == pressed) 0.86f else 1f
            p.style = Paint.Style.FILL
            p.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            p.textSize = d(if (sel) 16f else 15f) * sc
            p.color = if (sel) ORANGE else Color.WHITE
            val txt = if (sel) (liveLabel ?: labels[idx]) + "×" else labels[idx]
            c.drawText(txt, cx, cy + d(5.5f) * sc, p)
        }
        p.typeface = Typeface.DEFAULT
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (labels.isEmpty()) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressed = idxAt(e.y)
                zoomDrag.down(e.x, e.y)
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (zoomDrag.move(e.x, e.y) && pressed != -1) { pressed = -1; invalidate() }
            }
            MotionEvent.ACTION_UP -> {
                val i = idxAt(e.y)
                pressed = -1
                invalidate()
                if (!zoomDrag.end()) {
                    onSelect?.invoke(i)
                    performClick()
                }
            }
            MotionEvent.ACTION_CANCEL -> { zoomDrag.end(); pressed = -1; invalidate() }
        }
        return true
    }
}

/** Các nút tiêu cự ở giữa dưới (giao diện tối giản): 14 · 23mm · 65 · 135 */
class LensPillsView(ctx: Context) : XView(ctx) {
    var labels: List<String> = emptyList()
        set(v) { field = v; invalidate(); requestLayout() }
    var selected = 0
        set(v) { field = v; slideTo(v.toFloat()) }
    var onSelect: ((Int) -> Unit)? = null
    /** Khi đang thu phóng liên tục (không đúng mốc): hiện tiêu cự (mm) thực thay cho nhãn của nút đang chọn. */
    var liveLabel: String? = null
        set(v) { if (field != v) { field = v; invalidate() } }
    val zoomDrag = ZoomDrag(this)
    /** Xếp dọc (cột bên phải, nút tiêu cự dài nhất ở trên cùng như thang zoom). */
    var vertical = false
        set(v) { if (field != v) { field = v; invalidate(); requestLayout() } }

    private var selPos = 0f
    private var selAnim: ValueAnimator? = null
    private var pressed = -1

    private fun slot(i: Float): Float {
        val k = if (vertical) (labels.size - 1 - i) else i
        return pad() + pillSize() / 2f + k * (pillSize() + gap())
    }

    fun pillSize() = d(33f)
    /** Chừa lề quanh dải nút để vòng cam (nét dày) không bị cắt ở mép view. */
    fun pad() = d(3f)
    fun gap() = d(9f)

    private fun slideTo(t: Float) {
        selAnim?.cancel()
        selAnim = ValueAnimator.ofFloat(selPos, t).apply {
            duration = 240
            interpolator = OvershootInterpolator(0.9f)
            addUpdateListener { selPos = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun idxAt(x: Float, y: Float): Int {
        val last = (labels.size - 1).coerceAtLeast(0)
        val k = (((if (vertical) y else x) - pad()) / (pillSize() + gap())).toInt().coerceIn(0, last)
        return if (vertical) last - k else k
    }

    override fun onDraw(c: Canvas) {
        val n = labels.size
        if (n == 0) return
        val s = pillSize()
        val r = s / 2f
        p.textAlign = Paint.Align.CENTER
        for (i in 0 until n) {
            val cx = if (vertical) width / 2f else slot(i.toFloat())
            val cy = if (vertical) slot(i.toFloat()) else height / 2f
            val rr = if (i == pressed) r * 0.88f else r
            drawGlassDisc(c, p, cx, cy, rr, resources.displayMetrics.density)
            p.style = Paint.Style.FILL
            val sel = i == selected
            p.color = if (sel) ORANGE else Theme.ink
            p.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            if (sel) {
                p.textSize = d(11f)
                c.drawText(liveLabel ?: labels[i], cx, cy - d(1f), p)
                p.textSize = d(8f)
                c.drawText("mm", cx, cy + d(9f), p)
            } else {
                p.textSize = d(11f)
                c.drawText(labels[i], cx, cy + d(4f), p)
            }
        }
        // vòng cam trượt từ nút cũ sang nút mới
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.6f)
        p.color = ORANGE
        if (vertical) c.drawCircle(width / 2f, slot(selPos), r, p)
        else c.drawCircle(slot(selPos), height / 2f, r, p)
        p.style = Paint.Style.FILL
        p.typeface = Typeface.DEFAULT
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (labels.isEmpty()) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressed = idxAt(e.x, e.y)
                zoomDrag.down(e.x, e.y)
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (zoomDrag.move(e.x, e.y) && pressed != -1) { pressed = -1; invalidate() }
            }
            MotionEvent.ACTION_UP -> {
                val i = idxAt(e.x, e.y)
                pressed = -1
                invalidate()
                if (!zoomDrag.end()) {
                    onSelect?.invoke(i)
                    performClick()
                }
            }
            MotionEvent.ACTION_CANCEL -> { zoomDrag.end(); pressed = -1; invalidate() }
        }
        return true
    }
}

class ShutterButton(ctx: Context) : XView(ctx) {
    private val hi = RectF()
    private var pressedNow = false
    /** Quầng sáng cam mạnh hơn trong lúc nhấn giữ. */
    private val lit get() = pressedNow
    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        // chừa chỗ cho bóng đổ phía dưới để không bị cắt mép view
        val r = min(width, height) / 2f * 0.9f
        p.style = Paint.Style.FILL
        if (classic) {
            // quả cầu trắng: vòng ngoài xám nhạt + lõi trắng bóng
            p.color = if (Theme.light) 0x33000000 else 0x55000000
            c.drawCircle(cx, cy + r * 0.05f, r, p)
            p.color = Color.BLACK      // alpha đặc: shader mới hiện đúng độ đậm
            p.shader = SweepGradient(
                cx, cy,
                if (Theme.light) intArrayOf(0xFFFFFFFF.toInt(), 0xFFB9B9C0.toInt(), 0xFFF4F4F6.toInt(), 0xFFA8A8B0.toInt(), 0xFFFFFFFF.toInt())
                else intArrayOf(0xFFCFCFD4.toInt(), 0xFF56565B.toInt(), 0xFFE6E6EA.toInt(), 0xFF46464B.toInt(), 0xFFCFCFD4.toInt()), null
            )
            c.drawCircle(cx, cy, r, p)
            p.shader = null
            p.color = if (Theme.light) 0xFFC4C4CA.toInt() else 0xFF17171A.toInt()
            c.drawCircle(cx, cy, r * 0.86f, p)
            p.shader = RadialGradient(cx - r * 0.18f, cy - r * 0.22f, r * 0.95f, 0xFFFFFFFF.toInt(), 0xFFCFCFD3.toInt(), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r * 0.80f, p)
            p.shader = null
        } else {
            // nút chụp theo ảnh mẫu: vòng xám đậm trong mờ bao quanh quả cầu cam bóng
            val dn = resources.displayMetrics.density
            val ringW = r * 0.17f
            p.style = Paint.Style.STROKE
            p.strokeWidth = ringW
            p.color = 0x8C3A3A3E.toInt()
            c.drawCircle(cx, cy, r - ringW / 2f, p)
            p.strokeWidth = 0.8f * dn
            p.color = 0x24FFFFFF
            c.drawCircle(cx, cy, r - 0.4f * dn, p)
            p.style = Paint.Style.FILL
            p.color = Color.BLACK      // trước đó paint đang mang alpha thấp của nét vẽ viền -> quả cầu cam bị mờ
            val rd = r * (if (pressedNow) 0.66f else 0.74f)
            p.shader = RadialGradient(
                cx - rd * 0.25f, cy - rd * 0.35f, rd * 1.45f,
                intArrayOf(0xFFFFB04A.toInt(), 0xFFF98A1B.toInt(), 0xFFEA6A06.toInt()),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
            c.drawCircle(cx, cy, rd, p)
            p.shader = null
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressedNow = true; invalidate()
                animate().cancel()
                animate().scaleX(0.88f).scaleY(0.88f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                pressedNow = false; invalidate()
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3.5f)).start()
            }
        }
        return super.onTouchEvent(e)
    }
}

/** Nút bộ lọc: huy hiệu "Original" (Hasselblad) hoặc biểu tượng cuộn phim (tối giản). */
class FilterButtonView(ctx: Context) : XView(ctx) {
    var label: String = "Original"
        set(v) { val ch = field != v; field = v; invalidate(); if (ch) pop(1.08f) }

    init { isClickable = true }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                animate().cancel()
                animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (classic) {
            p.style = Paint.Style.FILL
            p.color = if (Theme.light) 0xFFF3F3F5.toInt() else 0xFF0E0E10.toInt()
            c.drawRoundRect(0f, 0f, w, h, d(14f), d(14f), p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(1f)
            p.color = if (Theme.light) 0xFFC0C0C7.toInt() else 0xFF3A3A3D.toInt()
            c.drawRoundRect(0f, 0f, w, h, d(14f), d(14f), p)
            p.strokeWidth = d(2f)
            p.shader = LinearGradient(
                w * 0.1f, 0f, w * 0.9f, 0f,
                intArrayOf(0x00F47B20, ORANGE, 0xFFFFC040.toInt(), ORANGE, 0x00F47B20),
                null, Shader.TileMode.CLAMP
            )
            c.drawLine(w * 0.1f, h * 0.2f, w * 0.9f, h * 0.2f, p)
            c.drawLine(w * 0.1f, h * 0.8f, w * 0.9f, h * 0.8f, p)
            p.shader = null
            p.style = Paint.Style.FILL
            p.color = Theme.ink
            p.typeface = Typeface.DEFAULT_BOLD
            p.textAlign = Paint.Align.CENTER
            p.textSize = h * 0.23f
            val fm = p.fontMetrics
            c.drawText(label, w / 2f, h / 2f - (fm.ascent + fm.descent) / 2f, p)
            p.typeface = Typeface.DEFAULT
        } else {
            drawGlassDisc(c, p, w / 2f, h / 2f, min(w, h) / 2f * 0.98f, resources.displayMetrics.density)
            c.save()
            c.scale(0.8f, 0.8f, w / 2f, h / 2f)
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(1.8f)
            p.color = Theme.ink
            c.drawRoundRect(w * 0.1f, h * 0.27f, w * 0.9f, h * 0.73f, d(3f), d(3f), p)
            p.style = Paint.Style.FILL
            val hole = w * 0.06f
            for (i in 0 until 5) {
                val x = w * (0.2f + i * 0.15f)
                c.drawRect(x, h * 0.31f, x + hole, h * 0.31f + hole, p)
                c.drawRect(x, h * 0.69f - hole, x + hole, h * 0.69f, p)
            }
            c.restore()
        }
    }
}

/** Nút chuyển giao diện (⇄) và nút cài đặt: núm kim loại khía (Hasselblad) hoặc biểu tượng phẳng (tối giản). */
class IconButtonView(ctx: Context, private val kind: Int) : XView(ctx) {
    companion object {
        const val GEAR = 0
        const val TOGGLE = 1
        const val EDIT = 2
        const val THEME = 3
        const val FLASH = 4
    }

    /** Chỉ dùng cho FLASH: 0 = tắt (tia chớp gạch chéo), 1 = bật (tia chớp viền), 2 = luôn bật (tia chớp đặc). */
    var state: Int = 0
        set(v) { field = v; invalidate() }

    init { isClickable = true }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                animate().cancel()
                animate().scaleX(0.86f).scaleY(0.86f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3.5f)).start()
        }
        return super.onTouchEvent(e)
    }

    private fun symbol(c: Canvas, cx: Float, cy: Float, r: Float) {
        if (kind == GEAR) {
            // bánh răng cài đặt: 8 răng + lỗ giữa, nét mảnh
            p.strokeWidth = r * 0.07f
            val ro = r * 0.46f
            val ri = r * 0.35f
            val g = Path()
            for (k in 0 until 8) {
                val a = Math.toRadians(k * 45.0)
                fun pt(rad: Float, off: Double, first: Boolean) {
                    val x = cx + rad * cos(a + Math.toRadians(off)).toFloat()
                    val y = cy + rad * sin(a + Math.toRadians(off)).toFloat()
                    if (first) g.moveTo(x, y) else g.lineTo(x, y)
                }
                pt(ri, -13.0, k == 0)
                pt(ro, -8.5, false)
                pt(ro, 8.5, false)
                pt(ri, 13.0, false)
            }
            g.close()
            c.drawPath(g, p)
            c.drawCircle(cx, cy, r * 0.15f, p)
        } else if (kind == FLASH) {
            p.strokeWidth = r * 0.07f
            p.strokeJoin = Paint.Join.ROUND
            val bolt = Path()
            bolt.moveTo(cx + r * 0.10f, cy - r * 0.46f)
            bolt.lineTo(cx - r * 0.20f, cy + r * 0.04f)
            bolt.lineTo(cx - r * 0.02f, cy + r * 0.04f)
            bolt.lineTo(cx - r * 0.10f, cy + r * 0.46f)
            bolt.lineTo(cx + r * 0.20f, cy - r * 0.06f)
            bolt.lineTo(cx + r * 0.02f, cy - r * 0.06f)
            bolt.close()
            val old = p.style
            if (state == 2) p.style = Paint.Style.FILL_AND_STROKE
            c.drawPath(bolt, p)
            p.style = old
            if (state == 0) c.drawLine(cx - r * 0.36f, cy - r * 0.40f, cx + r * 0.36f, cy + r * 0.40f, p)
            p.strokeJoin = Paint.Join.MITER
        } else if (kind == TOGGLE) {
            // biểu tượng máy ảnh (đổi chế độ)
            p.strokeWidth = r * 0.07f
            val bw = r * 0.46f
            val bh = r * 0.32f
            val top = cy - bh + r * 0.04f
            val body = RectF(cx - bw, top, cx + bw, cy + bh + r * 0.04f)
            c.drawRoundRect(body, r * 0.1f, r * 0.1f, p)
            val hump = Path()
            hump.moveTo(cx - bw * 0.42f, top)
            hump.lineTo(cx - bw * 0.26f, top - r * 0.11f)
            hump.lineTo(cx + bw * 0.26f, top - r * 0.11f)
            hump.lineTo(cx + bw * 0.42f, top)
            c.drawPath(hump, p)
            c.drawCircle(cx, (top + body.bottom) / 2f, r * 0.17f, p)
            val old = p.style
            p.style = Paint.Style.FILL
            c.drawCircle(cx + bw * 0.68f, top + r * 0.1f, r * 0.03f, p)
            p.style = old
        } else if (kind == THEME) {
            if (Theme.light) {
                // đang sáng -> biểu tượng trăng lưỡi liềm (bấm để sang tối)
                val m = Path()
                m.addCircle(cx, cy, r * 0.36f, Path.Direction.CW)
                val cut = Path()
                cut.addCircle(cx + r * 0.20f, cy - r * 0.14f, r * 0.31f, Path.Direction.CW)
                m.op(cut, Path.Op.DIFFERENCE)
                val old = p.style
                p.style = Paint.Style.FILL
                c.drawPath(m, p)
                p.style = old
            } else {
                // đang tối -> biểu tượng mặt trời (bấm để sang sáng)
                p.strokeWidth = r * 0.075f
                c.drawCircle(cx, cy, r * 0.2f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val ca = cos(a).toFloat(); val sa = sin(a).toFloat()
                    c.drawLine(cx + r * 0.34f * ca, cy + r * 0.34f * sa, cx + r * 0.50f * ca, cy + r * 0.50f * sa, p)
                }
            }
        } else if (kind == EDIT) {
            // biểu tượng 3 thanh trượt
            p.strokeWidth = r * 0.07f
            val x0 = cx - r * 0.42f
            val x1 = cx + r * 0.42f
            val kn = floatArrayOf(-0.18f, 0.2f, -0.05f)
            for (i in 0 until 3) {
                val y = cy + (i - 1) * r * 0.30f
                c.drawLine(x0, y, x1, y, p)
                val oldStyle = p.style
                p.style = Paint.Style.FILL
                c.drawCircle(cx + kn[i] * r * 2f, y, r * 0.085f, p)
                p.style = oldStyle
            }
        } else {
            p.strokeWidth = r * 0.085f
            val y1 = cy - r * 0.17f
            val y2 = cy + r * 0.17f
            val x0 = cx - r * 0.4f
            val x1 = cx + r * 0.4f
            val a = r * 0.14f
            c.drawLine(x0, y1, x1, y1, p)
            c.drawLine(x1, y1, x1 - a, y1 - a, p)
            c.drawLine(x1, y1, x1 - a, y1 + a, p)
            c.drawLine(x1, y2, x0, y2, p)
            c.drawLine(x0, y2, x0 + a, y2 - a, p)
            c.drawLine(x0, y2, x0 + a, y2 + a, p)
        }
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f
        p.strokeCap = Paint.Cap.ROUND
        if (classic && (kind == GEAR || kind == TOGGLE || kind == THEME || kind == FLASH)) {
            // nút tròn tối bóng viền mảnh, biểu tượng nét mảnh (theo ảnh mẫu)
            drawRefButton(c, p, cx, cy, r, resources.displayMetrics.density)
            p.style = Paint.Style.STROKE
            p.color = if (Theme.light) 0xFF2A2A2E.toInt() else 0xFFEDEDF0.toInt()
            symbol(c, cx, cy, r * 0.93f)
        } else if (classic) {
            drawMetalKnob(c, p, cx, cy, r, resources.displayMetrics.density)
            // biểu tượng khắc chìm: nét sáng lệch xuống 1 chút + nét mực chính
            val off = 0.9f * resources.displayMetrics.density
            p.style = Paint.Style.STROKE
            c.save()
            c.translate(0f, off)
            p.color = if (Theme.light) 0xCCFFFFFF.toInt() else 0x55000000
            symbol(c, cx, cy, r * 0.93f)
            c.restore()
            p.color = if (Theme.light) 0xFF3A3A40.toInt() else 0xFFF1F1F4.toInt()
            symbol(c, cx, cy, r * 0.93f)
        } else if (kind == GEAR || kind == TOGGLE || kind == FLASH) {
            // ngắm rộng: biểu tượng trần nét mảnh, không nền (theo ảnh mẫu)
            p.style = Paint.Style.STROKE
            p.color = Color.WHITE
            symbol(c, cx, cy, r * 1.15f)
        } else {
            drawGlassDisc(c, p, cx, cy, r * 0.95f, resources.displayMetrics.density)
            p.style = Paint.Style.STROKE
            p.color = Theme.ink
            symbol(c, cx, cy, r)
        }
    }
}

/**
 * Tấm phủ xám phẳng của hiệu ứng màn trập (đo từ video mẫu): sau khi giữ ảnh âm bản ~1s,
 * xám phủ kín trong 0,2s rồi tan dần trong 0,6s để lộ ảnh.
 */
class ShutterFxView(ctx: Context) : View(ctx) {
    private var greyAlpha = 0f
    private var anim: ValueAnimator? = null
    private val grey = Color.rgb(132, 131, 134)

    override fun onDraw(c: Canvas) {
        if (greyAlpha > 0f) c.drawColor((grey and 0x00FFFFFF) or ((greyAlpha * 255).toInt().coerceIn(0, 255) shl 24))
    }

    private fun run(from: Float, to: Float, ms: Long, ip: android.view.animation.Interpolator, end: () -> Unit) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(from, to).apply {
            duration = ms
            interpolator = ip
            addUpdateListener { greyAlpha = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) { if (!cancelled) end() }
            })
            start()
        }
    }

    fun greyIn(ms: Long, onFull: () -> Unit) =
        run(0f, 1f, ms, android.view.animation.LinearInterpolator(), onFull)

    fun greyOut(ms: Long, onDone: () -> Unit) =
        run(1f, 0f, ms, android.view.animation.AccelerateDecelerateInterpolator(), onDone)

    fun reset() {
        anim?.cancel()
        greyAlpha = 0f
        invalidate()
    }
}

/**
 * Hiệu ứng "ảnh lưu về máy" (theo video): ảnh vừa chụp thu nhỏ rất nhanh (giảm tốc) từ khung ngắm
 * về ô thumbnail ở góc dưới phải, bo góc dần và chuyển từ khung rộng sang vuông.
 */
class SaveFlyView(ctx: Context) : View(ctx) {
    private var bmp: Bitmap? = null
    private val from = RectF()
    private val to = RectF()
    private val cur = RectF()
    private val src = android.graphics.Rect()
    private val clip = Path()
    private var t = 0f
    private var anim: ValueAnimator? = null
    private val dn = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
    }
    private val fade = Paint()
    /** true: giữ viền mờ + bo góc như khung ngắm lúc đầu rồi mất dần khi thu về thumbnail. */
    var soft = false

    init { visibility = GONE }

    private fun lerp(a: Float, b: Float, f: Float) = a + (b - a) * f

    fun start(b: Bitmap, f: RectF, target: RectF, ms: Long, onEnd: () -> Unit) {
        anim?.cancel()
        bmp = b
        from.set(f)
        to.set(target)
        t = 0f
        visibility = VISIBLE
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms
            interpolator = android.view.animation.DecelerateInterpolator(1.8f)
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) {
                    visibility = GONE
                    bmp = null
                    if (!cancelled) onEnd()
                }
            })
            start()
        }
    }

    fun cancel() {
        anim?.cancel()
        visibility = GONE
        bmp = null
    }

    override fun onDraw(c: Canvas) {
        val b = bmp ?: return
        cur.set(lerp(from.left, to.left, t), lerp(from.top, to.top, t), lerp(from.right, to.right, t), lerp(from.bottom, to.bottom, t))
        val dw = cur.width()
        val dh = cur.height()
        if (dw < 1f || dh < 1f) return
        // cắt kiểu "cover" để khung chuyển dần từ chữ nhật rộng sang vuông mà không méo ảnh
        val sa = b.width.toFloat() / b.height
        val da = dw / dh
        if (sa > da) {
            val w = (b.height * da).toInt().coerceAtLeast(1)
            src.set((b.width - w) / 2, 0, (b.width + w) / 2, b.height)
        } else {
            val h = (b.width / da).toInt().coerceAtLeast(1)
            src.set(0, (b.height - h) / 2, b.width, (b.height + h) / 2)
        }
        val r = lerp(if (soft) 12f * dn else 7f * dn, 6f * dn, t)
        clip.reset()
        clip.addRoundRect(cur, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        c.drawBitmap(b, src, cur, p)
        val k = ((1f - t) * 255).toInt()
        if (soft && k > 0) {
            val e = k shl 24
            val z = 0
            val fx = cur.width() * 0.009f
            val fy = cur.height() * 0.03f
            fade.shader = LinearGradient(cur.left, 0f, cur.left + fx, 0f, e, z, Shader.TileMode.CLAMP)
            c.drawRect(cur.left, cur.top, cur.left + fx, cur.bottom, fade)
            fade.shader = LinearGradient(cur.right, 0f, cur.right - fx, 0f, e, z, Shader.TileMode.CLAMP)
            c.drawRect(cur.right - fx, cur.top, cur.right, cur.bottom, fade)
            fade.shader = LinearGradient(0f, cur.top, 0f, cur.top + fy, e, z, Shader.TileMode.CLAMP)
            c.drawRect(cur.left, cur.top, cur.right, cur.top + fy, fade)
            fade.shader = LinearGradient(0f, cur.bottom, 0f, cur.bottom - fy, e, z, Shader.TileMode.CLAMP)
            c.drawRect(cur.left, cur.bottom - fy, cur.right, cur.bottom, fade)
            fade.shader = null
        }
        c.restore()
        edge.strokeWidth = 2f * dn
        edge.alpha = (0x99 * t).toInt()
        c.drawRoundRect(cur, r, r, edge)
    }
}


class LensFxNode(val title: String, val sub: String, val ratio: String, val eq: Float)

/**
 * Hiệu ứng chuyển ống kính: làm mờ khung ngắm, thanh nối Ultra Wide → Wide → Telephoto với vòng cam
 * chạy từ ống kính cũ sang mới, hình nón góc nhìn (FOV) co/giãn theo tiêu cự, và tên ống kính đổi chéo.
 */
class LensSwitchView(ctx: Context) : View(ctx) {
    /** false = giao diện toàn màn: phủ viền đen mờ/bo góc lên ảnh để không lộ cạnh vuông khi chuyển ống kính. */
    var classic: Boolean = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dn = resources.displayMetrics.density
    private var nodes: List<LensFxNode> = emptyList()
    private var from = 0
    private var to = 0
    private var sharp: Bitmap? = null
    private var blur: Bitmap? = null
    private var bgFilter: ColorFilter? = null
    private var blurA = 0f
    private var prog = 0f
    /** Độ đậm của lớp ảnh đóng băng/mờ phía sau (1 = che hết, 0 = lộ hẳn khung ngắm thật của ống kính mới). */
    private var bgA = 1f
    private var completing = false
    private var anim: ValueAnimator? = null
    private var blurAnim: ValueAnimator? = null
    private var bgAnim: ValueAnimator? = null
    /** Độ đậm của cụm hiệu ứng (thanh ống kính, hình nón FOV, tên): rõ dần khi vào, mờ dần khi ra. */
    private var uiA = 0f
    private var uiInAnim: ValueAnimator? = null
    private var uiOutAnim: ValueAnimator? = null
    private val argb = ArgbEvaluator()
    private val cone = Path()

    private fun d(v: Float) = v * dn

    fun start(n: List<LensFxNode>, fromIdx: Int, toIdx: Int, frame: Bitmap?, filter: ColorFilter?, expectMs: Long = 500L) {
        animate().cancel()
        anim?.cancel()
        blurAnim?.cancel()
        bgAnim?.cancel()
        uiInAnim?.cancel()
        uiOutAnim?.cancel()
        completing = false
        bgA = 1f
        uiA = 0f
        nodes = n
        from = fromIdx.coerceIn(0, (n.size - 1).coerceAtLeast(0))
        to = toIdx.coerceIn(0, (n.size - 1).coerceAtLeast(0))
        sharp = frame
        blur = frame?.let { makeBlur(it) }
        bgFilter = filter
        blurA = 0f
        prog = 0f
        alpha = 1f
        visibility = VISIBLE
        blurAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 110
            addUpdateListener { blurA = it.animatedValue as Float; invalidate() }
            start()
        }
        // cụm hiệu ứng rõ dần (không bật cái vụt)
        uiInAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 220
            interpolator = DecelerateInterpolator(1.4f)
            addUpdateListener { uiA = it.animatedValue as Float; invalidate() }
            start()
        }
        // chuyển động trải đều theo độ trễ thực của camera (đo từ lần trước) tới ~90%, để lúc camera mới có hình thì hiệu ứng
        // đang chạy gần xong; complete() chạy nốt phần còn lại cùng lúc lộ khung ngắm mới
        anim = ValueAnimator.ofFloat(0f, 0.9f).apply {
            duration = (expectMs - 170L).coerceIn(220L, 900L)
            startDelay = 20
            interpolator = DecelerateInterpolator(1.3f)
            addUpdateListener { prog = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    /**
     * Camera mới đã sẵn sàng: hoàn tất chuyển động (thanh trượt, hình nón FOV, tên ống kính) VÀ đồng thời mờ dần lớp ảnh
     * đóng băng để lộ khung ngắm thật, nên ống kính mới hiện ra ngay trong lúc hiệu ứng còn chạy chứ không đợi hiệu ứng kết thúc.
     */
    fun complete() {
        if (completing || visibility != VISIBLE) return
        completing = true
        anim?.cancel()
        uiInAnim?.cancel()
        // cụm hiệu ứng mờ dần MƯỢT đúng lúc đang hoàn tất chuyển động, thay vì giữ nguyên rồi tắt phụt
        uiOutAnim?.cancel()
        uiOutAnim = ValueAnimator.ofFloat(uiA, 0f).apply {
            duration = 420
            startDelay = 90
            interpolator = android.view.animation.AccelerateDecelerateInterpolator()
            addUpdateListener { uiA = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) {
                    if (cancelled) return
                    visibility = GONE
                    sharp = null
                    blur = null
                    alpha = 1f
                }
            })
            start()
        }
        anim = ValueAnimator.ofFloat(prog, 1f).apply {
            duration = 260
            interpolator = DecelerateInterpolator()
            addUpdateListener { prog = it.animatedValue as Float; invalidate() }
            start()
        }
        bgAnim?.cancel()
        bgAnim = ValueAnimator.ofFloat(bgA, 0f).apply {
            duration = 170
            addUpdateListener { bgA = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun hide() {
        if (completing) return   // đang mờ dần theo animation riêng của complete()
        animate().alpha(0f).setDuration(120).withEndAction {
            visibility = GONE
            sharp = null
            blur = null
            alpha = 1f
        }.start()
    }

    private fun makeBlur(src: Bitmap): Bitmap {
        val sw = max(16, src.width / 16)
        val sh = max(8, src.height / 16)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        repeat(3) { boxBlur(px, sw, sh, 2) }
        val out = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, sw, 0, 0, sw, sh)
        return out
    }

    private fun boxBlur(px: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(px.size)
        for (y in 0 until h) for (x in 0 until w) {
            var rr = 0; var g = 0; var b = 0; var cnt = 0
            for (k in -r..r) {
                val c = px[y * w + (x + k).coerceIn(0, w - 1)]
                rr += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255; cnt++
            }
            tmp[y * w + x] = (0xFF shl 24) or ((rr / cnt) shl 16) or ((g / cnt) shl 8) or (b / cnt)
        }
        for (y in 0 until h) for (x in 0 until w) {
            var rr = 0; var g = 0; var b = 0; var cnt = 0
            for (k in -r..r) {
                val c = tmp[(y + k).coerceIn(0, h - 1) * w + x]
                rr += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255; cnt++
            }
            px[y * w + x] = (0xFF shl 24) or ((rr / cnt) shl 16) or ((g / cnt) shl 8) or (b / cnt)
        }
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
    private fun mix(a: Int, b: Int, t: Float) = argb.evaluate(t.coerceIn(0f, 1f), a, b) as Int

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rect = RectF(0f, 0f, w, h)
        p.style = Paint.Style.FILL
        p.colorFilter = bgFilter
        sharp?.let { p.alpha = ((1f - blurA) * bgA * 255).toInt(); c.drawBitmap(it, null, rect, p) }
        blur?.let { p.alpha = (blurA * bgA * 255).toInt(); c.drawBitmap(it, null, rect, p) }
        p.colorFilter = null
        p.alpha = 255
        p.color = Color.argb((blurA * bgA * 120).toInt(), 0, 0, 0)
        c.drawRect(rect, p)
        if (!classic) drawEdgeFade(c, p, w, h)
        p.style = Paint.Style.FILL
        if (nodes.isEmpty()) return

        // thu nhỏ cả cụm hiệu ứng và dời lên trên để không bị các nút tiêu cự (14/23/60mm) đè lên
        c.save()
        c.scale(0.62f, 0.62f, w / 2f, h * 0.30f)

        val n = nodes.size
        val ep = prog
        val cx = w / 2f
        val trackY = h * 0.60f
        val gap = min(w * 0.2f, d(120f))
        fun nx(i: Int) = cx + (i - (n - 1) / 2f) * gap
        val pos = lerp(nx(from), nx(to), ep)
        val ui = uiA

        // đường thanh
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = d(2f)
        p.color = Color.argb((90 * ui).toInt(), 255, 255, 255)
        c.drawLine(nx(0), trackY, nx(n - 1), trackY, p)
        p.color = Color.argb((255 * ui).toInt(), 244, 123, 32)
        c.drawLine(nx(from), trackY, pos, trackY, p)

        // các nút ống kính
        p.textAlign = Paint.Align.CENTER
        for (i in 0 until n) {
            val act = (1f - abs(pos - nx(i)) / gap).coerceIn(0f, 1f)
            val r = d(9f) + d(5f) * act
            p.style = Paint.Style.FILL
            p.color = Color.argb((200 * ui).toInt(), 16, 16, 16)
            c.drawCircle(nx(i), trackY, r, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(2f)
            p.color = (mix(0xFFFFFFFF.toInt(), ORANGE, act) and 0x00FFFFFF) or ((255 * ui).toInt() shl 24)
            c.drawCircle(nx(i), trackY, r, p)
            p.style = Paint.Style.FILL
            p.typeface = Typeface.DEFAULT_BOLD
            p.textSize = h * 0.042f + h * 0.01f * act
            p.color = (mix(0xFFFFFFFF.toInt(), ORANGE, act) and 0x00FFFFFF) or ((255 * ui).toInt() shl 24)
            c.drawText(nodes[i].ratio + "×", nx(i), trackY + r + h * 0.065f, p)
        }

        // vòng cam di chuyển + quầng sáng
        p.style = Paint.Style.FILL
        for (k in 3 downTo 1) {
            p.color = Color.argb((38 * ui).toInt(), 244, 123, 32)
            c.drawCircle(pos, trackY, d(12f) + d(8f) * k, p)
        }
        p.color = Color.argb((255 * ui).toInt(), 244, 123, 32)
        c.drawCircle(pos, trackY, d(7f), p)

        // hình nón góc nhìn (FOV) co giãn theo tiêu cự
        val aFrom = atan(18f / nodes[from].eq.coerceAtLeast(1f))
        val aTo = atan(18f / nodes[to].eq.coerceAtLeast(1f))
        val a = lerp(aFrom, aTo, ep)
        val deg = Math.toDegrees(a.toDouble()).toFloat()
        val apexY = h * 0.47f
        val len = h * 0.22f
        val lx = cx - len * sin(a)
        val rx = cx + len * sin(a)
        val ty = apexY - len * cos(a)
        val arc = RectF(cx - len, apexY - len, cx + len, apexY + len)
        cone.reset()
        cone.moveTo(cx, apexY)
        cone.lineTo(lx, ty)
        cone.arcTo(arc, -90f - deg, 2f * deg)
        cone.close()
        p.style = Paint.Style.FILL
        p.color = Color.argb((45 * ui).toInt(), 244, 123, 32)
        c.drawPath(cone, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(2f)
        p.color = Color.argb((230 * ui).toInt(), 255, 255, 255)
        c.drawLine(cx, apexY, lx, ty, p)
        c.drawLine(cx, apexY, rx, ty, p)
        p.color = Color.argb((255 * ui).toInt(), 244, 123, 32)
        p.strokeWidth = d(2.6f)
        c.drawArc(arc, -90f - deg, 2f * deg, false, p)
        p.style = Paint.Style.FILL
        p.color = Color.argb((255 * ui).toInt(), 255, 255, 255)
        c.drawCircle(cx, apexY, d(4f), p)

        // tên ống kính: đổi chéo giữa cũ và mới
        val fromA = (1f - ((ep - 0.30f) * 4f)).coerceIn(0f, 1f)
        val toA = ((ep - 0.40f) * 4f).coerceIn(0f, 1f)
        p.style = Paint.Style.FILL
        p.typeface = Typeface.DEFAULT_BOLD
        p.letterSpacing = 0.12f
        p.textSize = h * 0.07f
        p.color = Color.argb((255 * fromA * ui).toInt(), 255, 255, 255)
        c.drawText(nodes[from].title, cx, h * 0.84f, p)
        p.color = Color.argb((255 * toA * ui).toInt(), 255, 255, 255)
        c.drawText(nodes[to].title, cx, h * 0.84f, p)
        p.letterSpacing = 0f
        p.typeface = Typeface.DEFAULT
        p.textSize = h * 0.045f
        p.color = Color.argb((230 * fromA * ui).toInt(), 204, 204, 204)
        c.drawText(nodes[from].sub, cx, h * 0.93f, p)
        p.color = Color.argb((230 * toA * ui).toInt(), 204, 204, 204)
        c.drawText(nodes[to].sub, cx, h * 0.93f, p)
        c.restore()
    }
}

/** Màn hình xem lại: nền trắng, chữ HASSELBLAD, ảnh và thông số máy. */
class ReviewView(ctx: Context) : FrameLayout(ctx) {
    private val img = ImageView(ctx)
    var onClose: (() -> Unit)? = null
    var onSaveFrame: (() -> Unit)? = null
    var onOpen: (() -> Unit)? = null

    init {
        val dn = resources.displayMetrics.density
        setBackgroundColor(Color.WHITE)
        isClickable = true
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        addView(img, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        fun btn(t: String, a: () -> Unit) {
            val tv = TextView(ctx)
            tv.text = t
            tv.textSize = 13f
            tv.setTextColor(0xFF333333.toInt())
            tv.setPadding((12 * dn).toInt(), (8 * dn).toInt(), (12 * dn).toInt(), (8 * dn).toInt())
            tv.setOnClickListener { a() }
            tv.pressFeedback(0.9f, false)
            row.addView(tv)
        }
        btn("Lưu ảnh khung") { onSaveFrame?.invoke() }
        btn("Thư viện") { onOpen?.invoke() }
        btn("✕") { onClose?.invoke() }
        val lp = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END)
        lp.setMargins(0, (6 * dn).toInt(), (10 * dn).toInt(), 0)
        addView(row, lp)
        visibility = GONE
    }

    private var openAnim: ValueAnimator? = null

    /** Mở như video: giao diện máy ảnh tối dần về đen (0,33s) rồi thẻ ảnh sáng lên từ đen sang trắng (0,4s). */
    fun show(b: android.graphics.Bitmap) {
        openAnim?.cancel()
        img.setImageBitmap(b)
        img.alpha = 0f
        setBackgroundColor(Color.BLACK)
        alpha = 0f
        visibility = VISIBLE
        val ev = ArgbEvaluator()
        openAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 760
            addUpdateListener {
                val f = it.animatedValue as Float
                val k = 330f / 760f
                if (f < k) {
                    alpha = f / k
                } else {
                    alpha = 1f
                    val g = ((f - k) / (1f - k)).coerceIn(0f, 1f)
                    setBackgroundColor(ev.evaluate(g, Color.BLACK, Color.WHITE) as Int)
                    img.alpha = g
                }
            }
            start()
        }
    }

    fun hide() {
        openAnim?.cancel()
        visibility = GONE
        alpha = 1f
        img.alpha = 1f
        setBackgroundColor(Color.WHITE)
        img.setImageDrawable(null)
    }
}

/**
 * Một ô trong khay bộ lọc dọc: ảnh xem trước (đã áp bộ lọc) bo góc, nhãn xoay dọc bên phải,
 * viền cam khi đang chọn, thẻ cam nhỏ (nếu có) dán sát mép phải ảnh.
 */
class FilterItemView(ctx: Context) : XView(ctx) {
    var name: String = ""
        set(v) { field = v; invalidate() }
    /** Nhãn phụ xoay dọc bên phải ô (tên tiếng Việt / "Của tôi"). */
    var caption: String = ""
        set(v) { field = v; invalidate() }
    var badge: String? = null
    var selectedItem: Boolean = false
        set(v) { field = v; invalidate() }
    /** Chỉ dùng để chọn màu nhấn cho ô; không còn xem trước ảnh thật (tránh lag). */
    var filter: XpanFilter = XpanFilter.all[0]
        set(v) { field = v; invalidate() }

    private val bez = RectF()
    private val scr = RectF()
    private val bar = RectF()
    private val clip = Path()

    init { isClickable = true }

    private val tw get() = d(68f)
    private val th get() = d(48f)

    /** Hai màu vệt trên/dưới của ô, gợi tính chất từng bộ lọc (như ô minh hoạ trong ảnh mẫu). */
    private fun accents(): IntArray = when (name) {
        "Original" -> intArrayOf(0xFFFF9A2E.toInt(), 0xFF3C8DFF.toInt())
        "Natural" -> intArrayOf(0xFF7FD6A0.toInt(), 0xFF4FA3C7.toInt())
        "Portrait" -> intArrayOf(0xFFFFB199.toInt(), 0xFFF06D8B.toInt())
        "Landscape" -> intArrayOf(0xFF8BE04E.toInt(), 0xFF2EB8E6.toInt())
        "XPan Chrome" -> intArrayOf(0xFF3CD6C0.toInt(), 0xFF2E86C1.toInt())
        "Golden Hour" -> intArrayOf(0xFFFFC23C.toInt(), 0xFFFF6A2E.toInt())
        "Mono" -> intArrayOf(0xFFE6E6E6.toInt(), 0xFF8A8A90.toInt())
        "Fuji Film" -> intArrayOf(0xFF5BC85B.toInt(), 0xFFE8554D.toInt())
        "Leica M9" -> intArrayOf(0xFFE5322D.toInt(), 0xFFD9D2C5.toInt())
        "Vivo Zeiss" -> intArrayOf(0xFF4DA3FF.toInt(), 0xFFBFEFFF.toInt())
        else -> intArrayOf(ORANGE, 0xFFFFD2A1.toInt())
    }

    private fun stripe(c: Canvas, cx: Float, y: Float, wd: Float, hh: Float, col: Int) {
        bar.set(cx - wd / 2f, y, cx + wd / 2f, y + hh)
        p.shader = LinearGradient(bar.left, 0f, bar.right, 0f, intArrayOf(0x00FFFFFF and col, col, col, 0x00FFFFFF and col), floatArrayOf(0f, 0.25f, 0.75f, 1f), Shader.TileMode.CLAMP)
        c.drawRoundRect(bar, hh / 2f, hh / 2f, p)
        p.shader = null
    }

    override fun onDraw(c: Canvas) {
        val left = d(4f)
        val top = (height - th) / 2f
        bez.set(left, top, left + tw, top + th)
        val rb = d(10f)

        // khung bezel đen bóng
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, bez.top, 0f, bez.bottom, 0xFF47474C.toInt(), 0xFF111113.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(bez, rb, rb, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1f)
        p.shader = LinearGradient(0f, bez.top, 0f, bez.bottom, 0x88FFFFFF.toInt(), 0x14FFFFFF, Shader.TileMode.CLAMP)
        c.drawRoundRect(bez.left + d(0.5f), bez.top + d(0.5f), bez.right - d(0.5f), bez.bottom - d(0.5f), rb, rb, p)
        p.shader = null

        // mặt kính tối vẽ tĩnh (không xem trước ảnh thật)
        val ins = d(3.5f)
        scr.set(bez.left + ins, bez.top + ins, bez.right - ins, bez.bottom - ins)
        val rs = d(7f)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, scr.top, 0f, scr.bottom, 0xFF2E2E33.toInt(), 0xFF09090B.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(scr, rs, rs, p)
        p.shader = null
        c.save()
        clip.reset()
        clip.addRoundRect(scr, rs, rs, Path.Direction.CW)
        c.clipPath(clip)
        // vệt màu nhấn trên và dưới
        val ac = accents()
        stripe(c, scr.centerX(), scr.top + d(5f), scr.width() * 0.8f, d(2.4f), ac[0])
        stripe(c, scr.centerX(), scr.bottom - d(7.4f), scr.width() * 0.8f, d(2.4f), ac[1])
        // vệt bóng kính nửa trên
        p.shader = LinearGradient(0f, scr.top, 0f, scr.centerY(), 0x30FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP)
        c.drawRect(scr.left, scr.top, scr.right, scr.centerY(), p)
        p.shader = null
        c.restore()

        // tên bộ lọc in trên ô
        p.typeface = Typeface.DEFAULT_BOLD
        p.textAlign = Paint.Align.CENTER
        p.color = Color.WHITE
        val maxW = scr.width() - d(8f)
        var ts = d(12f)
        p.textSize = ts
        while (p.measureText(name) > maxW && ts > d(8.5f)) { ts -= d(0.5f); p.textSize = ts }
        val cx = scr.centerX()
        val cy = scr.centerY()
        if (p.measureText(name) > maxW && name.contains(' ')) {
            val i = name.indexOf(' ')
            p.textSize = d(9.5f)
            val fm = p.fontMetrics
            val lh = p.fontSpacing
            c.drawText(name.substring(0, i), cx, cy - lh / 2f - (fm.ascent + fm.descent) / 2f, p)
            c.drawText(name.substring(i + 1), cx, cy + lh / 2f - (fm.ascent + fm.descent) / 2f, p)
        } else {
            val fm = p.fontMetrics
            c.drawText(name, cx, cy - (fm.ascent + fm.descent) / 2f, p)
        }

        // viền cam bao ngoài ô đang chọn
        if (selectedItem) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(2f)
            p.color = ORANGE
            val o = d(3f)
            c.drawRoundRect(bez.left - o, bez.top - o, bez.right + o, bez.bottom + o, rb + o, rb + o, p)
            p.style = Paint.Style.FILL
        }

        // nhãn phụ xoay dọc bên phải ô
        if (caption.isNotEmpty()) {
            p.typeface = if (selectedItem) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            p.textAlign = Paint.Align.CENTER
            p.color = if (selectedItem) ORANGE else (if (Theme.light) 0xFF55555A.toInt() else 0xCCFFFFFF.toInt())
            var cs = d(11f)
            p.textSize = cs
            val maxLen = th
            while (p.measureText(caption) > maxLen && cs > d(7.5f)) { cs -= d(0.5f); p.textSize = cs }
            val fm = p.fontMetrics
            c.save()
            c.translate(bez.right + d(11f), bez.centerY())
            c.rotate(90f)
            c.drawText(caption, 0f, -(fm.ascent + fm.descent) / 2f, p)
            c.restore()
        }
        p.typeface = Typeface.DEFAULT
    }

    companion object {
        /** Kích thước ô theo dp: rộng x cao. */
        const val W_DP = 100f
        const val H_DP = 62f
    }
}

/** Nhóm view không tự sắp xếp con: CameraLayout đặt vị trí trực tiếp, nhóm này chỉ để thu nhỏ cả giao diện khi mở ngăn kéo. */
class RawGroup(ctx: Context) : ViewGroup(ctx) {
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {}
}

/**
 * Ngăn kéo bộ lọc bên phải (theo ảnh mẫu): nền tối lõm, thanh nắm ở mép, và tab "XPAN ×" nhô ra bên trái để đóng.
 * Phần thân (tab + panel) chặn chạm để không lọt xuống khung ngắm phía sau.
 */
class DrawerView(ctx: Context) : View(ctx) {
    var onTab: (() -> Unit)? = null
    /** Giữ lâu nút XPAN: mở bảng chọn dấu chìm. */
    var onTabLong: (() -> Unit)? = null
    private val dn = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tab = RectF()
    private val path = Path()
    /** Đã bỏ tab XPAN × nhô ra: ngăn kéo chỉ còn thân panel (mở bằng nút bộ lọc, chạm ra ngoài để đóng). */
    val tabW get() = 0f
    private val showTab = false

    private fun layoutTab() {
        val h = height.toFloat()
        val th = min(h * 0.3f, 150f * dn)
        val cy = h * 0.47f
        tab.set(0f, cy - th / 2f, tabW + 3f * dn, cy + th / 2f)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pl = tabW
        val light = Theme.light
        layoutTab()
        // thân panel
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, 0f, 0f, h,
            if (light) intArrayOf(0xFFEDEDF0.toInt(), 0xFFDCDCE1.toInt()) else intArrayOf(0xFF1D1D20.toInt(), 0xFF101012.toInt()),
            null, Shader.TileMode.CLAMP
        )
        c.drawRect(pl, 0f, w, h, p)
        // bóng lõm ở mép trái
        p.shader = LinearGradient(pl, 0f, pl + 16f * dn, 0f, if (light) 0x30000000 else 0x66000000, 0x00000000, Shader.TileMode.CLAMP)
        c.drawRect(pl, 0f, pl + 16f * dn, h, p)
        p.shader = null
        p.color = if (light) 0x33000000 else 0x30FFFFFF
        c.drawRect(pl, 0f, pl + 1f * dn, h, p)
        // thanh nắm
        p.color = 0xA6FFFFFF.toInt()
        c.drawRoundRect(pl + 9f * dn, h * 0.47f - 17f * dn, pl + 12f * dn, h * 0.47f + 17f * dn, 2f * dn, 2f * dn, p)

        if (showTab) {
        // tab nhô ra bên trái
        val r = 12f * dn
        path.reset()
        path.addRoundRect(tab, floatArrayOf(r, r, 0f, 0f, 0f, 0f, r, r), Path.Direction.CW)
        p.shader = LinearGradient(tab.left, 0f, tab.right, 0f, 0xFF232326.toInt(), 0xFF141416.toInt(), Shader.TileMode.CLAMP)
        c.drawPath(path, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f * dn
        p.color = 0x33FFFFFF
        c.drawPath(path, p)
        p.style = Paint.Style.FILL
        // dấu ×
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT
        p.textSize = 15f * dn
        p.color = 0xCCFFFFFF.toInt()
        val fm0 = p.fontMetrics
        c.drawText("×", tabW / 2f, tab.top + 20f * dn - (fm0.ascent + fm0.descent) / 2f, p)
        // chữ XPAN xoay dọc
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        p.textSize = 12f * dn
        p.letterSpacing = 0.12f
        p.color = ORANGE
        val fm = p.fontMetrics
        c.save()
        c.translate(tabW / 2f, tab.centerY() + 12f * dn)
        c.rotate(-90f)
        c.drawText("XPAN", 0f, -(fm.ascent + fm.descent) / 2f, p)
        c.restore()
        }
        p.letterSpacing = 0f
        p.typeface = Typeface.DEFAULT
    }

    private var tabDown = false
    private var longFired = false
    private val longRun = Runnable {
        if (tabDown) {
            longFired = true
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            onTabLong?.invoke()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        layoutTab()
        val inTab = showTab && e.x >= tab.left - 6f * dn && e.x <= tab.right + 6f * dn && e.y >= tab.top - 6f * dn && e.y <= tab.bottom + 6f * dn
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (inTab) {
                    tabDown = true
                    longFired = false
                    removeCallbacks(longRun)
                    postDelayed(longRun, 450)
                    return true
                }
                tabDown = false
                return e.x >= tabW      // chạm vào panel thì chặn, chạm vùng trống bên trái tab thì cho lọt xuống
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRun)
                if (tabDown && inTab && !longFired) {
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    onTab?.invoke()
                }
                tabDown = false
            }
            MotionEvent.ACTION_CANCEL -> { removeCallbacks(longRun); tabDown = false }
        }
        return true
    }
}

/** Hiệu ứng màn chập: khung ngắm tối đen NGAY khi bấm, giữ một nhịp ngắn rồi sáng lại (~0,17s) — như màn trập che cảm biến. */
class CurtainView(ctx: Context) : View(ctx) {
    private var prog = -1f
    private var anim: ValueAnimator? = null

    fun fire() {
        anim?.cancel()
        prog = 0f
        invalidate()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 170
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { prog = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: android.animation.Animator) { prog = -1f; invalidate() }
                override fun onAnimationCancel(a: android.animation.Animator) { prog = -1f }
            })
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        if (prog < 0f) return
        // đen kịt ở 35% đầu, sau đó sáng lại nhanh
        val a = if (prog < 0.35f) 1f else 1f - (prog - 0.35f) / 0.65f
        c.drawColor(((a.coerceIn(0f, 1f) * 255).toInt() shl 24) or 0x040404)
    }
}


/**
 * Hiệu ứng riêng của chế độ HQ ghép 5 khung. Khung ngắm đóng băng + nhoè; khung ngắm 65:24 không có lưới 3×3 nên chia thành 5 CỘT
 * đúng bằng 5 khung: mỗi khung chụp xong thì một cột rõ nét lên. Sau đó là pha ghép: dải sáng quét qua, thanh tiến trình + % ,
 * rồi ảnh kết quả quét từ trái sang phải thay cho khung nhoè.
 */
class HqFxView(ctx: Context) : XView(ctx), MultiFx {
    companion object {
        const val COLS = 5
        /** Thứ tự cột rõ lên theo từng khung: giữa → trái kề → phải kề → trái ngoài cùng → phải ngoài cùng. */
        val ORDER = intArrayOf(2, 1, 3, 0, 4)
    }
    private var sharp: Bitmap? = null
    private var blur: Bitmap? = null
    private var mid: Bitmap? = null
    private var result: Bitmap? = null
    private val colProg = FloatArray(COLS)
    private val colAnims = arrayOfNulls<ValueAnimator>(COLS)
    private var captured = 0
    /** Số khung thật đã chụp xong (có thể nhiều hơn số cột khi UP chụp 9 khung). */
    private var shotN = 0
    private var total = COLS
    private var merging = false
    private var mergePct = 0f
    private var mergeTarget = 0f
    private var wipe = 0f
    private var shimmer = 0f
    private var ticker: ValueAnimator? = null
    private var wipeAnim: ValueAnimator? = null
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val src = Rect()
    private val dst = RectF()
    private val pill = RectF()

    init { visibility = GONE }

    private fun makeBlur(b: Bitmap, div: Int): Bitmap? = try {
        val q = Bitmap.createScaledBitmap(b, (b.width / 3).coerceAtLeast(16), (b.height / 3).coerceAtLeast(16), true)
        val small = Bitmap.createScaledBitmap(q, (b.width / div).coerceAtLeast(8), (b.height / div).coerceAtLeast(8), true)
        if (q !== b) q.recycle()
        small
    } catch (t: Throwable) { null }

    fun start(frozen: Bitmap, n: Int) {
        stop()
        sharp = frozen
        blur = makeBlur(frozen, 30)
        mid = makeBlur(frozen, 9)
        total = n
        visibility = VISIBLE
        alpha = 1f
        ticker = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1100
            repeatCount = ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener {
                shimmer = it.animatedValue as Float
                mergePct += (mergeTarget - mergePct) * 0.12f
                invalidate()
            }
            start()
        }
        invalidate()
    }

    /** Khung thứ n (1..total) đã chụp xong: cột tương ứng rõ nét lên. */
    override fun setCaptured(n: Int) {
        // số khung chụp có thể nhiều hơn 5 cột (UP: 9 khung): cột rõ lên theo tỉ lệ khung đã chụp
        val upto = if (total <= COLS) n.coerceAtMost(COLS) else ((n * COLS + total - 1) / total).coerceIn(0, COLS)
        for (idx in captured until upto) {
            val k = ORDER[idx]
            colAnims[k]?.cancel()
            colAnims[k] = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 380
                interpolator = DecelerateInterpolator(1.6f)
                addUpdateListener { colProg[k] = it.animatedValue as Float; invalidate() }
                start()
            }
        }
        captured = maxOf(captured, upto)
        shotN = maxOf(shotN, n)
        invalidate()
    }

    override fun beginMerge() { merging = true; mergeTarget = maxOf(mergeTarget, 0.02f); invalidate() }

    override fun setMerge(pct: Int) { merging = true; mergeTarget = (pct / 100f).coerceIn(0f, 1f) }

    /** Ghép xong: ảnh kết quả quét từ trái sang phải thay khung nhoè; xong thì gọi `done`. */
    override fun complete(res: Bitmap?, done: () -> Unit) {
        mergeTarget = 1f
        mergePct = 1f
        result = res
        wipeAnim?.cancel()
        if (res == null) { done(); return }
        wipeAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 420
            interpolator = android.view.animation.AccelerateDecelerateInterpolator()
            addUpdateListener { wipe = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) { if (!cancelled) done() }
            })
            start()
        }
    }

    override fun stop() {
        ticker?.cancel(); ticker = null
        wipeAnim?.cancel(); wipeAnim = null
        for (i in 0 until COLS) { colAnims[i]?.cancel(); colAnims[i] = null; colProg[i] = 0f }
        captured = 0; shotN = 0; merging = false; mergePct = 0f; mergeTarget = 0f; wipe = 0f
        sharp = null; blur?.recycle(); blur = null; mid?.recycle(); mid = null; result = null
        visibility = GONE
    }

    override fun onDraw(c: Canvas) {
        val s = sharp ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val bl = blur
        // 1) khung nhoè (nền) + hơi tối
        dst.set(0f, 0f, w, h)
        bp.alpha = 255
        if (bl != null) c.drawBitmap(bl, null, dst, bp) else c.drawBitmap(s, null, dst, bp)
        c.drawColor(0x40000000)
        // 2) mỗi khung đã chụp -> một cột rõ nét (kèm chớp sáng khi vừa hiện)
        for (k in 0 until COLS) {
            val a = colProg[k]
            if (a <= 0f) continue
            src.set(s.width * k / COLS, 0, s.width * (k + 1) / COLS, s.height)
            dst.set(w * k / COLS, 0f, w * (k + 1) / COLS, h)
            // mờ dần -> rõ dần theo 2 bậc: nhoè nặng -> nhoè nhẹ -> nét
            val md = mid
            if (md != null && a < 0.5f) {
                src.set(md.width * k / COLS, 0, md.width * (k + 1) / COLS, md.height)
                bp.alpha = (a * 2f * 255).toInt().coerceIn(0, 255)
                c.drawBitmap(md, src, dst, bp)
            } else {
                if (md != null) {
                    src.set(md.width * k / COLS, 0, md.width * (k + 1) / COLS, md.height)
                    bp.alpha = 255
                    c.drawBitmap(md, src, dst, bp)
                }
                src.set(s.width * k / COLS, 0, s.width * (k + 1) / COLS, s.height)
                bp.alpha = (((if (md != null) (a - 0.5f) * 2f else a)) * 255).toInt().coerceIn(0, 255)
                c.drawBitmap(s, src, dst, bp)
            }
            if (a < 1f) {
                p.style = Paint.Style.FILL; p.shader = null
                p.color = ((1f - a) * 70).toInt().coerceIn(0, 255) shl 24 or 0xFFFFFF
                c.drawRect(dst, p)
            }
        }
        bp.alpha = 255
        // 3) pha ghép: dải sáng quét qua các cột
        val res = result
        if (merging && res == null) {
            val bw = w * 0.22f
            val x = -bw + (w + bw) * shimmer
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(x, 0f, x + bw, 0f, intArrayOf(0x00FFFFFF, 0x30FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
            c.drawRect(x, 0f, x + bw, h, p)
            p.shader = null
        }
        // 4) ảnh kết quả quét từ trái sang phải
        if (res != null && wipe > 0f) {
            val x = w * wipe
            src.set(0, 0, (res.width * wipe).toInt().coerceAtLeast(1), res.height)
            dst.set(0f, 0f, x, h)
            c.drawBitmap(res, src, dst, bp)
            p.style = Paint.Style.FILL; p.shader = null
            p.color = 0xCCFFFFFF.toInt()
            c.drawRect(x - d(1f), 0f, x + d(1f), h, p)
        }
        // 5) vạch chia 5 cột + dấu cộng nhỏ + số khung
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(0.8f)
        p.color = 0x55FFFFFF
        for (k in 1 until COLS) c.drawLine(w * k / COLS, d(10f), w * k / COLS, h - d(10f), p)
        p.strokeWidth = d(1f)
        p.color = 0x99FFFFFF.toInt()
        val cr = d(4f)
        for (k in 1 until COLS) {
            val x = w * k / COLS
            c.drawLine(x - cr, h / 2f, x + cr, h / 2f, p)
            c.drawLine(x, h / 2f - cr, x, h / 2f + cr, p)
        }
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.textSize = d(10f)
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        for (k in 0 until COLS) {
            val order = ORDER.indexOf(k)          // cột này thuộc khung số mấy
            p.color = if (order < captured) ORANGE else 0x88FFFFFF.toInt()
            c.drawText((order + 1).toString(), w * (k + 0.5f) / COLS, h - d(16f), p)
        }
        p.typeface = Typeface.DEFAULT
        // 6) thanh tiến trình dưới đáy: chụp = 30% đầu, ghép = 70% còn lại
        val prog = if (res != null) 1f else if (!merging) captured.toFloat() / COLS * 0.3f else 0.3f + 0.7f * mergePct
        val bx0 = d(14f)
        val bx1 = w - d(14f)
        val by = h - d(8f)
        p.strokeCap = Paint.Cap.ROUND
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(2.5f)
        p.color = 0x33FFFFFF
        c.drawLine(bx0, by, bx1, by, p)
        p.color = ORANGE
        if (prog > 0.005f) c.drawLine(bx0, by, bx0 + (bx1 - bx0) * prog.coerceIn(0f, 1f), by, p)
        p.strokeCap = Paint.Cap.BUTT
        // 7) nhãn trạng thái phía trên
        val label = when {
            res != null -> "Hoàn tất"
            merging -> "Đang xử lí ${(mergePct * 100).toInt().coerceIn(0, 100)}%"
            else -> "Đang chụp $shotN/$total"
        }
        p.style = Paint.Style.FILL
        p.textSize = d(11f)
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        val badge = "LUNA Engine"
        val bwid = p.measureText(badge)
        val lw = p.measureText("  $label")
        val pw = bwid + lw + d(22f)
        val ph = d(22f)
        pill.set((w - pw) / 2f, d(12f), (w + pw) / 2f, d(12f) + ph)
        p.color = 0xB0101012.toInt()
        c.drawRoundRect(pill, ph / 2f, ph / 2f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = d(1f); p.color = 0x40FFFFFF
        c.drawRoundRect(pill, ph / 2f, ph / 2f, p)
        p.style = Paint.Style.FILL
        val fm = p.fontMetrics
        val ty = pill.centerY() - (fm.ascent + fm.descent) / 2f
        p.color = ORANGE
        c.drawText(badge, pill.left + d(11f), ty, p)
        p.color = Color.WHITE
        c.drawText("  $label", pill.left + d(11f) + bwid, ty, p)
        p.typeface = Typeface.DEFAULT
    }
}

/** Hiệu ứng chụp nhiều khung dùng chung giữa HQ (HqFxView) và thiếu sáng (NightFxView). */
interface MultiFx {
    fun setCaptured(n: Int)
    fun beginMerge()
    fun setMerge(pct: Int)
    fun complete(res: Bitmap?, done: () -> Unit)
    fun stop()
}

private fun moonPath(cx: Float, cy: Float, r: Float): Path {
    val moon = Path()
    moon.addCircle(cx, cy, r, Path.Direction.CW)
    val cut = Path()
    cut.addCircle(cx + r * 0.58f, cy - r * 0.38f, r * 0.86f, Path.Direction.CW)
    moon.op(cut, Path.Op.DIFFERENCE)
    return moon
}

/** Huy hiệu chế độ thiếu sáng: trăng + thời gian phơi sáng. Chạm để đổi vòng 3 → 5 → 8 → 10 giây. */
class NightBadgeView(ctx: Context) : XView(ctx) {
    private val box = RectF()
    private var down = false
    var secs: Int = 5
        set(v) { val ch = field != v; field = v; invalidate(); if (ch) pop(1.12f) }
    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val bw = min(w, d(64f))
        val bh = min(h, d(28f))
        box.set((w - bw) / 2f, (h - bh) / 2f, (w + bw) / 2f, (h + bh) / 2f)
        val light = Theme.light && classic
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = if (light) 0xFFFFFFFF.toInt() else if (classic) 0xFF111113.toInt() else 0x66000000
        c.drawRoundRect(box, bh / 2f, bh / 2f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1f)
        p.color = ORANGE
        c.drawRoundRect(box, bh / 2f, bh / 2f, p)
        // trăng lưỡi liềm
        p.style = Paint.Style.FILL
        p.color = ORANGE
        c.drawPath(moonPath(box.left + d(15f), box.centerY(), d(6.2f)), p)
        // thời gian
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        p.textSize = d(12.5f)
        p.textAlign = Paint.Align.LEFT
        p.color = if (light) 0xFF111114.toInt() else Color.WHITE
        val fm = p.fontMetrics
        c.drawText("${secs}s", box.left + d(27f), box.centerY() - (fm.ascent + fm.descent) / 2f, p)
        p.typeface = Typeface.DEFAULT
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true; invalidate()
                animate().cancel()
                animate().scaleX(0.9f).scaleY(0.9f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                down = false; invalidate()
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3.5f)).start()
            }
        }
        return super.onTouchEvent(e)
    }
}

/**
 * Hiệu ứng chụp thiếu sáng: khung xem trước đóng băng "sáng dần" như đang hiện ảnh, sao nhấp nháy, vòng đếm ngược
 * quanh số giây còn lại; hết giờ chuyển sang vòng xoay xử lí (% thật từ LUNA Night), rồi ảnh kết quả quét từ trái sang phải.
 */
class NightFxView(ctx: Context) : XView(ctx), MultiFx {
    private var frozen: Bitmap? = null
    private var result: Bitmap? = null
    private var secs = 5
    private var steady = false
    private var started = false
    private var startMs = 0L
    private var appearMs = 0L
    private var captured = 0
    private var shownCap = 0f
    private var estTotal = 0
    private var merging = false
    private var mergeMs = 0L
    private var mergePct = 0f
    private var mergeTarget = 0f
    private var finishU = 0f          // 0..1: vòng thu lại + dấu tích, sau đó ảnh kết quả quét ra
    private var stopping = false
    private var lastLeft = -1
    private var prevLeft = -1
    private var tickMs = 0L
    private var ticker: ValueAnimator? = null
    private var finishAnim: ValueAnimator? = null
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val sp = Paint(Paint.ANTI_ALIAS_FLAG)
    private val np = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        textAlign = Paint.Align.CENTER
    }
    private val dst = RectF()
    private val src = Rect()
    private val ring = RectF()
    private val pill = RectF()
    private val cm = ColorMatrix()
    private val chk = Path()
    private var vignette: Shader? = null
    private val glowO: Shader = unitGlow(0xFFF47B20.toInt())
    private val glowW: Shader = unitGlow(0xFFFFFFFF.toInt())
    private val tc = FloatArray(60) { Math.cos(Math.toRadians(-90.0 + it * 6.0)).toFloat() }
    private val ts = FloatArray(60) { Math.sin(Math.toRadians(-90.0 + it * 6.0)).toFloat() }
    // bụi sáng: x, y, tốc độ trôi lên, pha nhấp nháy, cỡ
    private val dust = FloatArray(40 * 5).also { a ->
        val r = java.util.Random(11)
        for (i in 0 until 40) {
            a[i * 5] = r.nextFloat(); a[i * 5 + 1] = r.nextFloat()
            a[i * 5 + 2] = 0.004f + r.nextFloat() * 0.012f
            a[i * 5 + 3] = r.nextFloat() * 6.28f
            a[i * 5 + 4] = 0.8f + r.nextFloat() * 1.6f
        }
    }

    /** Mỗi khi số giây còn lại đổi trong lúc phơi sáng (để phát tiếng tích tắc). */
    var onSecond: (() -> Unit)? = null

    init {
        visibility = GONE
        np.setShadowLayer(6f, 0f, 2f, 0xAA000000.toInt())
    }

    private fun unitGlow(color: Int): Shader =
        RadialGradient(0f, 0f, 1f, intArrayOf(color, color and 0x00FFFFFF), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP)

    private fun ca(color: Int, mul: Float): Int {
        val a = ((color ushr 24) * mul.coerceIn(0f, 1f)).toInt()
        return (a shl 24) or (color and 0xFFFFFF)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w > 0 && h > 0) {
            val rad = Math.hypot(w.toDouble(), h.toDouble()).toFloat() / 2f
            vignette = RadialGradient(
                w / 2f, h / 2f, rad,
                intArrayOf(0x00000000, 0x00000000, 0xB8000000.toInt()), floatArrayOf(0f, 0.42f, 1f), Shader.TileMode.CLAMP
            )
        }
    }

    fun start(frozenBmp: Bitmap, seconds: Int, isSteady: Boolean) {
        stop()
        frozen = frozenBmp
        secs = seconds
        steady = isSteady
        visibility = VISIBLE
        alpha = 1f
        appearMs = SystemClock.uptimeMillis()
        ticker = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            repeatCount = ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener {
                mergePct += (mergeTarget - mergePct) * 0.12f
                shownCap += (captured - shownCap) * 0.25f
                if (started && !merging) {
                    val left = Math.ceil(max(0.0, secs - (SystemClock.uptimeMillis() - startMs) / 1000.0)).toInt()
                    if (left != lastLeft) {
                        prevLeft = lastLeft
                        lastLeft = left
                        tickMs = SystemClock.uptimeMillis()
                        if (left in 1 until secs) onSecond?.invoke()
                    }
                }
                invalidate()
            }
            start()
        }
        invalidate()
    }

    /** Camera đã bắt đầu phơi sáng thật (sau lấy nét): đồng hồ đếm ngược chạy từ đây. */
    fun startClock(total: Int) {
        started = true
        startMs = SystemClock.uptimeMillis()
        estTotal = total
        lastLeft = secs
        prevLeft = -1
        tickMs = 0L
        invalidate()
    }

    fun setStopping() { stopping = true; invalidate() }

    override fun setCaptured(n: Int) { captured = n; invalidate() }
    override fun beginMerge() {
        if (!merging) { merging = true; mergeMs = SystemClock.uptimeMillis() }
        mergeTarget = max(mergeTarget, 0.02f)
        invalidate()
    }
    override fun setMerge(pct: Int) {
        if (!merging) { merging = true; mergeMs = SystemClock.uptimeMillis() }
        mergeTarget = (pct / 100f).coerceIn(0f, 1f)
    }

    override fun complete(res: Bitmap?, done: () -> Unit) {
        mergeTarget = 1f
        mergePct = 1f
        result = res
        finishAnim?.cancel()
        if (res == null) { done(); return }
        finishAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 950
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { finishU = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) { if (!cancelled) done() }
            })
            start()
        }
    }

    override fun stop() {
        ticker?.cancel(); ticker = null
        finishAnim?.cancel(); finishAnim = null
        started = false; merging = false; mergePct = 0f; mergeTarget = 0f; finishU = 0f
        captured = 0; shownCap = 0f; estTotal = 0; stopping = false
        lastLeft = -1; prevLeft = -1; tickMs = 0L; mergeMs = 0L
        frozen = null; result = null
        visibility = GONE
    }

    private fun text(c: Canvas, t: String, x: Float, y: Float, size: Float, color: Int, bold: Boolean, align: Paint.Align = Paint.Align.CENTER) {
        p.style = Paint.Style.FILL
        p.shader = null
        p.typeface = if (bold) Typeface.create(Typeface.DEFAULT, Typeface.BOLD) else Typeface.DEFAULT
        p.textSize = size
        p.textAlign = align
        p.color = color
        p.setShadowLayer(d(3f), 0f, d(1f), 0xAA000000.toInt())
        c.drawText(t, x, y, p)
        p.clearShadowLayer()
        p.typeface = Typeface.DEFAULT
    }

    /** Quầng sáng mềm (dùng shader đơn vị co giãn bằng canvas, không cấp phát mỗi khung). */
    private fun glow(c: Canvas, sh: Shader, x: Float, y: Float, rad: Float, a: Float) {
        if (a <= 0.01f || rad <= 0f) return
        sp.shader = sh
        sp.alpha = (a.coerceIn(0f, 1f) * 255f).toInt()
        c.save()
        c.translate(x, y)
        c.scale(rad, rad)
        c.drawCircle(0f, 0f, 1f, sp)
        c.restore()
        sp.shader = null
        sp.alpha = 255
    }

    private fun arcGlow(c: Canvas, startA: Float, sweep: Float, a: Float) {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = d(11f); p.color = ca(ORANGE, 0.10f * a); c.drawArc(ring, startA, sweep, false, p)
        p.strokeWidth = d(7f); p.color = ca(ORANGE, 0.18f * a); c.drawArc(ring, startA, sweep, false, p)
        p.strokeWidth = d(3.2f); p.color = ca(ORANGE, a); c.drawArc(ring, startA, sweep, false, p)
    }

    private fun stageName(pct: Float): String = when {
        pct < 0.30f -> "Ghép các khung"
        pct < 0.62f -> "Cân sáng và màu"
        pct < 0.88f -> "Khử nhiễu, giữ chi tiết"
        else -> "Làm nét"
    }

    override fun onDraw(c: Canvas) {
        val fz = frozen ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        val now = SystemClock.uptimeMillis()
        val t = (now - appearMs) / 1000f
        val elapsed = if (started) (now - startMs) / 1000f else 0f
        val capFrac = if (!started) 0f else (elapsed / secs).coerceIn(0f, 1f)
        val res = result
        val cx = w / 2f
        val cy = h / 2f + d(4f)
        val r = min(w, h) * 0.25f
        val appear = ((now - appearMs) / 550f).coerceIn(0f, 1f)
        val ap = 1f - (1f - appear) * (1f - appear) * (1f - appear)

        // 1) ảnh đóng băng sáng dần (mô phỏng ánh sáng tích luỹ) + vignette + quầng sáng ấm ở giữa
        val k = 1f + 1.1f * (1f - (1f - capFrac) * (1f - capFrac))
        cm.setScale(k, k, k * 1.02f, 1f)
        bp.colorFilter = ColorMatrixColorFilter(cm)
        dst.set(0f, 0f, w, h)
        c.drawBitmap(fz, null, dst, bp)
        bp.colorFilter = null
        c.drawColor(0x40000000)
        vignette?.let { sp.shader = it; c.drawRect(0f, 0f, w, h, sp); sp.shader = null }
        val lightK = if (merging) 1f else capFrac
        glow(c, glowO, cx, cy, r * 3.0f, 0.08f + 0.22f * lightK * ap)

        // 2) bụi sáng trôi lên, nhấp nháy + sao băng thỉnh thoảng
        p.style = Paint.Style.FILL
        p.shader = null
        for (i in 0 until 40) {
            val y = (((dust[i * 5 + 1] - t * dust[i * 5 + 2]) % 1f) + 1f) % 1f
            val x = dust[i * 5] + Math.sin((t * 0.35f + dust[i * 5 + 3]).toDouble()).toFloat() * 0.012f
            val a = 0.25f + 0.40f * (0.5f + 0.5f * Math.sin((t * 2.2f + dust[i * 5 + 3]).toDouble()).toFloat())
            p.color = ca(0xFFFFFFFF.toInt(), a * ap)
            c.drawCircle(x * w, y * h, d(dust[i * 5 + 4] * 0.7f), p)
        }
        val cyc = t % 6.5f
        if (cyc < 0.8f && t > 1.5f) {
            val u = cyc / 0.8f
            val n = (t / 6.5f).toInt()
            val sx0 = w * (0.08f + 0.45f * ((n * 0.618f) % 1f))
            val sy0 = h * 0.16f
            val hx = sx0 + u * w * 0.30f
            val hy = sy0 + u * h * 0.26f
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            for (s in 0 until 7) {
                val f0 = (u - s * 0.035f).coerceAtLeast(0f)
                val f1 = (u - (s + 1) * 0.035f).coerceAtLeast(0f)
                p.strokeWidth = d(2.2f - s * 0.25f)
                p.color = ca(0xFFFFFFFF.toInt(), (1f - s / 7f) * 0.85f * (1f - u * 0.4f))
                c.drawLine(sx0 + f0 * w * 0.30f, sy0 + f0 * h * 0.26f, sx0 + f1 * w * 0.30f, sy0 + f1 * h * 0.26f, p)
            }
            glow(c, glowW, hx, hy, d(9f), 0.8f * (1f - u * 0.5f))
        }

        // 3) mặt đồng hồ: vòng đếm ngược / vòng xử lí
        val dialA = if (res == null) ap else 1f - (finishU / 0.35f).coerceIn(0f, 1f)
        if (dialA > 0.01f) {
            val sc = (0.84f + 0.16f * ap) * (if (res != null) 1f + 0.10f * finishU else 1f)
            c.save()
            c.scale(sc, sc, cx, cy)
            val left = 1f - capFrac
            glow(c, glowO, cx, cy, r * 1.9f, (0.30f + 0.12f * Math.sin((t * 2.4f).toDouble()).toFloat()) * dialA)
            // đĩa tối + viền
            p.style = Paint.Style.FILL
            p.color = ca(0x70000000, dialA)
            c.drawCircle(cx, cy, r + d(5f), p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(3f)
            p.color = ca(0x26FFFFFF, dialA)
            c.drawCircle(cx, cy, r, p)
            // vạch chia 60 nấc quanh mặt: đếm ngược thì tắt dần theo thời gian còn lại, xử lí thì sáng dần + sao chổi chạy vòng
            val tr0 = r + d(11f)
            p.strokeCap = Paint.Cap.ROUND
            for (i in 0 until 60) {
                val frac = i / 60f
                val major = i % 5 == 0
                val len = if (major) d(8f) else d(4.5f)
                var al: Float
                var col: Int
                if (!merging) {
                    if (!started) {
                        val dd = (((t * 48f - i) % 60f) + 60f) % 60f
                        al = 0.18f + 0.65f * (1f - dd / 14f).coerceAtLeast(0f)
                        col = 0xFFFFFFFF.toInt()
                    } else {
                        val lit = frac < left
                        al = if (lit) (if (major) 0.95f else 0.70f) else 0.14f
                        if (lit && left - frac < 0.04f) al = 1f
                        col = if (lit) 0xFFFFE6CC.toInt() else 0xFFFFFFFF.toInt()
                    }
                } else {
                    val dd = (((t * 45f - i) % 60f) + 60f) % 60f
                    val comet = (1f - dd / 16f).coerceAtLeast(0f)
                    val done = frac < mergePct
                    al = if (done) 0.85f else 0.14f + 0.80f * comet
                    col = if (done) 0xFFFFA25C.toInt() else 0xFFFFFFFF.toInt()
                }
                p.strokeWidth = if (major) d(2f) else d(1.2f)
                p.color = ca(col, al * dialA)
                c.drawLine(cx + tc[i] * tr0, cy + ts[i] * tr0, cx + tc[i] * (tr0 + len), cy + ts[i] * (tr0 + len), p)
            }
            // cung chính (có quầng sáng) + đầu cung phát sáng
            ring.set(cx - r, cy - r, cx + r, cy + r)
            var startA = -90f
            val sweep: Float = if (!started && !merging) { startA += t * 220f; 70f }
                else if (!merging) 360f * left
                else 360f * mergePct.coerceAtLeast(0.02f)
            if (sweep > 0.5f) {
                arcGlow(c, startA, sweep, dialA)
                val ang = Math.toRadians((startA + sweep).toDouble())
                val hx = cx + r * Math.cos(ang).toFloat()
                val hy = cy + r * Math.sin(ang).toFloat()
                glow(c, glowO, hx, hy, d(17f), 0.9f * dialA)
                p.style = Paint.Style.FILL
                p.color = ca(0xFFFFFFFF.toInt(), dialA)
                c.drawCircle(hx, hy, d(3.2f), p)
            }
            // gợn sóng: mỗi giây một gợn nhỏ; lúc chuyển sang xử lí một gợn lớn như đóng màn trập
            val tickAge = (now - tickMs) / 700f
            if (started && !merging && tickMs > 0L && tickAge in 0f..1f) {
                val e = 1f - (1f - tickAge) * (1f - tickAge)
                p.style = Paint.Style.STROKE
                p.strokeWidth = d(1.6f)
                p.color = ca(0xFFFFFFFF.toInt(), (1f - tickAge) * 0.35f * dialA)
                c.drawCircle(cx, cy, r + d(20f) + e * r * 0.35f, p)
            }
            val flAge = (now - mergeMs) / 900f
            if (merging && mergeMs > 0L && flAge in 0f..1f) {
                val e = 1f - (1f - flAge) * (1f - flAge) * (1f - flAge)
                p.style = Paint.Style.STROKE
                p.strokeWidth = d(3f) * (1f - e) + d(0.8f)
                p.color = ca(0xFFFFE6CC.toInt(), (1f - flAge) * 0.75f * dialA)
                c.drawCircle(cx, cy, r + d(10f) + e * r * 1.0f, p)
            }
            // trăng nhỏ phía trên số, nhấp nhô nhẹ
            val moonY = cy - r * 0.52f + Math.sin((t * 2.2f).toDouble()).toFloat() * d(1.5f)
            glow(c, glowO, cx, moonY, r * 0.5f, 0.55f * dialA)
            p.style = Paint.Style.FILL
            p.color = ca(ORANGE, dialA)
            c.drawPath(moonPath(cx, moonY, r * 0.15f), p)
            // số lớn
            val big = r * 1.0f
            np.textSize = big
            val fmBig = np.fontMetrics
            val baseY = cy - (fmBig.ascent + fmBig.descent) / 2f + r * 0.10f
            if (!merging) {
                val leftS = if (started && lastLeft >= 0) lastLeft else secs
                val age = ((now - tickMs) / 420f).coerceIn(0f, 1f)
                val e = 1f - (1f - age) * (1f - age)
                val slide = r * 0.22f
                val changing = started && prevLeft >= 0 && prevLeft != leftS && age < 1f
                np.textSize = big
                if (changing) {
                    np.color = ca(0xFFFFFFFF.toInt(), (1f - e) * dialA * 0.9f)
                    c.drawText(prevLeft.toString(), cx, baseY - e * slide, np)
                }
                np.color = ca(0xFFFFFFFF.toInt(), (if (changing) e else 1f) * dialA)
                c.drawText(leftS.toString(), cx, baseY + (if (changing) (1f - e) * slide else 0f), np)
                text(c, "giây", cx, cy + r * 0.64f, r * 0.20f, ca(0xFFFFFFFF.toInt(), 0.8f * dialA), false)
            } else {
                val pctI = (mergePct * 100f).toInt().coerceIn(0, 100)
                np.textSize = big * 0.66f
                np.color = ca(0xFFFFFFFF.toInt(), dialA)
                c.drawText("$pctI%", cx, cy - (fmBig.ascent + fmBig.descent) / 2f * 0.66f + r * 0.08f, np)
                val shimmer = 0.55f + 0.35f * Math.sin((t * 3.2f).toDouble()).toFloat()
                text(c, "LUNA Engine", cx, cy + r * 0.64f, r * 0.19f, ca(0xFFFFFFFF.toInt(), shimmer * dialA), false)
            }
            c.restore()
        }
        // dấu tích khi xong: nảy vào rồi mờ đi trước khi ảnh quét ra
        if (res != null) {
            val ck = ((finishU - 0.05f) / 0.25f).coerceIn(0f, 1f)
            val fo = 1f - ((finishU - 0.45f) / 0.3f).coerceIn(0f, 1f)
            if (ck > 0f && fo > 0f) {
                glow(c, glowO, cx, cy, r * 1.5f, 0.6f * ck * fo)
                chk.reset()
                chk.moveTo(cx - r * 0.30f, cy + r * 0.02f)
                chk.lineTo(cx - r * 0.08f, cy + r * 0.24f)
                chk.lineTo(cx + r * 0.32f, cy - r * 0.22f)
                p.style = Paint.Style.STROKE
                p.strokeWidth = d(4.5f)
                p.strokeCap = Paint.Cap.ROUND
                p.strokeJoin = Paint.Join.ROUND
                p.color = ca(0xFFFFFFFF.toInt(), ck * fo)
                val s2 = 0.7f + 0.3f * ck
                c.save()
                c.scale(s2, s2, cx, cy)
                c.drawPath(chk, p)
                c.restore()
                p.strokeJoin = Paint.Join.MITER
            }
        }
        // 4) ảnh kết quả quét từ trái sang phải, mép sáng mềm
        if (res != null) {
            val wp = ((finishU - 0.25f) / 0.75f).coerceIn(0f, 1f)
            if (wp > 0f) {
                val e = 1f - (1f - wp) * (1f - wp) * (1f - wp)
                val x = w * e
                src.set(0, 0, (res.width * e).toInt().coerceAtLeast(1), res.height)
                dst.set(0f, 0f, x, h)
                c.drawBitmap(res, src, dst, bp)
                val gw = d(46f)
                sp.shader = LinearGradient(x - gw, 0f, x, 0f, 0x00FFFFFF, 0x66FFE6CC, Shader.TileMode.CLAMP)
                c.drawRect(max(0f, x - gw), 0f, x, h, sp)
                sp.shader = null
                p.style = Paint.Style.FILL
                p.color = 0xE6FFFFFF.toInt()
                c.drawRect(x - d(1f), 0f, x + d(1f), h, p)
            }
        }
        // gợi ý phía dưới
        if (res == null) {
            val hint = when {
                merging -> "${stageName(mergePct)} — có thể cầm máy tự do"
                !started -> "Đang lấy nét…"
                stopping -> "Đang dừng…"
                steady -> "Máy đang vững · bấm nút chụp để dừng sớm"
                else -> "Giữ chắc máy hoặc đặt lên chân máy · bấm nút chụp để dừng sớm"
            }
            text(c, hint, cx, h - d(26f), d(10.5f), ca(0xFFFFFFFF.toInt(), 0.87f * ap), false)
        }
        // 5) thanh tiến trình đáy: phơi sáng 70%, xử lí 30%, có vạch mốc và đầu sáng
        val prog = if (res != null) 1f else if (!merging) capFrac * 0.7f else 0.7f + 0.3f * mergePct
        val bx0 = d(18f)
        val bx1 = w - d(18f)
        val by = h - d(9f)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = d(2.5f)
        p.color = 0x26FFFFFF
        c.drawLine(bx0, by, bx1, by, p)
        if (prog > 0.005f) {
            val fx = bx0 + (bx1 - bx0) * prog.coerceIn(0f, 1f)
            p.strokeWidth = d(6f); p.color = ca(ORANGE, 0.22f); c.drawLine(bx0, by, fx, by, p)
            p.strokeWidth = d(2.5f); p.color = ORANGE; c.drawLine(bx0, by, fx, by, p)
            glow(c, glowO, fx, by, d(13f), 0.8f)
        }
        val mx = bx0 + (bx1 - bx0) * 0.7f
        p.strokeCap = Paint.Cap.BUTT
        p.strokeWidth = d(1.2f)
        p.color = 0x66FFFFFF
        c.drawLine(mx, by - d(4f), mx, by + d(4f), p)
        // 6) nhãn trạng thái phía trên: trăng + LUNA Night + trạng thái (số khung chạy mượt)
        val label = when {
            res != null -> "Hoàn tất"
            merging -> "Đang xử lí"
            !started -> "Chuẩn bị"
            else -> "Phơi sáng ${secs}s · ${shownCap.roundToInt()} khung"
        }
        p.style = Paint.Style.FILL
        p.textSize = d(11f)
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        val badge = "LUNA Night"
        val bwid = p.measureText(badge)
        val lw = p.measureText("  $label")
        val moonW = d(16f)
        val pw = moonW + bwid + lw + d(24f)
        val ph = d(24f)
        pill.set((w - pw) / 2f, d(12f), (w + pw) / 2f, d(12f) + ph)
        p.color = ca(0xB0101012.toInt(), ap)
        c.drawRoundRect(pill, ph / 2f, ph / 2f, p)
        p.style = Paint.Style.STROKE; p.strokeWidth = d(1f); p.color = ca(0x40FFFFFF, ap)
        c.drawRoundRect(pill, ph / 2f, ph / 2f, p)
        p.style = Paint.Style.FILL
        p.color = ca(ORANGE, ap)
        c.drawPath(moonPath(pill.left + d(15f), pill.centerY(), d(5.2f)), p)
        p.style = Paint.Style.FILL
        p.textSize = d(11f)
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        val fm = p.fontMetrics
        val ty = pill.centerY() - (fm.ascent + fm.descent) / 2f
        p.color = ca(ORANGE, ap)
        c.drawText(badge, pill.left + d(11f) + moonW, ty, p)
        p.color = ca(0xFFFFFFFF.toInt(), ap)
        c.drawText("  $label", pill.left + d(11f) + moonW + bwid, ty, p)
        p.typeface = Typeface.DEFAULT
    }
}

/**
 * Bộ đếm giây khi đang xử lí ảnh (HQ / HQ RAW / thiếu sáng): nằm đúng vị trí nút XPAN (nút này tự ẩn lúc xử lí).
 * Chạy từ lúc bắt đầu xử lí; tự ẩn khi giao diện hiện lại.
 */
class ProcTimerView(ctx: Context) : XView(ctx) {
    private val box = RectF()
    private val arc = RectF()
    private var startMs = 0L
    private var running = false
    private var tick: ValueAnimator? = null
    private var phase = 0f
    init { visibility = GONE; isClickable = false }

    fun start() {
        stop()
        startMs = SystemClock.uptimeMillis()
        running = true
        visibility = VISIBLE
        tick = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900
            repeatCount = ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { phase = it.animatedValue as Float; invalidate() }
            start()
        }
        invalidate()
    }

    fun stop() {
        tick?.cancel(); tick = null
        running = false
        visibility = GONE
    }

    override fun onDraw(c: Canvas) {
        if (!running) return
        val w = width.toFloat()
        val h = height.toFloat()
        val bw = min(w, d(64f))
        val bh = min(h, d(28f))
        box.set((w - bw) / 2f, (h - bh) / 2f, (w + bw) / 2f, (h + bh) / 2f)
        val light = Theme.light && classic
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = if (light) 0xFFFFFFFF.toInt() else if (classic) 0xFF111113.toInt() else 0x66000000
        c.drawRoundRect(box, bh / 2f, bh / 2f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1f)
        p.color = 0x40FFFFFF
        c.drawRoundRect(box, bh / 2f, bh / 2f, p)
        // vòng xoay nhỏ bên trái
        val r = d(4.5f)
        val cx = box.left + d(15f)
        val cy = box.centerY()
        arc.set(cx - r, cy - r, cx + r, cy + r)
        p.strokeWidth = d(1.8f)
        p.strokeCap = Paint.Cap.ROUND
        p.color = ORANGE
        c.drawArc(arc, phase * 360f, 250f, false, p)
        p.strokeCap = Paint.Cap.BUTT
        // số giây (một chữ số thập phân)
        val sec = (SystemClock.uptimeMillis() - startMs) / 1000f
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        p.textSize = d(12f)
        p.textAlign = Paint.Align.LEFT
        p.color = if (light) 0xFF111114.toInt() else Color.WHITE
        val fm = p.fontMetrics
        c.drawText(String.format(java.util.Locale.US, "%.1fs", sec), box.left + d(26f), box.centerY() - (fm.ascent + fm.descent) / 2f, p)
        p.typeface = Typeface.DEFAULT
    }
}

/** Nút "XPAN" nằm sẵn ngoài màn hình: chạm để mở bảng chọn kiểu khung / dấu chìm. */
class WatermarkButtonView(ctx: Context) : XView(ctx) {
    private val box = RectF()
    private var down = false
    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val bw = min(w, d(64f))
        val bh = min(h, d(28f))
        box.set((w - bw) / 2f, (h - bh) / 2f, (w + bw) / 2f, (h + bh) / 2f)
        val light = Theme.light && classic
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = if (light) 0xFFFFFFFF.toInt() else if (classic) 0xFF111113.toInt() else 0x66000000
        c.drawRoundRect(box, bh / 2f, bh / 2f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1f)
        p.color = if (down) ORANGE else if (light) 0x33000000 else 0x40FFFFFF
        c.drawRoundRect(box, bh / 2f, bh / 2f, p)
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
        p.textSize = d(12f)
        p.letterSpacing = 0.12f
        p.textAlign = Paint.Align.CENTER
        p.color = ORANGE
        val fm = p.fontMetrics
        c.drawText("XPAN", box.centerX() - d(5f), box.centerY() - (fm.ascent + fm.descent) / 2f, p)
        p.letterSpacing = 0f
        p.typeface = Typeface.DEFAULT
        // mũi tên ">": mở menu Khung ảnh / Hiệu ứng chụp
        val ax = box.right - d(12f)
        val ay = box.centerY()
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.7f)
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = if (light) 0xFF111114.toInt() else Color.WHITE
        val arrow = Path()
        arrow.moveTo(ax - d(1.8f), ay - d(3.8f))
        arrow.lineTo(ax + d(2.0f), ay)
        arrow.lineTo(ax - d(1.8f), ay + d(3.8f))
        c.drawPath(arrow, p)
        p.style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true; invalidate()
                animate().cancel()
                animate().scaleX(0.9f).scaleY(0.9f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                down = false; invalidate()
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3.5f)).start()
            }
        }
        return super.onTouchEvent(e)
    }
}

/** Bố cục chính: sắp xếp lại toàn bộ control theo hai giao diện. */
/** Rung phản hồi "nấc" cơ học: ưu tiên rung hệ thống dạng CLICK (giật gọn), thiếu thì dùng phản hồi cảm ứng. */
object Haptic {
    fun click(v: View, heavy: Boolean = false) {
        try {
            val vib = v.context.getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
            if (vib != null && vib.hasVibrator()) {
                vib.vibrate(android.os.VibrationEffect.createPredefined(if (heavy) android.os.VibrationEffect.EFFECT_HEAVY_CLICK else android.os.VibrationEffect.EFFECT_CLICK))
                return
            }
        } catch (t: Throwable) {}
        v.performHapticFeedback(if (heavy) HapticFeedbackConstants.LONG_PRESS else HapticFeedbackConstants.CLOCK_TICK)
    }
}

/** Viên thuốc hiện thời gian hẹn giờ dạng 00.00s, nằm bên trái nút XPAN. */
class TimerPillView(ctx: Context) : XView(ctx) {
    private val box = RectF()
    private var secs = 0f
    private var run = false

    init { visibility = GONE; isClickable = false }

    fun set(s: Float, running: Boolean) {
        if (s == secs && running == run) return
        secs = s; run = running; invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val bw = min(w, d(94f))
        val bh = min(h, d(28f))
        box.set((w - bw) / 2f, (h - bh) / 2f, (w + bw) / 2f, (h + bh) / 2f)
        val light = Theme.light && classic
        p.style = Paint.Style.FILL
        p.shader = null
        p.color = if (light) 0xFFFFFFFF.toInt() else if (classic) 0xFF111113.toInt() else 0x66000000
        c.drawRoundRect(box, bh / 2f, bh / 2f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1f)
        p.color = if (run || secs > 0f) ORANGE else 0x40FFFFFF
        c.drawRoundRect(box, bh / 2f, bh / 2f, p)
        // biểu tượng cần gạt thu nhỏ: trục tròn + cán xuống dưới
        val ix = box.left + d(15f)
        val iy = box.centerY()
        p.color = ORANGE
        p.strokeWidth = d(1.6f)
        p.strokeCap = Paint.Cap.ROUND
        c.drawCircle(ix, iy - d(2.6f), d(3.6f), p)
        c.drawLine(ix, iy + d(1f), ix - d(1.6f), iy + d(6.4f), p)
        p.strokeCap = Paint.Cap.BUTT
        // thời gian
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        p.textSize = d(12.5f)
        p.textAlign = Paint.Align.LEFT
        p.color = if (run) ORANGE else if (light) 0xFF111114.toInt() else Color.WHITE
        if (!run && secs <= 0f) p.alpha = 150
        val fm = p.fontMetrics
        c.drawText(String.format(java.util.Locale.US, "%05.2fs", secs), box.left + d(28f), box.centerY() - (fm.ascent + fm.descent) / 2f, p)
        p.typeface = Typeface.DEFAULT
        p.alpha = 255
    }
}

/**
 * Cần gạt hẹn giờ kiểu máy ảnh film (thay nút chụp khi bật Hẹn giờ): trục tròn bằng kim loại + cán dài hướng xuống.
 * Giữ đầu hoặc thân cán rồi xoay lên trên sang trái để lên dây (vuông góc = 5s, hướng thẳng lên = 10s, tối đa), mỗi nấc rung giật một cái;
 * bấm vào trục để bắt đầu đếm ngược: cán tự quay về, hết giờ thì chụp.
 */
class TimerLeverView(ctx: Context) : XView(ctx) {
    interface Listener {
        /** Bấm trục: bắt đầu đếm ngược [secs] giây (tiếng dây cót chạy). */
        fun onStart(secs: Float)
        /** Còn rất ít giờ: dây cót chậm lại rồi nhả cò. */
        fun onEndSoon()
        /** Hết giờ: chụp. */
        fun onFire()
        /** Huỷ giữa chừng. */
        fun onCancel()
    }

    companion object {
        const val MAX_SECS = 10f
        const val STEP_DEG = 4.5f          // mỗi nấc = 0,25s
        const val END_SOON_MS = 430L
    }

    var listener: Listener? = null
    var pill: TimerPillView? = null
    /** Tâm trục + bán kính trục (toạ độ trong view), do CameraLayout đặt. */
    var hubX = 0f
    var hubY = 0f
    var hubR = 0f
        set(v) { field = v; armPath = null }

    /** Góc cán: 0 = hướng xuống (nghỉ), 90 = sang trái (5s), 180 = hướng lên (10s). */
    var angle = 0f
        private set
    var running = false
        private set

    private var armPath: Path? = null
    private val tmp = Path()
    private var dragging = false
    private var hubDown = false
    private var rawDeg = 0f
    private var lastTouchDeg = 0f
    private var lastNotch = 0
    private var atStop = false
    private var lastHapticMs = 0L
    private var runStartMs = 0L
    private var runTotalMs = 0L
    private var runStartAngle = 0f
    private var endSoonSent = false
    private var ticker: ValueAnimator? = null
    private var backAnim: ValueAnimator? = null

    val secsSet: Float get() = angle / 180f * MAX_SECS

    private fun touchDeg(dx: Float, dy: Float): Float = Math.toDegrees(Math.atan2((-dx).toDouble(), dy.toDouble())).toFloat()

    private fun syncPill(remain: Float? = null) {
        pill?.set(remain ?: secsSet, running)
    }

    private fun hitArm(x: Float, y: Float): Boolean {
        val dx = x - hubX
        val dy = y - hubY
        val dist = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
        if (dist <= hubR * 1.15f) return dist > hubR * 0.72f
        val th = Math.toRadians(angle.toDouble())
        val ux = (-Math.sin(th)).toFloat()
        val uy = Math.cos(th).toFloat()
        val len = hubR * 2.1f
        val t = (dx * ux + dy * uy).coerceIn(0f, len)
        val px = ux * t
        val py = uy * t
        return Math.hypot((dx - px).toDouble(), (dy - py).toDouble()) <= hubR * 0.8f
    }

    private fun notch(heavy: Boolean) {
        val now = SystemClock.uptimeMillis()
        if (!heavy && now - lastHapticMs < 22) return
        lastHapticMs = now
        Haptic.click(this, heavy)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val dx = e.x - hubX
                val dy = e.y - hubY
                val dist = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                if (dist <= hubR * 0.72f) {
                    hubDown = true
                    invalidate()
                    Haptic.click(this)
                    parent?.requestDisallowInterceptTouchEvent(true)
                    return true
                }
                if (running || !hitArm(e.x, e.y)) return false
                backAnim?.cancel()
                dragging = true
                rawDeg = angle
                lastTouchDeg = touchDeg(dx, dy)
                lastNotch = (angle / STEP_DEG).toInt()
                atStop = angle <= 0f || angle >= 180f
                parent?.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragging) {
                    val dx = e.x - hubX
                    val dy = e.y - hubY
                    if (Math.hypot(dx.toDouble(), dy.toDouble()) > hubR * 0.5f) {
                        val td = touchDeg(dx, dy)
                        var dd = td - lastTouchDeg
                        while (dd > 180f) dd -= 360f
                        while (dd < -180f) dd += 360f
                        lastTouchDeg = td
                        rawDeg = (rawDeg + dd).coerceIn(-25f, 205f)
                        val na = rawDeg.coerceIn(0f, 180f)
                        if (na != angle) {
                            angle = na
                            val idx = (angle / STEP_DEG).toInt()
                            if (idx != lastNotch) {
                                lastNotch = idx
                                // mốc 5s (90°) và 10s (180°) giật mạnh hơn
                                notch(idx % 20 == 0)
                            }
                            val stop = angle <= 0f || angle >= 180f
                            if (stop && !atStop) notch(true)
                            atStop = stop
                            syncPill()
                            invalidate()
                        }
                    }
                } else if (hubDown) {
                    val dist = Math.hypot((e.x - hubX).toDouble(), (e.y - hubY).toDouble()).toFloat()
                    if (dist > hubR * 1.1f) { hubDown = false; invalidate() }
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val tap = hubDown && e.actionMasked == MotionEvent.ACTION_UP
                hubDown = false
                dragging = false
                invalidate()
                if (tap) hubTap()
            }
        }
        return true
    }

    private fun hubTap() {
        if (running) { cancelRun(); return }
        val s = secsSet
        if (s < 0.3f) { listener?.onFire(); return }     // chưa lên dây: bấm trục = chụp ngay
        startRun(s)
    }

    private fun startRun(s: Float) {
        running = true
        runStartMs = SystemClock.uptimeMillis()
        runTotalMs = (s * 1000f).toLong()
        runStartAngle = angle
        endSoonSent = false
        listener?.onStart(s)
        ticker?.cancel()
        ticker = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener { stepRun() }
            start()
        }
        syncPill(s)
    }

    private fun stepRun() {
        if (!running) return
        val left = runTotalMs - (SystemClock.uptimeMillis() - runStartMs)
        if (!endSoonSent && left <= END_SOON_MS) { endSoonSent = true; listener?.onEndSoon() }
        if (left <= 0L) {
            running = false
            ticker?.cancel(); ticker = null
            angle = 0f
            syncPill(0f)
            invalidate()
            listener?.onFire()
            return
        }
        angle = runStartAngle * left / runTotalMs.toFloat()
        syncPill(left / 1000f)
        invalidate()
    }

    private fun springBack() {
        backAnim?.cancel()
        val from = angle
        if (from <= 0f) { syncPill(); return }
        backAnim = ValueAnimator.ofFloat(from, 0f).apply {
            duration = 260
            interpolator = DecelerateInterpolator(1.4f)
            addUpdateListener { angle = it.animatedValue as Float; syncPill(); invalidate() }
            start()
        }
    }

    private fun cancelRun() {
        running = false
        ticker?.cancel(); ticker = null
        Haptic.click(this, true)
        listener?.onCancel()
        springBack()
    }

    /** Về trạng thái nghỉ ngay (thoát app, tắt chế độ hẹn giờ...). [notify] = có báo huỷ cho bên ngoài hay không. */
    fun reset(notify: Boolean = false) {
        val was = running
        running = false
        dragging = false; hubDown = false
        ticker?.cancel(); ticker = null
        backAnim?.cancel()
        angle = 0f
        if (was && notify) listener?.onCancel()
        syncPill()
        invalidate()
    }

    override fun onDetachedFromWindow() {
        ticker?.cancel(); backAnim?.cancel()
        super.onDetachedFromWindow()
    }

    private fun buildArm(R: Float): Path {
        armPath?.let { return it }
        val len = R * 2.1f
        val pr = R * 0.56f
        val a = Path().apply {
            moveTo(-R * 0.5f, 0f); lineTo(R * 0.5f, 0f); lineTo(R * 0.33f, len); lineTo(-R * 0.33f, len); close()
        }
        val b = Path().apply { addCircle(0f, len, pr, Path.Direction.CW) }
        val u = Path()
        u.op(a, b, Path.Op.UNION)
        armPath = u
        return u
    }

    override fun onDraw(c: Canvas) {
        val R = hubR
        if (R <= 1f) return
        val cx = hubX
        val cy = hubY
        val ink = Theme.ink

        // vạch chia thời gian quanh trục: mỗi 1s một chấm, 5s và 10s to hơn kèm nhãn
        p.style = Paint.Style.FILL
        p.shader = null
        for (i in 0..10) {
            val th = Math.toRadians(i * 18.0)
            val rr = R * 1.34f
            val x = cx + (-Math.sin(th)).toFloat() * rr
            val y = cy + Math.cos(th).toFloat() * rr
            p.color = (ink and 0x00FFFFFF) or (if (i == 5 || i == 10) 0xB0000000.toInt() else 0x66000000)
            c.drawCircle(x, y, R * (if (i == 5 || i == 10) 0.065f else 0.035f), p)
        }
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        p.textSize = R * 0.3f
        p.textAlign = Paint.Align.CENTER
        p.color = (ink and 0x00FFFFFF) or 0x99000000.toInt()
        val fm = p.fontMetrics
        c.drawText("5", cx - R * 1.68f, cy - (fm.ascent + fm.descent) / 2f, p)
        c.drawText("10", cx, cy - R * 1.68f - (fm.ascent + fm.descent) / 2f, p)
        p.typeface = Typeface.DEFAULT

        val arm = buildArm(R)
        val len = R * 2.1f
        val pr = R * 0.56f

        // bóng đổ của cán + trục
        c.save()
        c.translate(cx + R * 0.07f, cy + R * 0.11f)
        c.rotate(angle)
        p.color = 0x55000000
        c.drawPath(arm, p)
        c.restore()
        p.color = 0x55000000
        c.drawCircle(cx + R * 0.05f, cy + R * 0.09f, R, p)

        // cán
        c.save()
        c.translate(cx, cy)
        c.rotate(angle)
        p.color = Color.BLACK
        p.shader = LinearGradient(
            -pr, 0f, pr, 0f,
            intArrayOf(0xFFF3F4F6.toInt(), 0xFFC7CACF.toInt(), 0xFFE9EBEE.toInt(), 0xFF9CA0A6.toInt(), 0xFFD6D9DD.toInt()),
            floatArrayOf(0f, 0.32f, 0.5f, 0.8f, 1f), Shader.TileMode.CLAMP
        )
        c.drawPath(arm, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = R * 0.035f
        p.color = 0x77000000
        c.drawPath(arm, p)
        // vệt sáng dọc thân cán
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = R * 0.07f
        p.color = 0x88FFFFFF.toInt()
        c.drawLine(-R * 0.13f, R * 0.95f, -R * 0.1f, len - pr * 1.05f, p)
        p.strokeCap = Paint.Cap.BUTT
        // vân tròn đồng tâm ở đầu cán
        for (k in 1..5) {
            val rr = pr * (0.14f + 0.17f * k)
            p.strokeWidth = R * 0.028f
            p.color = 0x66000000
            c.drawCircle(0f, len, rr, p)
            p.color = 0x99FFFFFF.toInt()
            c.drawCircle(0f, len + R * 0.018f, rr, p)
        }
        p.style = Paint.Style.FILL
        c.restore()

        // trục: đĩa ngoài + đĩa trong có rãnh + đinh vít ở giữa
        val k = if (hubDown) 0.94f else 1f
        c.save()
        c.translate(cx, cy)
        c.scale(k, k)
        p.color = Color.BLACK
        p.shader = SweepGradient(0f, 0f, intArrayOf(0xFFEEEFF1.toInt(), 0xFFA6AAB0.toInt(), 0xFFF7F8F9.toInt(), 0xFF989CA2.toInt(), 0xFFEEEFF1.toInt()), null)
        c.drawCircle(0f, 0f, R, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = R * 0.04f
        p.color = 0x88000000.toInt()
        c.drawCircle(0f, 0f, R * 0.985f, p)
        p.strokeWidth = R * 0.03f
        p.color = 0xAAFFFFFF.toInt()
        c.drawCircle(0f, 0f, R * 0.9f, p)
        p.style = Paint.Style.FILL
        p.color = Color.BLACK
        p.shader = SweepGradient(0f, 0f, intArrayOf(0xFFE2E4E7.toInt(), 0xFFB4B8BD.toInt(), 0xFFEFF0F2.toInt(), 0xFFAAAEB4.toInt(), 0xFFE2E4E7.toInt()), null)
        c.drawCircle(0f, 0f, R * 0.62f, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = R * 0.035f
        p.color = 0x88000000.toInt()
        c.drawCircle(0f, 0f, R * 0.62f, p)
        p.strokeWidth = R * 0.025f
        p.color = 0x66000000
        c.drawCircle(0f, 0f, R * 0.44f, p)
        p.color = 0x99FFFFFF.toInt()
        c.drawCircle(0f, R * 0.02f, R * 0.44f, p)
        if (running) {
            p.strokeWidth = R * 0.06f
            p.color = ORANGE
            c.drawCircle(0f, 0f, R * 0.7f, p)
        }
        // đinh vít giữa trục (rãnh quay theo cán)
        p.style = Paint.Style.FILL
        p.color = 0xFF8E9298.toInt()
        c.drawCircle(0f, 0f, R * 0.15f, p)
        p.color = 0xFFD9DBDF.toInt()
        c.drawCircle(-R * 0.03f, -R * 0.03f, R * 0.115f, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = R * 0.035f
        p.color = 0xAA000000.toInt()
        c.save()
        c.rotate(angle)
        c.drawLine(-R * 0.1f, 0f, R * 0.1f, 0f, p)
        c.restore()
        p.style = Paint.Style.FILL
        c.restore()
    }
}

/**
 * Màn giới thiệu chế độ (HQ / HQ RAW / UP) khi vừa bật: nền đen hiện dần, dòng chữ "<TIÊU ĐỀ> With LUNA. 3" (dấu chấm cam)
 * kèm ghi chú nhỏ "( Without AI )", rồi nền đen mờ dần; tổng cộng ~1s. Không chặn chạm.
 */
class ModeSplashView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var title = "REAL DETAILS"
    private var t = 0f
    private var anim: ValueAnimator? = null
    private val dn = resources.displayMetrics.density

    init { visibility = GONE; isClickable = false; isFocusable = false }

    fun show(title: String) {
        this.title = title
        anim?.cancel()
        visibility = VISIBLE
        t = 0f
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) { if (!cancelled) visibility = GONE }
            })
            start()
        }
    }

    private fun ramp(x: Float, a: Float, b: Float): Float = ((x - a) / (b - a)).coerceIn(0f, 1f)

    override fun onDraw(c: Canvas) {
        // nền: hiện dần 0-0,25 -> giữ -> mờ dần 0,6-1
        val bg = ramp(t, 0f, 0.25f) * (1f - ramp(t, 0.6f, 1f))
        if (bg <= 0f) return
        c.drawColor(Color.argb((bg * 255f).toInt(), 0, 0, 0))
        // chữ: vào chậm hơn nền một nhịp, ra sớm hơn nền
        val ta = ramp(t, 0.1f, 0.32f) * (1f - ramp(t, 0.5f, 0.72f))
        if (ta <= 0f) return
        val w = width.toFloat()
        val h = height.toFloat()
        val size = max(18f * dn, min(30f * dn, h * 0.085f))
        val sc = 0.96f + 0.04f * ramp(t, 0.1f, 0.4f)
        val bold = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        val light = Typeface.create("sans-serif-light", Typeface.ITALIC)
        val white = Color.WHITE
        val soft = 0xCCFFFFFF.toInt()
        val segs = listOf(
            Triple(title, bold, white),
            Triple("  With  ", light, soft),
            Triple("LUNA", bold, white),
            Triple(".", bold, ORANGE),
            Triple(" 3", bold, white)
        )
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.textSize = size
        p.letterSpacing = 0.07f
        var total = 0f
        val ws = FloatArray(segs.size)
        for ((i, s) in segs.withIndex()) { p.typeface = s.second; ws[i] = p.measureText(s.first); total += ws[i] }
        val cy = h / 2f
        c.save()
        c.scale(sc, sc, w / 2f, cy)
        var x = (w - total) / 2f
        val fm = p.fontMetrics
        val base = cy - (fm.ascent + fm.descent) / 2f - size * 0.12f
        for ((i, s) in segs.withIndex()) {
            p.typeface = s.second
            p.color = (s.third and 0x00FFFFFF) or ((((s.third ushr 24) * ta).toInt()) shl 24)
            c.drawText(s.first, x, base, p)
            x += ws[i]
        }
        // ghi chú nhỏ bên dưới
        p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        p.textSize = size * 0.42f
        p.letterSpacing = 0.12f
        p.textAlign = Paint.Align.CENTER
        p.color = Color.argb((0x99 * ta).toInt(), 255, 255, 255)
        c.drawText("( Without AI )", w / 2f, base + size * 0.95f, p)
        c.restore()
        p.letterSpacing = 0f
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.DEFAULT
    }
}

class CameraLayout(ctx: Context) : ViewGroup(ctx) {
    private companion object {
        /** Bề rộng ngăn kéo bộ lọc (dp). */
        const val DRAWER_DP = 144f
    }

    val decor = DecorView(ctx)
    val texture = TextureView(ctx)
    val freeze = ImageView(ctx)
    val fly = SaveFlyView(ctx)
    val frame = FrameOverlayView(ctx)
    val focusBox = FocusBoxView(ctx)
    val fx = ShutterFxView(ctx)
    val lensFx = LensSwitchView(ctx)
    val ev = EvView(ctx)
    val ladder = ZoomLadderView(ctx)
    val pills = LensPillsView(ctx)
    val zoomHud = ZoomReadoutView(ctx)
    val content = RawGroup(ctx)
    val drawer = DrawerView(ctx)
    val tray = ScrollView(ctx)
    val trayRow = LinearLayout(ctx)
    val shutter = ShutterButton(ctx)
    val thumb = ImageView(ctx)
    val filterBtn = FilterButtonView(ctx)
    val toggle = IconButtonView(ctx, IconButtonView.TOGGLE)
    val gear = IconButtonView(ctx, IconButtonView.GEAR)
    val edit = IconButtonView(ctx, IconButtonView.EDIT)
    val theme = IconButtonView(ctx, IconButtonView.THEME)
    val flash = IconButtonView(ctx, IconButtonView.FLASH)
    val wm = WatermarkButtonView(ctx)
    val proc = ProcTimerView(ctx)
    val curtain = CurtainView(ctx)
    val hqFx = HqFxView(ctx)
    val nightFx = NightFxView(ctx)
    val leFx = LongExpFxView(ctx)
    val night = NightBadgeView(ctx)
    val lever = TimerLeverView(ctx)
    val timerPill = TimerPillView(ctx)
    val splash = ModeSplashView(ctx)

    private val vf = RectF()
    /** Đang ở chế độ hẹn giờ: cụm nút bên phải được dàn lại để chừa chỗ cho vùng quét của cần gạt. */
    private var timerOn = false
    private var safeL = 0
    private var safeR = 0
    private val dn = resources.displayMetrics.density

    var classic: Boolean = true
        set(v) { field = v; applyMode() }

    /** Bán kính bo góc của khung ngắm (khớp với viền đen ở giả máy ảnh và viền mờ ở toàn màn). */
    private val vfRadius get() = (if (classic) 7f else 12f) * dn
    private val roundOutline = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, vfRadius)
        }
    }

    /** Giao diện trắng (true) hoặc tối (false). */
    var light: Boolean = false
        set(v) {
            field = v
            applyMode()
            invalidateTree(this)
        }

    private fun invalidateTree(v: View) {
        v.invalidate()
        if (v is ViewGroup) for (i in 0 until v.childCount) invalidateTree(v.getChildAt(i))
    }

    init {
        tray.isVerticalScrollBarEnabled = false
        tray.isVerticalFadingEdgeEnabled = false
        tray.overScrollMode = View.OVER_SCROLL_NEVER
        tray.isFillViewport = false
        tray.clipToPadding = false
        tray.clipChildren = false
        tray.isNestedScrollingEnabled = true
        trayRow.orientation = LinearLayout.VERTICAL
        tray.addView(trayRow)
        tray.visibility = GONE
        freeze.scaleType = ImageView.ScaleType.FIT_XY
        freeze.visibility = GONE
        lensFx.visibility = GONE
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.clipToOutline = true
        thumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, 6f * dn)
            }
        }
        thumb.foreground = GradientDrawable().apply {
            setStroke((2 * dn).toInt(), 0x99FFFFFF.toInt())
            cornerRadius = 6f * dn
        }
        thumb.isClickable = true
        // mọi lớp phủ lên khung ngắm (ảnh xem trước, ảnh đóng băng, hiệu ứng chụp, hiệu ứng đổi ống kính) đều bị cắt bo góc
        for (v in listOf<View>(texture, freeze, fx, lensFx, hqFx, nightFx, leFx)) {
            v.outlineProvider = roundOutline
            v.clipToOutline = true
        }
        // toàn bộ giao diện camera nằm trong `content` (thu nhỏ sang trái khi mở ngăn kéo); ngăn kéo + khay nằm đè lên trên
        for (v in listOf<View>(decor, texture, freeze, fx, frame, focusBox, lensFx, hqFx, nightFx, leFx, ev, ladder, pills, zoomHud, curtain, shutter, thumb, filterBtn, toggle, gear, edit, theme, flash, wm, proc, night, timerPill, lever, fly)) {
            content.addView(v)
        }
        lever.pill = timerPill
        lever.visibility = GONE
        addView(content)
        addView(drawer)
        addView(tray)
        addView(splash)      // trên cùng: màn giới thiệu chế độ HQ / UP
        applyMode()
    }

    fun setSafe(l: Int, r: Int) {
        safeL = l; safeR = r
        decor.safeL = l.toFloat()
        decor.safeR = r.toFloat()
        requestLayout()
    }

    private fun applyMode() {
        // giao diện ngắm rộng luôn tối; chỉ giao diện giả máy ảnh mới có chế độ sáng
        Theme.light = light && classic
        theme.visibility = if (classic) VISIBLE else GONE
        if (tray.visibility != VISIBLE) drawer.visibility = GONE
        setBackgroundColor(if (classic) Theme.bgClassic else Theme.bgFull)
        for (v in listOf<XView>(decor, frame, focusBox, ev, ladder, pills, zoomHud, shutter, filterBtn, toggle, gear, edit, theme, flash, wm, proc, night, timerPill, lever)) v.classic = classic
        ladder.visibility = if (classic) VISIBLE else GONE
        pills.visibility = if (classic) GONE else VISIBLE
        pills.vertical = true
        lensFx.classic = classic
        for (v in listOf<View>(texture, freeze, fx, lensFx, hqFx, nightFx, leFx)) v.invalidateOutline()
        requestLayout()
        invalidate()
    }

    fun vfRect(): RectF = RectF(vf)

    /** Màn đen giới thiệu chế độ (~1s): "<tiêu đề> With LUNA. 3" + "( Without AI )". */
    fun showModeSplash(title: String) = splash.show(title)

    /** Bật/tắt chế độ hẹn giờ: cần gạt thay nút chụp, viên thuốc 00.00s hiện bên trái nút XPAN. */
    fun setTimerMode(on: Boolean) {
        timerOn = on
        shutter.visibility = if (on) INVISIBLE else VISIBLE
        lever.visibility = if (on) VISIBLE else GONE
        timerPill.visibility = if (on) VISIBLE else GONE
        if (!on) lever.reset()
        requestLayout()
    }

    // ---- ngăn kéo bộ lọc: giao diện thu nhỏ sang trái, ngăn kéo trượt vào từ mép phải
    private var drawerP = 0f
    private var drawerAnim: ValueAnimator? = null

    fun setDrawer(open: Boolean) {
        drawerAnim?.cancel()
        if (open) { drawer.visibility = VISIBLE; tray.visibility = VISIBLE }
        drawerAnim = ValueAnimator.ofFloat(drawerP, if (open) 1f else 0f).apply {
            duration = if (open) 280 else 210
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener { drawerP = it.animatedValue as Float; applyDrawer() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) {
                    if (!open && !cancelled) { drawer.visibility = GONE; tray.visibility = GONE }
                }
            })
            start()
        }
    }

    private fun applyDrawer() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val dw = DRAWER_DP * dn
        val s = (w - dw) / w
        val sc = 1f - (1f - s) * drawerP
        content.pivotX = 0f
        content.pivotY = h / 2f
        content.scaleX = sc
        content.scaleY = sc
        // giao diện ngắm rộng: tab XPAN × luôn ló ra ở mép phải làm nút kéo; giả máy ảnh thì ẩn hẳn khi đóng
        val closedOff = dw + 24f * dn
        val off = (1f - drawerP) * closedOff
        drawer.translationX = off
        tray.translationX = off + (if (classic) 0f else drawer.tabW * 0f)
    }


    fun thumbRect(): RectF = RectF(thumb.left.toFloat(), thumb.top.toFloat(), thumb.right.toFloat(), thumb.bottom.toFloat())

    /** Trong lúc chụp (theo video) khung ngắm, thang EV, dải zoom, ô nét... biến mất tức thì; lúc ảnh bay về thumbnail thì hiện lại. */
    fun setChromeHidden(hidden: Boolean) {
        val a = if (hidden) 0f else 1f
        frame.linesHidden = hidden
        if (!hidden) proc.stop()
        for (v in listOf<View>(focusBox, ev, ladder, pills, tray, drawer, wm, night, timerPill)) v.alpha = a
    }

    private fun place(v: View, l: Float, t: Float, r: Float, b: Float) {
        val li = l.toInt(); val ti = t.toInt(); val ri = r.toInt(); val bi = b.toInt()
        v.measure(MeasureSpec.makeMeasureSpec(ri - li, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(bi - ti, MeasureSpec.EXACTLY))
        v.layout(li, ti, ri, bi)
    }

    private fun placeC(v: View, cx: Float, cy: Float, w: Float, h: Float) =
        place(v, cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = (r - l).toFloat()
        val h = (b - t).toFloat()
        if (w <= 0f || h <= 0f) return
        // giao diện tối giản: khung ngắm nằm chính giữa màn hình (đối xứng hai bên, tránh tai thỏ)
        val side = max(safeL, safeR).toFloat()
        // toàn màn: lấy lề an toàn lớn hơn ở CẢ HAI bên để khung ngắm luôn đối xứng, không lệch về phải
        val ax = if (classic) safeL.toFloat() else side
        val aw = if (classic) w - safeL - safeR else w - 2f * side
        val vfW = if (classic) aw * 0.835f else aw                // ngắm rộng: vừa phải, chừa lề hai bên (đối xứng, tránh tai thỏ)
        val vfH = vfW * 24f / 65f
        val vfL = if (classic) ax + aw * 0.008f else ax + (aw - vfW) / 2f
        val vfT = (h - vfH) / 2f
        vf.set(vfL, vfT, vfL + vfW, vfT + vfH)
        decor.vf.set(vf)

        place(content, 0f, 0f, w, h)
        place(decor, 0f, 0f, w, h)
        place(texture, vf.left, vf.top, vf.right, vf.bottom)
        place(freeze, vf.left, vf.top, vf.right, vf.bottom)
        place(frame, vf.left, vf.top, vf.right, vf.bottom)
        place(focusBox, vf.left, vf.top, vf.right, vf.bottom)
        place(fx, vf.left, vf.top, vf.right, vf.bottom)
        place(curtain, vf.left, vf.top, vf.right, vf.bottom)
        place(lensFx, vf.left, vf.top, vf.right, vf.bottom)
        place(hqFx, vf.left, vf.top, vf.right, vf.bottom)
        place(nightFx, vf.left, vf.top, vf.right, vf.bottom)
        place(leFx, vf.left, vf.top, vf.right, vf.bottom)
        place(fly, 0f, 0f, w, h)

        val btn = h * 0.095f
        val by = if (classic) h * 0.085f else h * 0.072f
        // như ảnh mẫu: cài đặt ở góc trái trên (kèm nút sáng/tối bên cạnh), đổi chế độ ở góc trái dưới
        if (classic) {
            val bx = ax + btn * 0.72f + dn * 8f
            placeC(gear, bx, by, btn, btn)
            placeC(flash, bx + btn * 1.3f, by, btn, btn)         // flash ngay bên phải nút cài đặt
            placeC(theme, bx + btn * 2.6f, by, btn, btn)
            placeC(toggle, bx, h - by, btn, btn)
        } else {
            // ngắm rộng: hai biểu tượng trần ở hai góc trái, nằm ngoài khung ngắm
            val bx = ax + aw * 0.055f
            placeC(gear, bx, h * 0.067f, btn, btn)
            placeC(flash, bx + btn * 1.3f, h * 0.067f, btn, btn)
            placeC(theme, bx + btn * 1.3f, h * 0.067f, btn, btn)
            placeC(toggle, bx, h * 0.933f, btn, btn)
        }


        // nút XPAN (đổi khung / dấu chìm): phía trên, sát mép phải khung ngắm
        val wmW = dn * 76f
        placeC(wm, vf.right - wmW / 2f - dn * 2f, if (classic) by else h * 0.067f, wmW, dn * 40f)
        placeC(proc, vf.right - wmW / 2f - dn * 2f, if (classic) by else h * 0.067f, wmW, dn * 40f)   // đúng chỗ nút XPAN
        // huy hiệu thiếu sáng (trăng + giây): ngay bên trái nút XPAN
        val nW = dn * 78f
        placeC(night, vf.right - wmW - dn * 8f - nW / 2f, if (classic) by else h * 0.067f, nW, dn * 40f)

        // viên thuốc hẹn giờ (00.00s): bên trái nút XPAN, nhường chỗ cho huy hiệu thiếu sáng nếu đang hiện
        val pW = dn * 98f
        val pRight = vf.right - wmW - dn * 8f - (if (night.visibility == VISIBLE) nW + dn * 6f else 0f)
        placeC(timerPill, pRight - pW / 2f, if (classic) by else h * 0.067f, pW, dn * 40f)

        val evH = vfH * 0.55f
        var shCx: Float
        var shSz: Float
        var leverR = 0f
        if (classic) {
            val cx = ax + aw * 0.943f
            shCx = cx; shSz = h * 0.19f
            leverR = shSz * 0.30f
            placeC(shutter, cx, h * 0.5f, h * 0.19f, h * 0.19f)
            // hẹn giờ: bộ lọc + chỉnh sửa dồn lên sát nhau để chừa khoảng thở phía trên vùng quét của cần gạt
            placeC(filterBtn, cx, if (timerOn) h * 0.165f else h * 0.215f, aw * 0.075f, h * 0.095f)
            // nút chỉnh sửa: cột phải, giữa nút bộ lọc và nút chụp (dễ chạm bằng ngón cái)
            placeC(edit, cx, if (timerOn) h * 0.268f else h * 0.334f, btn, btn)
            placeC(thumb, cx, h * 0.8f, h * 0.115f, h * 0.115f)
            val n = ladder.labels.size
            val lh = min(vfH * 0.9f, n * dn * 52f).coerceAtLeast(dn * 52f)
            placeC(ladder, vf.right - dn * 34f, vf.centerY(), dn * 56f, lh)
            placeC(zoomHud, vf.right - dn * 34f - dn * 78f, vf.centerY(), dn * 104f, dn * 30f)
            place(ev, vf.left + vfW * 0.02f, vf.centerY() - evH * 0.35f, vf.left + vfW * 0.02f + dn * 90f, vf.centerY() - evH * 0.35f + evH)
        } else {
            val cx = vf.right - vfW * 0.087f
            val sh = h * 0.235f                       // nút chụp to hơn cho cân đối
            shCx = cx; shSz = sh
            placeC(shutter, cx, vf.centerY(), sh, sh)
            val th = h * 0.105f
            val gapV = h * 0.02f
            val eh = h * 0.08f
            val fh = h * 0.085f
            if (timerOn) {
                // hẹn giờ: album xuống sát đáy khung, bộ lọc + chỉnh sửa xếp NGANG ở sát đỉnh khung -> giữa cột trống cho cần gạt quét
                val tcyT = vf.bottom - th / 2f - vfH * 0.03f
                placeC(thumb, cx, tcyT, th, th)
                val topY = vf.top + vfH * 0.04f + fh / 2f
                val sep = max(fh, eh) / 2f + gapV
                placeC(filterBtn, cx - sep, topY, fh, fh)
                placeC(edit, cx + sep, topY, eh, eh)
                leverR = min(sh * 0.30f, (tcyT - th / 2f - vf.centerY() - dn * 8f) / 2.75f)
            } else {
                // album ngay dưới nút chụp; filter + chỉnh thông số ngay trên nút chụp với cùng khoảng hở -> cột cân xứng
                val tcy = min(vf.centerY() + sh / 2f + gapV + th / 2f, vf.bottom - th / 2f - vfH * 0.03f)
                placeC(thumb, cx, tcy, th, th)
                val ey = vf.centerY() - sh / 2f - gapV - eh / 2f
                placeC(edit, cx, ey, eh, eh)
                placeC(filterBtn, cx, ey - eh / 2f - gapV - fh / 2f, fh, fh)
                leverR = sh * 0.30f
            }
            // nút tiêu cự: cột dọc ngay bên trái nút chụp (hẹn giờ: lùi sang trái ngoài vùng quét của cán gạt)
            val n = pills.labels.size
            val ph = if (n == 0) dn * 40f else n * pills.pillSize() + (n - 1) * pills.gap() + pills.pad() * 2f
            val pw = pills.pillSize() + pills.pad() * 2f
            val px = if (timerOn) cx - (leverR * 2.75f + dn * 6f) - dn * 14f - pw / 2f else cx - sh / 2f - dn * 16f - pw / 2f
            placeC(pills, px, vf.centerY(), pw, ph)
            placeC(zoomHud, px - pw / 2f - dn * 8f - dn * 56f, vf.centerY(), dn * 112f, dn * 30f)
            place(ev, vf.left + vfW * 0.04f, vf.centerY() - evH * 0.5f, vf.left + vfW * 0.04f + dn * 90f, vf.centerY() - evH * 0.5f + evH)
        }
        // cần gạt hẹn giờ: trục trùng tâm nút chụp, vùng quét của cán nằm bên trái + phía trên/dưới trục
        run {
            val shCy = if (classic) h * 0.5f else vf.centerY()
            val hr = if (leverR > 0f) leverR else shSz * 0.30f
            val reach = hr * 2.75f + dn * 6f
            val rim = hr * 1.95f
            val l = shCx - max(reach, rim)
            val t = shCy - max(reach, rim)
            lever.hubX = shCx - l
            lever.hubY = shCy - t
            lever.hubR = hr
            place(lever, l, t, shCx + rim, shCy + max(reach, rim))
        }
        // ngăn kéo bộ lọc bên phải + khay cuộn dọc bên trong
        val dw = DRAWER_DP * dn
        place(drawer, w - dw - drawer.tabW, 0f, w, h)
        place(tray, w - dw + 16f * dn, 0f, w - 4f * dn, h)
        place(splash, 0f, 0f, w, h)
        val padv = (16f * dn).toInt()
        if (tray.paddingTop != padv) tray.setPadding(0, padv, 0, padv)
        applyDrawer()
    }
}

/**
 * Phơi sáng lâu: khung ngắm đóng băng mờ đi, ảnh CỘNG DỒN trực tiếp hiện ở giữa (đúng tỉ lệ 65:24 sẽ lưu), nhãn thời gian đỏ đếm lên
 * (00:00, 00:01…) và dòng nhắc giữ máy yên. Bấm nút chụp để dừng. Xử lí xong ảnh kết quả hiện dần thay ảnh cộng dồn.
 */
class LongExpFxView(ctx: Context) : XView(ctx), MultiFx {
    private var frozen: Bitmap? = null
    private var live: Bitmap? = null
    private var result: Bitmap? = null
    private var started = false
    private var startMs = 0L
    private var stopping = false
    private var merging = false
    private var mergePct = 0f
    private var mergeTarget = 0f
    private var frozenSecs = -1
    private var finishU = 0f
    private var ticker: ValueAnimator? = null
    private var finishAnim: ValueAnimator? = null
    private val bp = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val dst = RectF()
    private val pill = RectF()
    private val dstFrozen = RectF()

    init { visibility = GONE }

    fun start(frozenBmp: Bitmap?) {
        stop()
        frozen = frozenBmp
        visibility = VISIBLE
        alpha = 1f
        ticker = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            repeatCount = ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener {
                mergePct += (mergeTarget - mergePct) * 0.15f
                invalidate()
            }
            start()
        }
        invalidate()
    }

    /** Camera đã bắt đầu phơi sáng thật: đồng hồ đếm lên từ đây. */
    fun startClock() { started = true; startMs = SystemClock.uptimeMillis(); invalidate() }
    fun setStopping() { stopping = true; invalidate() }

    /** Ảnh cộng dồn mới nhất (đã xoay đúng chiều cầm máy). */
    fun setPreview(b: Bitmap?) {
        if (b == null) return
        val old = live
        live = b
        if (old != null && old !== b) old.recycle()
        invalidate()
    }

    override fun setCaptured(n: Int) {}
    override fun beginMerge() {
        if (!merging) { merging = true; frozenSecs = elapsedSecs() }
        mergeTarget = max(mergeTarget, 0.02f)
        invalidate()
    }
    override fun setMerge(pct: Int) {
        if (!merging) { merging = true; frozenSecs = elapsedSecs() }
        mergeTarget = (pct / 100f).coerceIn(0f, 1f)
    }

    private fun elapsedSecs(): Int = if (!started) 0 else ((SystemClock.uptimeMillis() - startMs) / 1000L).toInt()

    override fun complete(res: Bitmap?, done: () -> Unit) {
        mergeTarget = 1f
        mergePct = 1f
        result = res
        finishAnim?.cancel()
        if (res == null) { done(); return }
        finishAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 700
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener { finishU = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) { if (!cancelled) done() }
            })
            start()
        }
    }

    override fun stop() {
        ticker?.cancel(); ticker = null
        finishAnim?.cancel(); finishAnim = null
        started = false; stopping = false; merging = false
        mergePct = 0f; mergeTarget = 0f; finishU = 0f; frozenSecs = -1
        val l = live
        live = null
        l?.recycle()
        frozen = null; result = null
        visibility = GONE
    }

    private fun fit(b: Bitmap, out: RectF) {
        val w = width.toFloat()
        val h = height.toFloat()
        val k = min(w / b.width, h / b.height)
        val bw = b.width * k
        val bh = b.height * k
        out.set((w - bw) / 2f, (h - bh) / 2f, (w + bw) / 2f, (h + bh) / 2f)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(0xFF000000.toInt())
        val fz = frozen
        if (fz != null) {
            dstFrozen.set(0f, 0f, w, h)
            bp.alpha = 90
            c.drawBitmap(fz, null, dstFrozen, bp)
        }
        bp.alpha = 255
        val lv = live
        if (lv != null) {
            fit(lv, dst)
            c.drawBitmap(lv, null, dst, bp)
        }
        val rs = result
        if (rs != null && finishU > 0f) {
            dstFrozen.set(0f, 0f, w, h)
            bp.alpha = (finishU * 255f).toInt()
            c.drawBitmap(rs, null, dstFrozen, bp)
            bp.alpha = 255
        }
        val top = d(14f)
        // dòng nhắc
        p.style = Paint.Style.FILL
        p.shader = null
        p.typeface = Typeface.DEFAULT
        p.textAlign = Paint.Align.CENTER
        p.textSize = d(12f)
        p.color = 0xFFFFFFFF.toInt()
        p.setShadowLayer(d(3f), 0f, d(1f), 0xAA000000.toInt())
        val hint = when {
            merging -> "Đang xử lí ảnh"
            stopping -> "Đang dừng…"
            started -> "Giữ điện thoại ổn định · bấm nút chụp để dừng"
            else -> "Đang lấy nét…"
        }
        c.drawText(hint, w / 2f, top + d(46f), p)
        p.clearShadowLayer()
        // nhãn thời gian đỏ
        val secs = if (merging) max(frozenSecs, 0) else elapsedSecs()
        val label = String.format(java.util.Locale.US, "%02d:%02d", secs / 60, secs % 60)
        p.textSize = d(14f)
        p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        val tw = p.measureText(label)
        pill.set(w / 2f - tw / 2f - d(12f), top, w / 2f + tw / 2f + d(12f), top + d(30f))
        p.color = if (started) 0xFFE5232E.toInt() else 0x88555555.toInt()
        c.drawRoundRect(pill, d(15f), d(15f), p)
        p.color = 0xFFFFFFFF.toInt()
        c.drawText(label, w / 2f, pill.centerY() + d(5f), p)
        p.typeface = Typeface.DEFAULT
        // thanh tiến trình xử lí
        if (merging) {
            val bh = d(3f)
            p.color = 0x55FFFFFF
            c.drawRect(w * 0.2f, h - d(28f), w * 0.8f, h - d(28f) + bh, p)
            p.color = ORANGE
            c.drawRect(w * 0.2f, h - d(28f), w * 0.2f + w * 0.6f * mergePct, h - d(28f) + bh, p)
        }
        if (visibility == VISIBLE && (started || merging)) postInvalidateOnAnimation()
    }
}
