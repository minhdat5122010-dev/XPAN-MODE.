package com.xpanmode.app

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.min

// ---------------------------------------------------------------- Bộ lọc màu

class Filt(val name: String, val short: String, val matrix: ColorMatrix?)

object Filters {
    /** Ma trận: bão hoà -> tương phản quanh 128 -> độ sáng -> cân bằng kênh màu. */
    private fun make(
        sat: Float = 1f, con: Float = 1f, bri: Float = 0f,
        gr: Float = 1f, gg: Float = 1f, gb: Float = 1f,
        ro: Float = 0f, go: Float = 0f, bo: Float = 0f
    ): ColorMatrix {
        val m = ColorMatrix()
        m.setSaturation(sat)
        val k = 128f * (1f - con) + bri
        m.postConcat(
            ColorMatrix(
                floatArrayOf(
                    con * gr, 0f, 0f, 0f, k + ro,
                    0f, con * gg, 0f, 0f, k + go,
                    0f, 0f, con * gb, 0f, k + bo,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
        return m
    }

    val list = listOf(
        Filt("Gốc (Original)", "Original", null),
        // Hasselblad Natural Colour: trung thực, da ấm nhẹ, tương phản mượt
        Filt("Hasselblad Natural", "Natural", make(sat = 0.96f, con = 1.07f, bri = -2f, gr = 1.015f, gb = 0.985f, ro = 1f, bo = -1f)),
        // Leica cổ điển: đậm đà, tương phản cao, đen sâu, ấm nhẹ
        Filt("Leica Classic", "Leica", make(sat = 1.14f, con = 1.22f, bri = -8f, gr = 1.04f, gb = 0.93f, go = 1f, bo = 3f)),
        // Zeiss: trong trẻo, sáng da, hơi mát
        Filt("Zeiss Clear", "Zeiss", make(sat = 1.06f, con = 1.04f, bri = 16f, gg = 1.01f, gb = 1.03f, bo = 2f)),
        // Leica Monochrom
        Filt("Leica Mono", "Mono", make(sat = 0f, con = 1.3f, bri = -10f))
    )

    val invert = ColorMatrix(
        floatArrayOf(
            -1f, 0f, 0f, 0f, 255f,
            0f, -1f, 0f, 0f, 255f,
            0f, 0f, -1f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f
        )
    )
}

// ---------------------------------------------------------------- Khung ngắm

class ViewfinderView(ctx: Context) : View(ctx) {
    var classic = false
        set(v) { field = v; rebuild(); invalidate() }
    var evText = "0.0"
    var evNorm = 0f                       // -1..1
    var onTap: ((Float, Float) -> Unit)? = null
    var onEvDelta: ((Float) -> Unit)? = null

    private var focus: PointF? = null
    private var focusAlpha = 0f

    private val d = resources.displayMetrics.density
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xE6FFFFFF.toInt(); strokeCap = Paint.Cap.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; typeface = Typeface.DEFAULT }
    private val edge = Paint()
    private var shaders: List<LinearGradient> = emptyList()
    private var edgeT = 0f

    private fun rebuild() {
        val w = width.toFloat(); val h = height.toFloat()
        if (w == 0f) return
        edgeT = if (classic) 16f * d else 34f * d
        val c0 = if (classic) 0x99000000.toInt() else 0xFF000000.toInt()
        val c1 = 0x00000000
        shaders = listOf(
            LinearGradient(0f, 0f, 0f, edgeT, c0, c1, Shader.TileMode.CLAMP),
            LinearGradient(0f, h, 0f, h - edgeT, c0, c1, Shader.TileMode.CLAMP),
            LinearGradient(0f, 0f, edgeT, 0f, c0, c1, Shader.TileMode.CLAMP),
            LinearGradient(w, 0f, w - edgeT, 0f, c0, c1, Shader.TileMode.CLAMP)
        )
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { rebuild() }

    fun showFocus(x: Float, y: Float) {
        focus = PointF(x, y); focusAlpha = 1f; invalidate()
        postDelayed({ fade() }, 700)
    }

    private fun fade() {
        focusAlpha -= 0.1f
        if (focusAlpha > 0f) { invalidate(); postDelayed({ fade() }, 40) } else { focusAlpha = 0f; invalidate() }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()

        // viền mờ (orange: mềm như video, classic: nhẹ)
        if (shaders.size == 4) {
            edge.shader = shaders[0]; c.drawRect(0f, 0f, w, edgeT, edge)
            edge.shader = shaders[1]; c.drawRect(0f, h - edgeT, w, h, edge)
            edge.shader = shaders[2]; c.drawRect(0f, 0f, edgeT, h, edge)
            edge.shader = shaders[3]; c.drawRect(w - edgeT, 0f, w, h, edge)
        }

        // khung góc + các đoạn ngắm
        line.strokeWidth = 2.2f * d
        val m = 7f * d
        val len = h * 0.17f
        val r = if (classic) 1.5f * d else 11f * d
        val p = Path()
        p.moveTo(m, m + len); p.lineTo(m, m + r); p.arcTo(RectF(m, m, m + 2 * r, m + 2 * r), 180f, 90f); p.lineTo(m + len, m)
        p.moveTo(w - m - len, m); p.lineTo(w - m - r, m); p.arcTo(RectF(w - m - 2 * r, m, w - m, m + 2 * r), 270f, 90f); p.lineTo(w - m, m + len)
        p.moveTo(m, h - m - len); p.lineTo(m, h - m - r); p.arcTo(RectF(m, h - m - 2 * r, m + 2 * r, h - m), 180f, -90f); p.lineTo(m + len, h - m)
        p.moveTo(w - m - len, h - m); p.lineTo(w - m - r, h - m); p.arcTo(RectF(w - m - 2 * r, h - m - 2 * r, w - m, h - m), 90f, -90f); p.lineTo(w - m, h - m - len)
        c.drawPath(p, line)
        c.drawLine(w * 0.43f, m, w * 0.60f, m, line)
        c.drawLine(w * 0.14f, m, w * 0.19f, m, line)
        c.drawLine(w * 0.22f, h - m, w * 0.31f, h - m, line)
        c.drawLine(w * 0.63f, h - m, w * 0.72f, h - m, line)
        c.drawLine(m, h * 0.36f, m, h * 0.60f, line)
        c.drawLine(w - m, h * 0.34f, w - m, h * 0.60f, line)

        // thang EV bên trái
        val ex = w * 0.045f
        val cy = h * 0.5f
        line.strokeWidth = 1.6f * d
        for (i in -2..2) {
            val y = cy + i * h * 0.075f
            c.drawLine(ex - 7f * d, y, ex + (if (i == 0) 9f else 4f) * d, y, line)
        }
        val py = cy - evNorm * h * 0.15f
        val tri = Path().apply {
            moveTo(ex + 16f * d, py - 7f * d); lineTo(ex + 16f * d, py + 7f * d); lineTo(ex + 6f * d, py); close()
        }
        c.drawPath(tri, fill)
        text.textSize = 15f * d
        c.drawText(evText, ex + 24f * d, py + 5f * d, text)

        // ô lấy nét
        focus?.let { f ->
            if (focusAlpha > 0f) {
                line.alpha = (255 * focusAlpha).toInt()
                line.strokeWidth = 2f * d
                val s = 30f * d
                c.drawRect(f.x - s, f.y - s, f.x + s, f.y + s, line)
                line.alpha = 230
            }
        }
    }

    private var downX = 0f; private var downY = 0f; private var lastY = 0f
    private var evDrag = false; private var moved = false

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y; lastY = e.y; moved = false
                evDrag = e.x < width * 0.16f
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(e.y - downY) > 10f * d) moved = true
                if (evDrag) { onEvDelta?.invoke(lastY - e.y); lastY = e.y }
            }
            MotionEvent.ACTION_UP -> {
                if (!evDrag && !moved) onTap?.invoke(e.x / width, e.y / height)
                evDrag = false
            }
        }
        return true
    }
}

// ---------------------------------------------------------------- Nút chụp

class ShutterView(ctx: Context) : View(ctx) {
    var classic = false
        set(v) { field = v; invalidate() }

    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init { isClickable = true }

    override fun setPressed(pressed: Boolean) {
        super.setPressed(pressed)
        animate().scaleX(if (pressed) 0.92f else 1f).scaleY(if (pressed) 0.92f else 1f).setDuration(80).start()
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f; val cy = height / 2f
        val r = min(width, height) / 2f - 2f * d
        if (!classic) {
            p.style = Paint.Style.STROKE; p.strokeWidth = 4f * d; p.shader = null; p.color = Color.WHITE
            c.drawCircle(cx, cy, r - 2f * d, p)
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(cx, cy - r * 0.3f, r, 0xFFF9923F.toInt(), 0xFFE8620C.toInt(), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r * 0.80f, p)
        } else {
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(cx, cy - r, cx, cy + r, 0xFFF2F2F2.toInt(), 0xFF8E8E8E.toInt(), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r, p)
            p.shader = LinearGradient(cx, cy - r, cx, cy + r, 0xFF8A8A8A.toInt(), 0xFFEFEFEF.toInt(), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r * 0.88f, p)
            p.shader = LinearGradient(cx, cy - r, cx, cy + r, 0xFFFDFDFD.toInt(), 0xFFBEBEBE.toInt(), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r * 0.80f, p)
            p.shader = null
        }
    }
}
