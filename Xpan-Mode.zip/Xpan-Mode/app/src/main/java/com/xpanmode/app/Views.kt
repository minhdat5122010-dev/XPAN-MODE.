package com.xpanmode.app

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BlurMaskFilter
import android.graphics.ColorMatrixColorFilter
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Matrix
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.view.TextureView
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.roundToInt

const val ORANGE = 0xFFF47B20.toInt()

/** Phản hồi chạm chung: nhấn xuống thì co lại (kèm rung nhẹ), thả ra thì nảy về — không chặn sự kiện click. */
fun View.pressFeedback(down: Float = 0.92f, haptic: Boolean = true) {
    setOnTouchListener { v, e ->
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                v.animate().cancel()
                v.animate().scaleX(down).scaleY(down).setDuration(80).setInterpolator(DecelerateInterpolator()).start()
                if (haptic) v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                v.animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()
        }
        false
    }
}

/** "Nảy" nhẹ một view (dùng khi chọn / đổi giá trị). */
fun View.pop(peak: Float = 1.12f) {
    animate().cancel()
    animate().scaleX(peak).scaleY(peak).setDuration(90).setInterpolator(DecelerateInterpolator()).withEndAction {
        animate().scaleX(1f).scaleY(1f).setDuration(220).setInterpolator(OvershootInterpolator(3f)).start()
    }.start()
}

/** Chủ đề giao diện dùng chung: false = tối (mặc định), true = trắng. Các view đọc trực tiếp khi vẽ. */
object Theme {
    @JvmStatic var light = false
    val bgFull: Int get() = if (light) 0xFFF6F6F8.toInt() else Color.BLACK
    val bgClassic: Int get() = if (light) 0xFFE4E4E8.toInt() else 0xFF1F1F21.toInt()
    /** Màu chữ / biểu tượng đặt trên nền giao diện (không phải trên ảnh). */
    val ink: Int get() = if (light) 0xFF1B1B1E.toInt() else Color.WHITE
}

abstract class XView(ctx: Context) : View(ctx) {
    var classic: Boolean = true
        set(v) { field = v; invalidate() }
    protected val p = Paint(Paint.ANTI_ALIAS_FLAG)
    protected fun d(v: Float): Float = v * resources.displayMetrics.density
}

/** Giao diện máy ảnh tối giản: nền xám đen phẳng, đường kẻ mảnh có vát góc, nhãn HASSELBLAD, viền đen quanh khung ngắm. */
class DecorView(ctx: Context) : XView(ctx) {
    val vf = RectF()
    var safeL = 0f
    var safeR = 0f
    private val logoFace = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
    private val line = Path()

    /** Đường kẻ: chạy ngang, vát xuống (hoặc lên) quanh nhãn rồi chạy tiếp tới mép phải. */
    private fun hud(c: Canvas, x0: Float, y: Float, cx: Float, half: Float, k: Float, depth: Float, w: Float) {
        line.reset()
        line.moveTo(x0, y)
        line.lineTo(cx - half - k, y)
        line.lineTo(cx - half, y + depth)
        line.lineTo(cx + half, y + depth)
        line.lineTo(cx + half + k, y)
        line.lineTo(w, y)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        c.save()
        c.translate(0f, d(1.2f))
        p.color = if (Theme.light) 0xFFFFFFFF.toInt() else 0xFF08080A.toInt()
        c.drawPath(line, p)
        c.restore()
        p.color = if (Theme.light) 0xFFB4B4BB.toInt() else 0xFF5A5A60.toInt()
        c.drawPath(line, p)
    }

    private fun screw(c: Canvas, x: Float, y: Float, r: Float) {
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(
            x - r * 0.3f, y - r * 0.3f, r * 1.3f,
            if (Theme.light) 0xFFFFFFFF.toInt() else 0xFFD6D6DA.toInt(),
            if (Theme.light) 0xFF9A9AA2.toInt() else 0xFF4A4A4F.toInt(), Shader.TileMode.CLAMP
        )
        c.drawCircle(x, y, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.28f
        p.color = if (Theme.light) 0xFF6A6A71.toInt() else 0xFF16161A.toInt()
        c.save()
        c.rotate(35f, x, y)
        c.drawLine(x - r * 0.7f, y, x + r * 0.7f, y, p)
        c.restore()
        p.strokeWidth = d(0.8f)
        p.color = 0x66000000
        c.drawCircle(x, y, r, p)
    }

    override fun onDraw(c: Canvas) {
        if (!classic) return
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = vf.centerX()
        val ax = safeL
        val aw = w - safeL - safeR

        // nền phẳng
        c.drawColor(Theme.bgClassic)

        val half = w * 0.16f
        val k = w * 0.03f
        val depth = h * 0.06f
        val by = h * 0.085f                  // trục ngang của hàng nút phía trên
        val tx = ax + aw * 0.045f            // tâm nút đầu tiên
        val btn = h * 0.095f
        // đường kẻ trên: bắt đầu sau 2 nút (đổi giao diện, cài đặt); đường kẻ dưới đối xứng
        val x0 = tx + btn * 1.3f + btn * 0.75f
        hud(c, x0, by, cx, half, k, depth, w)
        hud(c, x0, h - by, cx, half, k, -depth, w)

        // viền đen bo góc quanh khung ngắm
        val o = d(5f)
        val ch = d(2.2f)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, vf.top - o - ch, 0f, vf.bottom + o + ch,
            if (Theme.light) intArrayOf(0xFFFFFFFF.toInt(), 0xFFD6D6DC.toInt(), 0xFFA8A8AF.toInt(), 0xFFEFEFF2.toInt())
            else intArrayOf(0xFFB4B4BA.toInt(), 0xFF55555A.toInt(), 0xFF2E2E32.toInt(), 0xFF84848A.toInt()),
            floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(vf.left - o - ch, vf.top - o - ch, vf.right + o + ch, vf.bottom + o + ch, d(14f), d(14f), p)
        p.shader = null
        p.color = 0xFF000000.toInt()
        c.drawRoundRect(vf.left - o, vf.top - o, vf.right + o, vf.bottom + o, d(12f), d(12f), p)

        // chữ khắc XPAN · 65:24 ở giữa phía dưới (dưới đường vát)
        p.style = Paint.Style.FILL
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        p.textSize = h * 0.034f
        p.letterSpacing = 0.32f
        p.textAlign = Paint.Align.CENTER
        p.color = if (Theme.light) 0xFF8A8A92.toInt() else 0xFFA9A9AF.toInt()
        c.drawText("XPAN  ·  65:24", cx, h - by + p.textSize * 0.35f, p)
        p.typeface = Typeface.DEFAULT
        p.letterSpacing = 0f

        // nhãn HASSELBLAD
        val txt = "HASSELBLAD"
        p.typeface = logoFace
        p.textSize = minOf(h * 0.052f, h * 0.06f)
        p.letterSpacing = 0.28f
        p.textAlign = Paint.Align.CENTER
        val tw = p.measureText(txt)
        val ph = p.textSize * 0.9f
        p.style = Paint.Style.FILL
        val bl = cx - tw / 2 - d(12f)
        val br = cx + tw / 2 + d(12f)
        p.shader = LinearGradient(0f, by - ph, 0f, by + ph, if (Theme.light) 0xFFFFFFFF.toInt() else 0xFF4A4A4E.toInt(), if (Theme.light) 0xFFD6D6DB.toInt() else 0xFF2A2A2D.toInt(), Shader.TileMode.CLAMP)
        c.drawRoundRect(bl, by - ph, br, by + ph, d(4f), d(4f), p)
        p.shader = null
        // vân phay xước
        c.save()
        c.clipRect(bl, by - ph, br, by + ph)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(0.5f)
        p.color = if (Theme.light) 0x16000000 else 0x10FFFFFF
        var yy = by - ph
        while (yy < by + ph) { c.drawLine(bl, yy, br, yy, p); yy += d(2.2f) }
        c.restore()
        // mép chrome
        p.shader = LinearGradient(0f, by - ph, 0f, by + ph, if (Theme.light) 0xFFFFFFFF.toInt() else 0xFFA8A8AE.toInt(), if (Theme.light) 0xFF9A9AA2.toInt() else 0xFF45454A.toInt(), Shader.TileMode.CLAMP)
        p.strokeWidth = d(1.1f)
        c.drawRoundRect(bl, by - ph, br, by + ph, d(4f), d(4f), p)
        p.shader = null
        p.style = Paint.Style.FILL
        p.color = if (Theme.light) 0xFF26262A.toInt() else 0xFFF2F2F2.toInt()
        c.drawText(txt, cx, by + p.textSize * 0.33f, p)
        p.typeface = Typeface.DEFAULT
        p.letterSpacing = 0f
        p.textAlign = Paint.Align.LEFT

        // vít kim loại hai góc dưới
        // (vít góc trái dưới nhường chỗ cho nút đổi giao diện sáng/tối)
        screw(c, w - w * 0.03f, h - by, d(4.5f))
    }
}

/** Viền đen mờ dần quanh khung ngắm (giao diện toàn màn). Dùng chung cho khung và cho hiệu ứng chuyển ống kính để hai bên liền mạch. */
fun drawEdgeFade(c: Canvas, p: Paint, w: Float, h: Float) {
    val bg = Theme.bgFull
    val e = bg or 0xFF000000.toInt()
    val z = bg and 0x00FFFFFF
    val fx = w * 0.022f
    val fy = h * 0.07f
    p.style = Paint.Style.FILL
    p.shader = LinearGradient(0f, 0f, fx, 0f, e, z, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, fx, h, p)
    p.shader = LinearGradient(w, 0f, w - fx, 0f, e, z, Shader.TileMode.CLAMP); c.drawRect(w - fx, 0f, w, h, p)
    p.shader = LinearGradient(0f, 0f, 0f, fy, e, z, Shader.TileMode.CLAMP); c.drawRect(0f, 0f, w, fy, p)
    p.shader = LinearGradient(0f, h, 0f, h - fy, e, z, Shader.TileMode.CLAMP); c.drawRect(0f, h - fy, w, h, p)
    p.shader = null
}

/**
 * Nút "kính mờ" cho giao diện toàn màn: nền trong suốt chuyển sắc, vầng sáng nhoè (blur) ở nửa trên,
 * viền xám mảnh có độ sáng giảm dần từ trên xuống. Không chụp/làm mờ khung ngắm thật nên không tốn CPU.
 */
fun drawGlassDisc(c: Canvas, p: Paint, cx: Float, cy: Float, r: Float, dn: Float) {
    val light = Theme.light
    val oldStyle = p.style
    val oldW = p.strokeWidth
    // thân kính
    p.style = Paint.Style.FILL
    p.shader = LinearGradient(
        0f, cy - r, 0f, cy + r,
        if (light) intArrayOf(0xF4FFFFFF.toInt(), 0xDDEDEDF1.toInt()) else intArrayOf(0x4DFFFFFF, 0x1F9A9AA2),
        null, Shader.TileMode.CLAMP
    )
    c.drawCircle(cx, cy, r, p)
    p.shader = null
    // vầng sáng nhoè phía trên, cắt trong hình tròn
    c.save()
    val clip = Path()
    clip.addCircle(cx, cy, r, Path.Direction.CW)
    c.clipPath(clip)
    p.maskFilter = BlurMaskFilter(r * 0.35f, BlurMaskFilter.Blur.NORMAL)
    p.color = if (light) 0xB0FFFFFF.toInt() else 0x30FFFFFF
    c.drawOval(cx - r * 0.7f, cy - r * 1.05f, cx + r * 0.7f, cy - r * 0.1f, p)
    p.maskFilter = null
    c.restore()
    // viền xám mảnh
    p.style = Paint.Style.STROKE
    p.strokeWidth = 1f * dn
    p.shader = LinearGradient(
        0f, cy - r, 0f, cy + r,
        if (light) intArrayOf(0x88787880.toInt(), 0x44787880) else intArrayOf(0xCCB4B4BA.toInt(), 0x66787880),
        null, Shader.TileMode.CLAMP
    )
    c.drawCircle(cx, cy, r - 0.5f * dn, p)
    p.shader = null
    p.style = oldStyle
    p.strokeWidth = oldW
}

/** Các vạch góc / cạnh của khung ngắm + viền mờ (giao diện tối giản) hoặc tối dần phía dưới (Hasselblad). */
class FrameOverlayView(ctx: Context) : XView(ctx) {
    private val path = Path()
    /** Khi chụp: ẩn các vạch khung nhưng GIỮ viền mờ/bo góc để ảnh đóng băng trông liền mạch với khung ngắm. */
    var linesHidden = false
        set(v) { field = v; invalidate() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        if (classic) {
            p.shader = LinearGradient(0f, h * 0.72f, 0f, h, 0x00000000, 0xB0000000.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, h * 0.72f, w, h, p)
            p.shader = null
        } else {
            drawEdgeFade(c, p, w, h)
        }
        if (linesHidden) return
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        val ins = if (classic) d(10f) else d(12f)
        val len = w * 0.045f
        val r = if (classic) d(4f) else d(10f)
        val top = if (classic) arrayOf(0.17f to 0.28f, 0.44f to 0.64f) else arrayOf(0.10f to 0.13f, 0.45f to 0.65f)
        val bot = if (classic) arrayOf(0.085f to 0.13f, 0.29f to 0.40f, 0.69f to 0.76f)
        else arrayOf(0.14f to 0.17f, 0.30f to 0.32f, 0.82f to 0.90f)
        val side = arrayOf(0.22f to 0.32f, 0.62f to 0.74f)
        val baseW = d(if (classic) 1.6f else 2.4f)
        // giao diện trắng: vẽ thêm một lớp viền sáng mờ bên dưới để vạch vẫn đọc được trên cả ảnh tối lẫn sáng
        val passes = if (Theme.light && !classic) listOf(0x99FFFFFF.toInt() to baseW + d(3f), 0xFF26262A.toInt() to baseW)
        else listOf((if (classic) 0xE6FFFFFF.toInt() else 0xFFD8D8D8.toInt()) to baseW)
        for ((col, sw) in passes) {
            p.strokeWidth = sw
            p.color = col
            path.reset()
            path.moveTo(ins, ins + len); path.lineTo(ins, ins + r)
            path.quadTo(ins, ins, ins + r, ins); path.lineTo(ins + len, ins)
            for (sx in floatArrayOf(1f, -1f)) for (sy in floatArrayOf(1f, -1f)) {
                c.save(); c.scale(sx, sy, w / 2f, h / 2f); c.drawPath(path, p); c.restore()
            }
            for ((a, b) in top) c.drawLine(w * a, ins, w * b, ins, p)
            for ((a, b) in bot) c.drawLine(w * a, h - ins, w * b, h - ins, p)
            for ((a, b) in side) {
                c.drawLine(ins, h * a, ins, h * b, p)
                c.drawLine(w - ins, h * a, w - ins, h * b, p)
            }
        }
    }
}

/** Khung lấy nét: hiện khi chạm, đổi màu khi bắt nét xong (xanh = nét, đỏ = không nét) rồi tự ẩn. */
class FocusBoxView(ctx: Context) : XView(ctx) {
    private var fx = 0f
    private var fy = 0f
    private var scale = 1f
    private var shown = false
    private var color = Color.WHITE
    private var anim: ValueAnimator? = null
    private val autoHide = Runnable { fadeOut() }

    init { visibility = GONE }

    fun showAt(x: Float, y: Float) {
        removeCallbacks(autoHide)
        animate().cancel()
        fx = x; fy = y
        color = Color.WHITE
        shown = true
        alpha = 1f
        visibility = VISIBLE
        anim?.cancel()
        anim = ValueAnimator.ofFloat(1.3f, 1f).apply {
            duration = 220
            addUpdateListener { scale = it.animatedValue as Float; invalidate() }
            start()
        }
        postDelayed(autoHide, 3500)
    }

    fun lock(ok: Boolean) {
        if (!shown) return
        removeCallbacks(autoHide)
        color = if (ok) 0xFF7CFF8A.toInt() else 0xFFFF6A5A.toInt()
        anim?.cancel()
        anim = ValueAnimator.ofFloat(1f, 0.82f).apply {
            duration = 130
            repeatCount = 1
            repeatMode = ValueAnimator.REVERSE
            interpolator = DecelerateInterpolator()
            addUpdateListener { scale = it.animatedValue as Float; invalidate() }
            start()
        }
        invalidate()
        postDelayed(autoHide, 450)
    }

    private fun fadeOut() {
        animate().alpha(0f).setDuration(220).withEndAction {
            shown = false
            visibility = GONE
            alpha = 1f
        }.start()
    }

    override fun onDraw(c: Canvas) {
        if (!shown) return
        val half = min(width, height) * 0.17f * scale
        val len = half * 0.45f
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.6f)
        p.color = color
        val l = fx - half; val r = fx + half; val t = fy - half; val b = fy + half
        c.drawLine(l, t, l + len, t, p); c.drawLine(l, t, l, t + len, p)
        c.drawLine(r, t, r - len, t, p); c.drawLine(r, t, r, t + len, p)
        c.drawLine(l, b, l + len, b, p); c.drawLine(l, b, l, b - len, p)
        c.drawLine(r, b, r - len, b, p); c.drawLine(r, b, r, b - len, p)
    }
}

/** Thanh bù sáng bên trái: vuốt dọc để đổi EV. */
class EvView(ctx: Context) : XView(ctx) {
    var min = 0
        set(v) { field = v; invalidate() }
    var max = 0
        set(v) { field = v; invalidate() }
    var step = 0f
    var value = 0
        set(v) { field = v; invalidate() }
    var onChange: ((Int) -> Unit)? = null
    private var downY = 0f
    private var downVal = 0

    override fun onDraw(c: Canvas) {
        if (max <= min) return
        val h = height.toFloat()
        val pad = d(8f)
        val n = (max - min).toFloat()
        val perEv = if (step > 0f) (1f / step).roundToInt().coerceAtLeast(1) else 1
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.4f)
        p.color = Color.WHITE
        if (Theme.light) p.setShadowLayer(d(2.5f), 0f, 0f, 0xAA000000.toInt())
        for (i in min..max) {
            val y = pad + (max - i) / n * (h - 2 * pad)
            val len = if (i % perEv == 0) d(14f) else d(5f)
            c.drawLine(d(4f), y, d(4f) + len, y, p)
        }
        val y = pad + (max - value) / n * (h - 2 * pad)
        p.style = Paint.Style.FILL
        val tri = Path()
        tri.moveTo(d(22f), y); tri.lineTo(d(32f), y - d(6f)); tri.lineTo(d(32f), y + d(6f)); tri.close()
        c.drawPath(tri, p)
        val ev = value * step
        val label = if (value == 0) "0.0" else String.format(Locale.US, "%+.1f", ev)
        p.textSize = d(14f)
        p.textAlign = Paint.Align.LEFT
        c.drawText(label, d(38f), y + d(5f), p)
        p.clearShadowLayer()
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downY = e.y; downVal = value
                parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                if (max > min) {
                    val per = (height - 2 * d(8f)) / (max - min)
                    val nv = (downVal - ((e.y - downY) / per).roundToInt()).coerceIn(min, max)
                    if (nv != value) { value = nv; onChange?.invoke(nv) }
                }
            }
        }
        return true
    }
}

/** Thang zoom bên phải (giao diện Hasselblad): 0,6 · 1 · 2 · 3× */
class ZoomLadderView(ctx: Context) : XView(ctx) {
    var labels: List<String> = emptyList()
        set(v) { field = v; invalidate(); requestLayout() }
    var selected = 0
        set(v) { field = v; slideTo(v.toFloat()) }
    var onSelect: ((Int) -> Unit)? = null

    private var selPos = 0f
    private var selAnim: ValueAnimator? = null
    private var pressed = -1

    private fun slideTo(t: Float) {
        selAnim?.cancel()
        selAnim = ValueAnimator.ofFloat(selPos, t).apply {
            duration = 240
            interpolator = OvershootInterpolator(0.9f)
            addUpdateListener { selPos = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun idxAt(y: Float): Int {
        val n = labels.size
        val k = (y / height * n).toInt().coerceIn(0, n - 1)
        return n - 1 - k
    }

    override fun onDraw(c: Canvas) {
        val n = labels.size
        if (n == 0) return
        val cellH = height.toFloat() / n
        val cx = width / 2f
        p.textAlign = Paint.Align.CENTER
        // vòng nền trượt theo lựa chọn
        val sy = (n - 1 - selPos + 0.5f) * cellH
        p.style = Paint.Style.FILL
        p.color = 0x66000000
        c.drawCircle(cx, sy, d(20f), p)
        for (k in 0 until n) {
            val idx = n - 1 - k
            val cy = (k + 0.5f) * cellH
            val sel = idx == selected
            val sc = if (idx == pressed) 0.86f else 1f
            p.style = Paint.Style.FILL
            p.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            p.textSize = d(if (sel) 16f else 15f) * sc
            p.color = if (sel) ORANGE else Color.WHITE
            val txt = if (sel) labels[idx] + "×" else labels[idx]
            c.drawText(txt, cx, cy + d(5.5f) * sc, p)
        }
        p.typeface = Typeface.DEFAULT
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (labels.isEmpty()) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressed = idxAt(e.y)
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                val i = idxAt(e.y)
                pressed = -1
                invalidate()
                onSelect?.invoke(i)
                performClick()
            }
            MotionEvent.ACTION_CANCEL -> { pressed = -1; invalidate() }
        }
        return true
    }
}

/** Các nút tiêu cự ở giữa dưới (giao diện tối giản): 14 · 23mm · 65 · 135 */
class LensPillsView(ctx: Context) : XView(ctx) {
    var labels: List<String> = emptyList()
        set(v) { field = v; invalidate(); requestLayout() }
    var selected = 0
        set(v) { field = v; slideTo(v.toFloat()) }
    var onSelect: ((Int) -> Unit)? = null

    private var selPos = 0f
    private var selAnim: ValueAnimator? = null
    private var pressed = -1

    fun pillSize() = d(33f)
    fun gap() = d(9f)

    private fun slideTo(t: Float) {
        selAnim?.cancel()
        selAnim = ValueAnimator.ofFloat(selPos, t).apply {
            duration = 240
            interpolator = OvershootInterpolator(0.9f)
            addUpdateListener { selPos = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun idxAt(x: Float) = (x / (pillSize() + gap())).toInt().coerceIn(0, (labels.size - 1).coerceAtLeast(0))

    override fun onDraw(c: Canvas) {
        val n = labels.size
        if (n == 0) return
        val s = pillSize()
        val r = s / 2f
        val cy = height / 2f
        p.textAlign = Paint.Align.CENTER
        for (i in 0 until n) {
            val cx = r + i * (s + gap())
            val rr = if (i == pressed) r * 0.88f else r
            drawGlassDisc(c, p, cx, cy, rr, resources.displayMetrics.density)
            p.style = Paint.Style.FILL
            val sel = i == selected
            p.color = if (sel) ORANGE else Theme.ink
            p.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            if (sel) {
                p.textSize = d(11f)
                c.drawText(labels[i], cx, cy - d(1f), p)
                p.textSize = d(8f)
                c.drawText("mm", cx, cy + d(9f), p)
            } else {
                p.textSize = d(11f)
                c.drawText(labels[i], cx, cy + d(4f), p)
            }
        }
        // vòng cam trượt từ nút cũ sang nút mới
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.6f)
        p.color = ORANGE
        c.drawCircle(r + selPos * (s + gap()), cy, r, p)
        p.style = Paint.Style.FILL
        p.typeface = Typeface.DEFAULT
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (labels.isEmpty()) return true
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressed = idxAt(e.x)
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                invalidate()
            }
            MotionEvent.ACTION_UP -> {
                val i = idxAt(e.x)
                pressed = -1
                invalidate()
                onSelect?.invoke(i)
                performClick()
            }
            MotionEvent.ACTION_CANCEL -> { pressed = -1; invalidate() }
        }
        return true
    }
}

class ShutterButton(ctx: Context) : XView(ctx) {
    private val hi = RectF()
    private var pressedNow = false
    /** Quầng sáng cam mạnh hơn trong lúc nhấn giữ. */
    private val lit get() = pressedNow
    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.96f
        p.style = Paint.Style.FILL
        if (classic) {
            // quả cầu trắng: vòng ngoài xám nhạt + lõi trắng bóng
            p.color = if (Theme.light) 0x33000000 else 0x55000000
            c.drawCircle(cx, cy + d(2f), r, p)
            p.shader = SweepGradient(
                cx, cy,
                if (Theme.light) intArrayOf(0xFFFFFFFF.toInt(), 0xFFB9B9C0.toInt(), 0xFFF4F4F6.toInt(), 0xFFA8A8B0.toInt(), 0xFFFFFFFF.toInt())
                else intArrayOf(0xFFCFCFD4.toInt(), 0xFF56565B.toInt(), 0xFFE6E6EA.toInt(), 0xFF46464B.toInt(), 0xFFCFCFD4.toInt()), null
            )
            c.drawCircle(cx, cy, r, p)
            p.shader = null
            p.color = if (Theme.light) 0xFFC4C4CA.toInt() else 0xFF17171A.toInt()
            c.drawCircle(cx, cy, r * 0.86f, p)
            p.shader = RadialGradient(cx - r * 0.18f, cy - r * 0.22f, r * 0.95f, 0xFFFFFFFF.toInt(), 0xFFCFCFD3.toInt(), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, r * 0.80f, p)
            p.shader = null
        } else {
            // nút chụp cơ bản: vòng trắng bên ngoài + nút cam đặc bên trong
            val ringW = r * 0.075f
            p.style = Paint.Style.STROKE
            p.strokeWidth = ringW
            p.color = Color.WHITE
            c.drawCircle(cx, cy, r - ringW / 2f, p)
            p.style = Paint.Style.FILL
            val rd = r * (if (pressedNow) 0.68f else 0.76f)
            p.color = ORANGE
            c.drawCircle(cx, cy, rd, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pressedNow = true; invalidate()
                animate().cancel()
                animate().scaleX(0.88f).scaleY(0.88f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                pressedNow = false; invalidate()
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3.5f)).start()
            }
        }
        return super.onTouchEvent(e)
    }
}

/** Nút bộ lọc: huy hiệu "Original" (Hasselblad) hoặc biểu tượng cuộn phim (tối giản). */
class FilterButtonView(ctx: Context) : XView(ctx) {
    var label: String = "Original"
        set(v) { val ch = field != v; field = v; invalidate(); if (ch) pop(1.08f) }

    init { isClickable = true }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                animate().cancel()
                animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()
        }
        return super.onTouchEvent(e)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (classic) {
            p.style = Paint.Style.FILL
            p.color = if (Theme.light) 0xFFF3F3F5.toInt() else 0xFF0E0E10.toInt()
            c.drawRoundRect(0f, 0f, w, h, d(14f), d(14f), p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(1f)
            p.color = if (Theme.light) 0xFFC0C0C7.toInt() else 0xFF3A3A3D.toInt()
            c.drawRoundRect(0f, 0f, w, h, d(14f), d(14f), p)
            p.strokeWidth = d(2f)
            p.shader = LinearGradient(
                w * 0.1f, 0f, w * 0.9f, 0f,
                intArrayOf(0x00F47B20, ORANGE, 0xFFFFC040.toInt(), ORANGE, 0x00F47B20),
                null, Shader.TileMode.CLAMP
            )
            c.drawLine(w * 0.1f, h * 0.2f, w * 0.9f, h * 0.2f, p)
            c.drawLine(w * 0.1f, h * 0.8f, w * 0.9f, h * 0.8f, p)
            p.shader = null
            p.style = Paint.Style.FILL
            p.color = Theme.ink
            p.typeface = Typeface.DEFAULT_BOLD
            p.textAlign = Paint.Align.CENTER
            p.textSize = h * 0.23f
            val fm = p.fontMetrics
            c.drawText(label, w / 2f, h / 2f - (fm.ascent + fm.descent) / 2f, p)
            p.typeface = Typeface.DEFAULT
        } else {
            drawGlassDisc(c, p, w / 2f, h / 2f, min(w, h) / 2f * 0.98f, resources.displayMetrics.density)
            c.save()
            c.scale(0.8f, 0.8f, w / 2f, h / 2f)
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(1.8f)
            p.color = Theme.ink
            c.drawRoundRect(w * 0.1f, h * 0.27f, w * 0.9f, h * 0.73f, d(3f), d(3f), p)
            p.style = Paint.Style.FILL
            val hole = w * 0.06f
            for (i in 0 until 5) {
                val x = w * (0.2f + i * 0.15f)
                c.drawRect(x, h * 0.31f, x + hole, h * 0.31f + hole, p)
                c.drawRect(x, h * 0.69f - hole, x + hole, h * 0.69f, p)
            }
            c.restore()
        }
    }
}

/** Nút chuyển giao diện (⇄) và nút cài đặt: núm kim loại khía (Hasselblad) hoặc biểu tượng phẳng (tối giản). */
class IconButtonView(ctx: Context, private val kind: Int) : XView(ctx) {
    companion object {
        const val GEAR = 0
        const val TOGGLE = 1
        const val EDIT = 2
        const val THEME = 3
    }

    init { isClickable = true }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                animate().cancel()
                animate().scaleX(0.86f).scaleY(0.86f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3.5f)).start()
        }
        return super.onTouchEvent(e)
    }

    private fun symbol(c: Canvas, cx: Float, cy: Float, r: Float) {
        if (kind == GEAR) {
            // biểu tượng lá khẩu độ
            p.strokeWidth = r * 0.07f
            c.drawCircle(cx, cy, r * 0.42f, p)
            for (i in 0 until 6) {
                val a1 = Math.toRadians(i * 60.0)
                val a2 = Math.toRadians(i * 60.0 + 62.0)
                c.drawLine(
                    cx + r * 0.42f * cos(a1).toFloat(), cy + r * 0.42f * sin(a1).toFloat(),
                    cx + r * 0.16f * cos(a2).toFloat(), cy + r * 0.16f * sin(a2).toFloat(), p
                )
            }
        } else if (kind == THEME) {
            if (Theme.light) {
                // đang sáng -> biểu tượng trăng lưỡi liềm (bấm để sang tối)
                val m = Path()
                m.addCircle(cx, cy, r * 0.36f, Path.Direction.CW)
                val cut = Path()
                cut.addCircle(cx + r * 0.20f, cy - r * 0.14f, r * 0.31f, Path.Direction.CW)
                m.op(cut, Path.Op.DIFFERENCE)
                val old = p.style
                p.style = Paint.Style.FILL
                c.drawPath(m, p)
                p.style = old
            } else {
                // đang tối -> biểu tượng mặt trời (bấm để sang sáng)
                p.strokeWidth = r * 0.075f
                c.drawCircle(cx, cy, r * 0.2f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0)
                    val ca = cos(a).toFloat(); val sa = sin(a).toFloat()
                    c.drawLine(cx + r * 0.34f * ca, cy + r * 0.34f * sa, cx + r * 0.50f * ca, cy + r * 0.50f * sa, p)
                }
            }
        } else if (kind == EDIT) {
            // biểu tượng 3 thanh trượt
            p.strokeWidth = r * 0.07f
            val x0 = cx - r * 0.42f
            val x1 = cx + r * 0.42f
            val kn = floatArrayOf(-0.18f, 0.2f, -0.05f)
            for (i in 0 until 3) {
                val y = cy + (i - 1) * r * 0.30f
                c.drawLine(x0, y, x1, y, p)
                val oldStyle = p.style
                p.style = Paint.Style.FILL
                c.drawCircle(cx + kn[i] * r * 2f, y, r * 0.085f, p)
                p.style = oldStyle
            }
        } else {
            p.strokeWidth = r * 0.085f
            val y1 = cy - r * 0.17f
            val y2 = cy + r * 0.17f
            val x0 = cx - r * 0.4f
            val x1 = cx + r * 0.4f
            val a = r * 0.14f
            c.drawLine(x0, y1, x1, y1, p)
            c.drawLine(x1, y1, x1 - a, y1 - a, p)
            c.drawLine(x1, y1, x1 - a, y1 + a, p)
            c.drawLine(x1, y2, x0, y2, p)
            c.drawLine(x0, y2, x0 + a, y2 - a, p)
            c.drawLine(x0, y2, x0 + a, y2 + a, p)
        }
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f
        p.strokeCap = Paint.Cap.ROUND
        if (classic) {
            p.style = Paint.Style.FILL
            p.shader = SweepGradient(
                cx, cy,
                if (Theme.light) intArrayOf(0xFFFFFFFF.toInt(), 0xFFB9B9C0.toInt(), 0xFFF4F4F6.toInt(), 0xFFA8A8B0.toInt(), 0xFFFFFFFF.toInt())
                else intArrayOf(0xFFCFCFD4.toInt(), 0xFF56565B.toInt(), 0xFFE6E6EA.toInt(), 0xFF46464B.toInt(), 0xFFCFCFD4.toInt()), null
            )
            c.drawCircle(cx, cy, r * 0.97f, p)
            p.shader = null
            p.color = if (Theme.light) 0xFFF2F2F4.toInt() else 0xFF3A3A3E.toInt()
            c.drawCircle(cx, cy, r * 0.88f, p)
            p.style = Paint.Style.STROKE
            p.color = if (Theme.light) 0xFF2A2A2E.toInt() else Color.WHITE
            symbol(c, cx, cy, r)
        } else {
            drawGlassDisc(c, p, cx, cy, r * 0.95f, resources.displayMetrics.density)
            p.style = Paint.Style.STROKE
            p.color = Theme.ink
            symbol(c, cx, cy, r)
        }
    }
}

/**
 * Tấm phủ xám phẳng của hiệu ứng màn trập (đo từ video mẫu): sau khi giữ ảnh âm bản ~1s,
 * xám phủ kín trong 0,2s rồi tan dần trong 0,6s để lộ ảnh.
 */
class ShutterFxView(ctx: Context) : View(ctx) {
    private var greyAlpha = 0f
    private var anim: ValueAnimator? = null
    private val grey = Color.rgb(132, 131, 134)

    override fun onDraw(c: Canvas) {
        if (greyAlpha > 0f) c.drawColor((grey and 0x00FFFFFF) or ((greyAlpha * 255).toInt().coerceIn(0, 255) shl 24))
    }

    private fun run(from: Float, to: Float, ms: Long, ip: android.view.animation.Interpolator, end: () -> Unit) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(from, to).apply {
            duration = ms
            interpolator = ip
            addUpdateListener { greyAlpha = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) { if (!cancelled) end() }
            })
            start()
        }
    }

    fun greyIn(ms: Long, onFull: () -> Unit) =
        run(0f, 1f, ms, android.view.animation.LinearInterpolator(), onFull)

    fun greyOut(ms: Long, onDone: () -> Unit) =
        run(1f, 0f, ms, android.view.animation.AccelerateDecelerateInterpolator(), onDone)

    fun reset() {
        anim?.cancel()
        greyAlpha = 0f
        invalidate()
    }
}

/**
 * Hiệu ứng "ảnh lưu về máy" (theo video): ảnh vừa chụp thu nhỏ rất nhanh (giảm tốc) từ khung ngắm
 * về ô thumbnail ở góc dưới phải, bo góc dần và chuyển từ khung rộng sang vuông.
 */
class SaveFlyView(ctx: Context) : View(ctx) {
    private var bmp: Bitmap? = null
    private val from = RectF()
    private val to = RectF()
    private val cur = RectF()
    private val src = android.graphics.Rect()
    private val clip = Path()
    private var t = 0f
    private var anim: ValueAnimator? = null
    private val dn = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
    }
    private val fade = Paint()
    /** true: giữ viền mờ + bo góc như khung ngắm lúc đầu rồi mất dần khi thu về thumbnail. */
    var soft = false

    init { visibility = GONE }

    private fun lerp(a: Float, b: Float, f: Float) = a + (b - a) * f

    fun start(b: Bitmap, f: RectF, target: RectF, ms: Long, onEnd: () -> Unit) {
        anim?.cancel()
        bmp = b
        from.set(f)
        to.set(target)
        t = 0f
        visibility = VISIBLE
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = ms
            interpolator = android.view.animation.DecelerateInterpolator(1.8f)
            addUpdateListener { t = it.animatedValue as Float; invalidate() }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(a: android.animation.Animator) { cancelled = true }
                override fun onAnimationEnd(a: android.animation.Animator) {
                    visibility = GONE
                    bmp = null
                    if (!cancelled) onEnd()
                }
            })
            start()
        }
    }

    fun cancel() {
        anim?.cancel()
        visibility = GONE
        bmp = null
    }

    override fun onDraw(c: Canvas) {
        val b = bmp ?: return
        cur.set(lerp(from.left, to.left, t), lerp(from.top, to.top, t), lerp(from.right, to.right, t), lerp(from.bottom, to.bottom, t))
        val dw = cur.width()
        val dh = cur.height()
        if (dw < 1f || dh < 1f) return
        // cắt kiểu "cover" để khung chuyển dần từ chữ nhật rộng sang vuông mà không méo ảnh
        val sa = b.width.toFloat() / b.height
        val da = dw / dh
        if (sa > da) {
            val w = (b.height * da).toInt().coerceAtLeast(1)
            src.set((b.width - w) / 2, 0, (b.width + w) / 2, b.height)
        } else {
            val h = (b.width / da).toInt().coerceAtLeast(1)
            src.set(0, (b.height - h) / 2, b.width, (b.height + h) / 2)
        }
        val r = lerp(if (soft) 12f * dn else 7f * dn, 6f * dn, t)
        clip.reset()
        clip.addRoundRect(cur, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        c.drawBitmap(b, src, cur, p)
        val k = ((1f - t) * 255).toInt()
        if (soft && k > 0) {
            val e = k shl 24
            val z = 0
            val fx = cur.width() * 0.022f
            val fy = cur.height() * 0.07f
            fade.shader = LinearGradient(cur.left, 0f, cur.left + fx, 0f, e, z, Shader.TileMode.CLAMP)
            c.drawRect(cur.left, cur.top, cur.left + fx, cur.bottom, fade)
            fade.shader = LinearGradient(cur.right, 0f, cur.right - fx, 0f, e, z, Shader.TileMode.CLAMP)
            c.drawRect(cur.right - fx, cur.top, cur.right, cur.bottom, fade)
            fade.shader = LinearGradient(0f, cur.top, 0f, cur.top + fy, e, z, Shader.TileMode.CLAMP)
            c.drawRect(cur.left, cur.top, cur.right, cur.top + fy, fade)
            fade.shader = LinearGradient(0f, cur.bottom, 0f, cur.bottom - fy, e, z, Shader.TileMode.CLAMP)
            c.drawRect(cur.left, cur.bottom - fy, cur.right, cur.bottom, fade)
            fade.shader = null
        }
        c.restore()
        edge.strokeWidth = 2f * dn
        edge.alpha = (0x99 * t).toInt()
        c.drawRoundRect(cur, r, r, edge)
    }
}


class LensFxNode(val title: String, val sub: String, val ratio: String, val eq: Float)

/**
 * Hiệu ứng chuyển ống kính: làm mờ khung ngắm, thanh nối Ultra Wide → Wide → Telephoto với vòng cam
 * chạy từ ống kính cũ sang mới, hình nón góc nhìn (FOV) co/giãn theo tiêu cự, và tên ống kính đổi chéo.
 */
class LensSwitchView(ctx: Context) : View(ctx) {
    /** false = giao diện toàn màn: phủ viền đen mờ/bo góc lên ảnh để không lộ cạnh vuông khi chuyển ống kính. */
    var classic: Boolean = true
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dn = resources.displayMetrics.density
    private var nodes: List<LensFxNode> = emptyList()
    private var from = 0
    private var to = 0
    private var sharp: Bitmap? = null
    private var blur: Bitmap? = null
    private var bgFilter: ColorFilter? = null
    private var blurA = 0f
    private var prog = 0f
    private var anim: ValueAnimator? = null
    private var blurAnim: ValueAnimator? = null
    private val argb = ArgbEvaluator()
    private val cone = Path()

    private fun d(v: Float) = v * dn

    fun start(n: List<LensFxNode>, fromIdx: Int, toIdx: Int, frame: Bitmap?, filter: ColorFilter?) {
        animate().cancel()
        anim?.cancel()
        blurAnim?.cancel()
        nodes = n
        from = fromIdx.coerceIn(0, (n.size - 1).coerceAtLeast(0))
        to = toIdx.coerceIn(0, (n.size - 1).coerceAtLeast(0))
        sharp = frame
        blur = frame?.let { makeBlur(it) }
        bgFilter = filter
        blurA = 0f
        prog = 0f
        alpha = 1f
        visibility = VISIBLE
        blurAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 280
            addUpdateListener { blurA = it.animatedValue as Float; invalidate() }
            start()
        }
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 800
            startDelay = 140
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { prog = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun hide() {
        animate().alpha(0f).setDuration(320).withEndAction {
            visibility = GONE
            sharp = null
            blur = null
            alpha = 1f
        }.start()
    }

    private fun makeBlur(src: Bitmap): Bitmap {
        val sw = max(16, src.width / 16)
        val sh = max(8, src.height / 16)
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val px = IntArray(sw * sh)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)
        repeat(3) { boxBlur(px, sw, sh, 2) }
        val out = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, sw, 0, 0, sw, sh)
        return out
    }

    private fun boxBlur(px: IntArray, w: Int, h: Int, r: Int) {
        val tmp = IntArray(px.size)
        for (y in 0 until h) for (x in 0 until w) {
            var rr = 0; var g = 0; var b = 0; var cnt = 0
            for (k in -r..r) {
                val c = px[y * w + (x + k).coerceIn(0, w - 1)]
                rr += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255; cnt++
            }
            tmp[y * w + x] = (0xFF shl 24) or ((rr / cnt) shl 16) or ((g / cnt) shl 8) or (b / cnt)
        }
        for (y in 0 until h) for (x in 0 until w) {
            var rr = 0; var g = 0; var b = 0; var cnt = 0
            for (k in -r..r) {
                val c = tmp[(y + k).coerceIn(0, h - 1) * w + x]
                rr += (c shr 16) and 255; g += (c shr 8) and 255; b += c and 255; cnt++
            }
            px[y * w + x] = (0xFF shl 24) or ((rr / cnt) shl 16) or ((g / cnt) shl 8) or (b / cnt)
        }
    }

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
    private fun mix(a: Int, b: Int, t: Float) = argb.evaluate(t.coerceIn(0f, 1f), a, b) as Int

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rect = RectF(0f, 0f, w, h)
        p.style = Paint.Style.FILL
        p.colorFilter = bgFilter
        sharp?.let { p.alpha = ((1f - blurA) * 255).toInt(); c.drawBitmap(it, null, rect, p) }
        blur?.let { p.alpha = (blurA * 255).toInt(); c.drawBitmap(it, null, rect, p) }
        p.colorFilter = null
        p.alpha = 255
        p.color = Color.argb((blurA * 120).toInt(), 0, 0, 0)
        c.drawRect(rect, p)
        if (!classic) drawEdgeFade(c, p, w, h)
        p.style = Paint.Style.FILL
        if (nodes.isEmpty()) return

        // thu nhỏ cả cụm hiệu ứng và dời lên trên để không bị các nút tiêu cự (14/23/60mm) đè lên
        c.save()
        c.scale(0.62f, 0.62f, w / 2f, h * 0.30f)

        val n = nodes.size
        val ep = prog
        val cx = w / 2f
        val trackY = h * 0.60f
        val gap = min(w * 0.2f, d(120f))
        fun nx(i: Int) = cx + (i - (n - 1) / 2f) * gap
        val pos = lerp(nx(from), nx(to), ep)
        val ui = blurA

        // đường thanh
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = d(2f)
        p.color = Color.argb((90 * ui).toInt(), 255, 255, 255)
        c.drawLine(nx(0), trackY, nx(n - 1), trackY, p)
        p.color = Color.argb((255 * ui).toInt(), 244, 123, 32)
        c.drawLine(nx(from), trackY, pos, trackY, p)

        // các nút ống kính
        p.textAlign = Paint.Align.CENTER
        for (i in 0 until n) {
            val act = (1f - abs(pos - nx(i)) / gap).coerceIn(0f, 1f)
            val r = d(9f) + d(5f) * act
            p.style = Paint.Style.FILL
            p.color = Color.argb((200 * ui).toInt(), 16, 16, 16)
            c.drawCircle(nx(i), trackY, r, p)
            p.style = Paint.Style.STROKE
            p.strokeWidth = d(2f)
            p.color = (mix(0xFFFFFFFF.toInt(), ORANGE, act) and 0x00FFFFFF) or ((255 * ui).toInt() shl 24)
            c.drawCircle(nx(i), trackY, r, p)
            p.style = Paint.Style.FILL
            p.typeface = Typeface.DEFAULT_BOLD
            p.textSize = h * 0.042f + h * 0.01f * act
            p.color = (mix(0xFFFFFFFF.toInt(), ORANGE, act) and 0x00FFFFFF) or ((255 * ui).toInt() shl 24)
            c.drawText(nodes[i].ratio + "×", nx(i), trackY + r + h * 0.065f, p)
        }

        // vòng cam di chuyển + quầng sáng
        p.style = Paint.Style.FILL
        for (k in 3 downTo 1) {
            p.color = Color.argb((38 * ui).toInt(), 244, 123, 32)
            c.drawCircle(pos, trackY, d(12f) + d(8f) * k, p)
        }
        p.color = Color.argb((255 * ui).toInt(), 244, 123, 32)
        c.drawCircle(pos, trackY, d(7f), p)

        // hình nón góc nhìn (FOV) co giãn theo tiêu cự
        val aFrom = atan(18f / nodes[from].eq.coerceAtLeast(1f))
        val aTo = atan(18f / nodes[to].eq.coerceAtLeast(1f))
        val a = lerp(aFrom, aTo, ep)
        val deg = Math.toDegrees(a.toDouble()).toFloat()
        val apexY = h * 0.47f
        val len = h * 0.22f
        val lx = cx - len * sin(a)
        val rx = cx + len * sin(a)
        val ty = apexY - len * cos(a)
        val arc = RectF(cx - len, apexY - len, cx + len, apexY + len)
        cone.reset()
        cone.moveTo(cx, apexY)
        cone.lineTo(lx, ty)
        cone.arcTo(arc, -90f - deg, 2f * deg)
        cone.close()
        p.style = Paint.Style.FILL
        p.color = Color.argb((45 * ui).toInt(), 244, 123, 32)
        c.drawPath(cone, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(2f)
        p.color = Color.argb((230 * ui).toInt(), 255, 255, 255)
        c.drawLine(cx, apexY, lx, ty, p)
        c.drawLine(cx, apexY, rx, ty, p)
        p.color = Color.argb((255 * ui).toInt(), 244, 123, 32)
        p.strokeWidth = d(2.6f)
        c.drawArc(arc, -90f - deg, 2f * deg, false, p)
        p.style = Paint.Style.FILL
        p.color = Color.argb((255 * ui).toInt(), 255, 255, 255)
        c.drawCircle(cx, apexY, d(4f), p)

        // tên ống kính: đổi chéo giữa cũ và mới
        val fromA = (1f - ((ep - 0.30f) * 4f)).coerceIn(0f, 1f)
        val toA = ((ep - 0.40f) * 4f).coerceIn(0f, 1f)
        p.style = Paint.Style.FILL
        p.typeface = Typeface.DEFAULT_BOLD
        p.letterSpacing = 0.12f
        p.textSize = h * 0.07f
        p.color = Color.argb((255 * fromA * ui).toInt(), 255, 255, 255)
        c.drawText(nodes[from].title, cx, h * 0.84f, p)
        p.color = Color.argb((255 * toA * ui).toInt(), 255, 255, 255)
        c.drawText(nodes[to].title, cx, h * 0.84f, p)
        p.letterSpacing = 0f
        p.typeface = Typeface.DEFAULT
        p.textSize = h * 0.045f
        p.color = Color.argb((230 * fromA * ui).toInt(), 204, 204, 204)
        c.drawText(nodes[from].sub, cx, h * 0.93f, p)
        p.color = Color.argb((230 * toA * ui).toInt(), 204, 204, 204)
        c.drawText(nodes[to].sub, cx, h * 0.93f, p)
        c.restore()
    }
}

/** Màn hình xem lại: nền trắng, chữ HASSELBLAD, ảnh và thông số máy. */
class ReviewView(ctx: Context) : FrameLayout(ctx) {
    private val img = ImageView(ctx)
    var onClose: (() -> Unit)? = null
    var onSaveFrame: (() -> Unit)? = null
    var onOpen: (() -> Unit)? = null

    init {
        val dn = resources.displayMetrics.density
        setBackgroundColor(Color.WHITE)
        isClickable = true
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        addView(img, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        fun btn(t: String, a: () -> Unit) {
            val tv = TextView(ctx)
            tv.text = t
            tv.textSize = 13f
            tv.setTextColor(0xFF333333.toInt())
            tv.setPadding((12 * dn).toInt(), (8 * dn).toInt(), (12 * dn).toInt(), (8 * dn).toInt())
            tv.setOnClickListener { a() }
            tv.pressFeedback(0.9f, false)
            row.addView(tv)
        }
        btn("Lưu ảnh khung") { onSaveFrame?.invoke() }
        btn("Thư viện") { onOpen?.invoke() }
        btn("✕") { onClose?.invoke() }
        val lp = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END)
        lp.setMargins(0, (6 * dn).toInt(), (10 * dn).toInt(), 0)
        addView(row, lp)
        visibility = GONE
    }

    private var openAnim: ValueAnimator? = null

    /** Mở như video: giao diện máy ảnh tối dần về đen (0,33s) rồi thẻ ảnh sáng lên từ đen sang trắng (0,4s). */
    fun show(b: android.graphics.Bitmap) {
        openAnim?.cancel()
        img.setImageBitmap(b)
        img.alpha = 0f
        setBackgroundColor(Color.BLACK)
        alpha = 0f
        visibility = VISIBLE
        val ev = ArgbEvaluator()
        openAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 760
            addUpdateListener {
                val f = it.animatedValue as Float
                val k = 330f / 760f
                if (f < k) {
                    alpha = f / k
                } else {
                    alpha = 1f
                    val g = ((f - k) / (1f - k)).coerceIn(0f, 1f)
                    setBackgroundColor(ev.evaluate(g, Color.BLACK, Color.WHITE) as Int)
                    img.alpha = g
                }
            }
            start()
        }
    }

    fun hide() {
        openAnim?.cancel()
        visibility = GONE
        alpha = 1f
        img.alpha = 1f
        setBackgroundColor(Color.WHITE)
        img.setImageDrawable(null)
    }
}

/**
 * Một ô trong khay bộ lọc dọc: ảnh xem trước (đã áp bộ lọc) bo góc, nhãn xoay dọc bên phải,
 * viền cam khi đang chọn, thẻ cam nhỏ (nếu có) dán sát mép phải ảnh.
 */
class FilterItemView(ctx: Context) : XView(ctx) {
    var name: String = ""
        set(v) { field = v; invalidate() }
    var badge: String? = null
        set(v) { field = v; invalidate() }
    var selectedItem: Boolean = false
        set(v) { field = v; invalidate() }
    var filter: XpanFilter = XpanFilter.all[0]
        set(v) { field = v; cf = ColorMatrixColorFilter(v.previewMatrix()); invalidate() }
    var source: Bitmap? = null
        set(v) { field = v; shader = null; invalidate() }

    private var cf: ColorMatrixColorFilter? = ColorMatrixColorFilter(XpanFilter.all[0].previewMatrix())
    private var shader: BitmapShader? = null
    private val rect = RectF()
    private val path = Path()
    private val mx = Matrix()

    init { isClickable = true }

    private val pad get() = d(4f)
    private val thumb get() = d(54f)
    private val badgeW get() = d(13f)

    private fun thumbShader(b: Bitmap): BitmapShader {
        shader?.let { return it }
        val sh = BitmapShader(b, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val t = thumb
        val sc = max(t / b.width, t / b.height)
        mx.reset()
        mx.postScale(sc, sc)
        mx.postTranslate(pad + (t - b.width * sc) / 2f, pad + (t - b.height * sc) / 2f)
        sh.setLocalMatrix(mx)
        shader = sh
        return sh
    }

    override fun onDraw(c: Canvas) {
        val t = thumb
        val r = d(8f)
        rect.set(pad, pad, pad + t, pad + t)

        // ảnh xem trước (đã áp bộ lọc), phóng/thu bằng lọc song tuyến cho mịn
        p.style = Paint.Style.FILL
        p.isFilterBitmap = true
        val b = source
        if (b != null && !b.isRecycled) {
            p.shader = thumbShader(b)
            p.colorFilter = cf
        } else {
            p.color = 0xFF2A2A2E.toInt()
        }
        c.drawRoundRect(rect, r, r, p)
        p.shader = null
        p.colorFilter = null

        // viền
        p.style = Paint.Style.STROKE
        if (selectedItem) {
            p.strokeWidth = d(2f)
            p.color = ORANGE
            val i = d(1f)
            c.drawRoundRect(rect.left + i, rect.top + i, rect.right - i, rect.bottom - i, r, r, p)
        } else {
            p.strokeWidth = d(1f)
            p.color = 0x40FFFFFF
            c.drawRoundRect(rect, r, r, p)
        }
        p.style = Paint.Style.FILL

        // thẻ cam dán mép phải ảnh (chữ xoay dọc)
        var x = pad + t
        val bd = badge
        if (bd != null) {
            p.typeface = Typeface.DEFAULT_BOLD
            p.textAlign = Paint.Align.CENTER
            p.textSize = d(8f)
            val bh = min(t - d(12f), p.measureText(bd) + d(12f))
            val top = pad + d(6f)
            val rr = d(5f)
            path.reset()
            path.addRoundRect(
                x - d(2f), top, x + badgeW, top + bh,
                floatArrayOf(0f, 0f, rr, rr, rr, rr, 0f, 0f), Path.Direction.CW
            )
            p.color = ORANGE
            c.drawPath(path, p)
            p.color = Color.WHITE
            val fm = p.fontMetrics
            c.save()
            c.translate(x - d(2f) + (badgeW + d(2f)) / 2f, top + bh / 2f)
            c.rotate(90f)
            c.drawText(bd, 0f, -(fm.ascent + fm.descent) / 2f, p)
            c.restore()
            p.typeface = Typeface.DEFAULT
        }
        x += badgeW // luôn chừa chỗ cho thẻ để nhãn của mọi ô thẳng hàng

        // nhãn xoay dọc (đọc từ trên xuống), co chữ cho vừa chiều cao ảnh
        p.typeface = Typeface.DEFAULT_BOLD
        p.textAlign = Paint.Align.CENTER
        var ts = d(12.5f)
        p.textSize = ts
        val maxLen = t - d(4f)
        while (p.measureText(name) > maxLen && ts > d(8f)) { ts -= d(0.5f); p.textSize = ts }
        p.color = if (selectedItem) ORANGE else Color.WHITE
        p.setShadowLayer(d(3f), 0f, 0f, 0xCC000000.toInt())
        val fm = p.fontMetrics
        c.save()
        c.translate(x + d(4f) + d(9f), pad + t / 2f)
        c.rotate(90f)
        c.drawText(name, 0f, -(fm.ascent + fm.descent) / 2f, p)
        c.restore()
        p.clearShadowLayer()
        p.typeface = Typeface.DEFAULT
    }

    companion object {
        /** Kích thước ô theo dp: rộng x cao. */
        const val W_DP = 98f
        const val H_DP = 62f
    }
}

/** Bố cục chính: sắp xếp lại toàn bộ control theo hai giao diện. */
class CameraLayout(ctx: Context) : ViewGroup(ctx) {
    val decor = DecorView(ctx)
    val texture = TextureView(ctx)
    val freeze = ImageView(ctx)
    val fly = SaveFlyView(ctx)
    val frame = FrameOverlayView(ctx)
    val focusBox = FocusBoxView(ctx)
    val fx = ShutterFxView(ctx)
    val lensFx = LensSwitchView(ctx)
    val ev = EvView(ctx)
    val ladder = ZoomLadderView(ctx)
    val pills = LensPillsView(ctx)
    val tray = ScrollView(ctx)
    val trayRow = LinearLayout(ctx)
    val shutter = ShutterButton(ctx)
    val thumb = ImageView(ctx)
    val filterBtn = FilterButtonView(ctx)
    val toggle = IconButtonView(ctx, IconButtonView.TOGGLE)
    val gear = IconButtonView(ctx, IconButtonView.GEAR)
    val edit = IconButtonView(ctx, IconButtonView.EDIT)
    val theme = IconButtonView(ctx, IconButtonView.THEME)

    private val vf = RectF()
    private var safeL = 0
    private var safeR = 0
    private val dn = resources.displayMetrics.density

    var classic: Boolean = true
        set(v) { field = v; applyMode() }

    /** Bán kính bo góc của khung ngắm (khớp với viền đen ở giả máy ảnh và viền mờ ở toàn màn). */
    private val vfRadius get() = (if (classic) 7f else 12f) * dn
    private val roundOutline = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, vfRadius)
        }
    }

    /** Giao diện trắng (true) hoặc tối (false). */
    var light: Boolean = false
        set(v) {
            field = v
            Theme.light = v
            applyMode()
            invalidateTree(this)
        }

    private fun invalidateTree(v: View) {
        v.invalidate()
        if (v is ViewGroup) for (i in 0 until v.childCount) invalidateTree(v.getChildAt(i))
    }

    init {
        tray.isVerticalScrollBarEnabled = false
        // mép trên/dưới mờ dần (fade) thay vì bị cắt cứng
        tray.isVerticalFadingEdgeEnabled = true
        tray.setFadingEdgeLength((34 * dn).toInt())
        tray.overScrollMode = View.OVER_SCROLL_NEVER
        trayRow.setPadding(0, (30 * dn).toInt(), 0, (30 * dn).toInt())
        trayRow.orientation = LinearLayout.VERTICAL
        tray.addView(trayRow)
        tray.visibility = GONE
        freeze.scaleType = ImageView.ScaleType.FIT_XY
        freeze.visibility = GONE
        lensFx.visibility = GONE
        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.clipToOutline = true
        thumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, 6f * dn)
            }
        }
        thumb.foreground = GradientDrawable().apply {
            setStroke((2 * dn).toInt(), 0x99FFFFFF.toInt())
            cornerRadius = 6f * dn
        }
        thumb.isClickable = true
        // mọi lớp phủ lên khung ngắm (ảnh xem trước, ảnh đóng băng, hiệu ứng chụp, hiệu ứng đổi ống kính) đều bị cắt bo góc
        for (v in listOf<View>(texture, freeze, fx, lensFx)) {
            v.outlineProvider = roundOutline
            v.clipToOutline = true
        }
        for (v in listOf<View>(decor, texture, freeze, fx, frame, focusBox, lensFx, ev, ladder, pills, tray, shutter, thumb, filterBtn, toggle, gear, edit, theme, fly)) {
            addView(v)
        }
        applyMode()
    }

    fun setSafe(l: Int, r: Int) {
        safeL = l; safeR = r
        decor.safeL = l.toFloat()
        decor.safeR = r.toFloat()
        requestLayout()
    }

    private fun applyMode() {
        setBackgroundColor(if (classic) Theme.bgClassic else Theme.bgFull)
        for (v in listOf<XView>(decor, frame, focusBox, ev, ladder, pills, shutter, filterBtn, toggle, gear, edit, theme)) v.classic = classic
        ladder.visibility = if (classic) VISIBLE else GONE
        pills.visibility = if (classic) GONE else VISIBLE
        lensFx.classic = classic
        for (v in listOf<View>(texture, freeze, fx, lensFx)) v.invalidateOutline()
        requestLayout()
        invalidate()
    }

    fun vfRect(): RectF = RectF(vf)

    fun thumbRect(): RectF = RectF(thumb.left.toFloat(), thumb.top.toFloat(), thumb.right.toFloat(), thumb.bottom.toFloat())

    /** Trong lúc chụp (theo video) khung ngắm, thang EV, dải zoom, ô nét... biến mất tức thì; lúc ảnh bay về thumbnail thì hiện lại. */
    fun setChromeHidden(hidden: Boolean) {
        val a = if (hidden) 0f else 1f
        frame.linesHidden = hidden
        for (v in listOf<View>(focusBox, ev, ladder, pills, tray)) v.alpha = a
    }

    private fun place(v: View, l: Float, t: Float, r: Float, b: Float) {
        val li = l.toInt(); val ti = t.toInt(); val ri = r.toInt(); val bi = b.toInt()
        v.measure(MeasureSpec.makeMeasureSpec(ri - li, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(bi - ti, MeasureSpec.EXACTLY))
        v.layout(li, ti, ri, bi)
    }

    private fun placeC(v: View, cx: Float, cy: Float, w: Float, h: Float) =
        place(v, cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.getSize(heightMeasureSpec))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val w = (r - l).toFloat()
        val h = (b - t).toFloat()
        if (w <= 0f || h <= 0f) return
        // giao diện tối giản: khung ngắm nằm chính giữa màn hình (đối xứng hai bên, tránh tai thỏ)
        val side = max(safeL, safeR).toFloat()
        // toàn màn: lấy lề an toàn lớn hơn ở CẢ HAI bên để khung ngắm luôn đối xứng, không lệch về phải
        val ax = if (classic) safeL.toFloat() else side
        val aw = if (classic) w - safeL - safeR else w - 2f * side
        val vfW = if (classic) aw * 0.835f else aw - dn * 4f
        val vfH = vfW * 24f / 65f
        val vfL = if (classic) ax + aw * 0.008f else ax + dn * 2f
        val vfT = (h - vfH) / 2f
        vf.set(vfL, vfT, vfL + vfW, vfT + vfH)
        decor.vf.set(vf)

        place(decor, 0f, 0f, w, h)
        place(texture, vf.left, vf.top, vf.right, vf.bottom)
        place(freeze, vf.left, vf.top, vf.right, vf.bottom)
        place(frame, vf.left, vf.top, vf.right, vf.bottom)
        place(focusBox, vf.left, vf.top, vf.right, vf.bottom)
        place(fx, vf.left, vf.top, vf.right, vf.bottom)
        place(lensFx, vf.left, vf.top, vf.right, vf.bottom)
        place(fly, 0f, 0f, w, h)

        val btn = h * 0.095f
        val by = if (classic) h * 0.085f else h * 0.072f
        placeC(toggle, ax + aw * 0.045f, by, btn, btn)
        placeC(gear, ax + aw * 0.045f + btn * 1.3f, by, btn, btn)
        // nút đổi giao diện sáng/tối: góc trái phía dưới
        placeC(theme, ax + aw * 0.045f, h - by, btn, btn)


        val evH = vfH * 0.55f
        if (classic) {
            val cx = ax + aw * 0.943f
            placeC(shutter, cx, h * 0.5f, h * 0.19f, h * 0.19f)
            placeC(filterBtn, cx, h * 0.215f, aw * 0.075f, h * 0.095f)
            // nút chỉnh sửa: cột phải, giữa nút bộ lọc và nút chụp (dễ chạm bằng ngón cái)
            placeC(edit, cx, h * 0.334f, btn, btn)
            placeC(thumb, cx, h * 0.8f, h * 0.115f, h * 0.115f)
            val n = ladder.labels.size
            val lh = min(vfH * 0.9f, n * dn * 52f).coerceAtLeast(dn * 52f)
            placeC(ladder, vf.right - dn * 34f, vf.centerY(), dn * 56f, lh)
            place(ev, vf.left + vfW * 0.02f, vf.centerY() - evH * 0.35f, vf.left + vfW * 0.02f + dn * 90f, vf.centerY() - evH * 0.35f + evH)
            // khay bộ lọc dọc: nằm ngay bên trái dải zoom, trong khung ngắm
            val tr = vf.right - dn * 66f
            place(tray, tr - dn * FilterItemView.W_DP, vf.top + vfH * 0.03f, tr, vf.bottom - vfH * 0.03f)
        } else {
            val cx = vf.right - vfW * 0.087f
            placeC(shutter, cx, vf.centerY(), h * 0.19f, h * 0.19f)
            val fc = vf.top + vfH * 0.14f
            placeC(filterBtn, cx, fc, h * 0.085f, h * 0.085f)
            val ey = ((fc + h * 0.0425f) + (vf.centerY() - h * 0.095f)) / 2f
            placeC(edit, cx, ey, h * 0.08f, h * 0.08f)
            placeC(thumb, cx, vf.bottom - vfH * 0.17f, h * 0.13f, h * 0.13f)
            val n = pills.labels.size
            val pw = if (n == 0) dn * 40f else n * pills.pillSize() + (n - 1) * pills.gap()
            placeC(pills, vf.centerX(), vf.bottom - vfH * 0.12f, pw, pills.pillSize() + dn * 4f)
            place(ev, vf.left + vfW * 0.04f, vf.centerY() - evH * 0.5f, vf.left + vfW * 0.04f + dn * 90f, vf.centerY() - evH * 0.5f + evH)
            // khay bộ lọc dọc: nằm ngay bên trái nút chụp, trong khung ngắm
            val tr = cx - h * 0.095f - dn * 6f
            place(tray, tr - dn * FilterItemView.W_DP, vf.top + vfH * 0.03f, tr, vf.bottom - vfH * 0.03f)
        }
    }
}
