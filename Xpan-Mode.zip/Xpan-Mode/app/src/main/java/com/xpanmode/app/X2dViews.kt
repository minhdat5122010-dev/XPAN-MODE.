package com.xpanmode.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Bảng màu thân máy X2D II: mặc định đen xám; phiên bản xanh rêu (Cài đặt ▸ X2D II ▸ Màu thân máy) đổi màu thân, khối màn hình,
 * phím, nút tiêu cự, tay cầm… theo bản thiết kế xanh rêu. [pick] trả về màu tương ứng phiên bản đang chọn.
 */
object X2dPalette {
    @JvmField @Volatile var green = false
    fun pick(gray: Int, grn: Int): Int = if (green) grn else gray
}

/**
 * Thân máy Hasselblad X2D II (mặt lưng) theo bản thiết kế: thân xám bo góc; bên trái là khối màn hình xám đậm chứa bezel đen
 * (màn hình 4:3 + dải chữ HASSELBLAD ngay dưới) và dải 4 phím dọc sát cạnh phải màn hình; bên phải là tay cầm bọc da giả
 * (hoạ tiết lấy từ ảnh da mẫu) chứa bánh xe, cột nút tiêu cự và nút chụp. Chỉ vẽ nền; các nút là view riêng nằm đè lên.
 */
class X2dDecorView(ctx: Context) : XView(ctx) {
    /** Toàn bộ thân máy. */
    val body = RectF()
    /** Khối màn hình + dải phím (xám đậm). */
    val slab = RectF()
    /** Bezel đen bao màn hình và dải chữ bên dưới. */
    val bezel = RectF()
    /** Màn hình (khung ngắm). */
    val vf = RectF()
    /** Vùng đặt chữ HASSELBLAD (dải đen dưới màn hình). */
    val word = RectF()
    /** Tay cầm. */
    val grip = RectF()
    /** Vùng chữ khắc "X2D II · HANDMADE IN SWEDEN" trên tay cầm (dưới cột nút tiêu cự). */
    val engrave = RectF()
    /** Đèn báo nhỏ dưới cột phím. */
    var ledX = 0f
    var ledY = 0f
    /** Số px của một đơn vị thiết kế (do CameraLayout đặt; thân máy có thể rộng hơn 958 đơn vị khi màn hình dài). */
    var unit = 0f

    private val leather: Bitmap? by lazy { try { BitmapFactory.decodeResource(resources, R.drawable.x2d_leather) } catch (_: Throwable) { null } }
    private val wordmark: Bitmap? by lazy { try { BitmapFactory.decodeResource(resources, R.drawable.x2d_wordmark) } catch (_: Throwable) { null } }
    private var leatherShader: BitmapShader? = null
    private val shaderMatrix = Matrix()
    private val greenLeather = ColorMatrixColorFilter(ColorMatrix(floatArrayOf(
        0.66f, 0f, 0f, 0f, 0f,
        0f, 0.76f, 0f, 0f, 0f,
        0f, 0f, 0.56f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f
    )))
    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val clip = Path()
    private val dst = RectF()
    private val engraveBmp: Bitmap? by lazy { try { BitmapFactory.decodeResource(resources, R.drawable.x2d_engrave) } catch (_: Throwable) { null } }
    private val engHi = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { colorFilter = PorterDuffColorFilter(0x3CFFFFFF, PorterDuff.Mode.SRC_IN) }
    private val engLo = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply { colorFilter = PorterDuffColorFilter(0xC4000000.toInt(), PorterDuff.Mode.SRC_IN) }

    override fun onDraw(c: Canvas) {
        c.drawColor(Theme.bgClassic)
        if (body.isEmpty) return
        val s = if (unit > 0f) unit else body.width() / 958f          // đơn vị thiết kế → px

        // --- thân máy xám: bóng đổ + chuyển sắc nhẹ + gờ sáng phía trên
        val br = 46f * s
        p.style = Paint.Style.FILL
        p.setShadowLayer(d(14f), 0f, d(5f), 0x88000000.toInt())
        p.color = X2dPalette.pick(0xFF767678.toInt(), 0xFF37443D.toInt())
        c.drawRoundRect(body, br, br, p)
        p.clearShadowLayer()
        p.shader = LinearGradient(
            0f, body.top, 0f, body.bottom,
            if (X2dPalette.green) intArrayOf(0xFF43534E.toInt(), 0xFF37443D.toInt(), 0xFF28332F.toInt()) else intArrayOf(0xFF858588.toInt(), 0xFF767678.toInt(), 0xFF68686B.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(body, br, br, p)
        p.shader = LinearGradient(
            0f, body.top, 0f, body.bottom,
            intArrayOf(0x88FFFFFF.toInt(), 0x10FFFFFF, 0x30000000), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.3f)
        c.drawRoundRect(body, br, br, p)
        p.shader = null

        // --- khối màn hình xám đậm
        val sr = 16f * s
        p.style = Paint.Style.FILL
        p.color = X2dPalette.pick(0xFF4C4C4C.toInt(), 0xFF0D1615.toInt())
        c.drawRoundRect(slab, sr, sr, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1f)
        p.color = 0x40FFFFFF
        c.drawRoundRect(slab, sr, sr, p)

        // --- bezel đen: nền + dải chữ bên dưới màn hình tối hơn
        val zr = 12f * s
        p.style = Paint.Style.FILL
        p.color = 0xFF1C1819.toInt()
        c.drawRoundRect(bezel, zr, zr, p)
        clip.reset()
        clip.addRoundRect(bezel, zr, zr, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        p.color = 0xFF0D0B0B.toInt()
        c.drawRect(bezel.left, vf.bottom, bezel.right, bezel.bottom, p)
        c.restore()
        // chữ HASSELBLAD (ảnh logo thật, nền đen trùng dải)
        val wm = wordmark
        if (wm != null && !word.isEmpty) {
            val ww = word.width()
            val wh = ww * wm.height / wm.width
            val cy = (vf.bottom + bezel.bottom) / 2f
            dst.set(word.centerX() - ww / 2f, cy - wh / 2f, word.centerX() + ww / 2f, cy + wh / 2f)
            c.drawBitmap(wm, null, dst, bmpPaint)
        }
        // đèn báo
        p.color = 0xFFC8D1D9.toInt()
        c.drawCircle(ledX, ledY, 4.5f * s, p)

        // --- tay cầm bọc da giả: nền xám tối + hoạ tiết da lặp liền mạch + bóng lõm + viền
        val gr = 26f * s
        p.setShadowLayer(d(10f), 0f, d(4f), 0x88000000.toInt())
        p.color = X2dPalette.pick(0xFF4C494D.toInt(), 0xFF1F2A24.toInt())
        c.drawRoundRect(grip, gr, gr, p)
        p.clearShadowLayer()
        p.shader = LinearGradient(
            grip.left, 0f, grip.right, 0f,
            if (X2dPalette.green) intArrayOf(0xFF1B251F.toInt(), 0xFF1F2A24.toInt(), 0xFF1E2923.toInt()) else intArrayOf(0xFF434146.toInt(), 0xFF4C494D.toInt(), 0xFF4A484C.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(grip, gr, gr, p)
        val lb = leather
        if (lb != null) {
            val sh = leatherShader ?: BitmapShader(lb, Shader.TileMode.MIRROR, Shader.TileMode.MIRROR).also { leatherShader = it }
            shaderMatrix.reset()
            shaderMatrix.postScale(0.9f, 0.9f)
            shaderMatrix.postTranslate(grip.left, grip.top)
            sh.setLocalMatrix(shaderMatrix)
            p.shader = sh
            if (X2dPalette.green) p.colorFilter = greenLeather     // da giả ngả xanh rêu
            c.drawRoundRect(grip, gr, gr, p)
            p.colorFilter = null
        }
        // chữ khắc chìm trên da: nét chữ tối + viền sáng mảnh lệch xuống dưới-phải (cảm giác khắc lõm)
        val eb = engraveBmp
        if (eb != null && !engrave.isEmpty) {
            val o = d(0.9f)
            dst.set(engrave.left + o, engrave.top + o, engrave.right + o, engrave.bottom + o)
            c.drawBitmap(eb, null, dst, engHi)
            c.drawBitmap(eb, null, engrave, engLo)
        }
        // bóng lõm sát mép trên và mép trái
        clip.reset()
        clip.addRoundRect(grip, gr, gr, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        p.shader = LinearGradient(0f, grip.top, 0f, grip.top + d(24f), 0x66000000, 0x00000000, Shader.TileMode.CLAMP)
        c.drawRect(grip.left, grip.top, grip.right, grip.top + d(24f), p)
        p.shader = LinearGradient(grip.left, 0f, grip.left + d(18f), 0f, 0x55000000, 0x00000000, Shader.TileMode.CLAMP)
        c.drawRect(grip.left, grip.top, grip.left + d(18f), grip.bottom, p)
        p.shader = null
        c.restore()
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.1f)
        p.color = 0x40FFFFFF
        c.drawRoundRect(grip, gr, gr, p)
        p.style = Paint.Style.FILL
    }
}

/**
 * Phím dọc bo góc kiểu X2D (nằm sát cạnh phải màn hình). Phím bộ lọc / chỉnh thông số bấm thì chuyển cho nút gốc trong suốt nằm đè
 * lên xử lí; phím album chỉ là nền (có ▶) cho ảnh thu nhỏ nằm trên; phím menu hiện chữ "X2D II" xoay dọc (nút gốc nằm đè lên nhận chạm).
 */
class X2dKeyView(ctx: Context, private val kind: Int) : XView(ctx) {
    companion object {
        const val FILTER = 0
        const val TUNE = 1
        const val ALBUM = 2
        const val MENU = 3
    }

    private val box = RectF()
    private val tri = Path()
    private var down = false

    /** Sáng cam khi chức năng của phím đang mở. */
    var active = false
        set(v) { field = v; invalidate() }

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        box.set(d(1f), d(1f), w - d(1f), h - d(1f))
        val r = d(8f)
        p.style = Paint.Style.FILL
        p.setShadowLayer(d(2.5f), 0f, d(1.2f), 0x66000000)
        p.color = X2dPalette.pick(0xFF3F3E3E.toInt(), 0xFF263029.toInt())
        c.drawRoundRect(box, r, r, p)
        p.clearShadowLayer()
        p.shader = LinearGradient(
            0f, 0f, 0f, h,
            if (X2dPalette.green) intArrayOf(0xFF2E3A34.toInt(), 0xFF263029.toInt(), 0xFF19231E.toInt()) else intArrayOf(0xFF484749.toInt(), 0xFF3F3E3E.toInt(), 0xFF383738.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(box, r, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        // gờ sáng phía trên
        p.strokeWidth = d(1f)
        p.color = 0x30FFFFFF
        c.drawLine(box.left + r, box.top + d(1.6f), box.right - r, box.top + d(1.6f), p)
        // viền
        p.strokeWidth = d(1.1f)
        p.color = if (down || active) ORANGE else 0xFF2B2A2B.toInt()
        c.drawRoundRect(box, r, r, p)
        val ink = if (active) ORANGE else 0xFFE8E8EA.toInt()
        p.color = ink
        p.strokeWidth = d(1.6f)
        val cx = w / 2f
        val cy = h / 2f
        when (kind) {
            FILTER -> {
                // ba vòng màu giao nhau
                val rr = d(5.4f)
                c.drawCircle(cx - rr * 0.72f, cy + rr * 0.5f, rr, p)
                c.drawCircle(cx + rr * 0.72f, cy + rr * 0.5f, rr, p)
                c.drawCircle(cx, cy - rr * 0.78f, rr, p)
            }
            TUNE -> {
                // ba thanh trượt
                val ks = floatArrayOf(-3f, 4f, -1f)
                for (i in 0..2) {
                    val y = cy + (i - 1) * d(7f)
                    p.style = Paint.Style.STROKE
                    c.drawLine(cx - d(8.5f), y, cx + d(8.5f), y, p)
                    p.style = Paint.Style.FILL
                    c.drawCircle(cx + d(ks[i]), y, d(2.4f), p)
                }
            }
            ALBUM -> {
                // ▶ phát lại ở dưới (ảnh thu nhỏ nằm phía trên)
                val ty = cy + h * 0.30f
                val s = d(5f)
                tri.reset()
                tri.moveTo(cx - s * 0.7f, ty - s)
                tri.lineTo(cx + s, ty)
                tri.lineTo(cx - s * 0.7f, ty + s)
                tri.close()
                p.style = Paint.Style.FILL
                c.drawPath(tri, p)
            }
            else -> {
                // chữ "X2D II" xoay dọc (đọc từ dưới lên), cam nghiêng như nút XPAN
                p.style = Paint.Style.FILL
                p.color = ORANGE
                p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
                p.textAlign = Paint.Align.CENTER
                p.letterSpacing = 0.1f
                p.textSize = d(11.5f)
                while (p.measureText("X2D II") > h - d(14f) && p.textSize > d(8f)) p.textSize -= d(0.5f)
                val fm = p.fontMetrics
                c.save()
                c.rotate(-90f, cx, cy)
                c.drawText("X2D II", cx, cy - (fm.ascent + fm.descent) / 2f, p)
                c.restore()
                p.letterSpacing = 0f
                p.typeface = Typeface.DEFAULT
                p.textAlign = Paint.Align.LEFT
            }
        }
        p.style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true; invalidate()
                animate().cancel()
                animate().scaleX(0.92f).scaleY(0.92f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                down = false; invalidate()
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3.5f)).start()
            }
        }
        return super.onTouchEvent(e)
    }
}

/**
 * Hai nút ở cạnh trái thân máy: viên thuốc dọc = Cài đặt, nút tròn nhỏ bên dưới = Flash (cam khi đang bật).
 * Vùng chạm [view] có thể lớn hơn hình vẽ ([shapeW] × [shapeH]) để dễ bấm.
 */
class X2dSideButton(ctx: Context, private val kind: Int) : XView(ctx) {
    companion object {
        const val GEAR = 0
        const val FLASH = 1
    }

    /** Kích thước hình vẽ (px); 0 = theo kích thước view. */
    var shapeW = 0f
    var shapeH = 0f

    /** Flash: 0 tắt, 1 bật (chớp khi chụp), 2 luôn sáng. */
    var flash = 0
        set(v) { if (field != v) { field = v; invalidate() } }

    private val box = RectF()
    private val bolt = Path()
    private var down = false

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val sw = if (shapeW > 0f) shapeW else width.toFloat()
        val sh = if (shapeH > 0f) shapeH else height.toFloat()
        box.set(cx - sw / 2f + d(1f), cy - sh / 2f + d(1f), cx + sw / 2f - d(1f), cy + sh / 2f - d(1f))
        val r = min(box.width(), box.height()) / 2f
        // hình nút: bóng + nền xám chuyển sắc + viền tối + gờ sáng
        p.style = Paint.Style.FILL
        p.setShadowLayer(d(3f), 0f, d(1.5f), 0x77000000)
        p.color = X2dPalette.pick(0xFF4D4D4D.toInt(), 0xFF3E4944.toInt())
        c.drawRoundRect(box, r, r, p)
        p.clearShadowLayer()
        p.shader = LinearGradient(
            box.left, box.top, box.right, box.bottom,
            if (X2dPalette.green) intArrayOf(0xFF4B5751.toInt(), 0xFF3E4944.toInt(), 0xFF2F3A36.toInt()) else intArrayOf(0xFF5A5A5C.toInt(), 0xFF4D4D4D.toInt(), 0xFF424244.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(box, r, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.color = if (down) ORANGE else X2dPalette.pick(0xFF131313.toInt(), 0xFF0F1A17.toInt())
        c.drawRoundRect(box, r, r, p)
        p.strokeWidth = d(0.8f)
        p.color = 0x44FFFFFF
        c.drawRoundRect(box.left + d(1.6f), box.top + d(1.6f), box.right - d(1.6f), box.bottom - d(1.6f), r, r, p)

        val ir = min(box.width(), box.height()) * 0.30f      // bán kính biểu tượng
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        if (kind == GEAR) {
            p.strokeWidth = d(1.6f)
            p.color = 0xFFEDEDEF.toInt()
            c.drawCircle(cx, cy, ir * 0.55f, p)
            for (i in 0 until 8) {
                val a = Math.toRadians(i * 45.0)
                val ca = cos(a).toFloat()
                val sa = sin(a).toFloat()
                c.drawLine(cx + ca * ir * 0.82f, cy + sa * ir * 0.82f, cx + ca * ir * 1.1f, cy + sa * ir * 1.1f, p)
            }
        } else {
            // tia chớp: tắt = viền trắng + gạch chéo, bật = đặc cam, luôn sáng = đặc cam + vòng
            bolt.reset()
            bolt.moveTo(cx + ir * 0.18f, cy - ir * 1.2f)
            bolt.lineTo(cx - ir * 0.62f, cy + ir * 0.15f)
            bolt.lineTo(cx - ir * 0.04f, cy + ir * 0.15f)
            bolt.lineTo(cx - ir * 0.20f, cy + ir * 1.2f)
            bolt.lineTo(cx + ir * 0.66f, cy - ir * 0.30f)
            bolt.lineTo(cx + ir * 0.04f, cy - ir * 0.30f)
            bolt.close()
            if (flash == 0) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = d(1.4f)
                p.color = 0xFFEDEDEF.toInt()
                c.drawPath(bolt, p)
                c.drawLine(cx - ir * 0.95f, cy - ir * 1.0f, cx + ir * 0.95f, cy + ir * 1.0f, p)
            } else {
                p.style = Paint.Style.FILL
                p.color = ORANGE
                c.drawPath(bolt, p)
                if (flash == 2) {
                    p.style = Paint.Style.STROKE
                    p.strokeWidth = d(1.2f)
                    c.drawCircle(cx, cy, ir * 1.5f, p)
                }
            }
        }
        p.style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true; invalidate()
                animate().cancel()
                animate().scaleX(0.9f).scaleY(0.9f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                down = false; invalidate()
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3.5f)).start()
            }
        }
        return super.onTouchEvent(e)
    }
}

/**
 * Bánh xe nhám nằm ngang trên tay cầm (giống X2D thật): mặt trụ có các gờ trắng, gờ ở giữa to + sáng, gờ về hai đầu hẹp lại,
 * mờ dần và dồn sát nhau (phối cảnh hình trụ) nên khi vuốt trái / phải thấy bánh xe thật sự xoay. Mỗi nấc rung một lần;
 * thả tay thì bánh xe trượt thêm một đoạn ngắn rồi dừng. Hiện chữ chức năng (EV / MF) + giá trị hiện tại ở giữa.
 * Chức năng do MainActivity quyết định theo Cài đặt.
 */
class X2dDialView(ctx: Context) : XView(ctx) {
    var label = "EV"
        set(v) { if (field != v) { field = v; invalidate() } }

    /** Giá trị hiện tại hiện cạnh nhãn, ví dụ "+0.7", "0.40m", "AF". */
    var valueText = ""
        set(v) { if (field != v) { field = v; invalidate() } }

    /** +1 khi vuốt sang phải một nấc, -1 khi vuốt sang trái. */
    var onStep: ((Int) -> Unit)? = null

    private val box = RectF()
    private val pill = RectF()
    private val clip = Path()
    private val tri = Path()
    /** Góc xoay của trụ (độ). */
    private var rot = 0f
    private var accDeg = 0f
    private var lastX = 0f
    private var pressed = false
    private var glow = 0f
    private var tracker: VelocityTracker? = null
    private var settle: ValueAnimator? = null

    private val pitch = 8f            // khoảng cách giữa hai gờ (độ trên mặt trụ)
    private val stepDeg = 16f         // mỗi nấc = 2 gờ

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        box.set(d(1.5f), d(1.5f), w - d(1.5f), h - d(1.5f))
        val r = box.height() / 2f
        val cx = box.centerX()
        val rr = box.width() / 2f - d(9f)       // bán kính hình trụ trên màn hình

        // bóng đổ + thân tối
        p.style = Paint.Style.FILL
        p.setShadowLayer(d(3f), 0f, d(1.5f), 0x88000000.toInt())
        p.color = 0xFF3A393B.toInt()
        c.drawRoundRect(box, r, r, p)
        p.clearShadowLayer()
        p.shader = LinearGradient(
            0f, box.top, 0f, box.bottom,
            intArrayOf(0xFF333234.toInt(), 0xFF454446.toInt(), 0xFF2A292B.toInt()), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(box, r, r, p)
        p.shader = null

        clip.reset()
        clip.addRoundRect(box, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        // các gờ trắng: x = R·sinθ, bề dày và độ sáng theo cosθ (phối cảnh trụ)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        val base = ((rot % pitch) + pitch) % pitch
        var th = -90f + base
        while (th < 90f) {
            val cs = cos(Math.toRadians(th.toDouble())).toFloat()
            if (cs > 0.08f) {
                val x = cx + rr * sin(Math.toRadians(th.toDouble())).toFloat()
                val a = (60 + 195 * Math.pow(cs.toDouble(), 1.25)).toInt().coerceIn(0, 255)
                val inset = d(5f) + d(3.5f) * (1f - cs)
                p.strokeWidth = d(3.3f) * cs.coerceAtLeast(0.2f)
                p.color = (a shl 24) or 0xFFFFFF
                c.drawLine(x, box.top + inset, x, box.bottom - inset, p)
            }
            th += pitch
        }
        // đổ bóng hai đầu cho ra khối trụ + vệt sáng bóng lệch trái
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            box.left, 0f, box.right, 0f,
            intArrayOf(0xE6000000.toInt(), 0x00000000, 0x00000000, 0xE6000000.toInt()), floatArrayOf(0f, 0.22f, 0.78f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(box, p)
        p.shader = LinearGradient(
            box.left + box.width() * 0.30f, 0f, box.left + box.width() * 0.48f, 0f,
            intArrayOf(0x00FFFFFF, 0x26FFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(box, p)
        p.shader = null
        c.restore()

        // viền: tối bên ngoài, gờ sáng bên trong, cam khi đang chạm
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.color = 0xFF171618.toInt()
        c.drawRoundRect(box, r, r, p)
        p.strokeWidth = d(0.8f)
        p.color = if (pressed) ORANGE else 0x40FFFFFF
        c.drawRoundRect(box.left + d(1.4f), box.top + d(1.4f), box.right - d(1.4f), box.bottom - d(1.4f), r, r, p)

        // viên thuốc chữ ở giữa: nhãn chức năng + giá trị
        p.style = Paint.Style.FILL
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = d(10.5f)
        p.letterSpacing = 0.08f
        val lw = p.measureText(label)
        p.typeface = Typeface.DEFAULT
        p.textSize = d(10f)
        val vw = if (valueText.isEmpty()) 0f else p.measureText(valueText)
        val gap = if (vw > 0f) d(6f) else 0f
        val pw = lw + vw + gap + d(18f)
        pill.set(cx - pw / 2f, box.centerY() - d(10f), cx + pw / 2f, box.centerY() + d(10f))
        p.color = 0xEE0B0B0C.toInt()
        c.drawRoundRect(pill, d(10f), d(10f), p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(0.8f)
        p.color = if (pressed) ORANGE else 0x33FFFFFF
        c.drawRoundRect(pill, d(10f), d(10f), p)
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = d(10.5f)
        p.color = Color.WHITE
        val fm = p.fontMetrics
        val ty = pill.centerY() - (fm.ascent + fm.descent) / 2f
        c.drawText(label, pill.left + d(9f), ty, p)
        if (vw > 0f) {
            p.typeface = Typeface.DEFAULT
            p.textSize = d(10f)
            p.color = ORANGE
            c.drawText(valueText, pill.left + d(9f) + lw + gap, ty, p)
        }
        p.letterSpacing = 0f
        p.typeface = Typeface.DEFAULT

        // mũi tên cam báo vị trí trên đỉnh bánh xe
        tri.reset()
        tri.moveTo(cx - d(4f), box.top + d(0.5f))
        tri.lineTo(cx + d(4f), box.top + d(0.5f))
        tri.lineTo(cx, box.top + d(5.5f))
        tri.close()
        p.color = ORANGE
        c.drawPath(tri, p)
    }

    private fun fire(dir: Int) {
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        onStep?.invoke(dir)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                settle?.cancel()
                tracker?.recycle()
                tracker = VelocityTracker.obtain().also { it.addMovement(e) }
                lastX = e.x
                accDeg = 0f
                pressed = true
                invalidate()
                animate().cancel()
                animate().scaleX(0.98f).scaleY(0.98f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
            }
            MotionEvent.ACTION_MOVE -> {
                tracker?.addMovement(e)
                val rr = (width - d(21f)) / 2f
                val dDeg = Math.toDegrees(((e.x - lastX) / rr).toDouble()).toFloat()    // bề mặt trụ chạy theo ngón tay
                lastX = e.x
                rot += dDeg
                accDeg += dDeg
                while (accDeg >= stepDeg) { accDeg -= stepDeg; fire(+1) }
                while (accDeg <= -stepDeg) { accDeg += stepDeg; fire(-1) }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                pressed = false
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
                // trượt thêm một đoạn ngắn theo đà vuốt (chỉ hiệu ứng, không đổi giá trị thêm)
                val tr = tracker
                var extra = 0f
                if (tr != null) {
                    tr.computeCurrentVelocity(1000)
                    val rr = (width - d(21f)) / 2f
                    extra = (Math.toDegrees((tr.xVelocity / rr).toDouble()).toFloat() * 0.16f).coerceIn(-150f, 150f)
                    tr.recycle()
                }
                tracker = null
                val rot0 = rot
                settle?.cancel()
                settle = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 420
                    interpolator = DecelerateInterpolator(2.2f)
                    addUpdateListener { rot = rot0 + extra * it.animatedValue as Float; invalidate() }
                    start()
                }
                invalidate()
            }
        }
        return true
    }
}

/**
 * Nút hiển thị chế độ chụp đang dùng (Normal / LUNA. HQ / HQ RAW / UP / Night Art / Live Art), nằm ngay dưới bánh xe.
 * Bấm để mở danh sách chọn nhanh ([X2dModePopup]); thay cho dòng ghi chú chế độ ở góc trên trái màn hình.
 */
class X2dModeButton(ctx: Context) : XView(ctx) {
    var text = "Normal"
        set(v) { if (field != v) { field = v; invalidate() } }
    /** Danh sách đang mở: viền cam, mũi tên quay lên. */
    var open = false
        set(v) { if (field != v) { field = v; invalidate() } }

    private val box = RectF()
    private val tri = Path()
    private var down = false

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        box.set(d(1.5f), d(1.5f), w - d(1.5f), h - d(1.5f))
        val r = box.height() / 2f
        p.style = Paint.Style.FILL
        p.setShadowLayer(d(3f), 0f, d(1.5f), 0x88000000.toInt())
        p.color = X2dPalette.pick(0xFF2C2B2E.toInt(), 0xFF212E2A.toInt())
        c.drawRoundRect(box, r, r, p)
        p.clearShadowLayer()
        p.shader = LinearGradient(0f, box.top, 0f, box.bottom, if (X2dPalette.green) intArrayOf(0xFF2A3A35.toInt(), 0xFF1B2724.toInt()) else intArrayOf(0xFF3E3D41.toInt(), 0xFF262528.toInt()), null, Shader.TileMode.CLAMP)
        c.drawRoundRect(box, r, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.color = if (open || down) ORANGE else X2dPalette.pick(0xFF111012.toInt(), 0xFF0F1A17.toInt())
        c.drawRoundRect(box, r, r, p)
        // chữ chế độ (tự co cho vừa) + mũi tên nhỏ bên phải
        p.style = Paint.Style.FILL
        p.typeface = Typeface.DEFAULT_BOLD
        p.textAlign = Paint.Align.CENTER
        p.color = if (text == "Normal") 0xFFD6D6DA.toInt() else Color.WHITE
        p.textSize = min(box.height() * 0.42f, d(12f))
        val avail = box.width() - r * 1.9f
        val mw = p.measureText(text)
        if (mw > avail) p.textSize *= avail / mw
        val fm = p.fontMetrics
        c.drawText(text, box.centerX() - r * 0.28f, box.centerY() - (fm.ascent + fm.descent) / 2f, p)
        val ax = box.right - r * 0.85f
        val ay = box.centerY()
        val a = r * 0.22f
        tri.reset()
        if (open) {
            tri.moveTo(ax - a, ay + a * 0.5f); tri.lineTo(ax + a, ay + a * 0.5f); tri.lineTo(ax, ay - a * 0.6f)
        } else {
            tri.moveTo(ax - a, ay - a * 0.5f); tri.lineTo(ax + a, ay - a * 0.5f); tri.lineTo(ax, ay + a * 0.6f)
        }
        tri.close()
        p.color = if (open) ORANGE else 0xFFB4B4B9.toInt()
        c.drawPath(tri, p)
        p.typeface = Typeface.DEFAULT
        p.textAlign = Paint.Align.LEFT
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true; invalidate()
                animate().cancel()
                animate().scaleX(0.95f).scaleY(0.92f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                down = false; invalidate()
                animate().scaleX(1f).scaleY(1f).setDuration(240).setInterpolator(OvershootInterpolator(3f)).start()
            }
        }
        return super.onTouchEvent(e)
    }
}

/**
 * Danh sách chọn nhanh chế độ chụp, xổ xuống ngay dưới [X2dModeButton] (phủ lên các nút khác khi mở).
 * Phủ toàn khung camera để chạm ra ngoài thì đóng; chạm một dòng thì chọn chế độ đó.
 */
class X2dModePopup(ctx: Context) : XView(ctx) {
    var items: List<String> = emptyList()
        set(v) { field = v; invalidate() }
    var selected = 0
        set(v) { if (field != v) { field = v; invalidate() } }
    /** Vùng nút chế độ (toạ độ của view này). */
    val anchor = RectF()
    var onPick: ((Int) -> Unit)? = null
    var onDismiss: (() -> Unit)? = null

    private val list = RectF()
    private val row = RectF()
    private var pressedRow = -1
    private var downOutside = false

    init {
        visibility = GONE
        isClickable = true
    }

    private fun rowH() = d(36f)

    private fun layoutList() {
        val w = max(anchor.width(), d(172f))
        val hgt = rowH() * items.size + d(12f)
        var left = anchor.right - w
        if (left < d(8f)) left = d(8f)
        var top = anchor.bottom + d(6f)
        if (top + hgt > height - d(8f)) top = (height - d(8f) - hgt).coerceAtLeast(d(8f))
        list.set(left, top, left + w, top + hgt)
    }

    fun show() {
        if (items.isEmpty()) return
        animate().cancel()
        visibility = VISIBLE
        pivotX = anchor.right
        pivotY = anchor.bottom
        alpha = 0f
        scaleX = 0.88f
        scaleY = 0.78f
        animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(170).setInterpolator(DecelerateInterpolator()).start()
    }

    fun dismiss(animated: Boolean = true) {
        if (visibility != VISIBLE) return
        pressedRow = -1
        animate().cancel()
        if (animated) {
            animate().alpha(0f).scaleX(0.92f).scaleY(0.85f).setDuration(120).withEndAction {
                visibility = GONE; alpha = 1f; scaleX = 1f; scaleY = 1f
            }.start()
        } else {
            visibility = GONE; alpha = 1f; scaleX = 1f; scaleY = 1f
        }
        onDismiss?.invoke()
    }

    override fun onDraw(c: Canvas) {
        if (items.isEmpty()) return
        layoutList()
        val rr = d(14f)
        p.style = Paint.Style.FILL
        p.setShadowLayer(d(14f), 0f, d(5f), 0xCC000000.toInt())
        p.color = X2dPalette.pick(0xFF29282B.toInt(), 0xFF1F2B26.toInt())
        c.drawRoundRect(list, rr, rr, p)
        p.clearShadowLayer()
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.color = X2dPalette.pick(0xFF3F3E42.toInt(), 0xFF34463F.toInt())
        c.drawRoundRect(list, rr, rr, p)
        p.textAlign = Paint.Align.LEFT
        for (i in items.indices) {
            val top = list.top + d(6f) + i * rowH()
            row.set(list.left + d(6f), top, list.right - d(6f), top + rowH())
            if (i == pressedRow) {
                p.style = Paint.Style.FILL
                p.color = 0x26FFFFFF
                c.drawRoundRect(row, d(9f), d(9f), p)
            }
            if (i > 0 && i != pressedRow && i - 1 != pressedRow) {
                p.style = Paint.Style.STROKE
                p.strokeWidth = d(0.8f)
                p.color = 0x1FFFFFFF
                c.drawLine(row.left + d(8f), top, row.right - d(8f), top, p)
            }
            val sel = i == selected
            p.style = Paint.Style.FILL
            p.typeface = if (sel) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
            p.color = if (sel) ORANGE else Color.WHITE
            p.textSize = d(13f)
            val fm = p.fontMetrics
            c.drawText(items[i], row.left + d(12f), row.centerY() - (fm.ascent + fm.descent) / 2f, p)
            if (sel) c.drawCircle(row.right - d(14f), row.centerY(), d(3.6f), p)
        }
        p.typeface = Typeface.DEFAULT
    }

    private fun rowAt(y: Float): Int {
        val i = ((y - list.top - d(6f)) / rowH()).toInt()
        return if (i in items.indices) i else -1
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                layoutList()
                parent?.requestDisallowInterceptTouchEvent(true)
                downOutside = !list.contains(e.x, e.y)
                pressedRow = if (downOutside) -1 else rowAt(e.y)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (!downOutside) {
                    val r = if (list.contains(e.x, e.y)) rowAt(e.y) else -1
                    if (r != pressedRow) { pressedRow = r; invalidate() }
                }
            }
            MotionEvent.ACTION_UP -> {
                if (downOutside) dismiss()
                else if (pressedRow >= 0) {
                    val r = pressedRow
                    performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                    dismiss()
                    onPick?.invoke(r)
                } else invalidate()
            }
            MotionEvent.ACTION_CANCEL -> { pressedRow = -1; invalidate() }
        }
        return true
    }
}

/**
 * Nút xám chấm đỏ cạnh nút chụp: bấm để đổi nhanh chức năng của bánh xe EV ⇄ MF
 * (chấm đỏ sáng rực + quầng khi đang ở MF, tối hơn khi ở EV).
 */
class X2dDialSwitch(ctx: Context) : XView(ctx) {
    var mf = false
        set(v) { if (field != v) { field = v; invalidate() } }
    private var down = false

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - d(3f)
        p.style = Paint.Style.FILL
        p.setShadowLayer(d(4f), 0f, d(2f), 0x99000000.toInt())
        p.color = 0xFF3C3B3E.toInt()
        c.drawCircle(cx, cy, r, p)
        p.clearShadowLayer()
        p.shader = LinearGradient(0f, cy - r, 0f, cy + r, intArrayOf(0xFF5D5C60.toInt(), 0xFF39383B.toInt()), null, Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.color = if (down) ORANGE else 0xFF141315.toInt()
        c.drawCircle(cx, cy, r, p)
        // hốc tối chứa chấm đỏ
        p.style = Paint.Style.FILL
        p.color = 0xFF161517.toInt()
        c.drawCircle(cx, cy, r * 0.62f, p)
        if (mf) {
            p.color = 0x44FF3B30
            c.drawCircle(cx, cy, r * 0.62f, p)
        }
        p.color = if (mf) 0xFFFF3B30.toInt() else 0xFF9A1B1B.toInt()
        c.drawCircle(cx, cy, r * 0.30f, p)
        p.color = 0x55FFFFFF
        c.drawCircle(cx - r * 0.09f, cy - r * 0.10f, r * 0.08f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true; invalidate()
                animate().cancel()
                animate().scaleX(0.9f).scaleY(0.9f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                down = false; invalidate()
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3.5f)).start()
            }
        }
        return super.onTouchEvent(e)
    }
}

/**
 * Thông tin trên màn hình ngắm theo X2D: biểu tượng tỉ lệ (trái trên), pin + ISO + AF (phải trên), hai thanh dọc bên phải
 * (ISO, tốc độ màn trập), thanh ngang EV ở dưới (kéo để đổi EV) và hàng chữ chế độ · EV · khẩu · tốc độ · số ảnh còn lại.
 * Số liệu do MainActivity cập nhật định kỳ.
 */
class X2dHudView(ctx: Context) : XView(ctx) {
    var iso = 0
    var expNs = 0L
    var fNumber = 0f
    var evMin = 0
    var evMax = 0
    var evStep = 0f
    var evValue = 0
    /** Đang lấy nét tay. */
    var mf = false
    /** Có thông số chỉnh tay (tốc độ hoặc ISO) → chế độ M. */
    var manual = false
    /** 0..100, âm = không rõ. */
    var battery = -1
    /** Số ảnh còn lại ước tính theo dung lượng trống. */
    var remaining = 0

    /** Kéo trên thanh EV (không còn dùng: hai thanh trượt trên màn hình giờ là thuỷ bình; EV chỉnh bằng bánh xe). */
    var onEv: ((Int) -> Unit)? = null
    /** Độ nghiêng trái / phải (độ, dương = đầu bên phải màn hình cao hơn). */
    var rollDeg = 0f
    /** Độ ngẩng / cúi của camera (độ, dương = camera hướng lên). */
    var pitchDeg = 0f
    /** Máy không nghiêng trái / phải → núm thanh ngang chuyển trắng. */
    var levelRoll = false
    /** Camera hướng ra phía trước (không ngẩng / cúi) → núm thanh dọc chuyển trắng. */
    var levelPitch = false

    private var dragging = false
    private val box = RectF()

    private fun sliderL() = width * 0.30f
    private fun sliderR() = width * 0.70f

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = d(14f)
        p.setShadowLayer(d(2.5f), 0f, d(1f), 0xCC000000.toInt())
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND

        // --- trái trên: biểu tượng tỉ lệ khung 4:3
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.5f)
        p.color = Color.WHITE
        box.set(pad, pad, pad + d(28f), pad + d(19f))
        c.drawRoundRect(box, d(4f), d(4f), p)
        box.set(pad + d(4f), pad + d(4f), pad + d(4f) + d(13f), pad + d(4f) + d(10f))
        c.drawRoundRect(box, d(1.5f), d(1.5f), p)
        p.style = Paint.Style.FILL
        box.set(pad + d(20f), pad + d(7.5f), pad + d(24f), pad + d(11.5f))
        c.drawRoundRect(box, d(2f), d(2f), p)

        // --- phải trên: pin
        val bw = d(24f)
        val bh = d(11f)
        val bl = w - pad - bw - d(2f)
        val bt = pad + d(1f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.3f)
        box.set(bl, bt, bl + bw, bt + bh)
        c.drawRoundRect(box, d(2.5f), d(2.5f), p)
        p.style = Paint.Style.FILL
        c.drawRect(bl + bw + d(1.2f), bt + bh * 0.32f, bl + bw + d(2.6f), bt + bh * 0.68f, p)
        if (battery >= 0) {
            p.color = if (battery < 20) 0xFFFF5A4A.toInt() else Color.WHITE
            box.set(bl + d(2f), bt + d(2f), bl + d(2f) + (bw - d(4f)) * battery / 100f, bt + bh - d(2f))
            c.drawRoundRect(box, d(1f), d(1f), p)
        }
        // ISO
        p.color = Color.WHITE
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = d(12f)
        p.textAlign = Paint.Align.RIGHT
        c.drawText("ISO " + (if (iso > 0) iso.toString() else "--"), w - pad, pad + d(34f), p)
        // AF / MF
        val tag = if (mf) "MF" else "AF"
        p.textSize = d(9.5f)
        val tw = p.measureText(tag)
        val bx1 = w - pad - d(12f)
        box.set(bx1 - tw - d(8f), pad + d(42f), bx1, pad + d(57f))
        p.color = Color.WHITE
        c.drawRoundRect(box, d(3f), d(3f), p)
        p.color = 0xFF111114.toInt()
        p.textAlign = Paint.Align.CENTER
        val fm = p.fontMetrics
        c.drawText(tag, box.centerX(), box.centerY() - (fm.ascent + fm.descent) / 2f, p)
        p.color = Color.WHITE
        p.textSize = d(11f)
        p.textAlign = Paint.Align.RIGHT
        c.drawText(if (mf) "" else "C", w - pad, box.centerY() - (fm.ascent + fm.descent) / 2f, p)
        p.typeface = Typeface.DEFAULT

        // --- thuỷ bình điện tử: thanh dọc = hướng lên / xuống (pitch), thanh ngang = nghiêng trái / phải (roll).
        // Núm đen chạy theo độ lệch (về phía cạnh/đầu máy đang cao hơn); khi máy thẳng và camera hướng ra phía trước thì cả hai núm chuyển trắng.
        val vx = w - d(30f)
        val top = h * 0.32f
        val bot = h * 0.76f
        val vm = (top + bot) / 2f
        val sy = h - d(46f)
        val l = sliderL()
        val r = sliderR()
        val hm = (l + r) / 2f
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = d(1.2f)
        p.color = 0x99FFFFFF.toInt()
        c.drawLine(vx, top, vx, bot, p)
        c.drawLine(l, sy, r, sy, p)
        // vạch chia: giữa (0°) dài, hai bên ±7,5° ngắn
        c.drawLine(vx - d(5f), vm, vx + d(5f), vm, p)
        c.drawLine(hm, sy - d(5f), hm, sy + d(5f), p)
        for (k in intArrayOf(-1, 1)) {
            c.drawLine(vx - d(3f), vm + k * (bot - top) / 4f, vx + d(3f), vm + k * (bot - top) / 4f, p)
            c.drawLine(hm + k * (r - l) / 4f, sy - d(3f), hm + k * (r - l) / 4f, sy + d(3f), p)
        }
        val range = 15f                                       // ±15° chạy hết thanh
        val pk = (pitchDeg / range).coerceIn(-1f, 1f)
        val rk = (rollDeg / range).coerceIn(-1f, 1f)
        levelKnob(c, vx, vm - pk * (bot - top) / 2f, d(8f), levelPitch)
        levelKnob(c, hm + rk * (r - l) / 2f, sy, d(9f), levelRoll)

        // --- hàng chữ phía dưới: chế độ · EV · khẩu · tốc độ · số ảnh còn lại
        val by = h - d(16f)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        p.textSize = d(17f)
        c.drawText(if (manual) "M" else "P", pad, by, p)
        p.typeface = Typeface.DEFAULT
        p.textSize = d(11f)
        val ev = evValue * evStep
        c.drawText(if (evValue == 0) "0.0" else String.format(Locale.US, "%+.1f", ev), pad + d(30f), by, p)
        p.textSize = d(14f)
        p.textAlign = Paint.Align.CENTER
        c.drawText(if (fNumber > 0f) String.format(Locale.US, "f/%.1f", fNumber) else "f/--", w * 0.40f, by, p)
        c.drawText(shutterText(), w * 0.57f, by, p)
        p.textAlign = Paint.Align.RIGHT
        p.textSize = d(13f)
        c.drawText("[" + remaining + "]", w - pad, by, p)
        p.textAlign = Paint.Align.LEFT
        p.clearShadowLayer()
    }

    /** Núm thuỷ bình: đen (vòng trắng) khi lệch, đặc trắng khi trục của nó đã đúng (mỗi núm tự xét riêng). */
    private fun levelKnob(c: Canvas, x: Float, y: Float, r: Float, ok: Boolean) {
        p.style = Paint.Style.FILL
        p.color = if (ok) Color.WHITE else 0xCC000000.toInt()
        c.drawCircle(x, y, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.7f)
        p.color = Color.WHITE
        c.drawCircle(x, y, r, p)
        p.style = Paint.Style.FILL
    }

    private fun knob(c: Canvas, x: Float, y: Float, r: Float) {
        p.style = Paint.Style.FILL
        p.color = 0x88000000.toInt()
        c.drawCircle(x, y, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.7f)
        p.color = Color.WHITE
        c.drawCircle(x, y, r, p)
        p.style = Paint.Style.FILL
    }

    private fun shutterText(): String {
        if (expNs <= 0L) return "--"
        val sec = expNs / 1e9
        return if (sec >= 0.5) String.format(Locale.US, "%.1fs", sec)
        else "1/" + max(1.0, Math.round(1.0 / sec).toDouble()).toInt()
    }

    /** Không nhận chạm: mọi cú chạm rơi xuống khung ngắm bên dưới (lấy nét, thu phóng). */
    override fun onTouchEvent(e: MotionEvent): Boolean = false
}
