package com.xpanmode.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Thân máy Hasselblad X2D II (mặt lưng, khổ 4:3) theo bản thiết kế: thân xám bo tròn lớn; bên trái là khối màn hình đen
 * (màn 4:3, nhãn HASSELBLAD ngay dưới, chấm LED nhỏ, dải 4 phím dọc sát cạnh phải); bên phải là tấm tay cầm bọc da giả
 * (bánh xe, cột nút tiêu cự, nút chụp cam). Chỉ vẽ nền; các nút là view riêng nằm đè lên.
 */
class X2dDecorView(ctx: Context) : XView(ctx) {
    /** Toàn bộ thân máy. */
    val body = RectF()
    /** Khối màn hình + dải phím (đen). */
    val slab = RectF()
    /** Màn hình (khung ngắm). */
    val vf = RectF()
    /** Tay cầm (tấm da giả). */
    val grip = RectF()
    /** Nhãn HASSELBLAD (chữ trắng trên nền đen) dưới màn hình. */
    val logo = RectF()
    var dotX = 0f
    var dotY = 0f
    var dotR = 0f

    private val bmpPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val mtx = Matrix()
    private val dst = RectF()
    private val wordmark: Bitmap? by lazy {
        try { BitmapFactory.decodeResource(resources, R.drawable.hb_wordmark_x2d) } catch (_: Throwable) { null }
    }
    private val leather: BitmapShader? by lazy {
        try {
            BitmapFactory.decodeResource(resources, R.drawable.grip_leather)?.let { BitmapShader(it, Shader.TileMode.MIRROR, Shader.TileMode.MIRROR) }
        } catch (_: Throwable) { null }
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF08080A.toInt())
        if (body.isEmpty) return

        // --- thân máy xám bo tròn lớn: bóng đổ + nền chuyển sắc nhẹ + gờ sáng
        val br = min(body.height() * 0.11f, d(40f))
        p.style = Paint.Style.FILL
        p.setShadowLayer(d(14f), 0f, d(5f), 0xAA000000.toInt())
        p.color = 0xFF68686B.toInt()
        c.drawRoundRect(body, br, br, p)
        p.clearShadowLayer()
        p.shader = LinearGradient(
            0f, body.top, 0f, body.bottom,
            intArrayOf(0xFF7E7E81.toInt(), 0xFF6D6D70.toInt(), 0xFF5F5F62.toInt()), floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(body, br, br, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.shader = LinearGradient(
            0f, body.top, 0f, body.bottom,
            intArrayOf(0x66FFFFFF, 0x10FFFFFF, 0x30000000), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(body, br, br, p)
        p.shader = null

        // --- khối màn hình đen
        val sr = d(16f)
        p.style = Paint.Style.FILL
        p.color = 0xFF1C1819.toInt()
        c.drawRoundRect(slab, sr, sr, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.color = 0xFF000000.toInt()
        c.drawRoundRect(slab, sr, sr, p)
        p.strokeWidth = d(1f)
        p.color = 0x22FFFFFF
        c.drawRoundRect(slab.left + d(0.8f), slab.top + d(0.8f), slab.right - d(0.8f), slab.bottom - d(0.8f), sr, sr, p)
        // viền đen quanh màn hình
        p.style = Paint.Style.FILL
        p.color = 0xFF000000.toInt()
        c.drawRoundRect(vf.left - d(3f), vf.top - d(3f), vf.right + d(3f), vf.bottom + d(3f), d(13f), d(13f), p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.color = 0xFF2C292A.toInt()
        c.drawRoundRect(vf.left - d(3f), vf.top - d(3f), vf.right + d(3f), vf.bottom + d(3f), d(13f), d(13f), p)

        // --- nhãn HASSELBLAD: ảnh chữ gốc (chữ trắng nghiêng trên nền đen)
        p.style = Paint.Style.FILL
        p.color = 0xFF000000.toInt()
        c.drawRect(logo, p)
        val wm = wordmark
        if (wm != null && !logo.isEmpty) {
            val ih = logo.height() - d(2f)
            val iw = ih * wm.width / wm.height
            val w2 = min(iw, logo.width() - d(2f))
            val h2 = w2 * wm.height / wm.width
            dst.set(logo.centerX() - w2 / 2f, logo.centerY() - h2 / 2f, logo.centerX() + w2 / 2f, logo.centerY() + h2 / 2f)
            c.drawBitmap(wm, null, dst, bmpPaint)
        }
        // chấm LED nhỏ cạnh dải phím
        if (dotR > 0f) {
            p.color = 0x33FFFFFF
            c.drawCircle(dotX, dotY, dotR * 1.9f, p)
            p.color = 0xFFEDEDEF.toInt()
            c.drawCircle(dotX, dotY, dotR, p)
        }

        // --- tay cầm: tấm da giả (ảnh vân da lát lặp), bóng đổ + gờ sáng mảnh
        val gr = min(grip.height() * 0.095f, d(36f))
        p.setShadowLayer(d(12f), 0f, d(4f), 0xAA000000.toInt())
        p.color = 0xFF48474A.toInt()
        c.drawRoundRect(grip, gr, gr, p)
        p.clearShadowLayer()
        val ls = leather
        if (ls != null) {
            val k = (d(1f) / 2.6f).coerceIn(0.8f, 1.7f)
            mtx.setScale(k, k)
            mtx.postTranslate(grip.left, grip.top)
            ls.setLocalMatrix(mtx)
            p.shader = ls
            c.drawRoundRect(grip, gr, gr, p)
            p.shader = null
        }
        // ánh sáng nhẹ phía trên, tối dần phía dưới
        p.shader = LinearGradient(
            0f, grip.top, 0f, grip.bottom,
            intArrayOf(0x26FFFFFF, 0x00000000, 0x30000000), floatArrayOf(0f, 0.4f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(grip, gr, gr, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.color = 0x30FFFFFF
        c.drawRoundRect(grip, gr, gr, p)
        p.style = Paint.Style.FILL
    }
}

/**
 * Phím dọc dẹt kiểu X2D (nằm sát cạnh phải màn hình), có biểu tượng:
 * bộ lọc = ba vòng giao nhau + tên bộ lọc xoay dọc · điều chỉnh = ba thanh trượt dẹt · album = biểu tượng ảnh · menu = chữ "X2D II" xoay dọc.
 * Bấm thì chuyển cho nút gốc trong suốt nằm đè lên xử lí.
 */
class X2dKeyView(ctx: Context, private val kind: Int) : XView(ctx) {
    companion object {
        const val FILTER = 0
        const val TUNE = 1
        const val ALBUM = 2
        const val MENU = 3
    }

    private val box = RectF()
    private var down = false

    /** Nút bộ lọc gốc: lấy tên bộ lọc đang chọn để in dọc trên phím. */
    var src: FilterButtonView? = null

    /** Sáng cam khi chức năng của phím đang mở. */
    var active = false
        set(v) { field = v; invalidate() }

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        box.set(d(1f), d(1f), w - d(1f), h - d(1f))
        val r = min(w, h) * 0.30f
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(0xFF47464A.toInt(), 0xFF39383B.toInt(), 0xFF313033.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(box, r, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.strokeWidth = d(1f)
        p.color = 0x2AFFFFFF
        c.drawLine(box.left + r, box.top + d(1.8f), box.right - r, box.top + d(1.8f), p)
        p.strokeWidth = d(1.3f)
        p.color = if (down || active) ORANGE else 0xFF151416.toInt()
        c.drawRoundRect(box, r, r, p)
        val ink = if (active) ORANGE else 0xFFE8E8EA.toInt()
        p.color = ink
        p.strokeWidth = d(1.5f)
        val cx = w / 2f
        val cy = h / 2f
        when (kind) {
            FILTER -> {
                // ba vòng giao nhau ở trên
                val rr = min(w * 0.16f, d(5f))
                val gy = d(11f) + rr * 1.5f
                c.drawCircle(cx - rr * 0.72f, gy + rr * 0.5f, rr, p)
                c.drawCircle(cx + rr * 0.72f, gy + rr * 0.5f, rr, p)
                c.drawCircle(cx, gy - rr * 0.78f, rr, p)
                // tên bộ lọc xoay dọc (đọc từ dưới lên)
                val name = src?.label ?: ""
                if (name.isNotEmpty()) {
                    val top = gy + rr * 1.5f + d(8f)
                    val avail = h - top - d(9f)
                    if (avail > d(12f)) {
                        p.style = Paint.Style.FILL
                        p.color = if (name == "Original") 0xFFB9B9BE.toInt() else ORANGE
                        p.typeface = Typeface.DEFAULT_BOLD
                        p.textAlign = Paint.Align.CENTER
                        p.textSize = min(w * 0.34f, d(10.5f))
                        val mw = p.measureText(name)
                        if (mw > avail) p.textSize *= avail / mw
                        val fm = p.fontMetrics
                        val my = top + avail / 2f
                        c.save()
                        c.rotate(-90f, cx, my)
                        c.drawText(name, cx, my - (fm.ascent + fm.descent) / 2f, p)
                        c.restore()
                        p.typeface = Typeface.DEFAULT
                    }
                }
            }
            TUNE -> {
                // ba thanh trượt dẹt: đường ngang mảnh + núm tròn
                val lw = w * 0.52f
                val ks = floatArrayOf(0.30f, 0.70f, 0.45f)
                for (i in 0..2) {
                    val y = cy + (i - 1) * d(8f)
                    p.style = Paint.Style.STROKE
                    p.color = ink
                    c.drawLine(cx - lw / 2f, y, cx + lw / 2f, y, p)
                    p.style = Paint.Style.FILL
                    c.drawCircle(cx - lw / 2f + lw * ks[i], y, d(2.5f), p)
                }
            }
            ALBUM -> {
                // biểu tượng ảnh: khung bo góc, núi, mặt trời
                val iw = min(w * 0.58f, d(20f))
                val ih = iw * 0.78f
                p.style = Paint.Style.STROKE
                c.drawRoundRect(cx - iw / 2f, cy - ih / 2f, cx + iw / 2f, cy + ih / 2f, d(2.5f), d(2.5f), p)
                val m = Path()
                m.moveTo(cx - iw / 2f + d(1.5f), cy + ih / 2f - d(2f))
                m.lineTo(cx - iw * 0.12f, cy - ih * 0.02f)
                m.lineTo(cx + iw * 0.06f, cy + ih * 0.22f)
                m.lineTo(cx + iw * 0.2f, cy + ih * 0.06f)
                m.lineTo(cx + iw / 2f - d(1.5f), cy + ih / 2f - d(2f))
                c.drawPath(m, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx + iw * 0.22f, cy - ih * 0.20f, d(1.8f), p)
            }
            else -> {
                // chữ "X2D II" xoay dọc (đọc từ dưới lên), cam nghiêng như nút XPAN
                p.style = Paint.Style.FILL
                p.color = ORANGE
                p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC)
                p.textAlign = Paint.Align.CENTER
                p.letterSpacing = 0.1f
                p.textSize = d(11.5f)
                while (p.measureText("X2D II") > h - d(14f) && p.textSize > d(8f)) p.textSize -= d(0.5f)
                val fm = p.fontMetrics
                c.save()
                c.rotate(-90f, cx, cy)
                c.drawText("X2D II", cx, cy - (fm.ascent + fm.descent) / 2f, p)
                c.restore()
                p.letterSpacing = 0f
                p.typeface = Typeface.DEFAULT
                p.textAlign = Paint.Align.LEFT
            }
        }
        p.style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true; invalidate()
                animate().cancel()
                animate().scaleX(0.93f).scaleY(0.93f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                down = false; invalidate()
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3.5f)).start()
            }
        }
        return super.onTouchEvent(e)
    }
}

/**
 * Hai nút ngoài cùng bên trái thân máy: viên thuốc dọc có biểu tượng bánh răng (Cài đặt) và nút tròn nhỏ có tia chớp (Flash).
 * Vùng chạm rộng hơn hình vẽ vài dp cho dễ bấm.
 */
class X2dRoundButton(ctx: Context, private val kind: Int = GEAR) : XView(ctx) {
    companion object {
        const val GEAR = 0
        const val FLASH = 1
    }

    /** 0 tắt, 1 bật (chớp khi chụp), 2 luôn sáng. */
    var flash = 0
        set(v) { if (field != v) { field = v; invalidate() } }

    private val box = RectF()
    private val bolt = Path()
    private var down = false

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val ins = d(4f)
        box.set(ins, ins, w - ins, h - ins)
        val r = min(box.width(), box.height()) / 2f
        val cx = box.centerX()
        val cy = box.centerY()
        p.style = Paint.Style.FILL
        p.setShadowLayer(d(4f), 0f, d(2f), 0x88000000.toInt())
        p.color = 0xFF3A393C.toInt()
        c.drawRoundRect(box, r, r, p)
        p.clearShadowLayer()
        p.shader = LinearGradient(
            0f, box.top, 0f, box.bottom,
            intArrayOf(0xFF4C4B4F.toInt(), 0xFF39383B.toInt(), 0xFF2F2E31.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(box, r, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.3f)
        p.color = if (down) ORANGE else 0xFF141315.toInt()
        c.drawRoundRect(box, r, r, p)
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        val ink = 0xFFE8E8EA.toInt()
        if (kind == GEAR) {
            // bánh răng: vòng tròn + 8 răng
            val g = box.width() * 0.19f
            p.strokeWidth = d(1.6f)
            p.color = ink
            c.drawCircle(cx, cy, g, p)
            for (i in 0 until 8) {
                val a = Math.toRadians(i * 45.0)
                val ca = cos(a).toFloat()
                val sa = sin(a).toFloat()
                c.drawLine(cx + ca * g * 1.35f, cy + sa * g * 1.35f, cx + ca * g * 1.85f, cy + sa * g * 1.85f, p)
            }
        } else {
            // tia chớp
            val k = box.width() * 0.30f
            bolt.reset()
            bolt.moveTo(cx + 0.12f * k, cy - 1.0f * k)
            bolt.lineTo(cx - 0.60f * k, cy + 0.12f * k)
            bolt.lineTo(cx - 0.06f * k, cy + 0.12f * k)
            bolt.lineTo(cx - 0.16f * k, cy + 1.0f * k)
            bolt.lineTo(cx + 0.60f * k, cy - 0.22f * k)
            bolt.lineTo(cx + 0.06f * k, cy - 0.22f * k)
            bolt.close()
            when (flash) {
                0 -> {
                    p.strokeWidth = d(1.3f)
                    p.color = 0xFF9A9A9F.toInt()
                    c.drawPath(bolt, p)
                    p.strokeWidth = d(1.6f)
                    c.drawLine(cx - k * 0.9f, cy - k * 0.9f, cx + k * 0.9f, cy + k * 0.9f, p)
                }
                1 -> {
                    p.style = Paint.Style.FILL
                    p.color = ink
                    c.drawPath(bolt, p)
                }
                else -> {
                    p.style = Paint.Style.FILL
                    p.color = ORANGE
                    c.drawPath(bolt, p)
                }
            }
        }
        p.style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true; invalidate()
                animate().cancel()
                animate().scaleX(0.9f).scaleY(0.9f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                down = false; invalidate()
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3.5f)).start()
            }
        }
        return super.onTouchEvent(e)
    }
}

/**
 * Bánh xe nằm ngang ở đầu tay cầm (như X2D thật): viên thuốc đen, các gờ trắng bo tròn bố trí trên mặt trụ.
 * Vuốt trái / phải để xoay: các gờ và nhãn chức năng (EV / MF, in trên mặt trụ) cùng cuộn, co hẹp theo độ cong ở hai đầu;
 * mỗi nấc rung một lần kèm vầng sáng cam; thả tay thì bánh còn quay theo đà rồi chậm dần.
 * Chức năng (EV / lấy nét tay) do MainActivity quyết định theo Cài đặt; [label] là chữ in trên bánh xe.
 */
class X2dDialView(ctx: Context) : XView(ctx) {
    var label = "EV"
        set(v) { if (field != v) { field = v; invalidate() } }

    /** +1 khi vuốt sang phải một nấc, -1 khi vuốt sang trái. */
    var onStep: ((Int) -> Unit)? = null

    private val box = RectF()
    private val rib = RectF()
    private val tag = RectF()
    private var rot = 0f             // góc quay của mặt trụ (độ)
    private var glow = 0f            // vầng sáng cam sau mỗi nấc (0..1)
    private var lastX = 0f
    private var acc = 0f
    private var pressed = false
    private var vt: VelocityTracker? = null
    private var fling: ValueAnimator? = null
    private var glowAnim: ValueAnimator? = null

    init { isClickable = true }

    private fun pulse() {
        glowAnim?.cancel()
        glow = 1f
        glowAnim = ValueAnimator.ofFloat(1f, 0f).apply {
            duration = 420
            interpolator = DecelerateInterpolator()
            addUpdateListener { glow = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        box.set(d(2f), d(2f), w - d(2f), h - d(2f))
        val r = box.height() / 2f
        val cx = box.centerX()
        val rad = box.width() / 2f - r * 0.35f           // bán kính hiệu dụng của mặt trụ (phần nhìn thấy)

        // hốc tối + thân đen
        p.style = Paint.Style.FILL
        p.color = 0xFF000000.toInt()
        c.drawRoundRect(box, r, r, p)
        p.shader = LinearGradient(
            box.left, 0f, box.right, 0f,
            intArrayOf(0xFF000000.toInt(), 0xFF202023.toInt(), 0xFF2A2A2E.toInt(), 0xFF202023.toInt(), 0xFF000000.toInt()),
            floatArrayOf(0f, 0.22f, 0.5f, 0.78f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(box.left + d(1f), box.top + d(1f), box.right - d(1f), box.bottom - d(1f), r, r, p)
        p.shader = null

        // các gờ trắng bo tròn: phân bố đều quanh mặt trụ, thu hẹp + mờ dần về hai đầu
        val n = 40
        val ribH = box.height() - d(9f)
        val baseW = d(4.2f)
        val clip = Path().apply { addRoundRect(box.left + d(1f), box.top + d(1f), box.right - d(1f), box.bottom - d(1f), r, r, Path.Direction.CW) }
        c.save()
        c.clipPath(clip)
        for (i in 0 until n) {
            val a = Math.toRadians((i * 360.0 / n) + rot)
            val cs = cos(a).toFloat()
            if (cs <= 0.06f) continue
            val x = cx + rad * sin(a).toFloat()
            val rw = baseW * (0.25f + 0.75f * cs)
            val shade = (0.28f + 0.72f * cs).coerceIn(0f, 1f)
            val bright = (0xDC + (0x23 * glow)).toInt().coerceIn(0, 255)
            val ch = (bright * shade).toInt().coerceIn(0, 255)
            // thân gờ (trắng ngà) + đường sáng nhỏ bên trái / bóng bên phải cho cảm giác nổi khối
            p.color = (0xFF shl 24) or (ch shl 16) or (ch shl 8) or ((ch * (1f - 0.12f * glow)).toInt())
            rib.set(x - rw / 2f, box.centerY() - ribH / 2f, x + rw / 2f, box.centerY() + ribH / 2f)
            c.drawRoundRect(rib, rw / 2f, rw / 2f, p)
            p.color = ((0x40 * shade).toInt() shl 24) or 0x000000
            c.drawRect(x + rw * 0.18f, rib.top + rw * 0.4f, x + rw / 2f, rib.bottom - rw * 0.4f, p)
        }
        // nhãn in trên mặt trụ: viên đen nhỏ chữ cam, cuộn theo gờ (bốn nhãn cách nhau 90°)
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = box.height() * 0.40f
        p.textAlign = Paint.Align.CENTER
        val fm = p.fontMetrics
        val tw = p.measureText(label)
        for (k in 0 until 4) {
            val a = Math.toRadians(rot + 45.0 + k * 90.0)
            val cs = cos(a).toFloat()
            if (cs <= 0.12f) continue
            val x = cx + rad * 0.95f * sin(a).toFloat()
            val hw = (tw / 2f + box.height() * 0.28f) * cs
            tag.set(x - hw, box.centerY() - box.height() * 0.33f, x + hw, box.centerY() + box.height() * 0.33f)
            val al = (cs * 255).toInt().coerceIn(0, 255)
            p.color = (((al * 0.92f).toInt()) shl 24)
            c.drawRoundRect(tag, tag.height() / 2f, tag.height() / 2f, p)
            c.save()
            c.scale(cs, 1f, x, box.centerY())
            p.color = (al shl 24) or (ORANGE and 0xFFFFFF)
            c.drawText(label, x, box.centerY() - (fm.ascent + fm.descent) / 2f, p)
            c.restore()
        }
        p.typeface = Typeface.DEFAULT
        // ánh sáng phản chiếu dọc mặt trụ + vệt sáng chạy khi xoay
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, box.top, 0f, box.bottom, intArrayOf(0x40FFFFFF, 0x00FFFFFF, 0x00FFFFFF, 0x30000000), floatArrayOf(0f, 0.35f, 0.6f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(box, p)
        p.shader = null
        val sx = cx + rad * 0.7f * sin(Math.toRadians(rot * 0.6)).toFloat()
        val sa = (0x14 + 0x40 * glow).toInt().coerceIn(0, 255)
        p.shader = LinearGradient(sx - d(22f), 0f, sx + d(22f), 0f, intArrayOf(0x00FFFFFF, (sa shl 24) or 0xFFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(box, p)
        p.shader = null
        c.restore()

        // vạch cam chỉ vị trí ở mép dưới (cố định)
        p.color = ORANGE
        c.drawRoundRect(cx - d(9f), box.bottom - d(4.5f), cx + d(9f), box.bottom - d(2.2f), d(1.2f), d(1.2f), p)
        // viền: xám nhạt, chuyển sang cam khi chạm / vừa xoay
        val t = max(glow, if (pressed) 0.7f else 0f)
        val a = (0x55 + (0xAA * t)).toInt().coerceIn(0, 255)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.color = (a shl 24) or (if (t > 0.05f) (ORANGE and 0xFFFFFF) else 0xFFFFFF)
        c.drawRoundRect(box, r, r, p)
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.LEFT
    }

    private fun fire(dir: Int) {
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        pulse()
        onStep?.invoke(dir)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                fling?.cancel()
                vt?.recycle()
                vt = VelocityTracker.obtain().also { it.addMovement(e) }
                lastX = e.x
                acc = 0f
                pressed = true
                invalidate()
                animate().cancel()
                animate().scaleX(0.97f).scaleY(0.95f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
            }
            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                val dx = e.x - lastX
                lastX = e.x
                val rad = (width / 2f - d(2f)).coerceAtLeast(1f)
                rot += (dx / rad) * 57.3f * 0.95f           // mặt trụ chạy theo ngón tay
                acc += dx
                val step = d(14f)
                while (acc >= step) { acc -= step; fire(+1) }
                while (acc <= -step) { acc += step; fire(-1) }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                pressed = false
                val rad = (width / 2f - d(2f)).coerceAtLeast(1f)
                var vx = 0f
                vt?.let { it.computeCurrentVelocity(1000); vx = it.xVelocity; it.recycle() }
                vt = null
                if (e.actionMasked == MotionEvent.ACTION_UP && abs(vx) > d(300f)) {
                    // quay theo đà rồi chậm dần (chỉ là hiệu ứng, không thêm nấc)
                    val from = rot
                    val extra = (vx / rad) * 57.3f * 0.16f
                    fling = ValueAnimator.ofFloat(0f, 1f).apply {
                        duration = 520
                        interpolator = DecelerateInterpolator(1.8f)
                        addUpdateListener { rot = from + extra * (it.animatedValue as Float); invalidate() }
                        start()
                    }
                }
                invalidate()
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
            }
        }
        return true
    }
}

/**
 * Thông tin trên màn hình ngắm theo X2D: biểu tượng tỉ lệ (trái trên), pin + ISO + AF (phải trên), hai thanh dọc bên phải
 * (ISO, tốc độ màn trập), thanh ngang EV ở dưới (kéo để đổi EV) và hàng chữ chế độ · EV · khẩu · tốc độ · số ảnh còn lại.
 * Số liệu do MainActivity cập nhật định kỳ.
 */
class X2dHudView(ctx: Context) : XView(ctx) {
    var iso = 0
    var expNs = 0L
    var fNumber = 0f
    var evMin = 0
    var evMax = 0
    var evStep = 0f
    var evValue = 0
    /** Đang lấy nét tay. */
    var mf = false
    /** Có thông số chỉnh tay (tốc độ hoặc ISO) → chế độ M. */
    var manual = false
    /** 0..100, âm = không rõ. */
    var battery = -1
    /** Số ảnh còn lại ước tính theo dung lượng trống. */
    var remaining = 0

    /** Kéo trên thanh EV. */
    var onEv: ((Int) -> Unit)? = null

    private var dragging = false
    private val box = RectF()

    private fun sliderL() = width * 0.30f
    private fun sliderR() = width * 0.70f

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = d(14f)
        p.setShadowLayer(d(2.5f), 0f, d(1f), 0xCC000000.toInt())
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND

        // --- trái trên: biểu tượng tỉ lệ khung 4:3
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.5f)
        p.color = Color.WHITE
        box.set(pad, pad, pad + d(28f), pad + d(19f))
        c.drawRoundRect(box, d(4f), d(4f), p)
        box.set(pad + d(4f), pad + d(4f), pad + d(4f) + d(13f), pad + d(4f) + d(10f))
        c.drawRoundRect(box, d(1.5f), d(1.5f), p)
        p.style = Paint.Style.FILL
        box.set(pad + d(20f), pad + d(7.5f), pad + d(24f), pad + d(11.5f))
        c.drawRoundRect(box, d(2f), d(2f), p)

        // --- phải trên: pin
        val bw = d(24f)
        val bh = d(11f)
        val bl = w - pad - bw - d(2f)
        val bt = pad + d(1f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.3f)
        box.set(bl, bt, bl + bw, bt + bh)
        c.drawRoundRect(box, d(2.5f), d(2.5f), p)
        p.style = Paint.Style.FILL
        c.drawRect(bl + bw + d(1.2f), bt + bh * 0.32f, bl + bw + d(2.6f), bt + bh * 0.68f, p)
        if (battery >= 0) {
            p.color = if (battery < 20) 0xFFFF5A4A.toInt() else Color.WHITE
            box.set(bl + d(2f), bt + d(2f), bl + d(2f) + (bw - d(4f)) * battery / 100f, bt + bh - d(2f))
            c.drawRoundRect(box, d(1f), d(1f), p)
        }
        // ISO
        p.color = Color.WHITE
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = d(12f)
        p.textAlign = Paint.Align.RIGHT
        c.drawText("ISO " + (if (iso > 0) iso.toString() else "--"), w - pad, pad + d(34f), p)
        // AF / MF
        val tag = if (mf) "MF" else "AF"
        p.textSize = d(9.5f)
        val tw = p.measureText(tag)
        val bx1 = w - pad - d(12f)
        box.set(bx1 - tw - d(8f), pad + d(42f), bx1, pad + d(57f))
        p.color = Color.WHITE
        c.drawRoundRect(box, d(3f), d(3f), p)
        p.color = 0xFF111114.toInt()
        p.textAlign = Paint.Align.CENTER
        val fm = p.fontMetrics
        c.drawText(tag, box.centerX(), box.centerY() - (fm.ascent + fm.descent) / 2f, p)
        p.color = Color.WHITE
        p.textSize = d(11f)
        p.textAlign = Paint.Align.RIGHT
        c.drawText(if (mf) "" else "C", w - pad, box.centerY() - (fm.ascent + fm.descent) / 2f, p)
        p.typeface = Typeface.DEFAULT

        // --- phải: hai thanh dọc (ISO, tốc độ), núm là vòng tròn
        val vx1 = w - d(46f)
        val vx2 = w - d(24f)
        val top = h * 0.32f
        val bot = h * 0.76f
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.color = 0x99FFFFFF.toInt()
        c.drawLine(vx1, top, vx1, bot, p)
        c.drawLine(vx2, top, vx2, bot, p)
        val isoT = if (iso > 0) (ln(iso.coerceIn(50, 6400).toDouble() / 50.0) / ln(128.0)).toFloat() else 0.5f
        val sec = if (expNs > 0L) expNs / 1e9 else 1.0 / 125.0
        val shT = ((ln(sec.coerceIn(1.0 / 8000.0, 0.5)) - ln(1.0 / 8000.0)) / (ln(0.5) - ln(1.0 / 8000.0))).toFloat()
        knob(c, vx1, bot - isoT * (bot - top), d(7.5f))
        knob(c, vx2, bot - shT * (bot - top), d(6f))

        // --- dưới: thanh EV ngang (kéo để đổi EV)
        val sy = h - d(46f)
        val l = sliderL()
        val r = sliderR()
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.3f)
        p.color = 0xCCFFFFFF.toInt()
        c.drawLine(l, sy, r, sy, p)
        // vạch 0 EV ở giữa
        val zeroT = if (evMax > evMin) (0 - evMin).toFloat() / (evMax - evMin) else 0.5f
        c.drawLine(l + (r - l) * zeroT, sy - d(4f), l + (r - l) * zeroT, sy + d(4f), p)
        val t = if (evMax > evMin) (evValue - evMin).toFloat() / (evMax - evMin) else 0.5f
        knob(c, l + (r - l) * t.coerceIn(0f, 1f), sy, d(9f))

        // --- hàng chữ phía dưới: chế độ · EV · khẩu · tốc độ · số ảnh còn lại
        val by = h - d(16f)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        p.textSize = d(17f)
        c.drawText(if (manual) "M" else "P", pad, by, p)
        p.typeface = Typeface.DEFAULT
        p.textSize = d(11f)
        val ev = evValue * evStep
        c.drawText(if (evValue == 0) "0.0" else String.format(Locale.US, "%+.1f", ev), pad + d(30f), by, p)
        p.textSize = d(14f)
        p.textAlign = Paint.Align.CENTER
        c.drawText(if (fNumber > 0f) String.format(Locale.US, "f/%.1f", fNumber) else "f/--", w * 0.40f, by, p)
        c.drawText(shutterText(), w * 0.57f, by, p)
        p.textAlign = Paint.Align.RIGHT
        p.textSize = d(13f)
        c.drawText("[" + remaining + "]", w - pad, by, p)
        p.textAlign = Paint.Align.LEFT
        p.clearShadowLayer()
    }

    private fun knob(c: Canvas, x: Float, y: Float, r: Float) {
        p.style = Paint.Style.FILL
        p.color = 0x88000000.toInt()
        c.drawCircle(x, y, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.7f)
        p.color = Color.WHITE
        c.drawCircle(x, y, r, p)
        p.style = Paint.Style.FILL
    }

    private fun shutterText(): String {
        if (expNs <= 0L) return "--"
        val sec = expNs / 1e9
        return if (sec >= 0.5) String.format(Locale.US, "%.1fs", sec)
        else "1/" + max(1.0, Math.round(1.0 / sec).toDouble()).toInt()
    }

    private fun applyX(x: Float) {
        val l = sliderL()
        val r = sliderR()
        val t = ((x - l) / (r - l)).coerceIn(0f, 1f)
        val v = (evMin + Math.round(t * (evMax - evMin))).coerceIn(evMin, evMax)
        if (v != evValue) {
            evValue = v
            invalidate()
            onEv?.invoke(v)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val h = height.toFloat()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // chỉ nhận chạm ở dải thanh EV; chỗ khác trả về false để chạm lấy nét xuống khung ngắm bên dưới
                if (evMax <= evMin || e.y < h - d(76f) || e.y > h - d(26f) || e.x < sliderL() - d(16f) || e.x > sliderR() + d(16f)) return false
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                applyX(e.x)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return false
                applyX(e.x)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val was = dragging
                dragging = false
                return was
            }
        }
        return false
    }
}
