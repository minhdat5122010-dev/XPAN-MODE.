package com.xpanmode.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min

/**
 * Thân máy Hasselblad X2D II: màn hình 4:3 viền đen ở bên trái (nhãn HASSELBLAD ngay dưới), cột 4 phím ở bên phải màn hình,
 * tay cầm bọc da ở mép phải (bánh xe + nút chụp cam). Chỉ vẽ nền; các nút là view riêng nằm đè lên.
 */
class X2dDecorView(ctx: Context) : XView(ctx) {
    /** Màn hình (khung ngắm). */
    val vf = RectF()
    /** Tấm nền của cột phím. */
    val keys = RectF()
    /** Tay cầm. */
    val grip = RectF()

    private val logoFace = Typeface.create(Typeface.SERIF, Typeface.BOLD)
    private val clip = Path()

    override fun onDraw(c: Canvas) {
        val light = Theme.light
        c.drawColor(Theme.bgClassic)

        // viền kim loại + viền đen quanh màn hình
        val o = d(5f)
        val ch = d(2.2f)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, vf.top - o - ch, 0f, vf.bottom + o + ch,
            if (light) intArrayOf(0xFFFFFFFF.toInt(), 0xFFD6D6DC.toInt(), 0xFFA8A8AF.toInt(), 0xFFEFEFF2.toInt())
            else intArrayOf(0xFFB4B4BA.toInt(), 0xFF55555A.toInt(), 0xFF2E2E32.toInt(), 0xFF84848A.toInt()),
            floatArrayOf(0f, 0.35f, 0.7f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(vf.left - o - ch, vf.top - o - ch, vf.right + o + ch, vf.bottom + o + ch, d(14f), d(14f), p)
        p.shader = null
        p.color = Color.BLACK
        c.drawRoundRect(vf.left - o, vf.top - o, vf.right + o, vf.bottom + o, d(12f), d(12f), p)

        // nhãn HASSELBLAD dưới màn hình
        p.typeface = logoFace
        p.textSize = min(height * 0.036f, d(15f))
        p.letterSpacing = 0.32f
        p.textAlign = Paint.Align.CENTER
        p.color = if (light) 0xFF8A8A92.toInt() else 0xFFA9A9AF.toInt()
        c.drawText("HASSELBLAD", vf.centerX(), vf.bottom + o + ch + d(20f), p)
        p.typeface = Typeface.DEFAULT
        p.letterSpacing = 0f
        p.textAlign = Paint.Align.LEFT

        // tấm nền cột phím
        p.style = Paint.Style.FILL
        p.color = if (light) 0xFFCBCBD2.toInt() else 0xFF131315.toInt()
        c.drawRoundRect(keys, d(16f), d(16f), p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1f)
        p.color = if (light) 0x33000000 else 0x33FFFFFF
        c.drawRoundRect(keys, d(16f), d(16f), p)

        // tay cầm bọc da: nền tối + hạt da li ti
        val gr = d(26f)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            grip.left, 0f, grip.right, 0f,
            intArrayOf(0xFF1D1D20.toInt(), 0xFF0F0F11.toInt(), 0xFF1B1B1E.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(grip, gr, gr, p)
        p.shader = null
        clip.reset()
        clip.addRoundRect(grip, gr, gr, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        p.color = 0x14FFFFFF
        val gap = d(6.5f)
        var yy = grip.top + gap / 2f
        var row = 0
        while (yy < grip.bottom) {
            var xx = grip.left + (if (row % 2 == 0) gap / 2f else gap)
            while (xx < grip.right) { c.drawCircle(xx, yy, d(0.8f), p); xx += gap }
            yy += gap * 0.86f
            row++
        }
        c.restore()
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.color = if (light) 0x55000000 else 0x40FFFFFF
        c.drawRoundRect(grip, gr, gr, p)
        p.style = Paint.Style.FILL
    }
}

/** Phím vuông bo góc kiểu X2D; bấm thì chuyển cho view gốc nằm ngay bên dưới (trong suốt) xử lí. */
class X2dKeyView(ctx: Context, private val kind: Int) : XView(ctx) {
    companion object {
        const val FILTER = 0
        const val TUNE = 1
    }

    private val box = RectF()
    private var down = false

    /** Sáng cam khi chức năng của phím đang mở. */
    var active = false
        set(v) { field = v; invalidate() }

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val light = Theme.light
        box.set(d(1f), d(1f), w - d(1f), h - d(1f))
        val r = d(10f)
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, 0f, 0f, h,
            if (light) intArrayOf(0xFFF4F4F7.toInt(), 0xFFD9D9DF.toInt()) else intArrayOf(0xFF47474C.toInt(), 0xFF1D1D20.toInt()),
            null, Shader.TileMode.CLAMP
        )
        c.drawRoundRect(box, r, r, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        // gờ sáng phía trên
        p.strokeWidth = d(1f)
        p.color = if (light) 0xFFFFFFFF.toInt() else 0x33FFFFFF
        c.drawLine(box.left + r, box.top + d(1.6f), box.right - r, box.top + d(1.6f), p)
        // viền
        p.strokeWidth = d(1.2f)
        p.color = if (down || active) ORANGE else if (light) 0x33000000 else 0x66000000
        c.drawRoundRect(box, r, r, p)
        // biểu tượng
        val ink = if (active) ORANGE else if (light) 0xFF1B1B1E.toInt() else 0xFFE8E8EA.toInt()
        p.color = ink
        p.strokeWidth = d(1.7f)
        val cx = w / 2f
        val cy = h / 2f
        if (kind == FILTER) {
            // ba vòng màu giao nhau
            val rr = d(7f)
            c.drawCircle(cx - rr * 0.72f, cy + rr * 0.5f, rr, p)
            c.drawCircle(cx + rr * 0.72f, cy + rr * 0.5f, rr, p)
            c.drawCircle(cx, cy - rr * 0.78f, rr, p)
        } else {
            // ba thanh trượt
            val ks = floatArrayOf(-4f, 5f, -1f)
            for (i in 0..2) {
                val y = cy + (i - 1) * d(8f)
                p.style = Paint.Style.STROKE
                c.drawLine(cx - d(11f), y, cx + d(11f), y, p)
                p.style = Paint.Style.FILL
                c.drawCircle(cx + d(ks[i]), y, d(2.9f), p)
            }
        }
        p.style = Paint.Style.FILL
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                down = true; invalidate()
                animate().cancel()
                animate().scaleX(0.92f).scaleY(0.92f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
                performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                down = false; invalidate()
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3.5f)).start()
            }
        }
        return super.onTouchEvent(e)
    }
}

/**
 * Bánh xe nhám trên tay cầm: vuốt dọc để xoay (mỗi nấc rung một lần, các gờ trượt theo ngón tay).
 * Chức năng (EV / lấy nét tay) do MainActivity quyết định theo Cài đặt; [label] chỉ hiện chữ trên bánh xe.
 */
class X2dDialView(ctx: Context) : XView(ctx) {
    var label = "EV"
        set(v) { field = v; invalidate() }

    /** +1 khi vuốt lên một nấc, -1 khi vuốt xuống. */
    var onStep: ((Int) -> Unit)? = null

    private val box = RectF()
    private val pill = RectF()
    private val clip = Path()
    private var offset = 0f
    private var lastY = 0f
    private var acc = 0f
    private var pressed = false

    init { isClickable = true }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        box.set(d(2f), d(2f), w - d(2f), h - d(2f))
        val r = w * 0.3f
        // thân hình trụ nhìn ngang: tối ở hai đầu, sáng ở giữa
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(
            0f, box.top, 0f, box.bottom,
            intArrayOf(0xFF08080A.toInt(), 0xFF3A3A3F.toInt(), 0xFF5A5A61.toInt(), 0xFF3A3A3F.toInt(), 0xFF08080A.toInt()),
            floatArrayOf(0f, 0.25f, 0.5f, 0.75f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRoundRect(box, r, r, p)
        p.shader = null
        // các gờ nhám trượt theo ngón tay, mờ dần về hai đầu
        clip.reset()
        clip.addRoundRect(box, r, r, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        val rid = d(7f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.4f)
        p.strokeCap = Paint.Cap.BUTT
        var y = box.top + (((offset % rid) + rid) % rid)
        while (y < box.bottom) {
            val t = ((y - box.top) / box.height()).coerceIn(0f, 1f)
            val shade = 1f - abs(t - 0.5f) * 2f
            val a = (0x20 + 0x70 * shade).toInt().coerceIn(0, 255)
            p.color = (a shl 24) or 0xFFFFFF
            c.drawLine(box.left + d(5f), y, box.right - d(5f), y, p)
            y += rid
        }
        c.restore()
        // vạch cam đánh dấu
        p.style = Paint.Style.FILL
        p.color = ORANGE
        c.drawRoundRect(box.right - d(8f), box.centerY() - d(10f), box.right - d(4f), box.centerY() + d(10f), d(2f), d(2f), p)
        // viền
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.1f)
        p.color = if (pressed) ORANGE else 0x66FFFFFF
        c.drawRoundRect(box, r, r, p)
        // nhãn chức năng trong viên thuốc tối giữa bánh xe
        p.style = Paint.Style.FILL
        pill.set(box.centerX() - d(15f), box.centerY() - d(9f), box.centerX() + d(15f), box.centerY() + d(9f))
        p.color = 0xE6000000.toInt()
        c.drawRoundRect(pill, d(9f), d(9f), p)
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = d(10.5f)
        p.letterSpacing = 0.08f
        p.textAlign = Paint.Align.CENTER
        p.color = Color.WHITE
        val fm = p.fontMetrics
        c.drawText(label, pill.centerX(), pill.centerY() - (fm.ascent + fm.descent) / 2f, p)
        p.letterSpacing = 0f
        p.typeface = Typeface.DEFAULT
        p.textAlign = Paint.Align.LEFT
    }

    private fun fire(dir: Int) {
        performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        onStep?.invoke(dir)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                lastY = e.y
                acc = 0f
                pressed = true
                invalidate()
                animate().cancel()
                animate().scaleX(0.97f).scaleY(0.97f).setDuration(70).setInterpolator(DecelerateInterpolator()).start()
            }
            MotionEvent.ACTION_MOVE -> {
                val dy = e.y - lastY
                lastY = e.y
                offset += dy
                acc += dy
                val step = d(16f)
                while (acc <= -step) { acc += step; fire(+1) }
                while (acc >= step) { acc -= step; fire(-1) }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                pressed = false
                invalidate()
                animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
            }
        }
        return true
    }
}

/**
 * Thông tin trên màn hình ngắm theo X2D: biểu tượng tỉ lệ (trái trên), pin + ISO + AF (phải trên), hai thanh dọc bên phải
 * (ISO, tốc độ màn trập), thanh ngang EV ở dưới (kéo để đổi EV) và hàng chữ chế độ · EV · khẩu · tốc độ · số ảnh còn lại.
 * Số liệu do MainActivity cập nhật định kỳ.
 */
class X2dHudView(ctx: Context) : XView(ctx) {
    var iso = 0
    var expNs = 0L
    var fNumber = 0f
    var evMin = 0
    var evMax = 0
    var evStep = 0f
    var evValue = 0
    /** Đang lấy nét tay. */
    var mf = false
    /** Có thông số chỉnh tay (tốc độ hoặc ISO) → chế độ M. */
    var manual = false
    /** 0..100, âm = không rõ. */
    var battery = -1
    /** Số ảnh còn lại ước tính theo dung lượng trống. */
    var remaining = 0

    /** Kéo trên thanh EV. */
    var onEv: ((Int) -> Unit)? = null

    private var dragging = false
    private val box = RectF()

    private fun sliderL() = width * 0.30f
    private fun sliderR() = width * 0.70f

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val pad = d(14f)
        p.setShadowLayer(d(2.5f), 0f, d(1f), 0xCC000000.toInt())
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND

        // --- trái trên: biểu tượng tỉ lệ khung 4:3
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.5f)
        p.color = Color.WHITE
        box.set(pad, pad, pad + d(28f), pad + d(19f))
        c.drawRoundRect(box, d(4f), d(4f), p)
        box.set(pad + d(4f), pad + d(4f), pad + d(4f) + d(13f), pad + d(4f) + d(10f))
        c.drawRoundRect(box, d(1.5f), d(1.5f), p)
        p.style = Paint.Style.FILL
        box.set(pad + d(20f), pad + d(7.5f), pad + d(24f), pad + d(11.5f))
        c.drawRoundRect(box, d(2f), d(2f), p)

        // --- phải trên: pin
        val bw = d(24f)
        val bh = d(11f)
        val bl = w - pad - bw - d(2f)
        val bt = pad + d(1f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.3f)
        box.set(bl, bt, bl + bw, bt + bh)
        c.drawRoundRect(box, d(2.5f), d(2.5f), p)
        p.style = Paint.Style.FILL
        c.drawRect(bl + bw + d(1.2f), bt + bh * 0.32f, bl + bw + d(2.6f), bt + bh * 0.68f, p)
        if (battery >= 0) {
            p.color = if (battery < 20) 0xFFFF5A4A.toInt() else Color.WHITE
            box.set(bl + d(2f), bt + d(2f), bl + d(2f) + (bw - d(4f)) * battery / 100f, bt + bh - d(2f))
            c.drawRoundRect(box, d(1f), d(1f), p)
        }
        // ISO
        p.color = Color.WHITE
        p.typeface = Typeface.DEFAULT_BOLD
        p.textSize = d(12f)
        p.textAlign = Paint.Align.RIGHT
        c.drawText("ISO " + (if (iso > 0) iso.toString() else "--"), w - pad, pad + d(34f), p)
        // AF / MF
        val tag = if (mf) "MF" else "AF"
        p.textSize = d(9.5f)
        val tw = p.measureText(tag)
        val bx1 = w - pad - d(12f)
        box.set(bx1 - tw - d(8f), pad + d(42f), bx1, pad + d(57f))
        p.color = Color.WHITE
        c.drawRoundRect(box, d(3f), d(3f), p)
        p.color = 0xFF111114.toInt()
        p.textAlign = Paint.Align.CENTER
        val fm = p.fontMetrics
        c.drawText(tag, box.centerX(), box.centerY() - (fm.ascent + fm.descent) / 2f, p)
        p.color = Color.WHITE
        p.textSize = d(11f)
        p.textAlign = Paint.Align.RIGHT
        c.drawText(if (mf) "" else "C", w - pad, box.centerY() - (fm.ascent + fm.descent) / 2f, p)
        p.typeface = Typeface.DEFAULT

        // --- phải: hai thanh dọc (ISO, tốc độ), núm là vòng tròn
        val vx1 = w - d(46f)
        val vx2 = w - d(24f)
        val top = h * 0.32f
        val bot = h * 0.76f
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.2f)
        p.color = 0x99FFFFFF.toInt()
        c.drawLine(vx1, top, vx1, bot, p)
        c.drawLine(vx2, top, vx2, bot, p)
        val isoT = if (iso > 0) (ln(iso.coerceIn(50, 6400).toDouble() / 50.0) / ln(128.0)).toFloat() else 0.5f
        val sec = if (expNs > 0L) expNs / 1e9 else 1.0 / 125.0
        val shT = ((ln(sec.coerceIn(1.0 / 8000.0, 0.5)) - ln(1.0 / 8000.0)) / (ln(0.5) - ln(1.0 / 8000.0))).toFloat()
        knob(c, vx1, bot - isoT * (bot - top), d(7.5f))
        knob(c, vx2, bot - shT * (bot - top), d(6f))

        // --- dưới: thanh EV ngang (kéo để đổi EV)
        val sy = h - d(46f)
        val l = sliderL()
        val r = sliderR()
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.3f)
        p.color = 0xCCFFFFFF.toInt()
        c.drawLine(l, sy, r, sy, p)
        // vạch 0 EV ở giữa
        val zeroT = if (evMax > evMin) (0 - evMin).toFloat() / (evMax - evMin) else 0.5f
        c.drawLine(l + (r - l) * zeroT, sy - d(4f), l + (r - l) * zeroT, sy + d(4f), p)
        val t = if (evMax > evMin) (evValue - evMin).toFloat() / (evMax - evMin) else 0.5f
        knob(c, l + (r - l) * t.coerceIn(0f, 1f), sy, d(9f))

        // --- hàng chữ phía dưới: chế độ · EV · khẩu · tốc độ · số ảnh còn lại
        val by = h - d(16f)
        p.style = Paint.Style.FILL
        p.color = Color.WHITE
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
        p.textSize = d(17f)
        c.drawText(if (manual) "M" else "P", pad, by, p)
        p.typeface = Typeface.DEFAULT
        p.textSize = d(11f)
        val ev = evValue * evStep
        c.drawText(if (evValue == 0) "0.0" else String.format(Locale.US, "%+.1f", ev), pad + d(30f), by, p)
        p.textSize = d(14f)
        p.textAlign = Paint.Align.CENTER
        c.drawText(if (fNumber > 0f) String.format(Locale.US, "f/%.1f", fNumber) else "f/--", w * 0.40f, by, p)
        c.drawText(shutterText(), w * 0.57f, by, p)
        p.textAlign = Paint.Align.RIGHT
        p.textSize = d(13f)
        c.drawText("[" + remaining + "]", w - pad, by, p)
        p.textAlign = Paint.Align.LEFT
        p.clearShadowLayer()
    }

    private fun knob(c: Canvas, x: Float, y: Float, r: Float) {
        p.style = Paint.Style.FILL
        p.color = 0x88000000.toInt()
        c.drawCircle(x, y, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = d(1.7f)
        p.color = Color.WHITE
        c.drawCircle(x, y, r, p)
        p.style = Paint.Style.FILL
    }

    private fun shutterText(): String {
        if (expNs <= 0L) return "--"
        val sec = expNs / 1e9
        return if (sec >= 0.5) String.format(Locale.US, "%.1fs", sec)
        else "1/" + max(1.0, Math.round(1.0 / sec).toDouble()).toInt()
    }

    private fun applyX(x: Float) {
        val l = sliderL()
        val r = sliderR()
        val t = ((x - l) / (r - l)).coerceIn(0f, 1f)
        val v = (evMin + Math.round(t * (evMax - evMin))).coerceIn(evMin, evMax)
        if (v != evValue) {
            evValue = v
            invalidate()
            onEv?.invoke(v)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val h = height.toFloat()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                // chỉ nhận chạm ở dải thanh EV; chỗ khác trả về false để chạm lấy nét xuống khung ngắm bên dưới
                if (evMax <= evMin || e.y < h - d(76f) || e.y > h - d(26f) || e.x < sliderL() - d(16f) || e.x > sliderR() + d(16f)) return false
                dragging = true
                parent?.requestDisallowInterceptTouchEvent(true)
                applyX(e.x)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) return false
                applyX(e.x)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val was = dragging
                dragging = false
                return was
            }
        }
        return false
    }
}
