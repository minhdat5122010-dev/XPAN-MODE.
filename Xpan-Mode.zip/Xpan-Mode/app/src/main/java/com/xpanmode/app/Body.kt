package com.xpanmode.app

/**
 * Thân máy đang mô phỏng: XPAN (khổ panorama 65:24) hoặc X2D II (khổ 4:3).
 * Cắt ảnh, khung ngắm, bố cục giao diện đều đọc từ đây để hai chế độ dùng chung toàn bộ chức năng chụp.
 */
object Body {
    @Volatile @JvmStatic var x2d = false

    /** Tỉ lệ rộng / cao của khung chụp khi cầm ngang. */
    @JvmStatic val ratio: Float get() = if (x2d) 4f / 3f else 65f / 24f

    /** Tên hiện trên nút menu. */
    @JvmStatic val name: String get() = if (x2d) "X2D II" else "XPAN"

    /** Tỉ lệ ghi trên chữ khắc, ghi chú. */
    @JvmStatic val ratioText: String get() = if (x2d) "4:3" else "65:24"
}
