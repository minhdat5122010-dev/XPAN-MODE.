package com.xpanmode.app

/** Khổ khung đang dùng: XPAN 65:24 (mặc định) hoặc 4:3 (giao diện X2D II). Tỉ lệ rộng/cao khi cầm ngang. */
object CropFmt {
    const val XPAN = 65f / 24f
    const val X2D = 4f / 3f

    @JvmStatic @Volatile var x2d = false

    val ratio: Float get() = if (x2d) X2D else XPAN

    /** Tỉ lệ rộng/cao trong không gian buffer cảm biến (vertical = buffer dựng dọc). */
    fun aspect(vertical: Boolean, x2d: Boolean = this.x2d): Float {
        val r = if (x2d) X2D else XPAN
        return if (vertical) 1f / r else r
    }
}
