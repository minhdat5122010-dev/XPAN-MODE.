package com.xpanmode.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.DngCreator
import android.hardware.camera2.TotalCaptureResult
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.Image
import android.media.ImageReader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import android.view.Surface
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.Executor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Camera2 thuần: mở đúng ống kính (kể cả camera vật lý ẩn trong camera logic),
 * chụp JPEG độ phân giải tối đa, chất lượng 100, bật khử nhiễu/nét ở chế độ HIGH_QUALITY.
 * Zoom số được thực hiện bằng cách CẮT ảnh gốc ở bước xử lý (không nội suy phóng to).
 */
class CameraController(
    private val ctx: Context,
    private val repo: LensRepository,
    private val cb: Callback
) {
    interface Callback {
        fun onReady(info: OpenInfo)
        fun onError(msg: String)
        fun onShot(shot: ShotResult)
        fun onFocus(ok: Boolean)
        /** Máy từ chối cấu hình HQ: đã tự mở lại ở chế độ thường. */
        fun onHqFailed() {}
        /** Khung thứ n/total của lượt chụp HQ ghép khung đã nhận xong. */
        fun onBurstFrame(n: Int, total: Int) {}
        /** LUNA Night bắt đầu phơi sáng (sau khi lấy nét xong): totalFrames là số khung dự kiến. */
        fun onNightStart(totalFrames: Int) {}
    }

    class OpenInfo(
        val lens: LensInfo, val preview: Size, val direct: Boolean, val sensorOrientation: Int,
        val evMin: Int, val evMax: Int, val evStep: Float, val maxZoom: Float, val raw: Boolean,
        val viaZoom: Boolean, val caps: Caps
    )

    /** Khả năng chỉnh tay của camera đang mở. */
    class Caps(
        val manualSensor: Boolean, val shutterMin: Long, val shutterMax: Long,
        val isoMin: Int, val isoMax: Int, val minFocus: Float, val awbModes: IntArray
    )

    class ShotMeta(
        val exposureNs: Long, val iso: Int, val aperture: Float, val focalMm: Float,
        val eq35: Float, val zoom: Float, val rotation: Int
    )

    class ShotResult(val jpeg: File, val dng: File?, val meta: ShotMeta, val extra: List<File> = emptyList(), val wantFuse: Boolean = false, val trail: Boolean = false, val night: LunaNight.Session? = null, val rawIn: RawHq.Input? = null)

    /** Yêu cầu chụp thiếu sáng: thời gian phơi (giây), hệ số cần thêm sáng so với khung xem trước, máy có đang vững (chân máy) không. */
    private class NightPlan(val secs: Int, val boost: Float, val steady: Boolean)

    private class Pending(val rawWanted: Boolean, val zoom: Float, val rotation: Int, val frames: Int = 1, val trail: Boolean = false, val night: NightPlan? = null, val rawHq: Boolean = false) {
        // --- chỉ dùng cho HQ RAW
        val rawFiles = ArrayList<File>()
        var rawW = 0
        var rawH = 0
        var rawFail = false
        // --- chỉ dùng cho LUNA Night
        var session: LunaNight.Session? = null
        var scheduled = 0
        var got = 0
        var failed = 0
        var closed = false
        var stop = false
        var nightDone = false
        var t0 = 0L
        var estTotal = 0
        var jpeg: File? = null
        val extra = ArrayList<File>()
        var completed = 0
        var result: TotalCaptureResult? = null
        var physRes: CaptureResult? = null
        var raw: Image? = null
    }

    private val thread = HandlerThread("xpan-camera").also { it.start() }
    private val handler = Handler(thread.looper)
    private val main = Handler(Looper.getMainLooper())
    private val executor = Executor { handler.post(it) }

    private var gen = 0
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var previewSurface: Surface? = null
    private var jpegReader: ImageReader? = null
    private var rawReader: ImageReader? = null
    private var chars: CameraCharacteristics? = null
    private var lens: LensInfo? = null
    private var physicalId: String? = null
    private var wantRaw = false
    private var previewBuilder: CaptureRequest.Builder? = null
    private var ev = 0
    @Volatile private var params = CamParams()
    @Volatile var lastExposureNs = 10_000_000L
        private set
    @Volatile var lastIso = 100
        private set
    private var zoom = 1f
    private var afRegions: Array<MeteringRectangle>? = null
    private var busy = false
    /** Các lệnh chụp bấm khi đang bận (chụp liên tiếp ở chế độ màn chập): chạy lần lượt ngay khi xong tấm trước. */
    private val queued = java.util.ArrayDeque<Int>()

    private fun idle() {
        busy = false
        val n = queued.pollFirst()
        if (n != null) handler.post { capture(n) }
    }
    private var pending: Pending? = null
    private var afterClose: Runnable? = null
    private var texture: SurfaceTexture? = null
    private var previewSize = Size(1280, 720)
    private var basePreview = Size(1280, 720)
    private var curJpeg = Size(4000, 3000)
    private var baseRatio = 1f
    private var focusPending = false
    private var focusT0 = 0L
    private var hwBase = 0f   // >0: đang dùng zoom phần cứng của camera chính để tới ống kính ẩn (tele/ultra)

    private companion object {
        const val MF_FRAMES = 5
        /** Vệt sáng: số khung chụp liên tiếp rồi căn chỉnh + xếp chồng thành ảnh phơi sáng dài. */
        const val TRAIL_FRAMES = 12
        /** LUNA Night: bộ đệm ảnh của ImageReader, trần số khung đặt lệnh, JPEG nén nhẹ hơn vì nhiễu che mất khác biệt. */
        const val NIGHT_READER = 6
        const val NIGHT_MAX_FRAMES = 240
        const val NIGHT_JPEG_Q: Byte = 95
        /** Chuỗi chụp ghép khung: xin camera giảm làm nét cạnh + khử nhiễu (EDGE OFF, NR MINIMAL) vì app tự ghép/khử nhiễu/làm nét sau.
         *  ISP làm nét từng khung tạo hiệu ứng "chuỗi hạt" trên sợi mảnh (tóc, lông mi). Máy nào bỏ qua yêu cầu này thì không đổi gì. Đặt false để tắt. */
        const val MF_LIGHT_ISP = true
    }

    // ---------------------------------------------------------------- mở / đóng

    /** Đang dùng chế độ HQ (độ phân giải tối đa) cho phiên hiện tại. */
    @Volatile var appIsp = true   // ảnh thường: true = khung thô (NR tối thiểu, không làm nét của máy), app tự xử lí
    @Volatile var hqActive = false
        private set
    /** HQ ghép nhiều khung (khi máy không chụp được độ phân giải tối đa): số khung chụp liên tiếp mỗi lần bấm. */
    @Volatile var multiFrame = false
    /** HQ RAW: ghép từ khung RAW (chỉ có hiệu lực khi multiFrame, máy có RAW và không có luồng 50MP). */
    @Volatile var rawHq = false
    private var rawHqActive = false
    /** Vệt sáng (Thợ săn ánh sáng): chụp liên tiếp TRAIL_FRAMES khung để xếp chồng. Chỉ ở chế độ thường. */
    @Volatile var trailMode = false
    /** LUNA Night (thiếu sáng): chụp liên tục trong N giây, ghép streaming. Chỉ ở chế độ thường (không đi cùng HQ / vệt sáng / RAW). */
    @Volatile var nightMode = false
    @Volatile private var nightReq: NightPlan? = null
    private var wantHq = false
    private var hqSize: Size? = null
    private var hqMaxRes = false

    fun open(l: LensInfo, st: SurfaceTexture, preview: Size, raw: Boolean, lensRatio: Float, hq: Boolean = false) {
        handler.post {
            closeNow(Runnable {
                val g = gen
                lens = l
                texture = st
                basePreview = preview
                previewSize = preview
                baseRatio = lensRatio
                chars = repo.chars[l.id]
                curJpeg = l.jpegSize
                hwBase = 0f
                wantHq = hq
                val pick = if (hq) repo.hqPick(l) else null
                hqSize = pick?.first
                hqMaxRes = pick?.second == true
                // HQ dùng khi mở trực tiếp hoặc qua camera logic (luồng vật lý); không dùng khi phải zoom camera chính. RAW không đi cùng HQ
                wantRaw = raw && l.rawSize != null && hqSize == null && !multiFrame && !trailMode && !nightMode
                rawHqActive = rawHq && multiFrame && l.rawSize != null && hqSize == null
                ev = 0
                afRegions = null
                attemptOpen(g, 0)
            })
        }
    }

    fun close() {
        handler.post { closeNow(null) }
    }

    fun release() {
        handler.post {
            closeNow(null)
            thread.quitSafely()
        }
    }

    private fun closeNow(after: Runnable?) {
        gen++
        busy = false
        queued.clear()
        try { session?.close() } catch (_: Exception) {}
        session = null
        try { pending?.raw?.close() } catch (_: Exception) {}
        try { pending?.session?.abort() } catch (_: Exception) {}
        pending = null
        try { jpegReader?.close() } catch (_: Exception) {}
        jpegReader = null
        try { rawReader?.close() } catch (_: Exception) {}
        rawReader = null
        previewBuilder = null
        val d = device
        device = null
        if (d == null) {
            previewSurface?.release()
            previewSurface = null
            after?.run()
            return
        }
        afterClose = Runnable {
            previewSurface?.release()
            previewSurface = null
            after?.run()
        }
        try { d.close() } catch (_: Exception) { runAfterClose() }
        handler.postDelayed({ runAfterClose() }, 700)
    }

    private fun runAfterClose() {
        val a = afterClose
        afterClose = null
        a?.run()
    }

    private fun fail(msg: String) {
        main.post { cb.onError(msg) }
    }

    private fun nextAttempt(@Suppress("UNUSED_PARAMETER") l: LensInfo, a: Int): Int? = when (a) {
        0 -> 1
        1 -> 2
        else -> null
    }

    /**
     * Thứ tự thử: 0 = mở trực tiếp ID ống kính; 1 = mở camera logic + physical stream;
     * 2 = mở camera sau chính rồi zoom phần cứng (CONTROL_ZOOM_RATIO) để hệ thống chuyển sang ống kính ẩn.
     */
    @SuppressLint("MissingPermission")
    private fun attemptOpen(g: Int, attempt: Int) {
        val l = lens ?: return
        val camId: String
        val phys: String?
        val parent = l.parentId
        if (attempt == 0) {
            camId = l.id; phys = null
        } else if (attempt == 1) {
            val pid = parent ?: repo.fallbackBackId()
            if (pid == null) { attemptOpen(g, 2); return }
            camId = pid; phys = l.id
        } else {
            val fb = repo.fallbackBackId()
            if (fb == null) { fail("Không mở được ống kính ${l.id}"); return }
            camId = fb; phys = null
        }
        physicalId = phys
        hqActive = attempt <= 1 && wantHq && hqSize != null
        if (attempt >= 2) {
            val fc = repo.chars[camId]
            chars = fc
            curJpeg = repo.maxJpeg(fc) ?: l.jpegSize
            previewSize = repo.previewSizeFor(fc, curJpeg)
            wantRaw = false
            rawHqActive = false   // zoom camera chính: không có luồng RAW của ống kính ẩn
            var r = baseRatio
            if (Build.VERSION.SDK_INT >= 30) {
                val rg = fc?.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
                if (rg != null) r = r.coerceIn(rg.lower, rg.upper)
            }
            hwBase = r
        } else {
            chars = repo.chars[l.id]
            curJpeg = l.jpegSize
            previewSize = basePreview
            hwBase = 0f
        }
        try {
            repo.manager.openCamera(camId, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    if (g != gen) { d.close(); return }
                    device = d
                    createSession(g, d, attempt)
                }

                override fun onDisconnected(d: CameraDevice) {
                    d.close()
                    if (g == gen) device = null
                }

                override fun onClosed(d: CameraDevice) {
                    runAfterClose()
                }

                override fun onError(d: CameraDevice, error: Int) {
                    d.close()
                    if (g != gen) return
                    device = null
                    val n = nextAttempt(l, attempt)
                    if (n != null) attemptOpen(g, n)
                    else fail("Không mở được camera ${l.id} (lỗi $error)")
                }
            }, handler)
        } catch (e: Exception) {
            val n = nextAttempt(l, attempt)
            if (n != null) attemptOpen(g, n)
            else fail("Không mở được camera ${l.id}: ${e.message}")
        }
    }

    private fun outCfg(s: Surface): OutputConfiguration {
        val c = OutputConfiguration(s)
        physicalId?.let { c.setPhysicalCameraId(it) }
        return c
    }

    private fun createSession(g: Int, d: CameraDevice, attempt: Int) {
        val l = lens ?: return
        val st = texture ?: return
        try {
            st.setDefaultBufferSize(previewSize.width, previewSize.height)
            val ps = Surface(st)
            previewSurface = ps
            val hqSz = if (hqActive) hqSize else null
            val jr = if (hqSz != null) ImageReader.newInstance(hqSz.width, hqSz.height, ImageFormat.JPEG, 1)
            else ImageReader.newInstance(curJpeg.width, curJpeg.height, ImageFormat.JPEG, if (multiFrame) MF_FRAMES + 1 else if (trailMode) TRAIL_FRAMES + 1 else if (nightMode) NIGHT_READER else 2)
            jr.setOnImageAvailableListener({ r -> onJpeg(r) }, handler)
            jpegReader = jr
            val outs = ArrayList<OutputConfiguration>()
            outs.add(outCfg(ps))
            val jcfg = outCfg(jr.surface)
            if (hqSz != null && hqMaxRes && Build.VERSION.SDK_INT >= 31) {
                jcfg.addSensorPixelModeUsed(CameraMetadata.SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION)
            }
            outs.add(jcfg)
            val rs = l.rawSize
            if ((wantRaw || rawHqActive) && rs != null) {
                val rr = ImageReader.newInstance(rs.width, rs.height, ImageFormat.RAW_SENSOR, if (rawHqActive) MF_FRAMES + 1 else 2)
                rr.setOnImageAvailableListener({ r -> onRaw(r) }, handler)
                rawReader = rr
                outs.add(outCfg(rr.surface))
            }
            val cfg = SessionConfiguration(
                SessionConfiguration.SESSION_REGULAR, outs, executor,
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) {
                        if (g != gen) { s.close(); return }
                        session = s
                        startPreview()
                        val inf = info()
                        main.post { cb.onReady(inf) }
                    }

                    override fun onConfigureFailed(s: CameraCaptureSession) {
                        if (g != gen) return
                        val n = nextAttempt(l, attempt)
                        if (hqActive) {
                            // máy không cho ghép luồng độ phân giải tối đa với xem trước: về chế độ thường
                            wantHq = false; hqSize = null; hqMaxRes = false; hqActive = false
                            main.post { cb.onHqFailed() }
                            reopen(attempt, false)
                        }
                        else if (rawHqActive) { rawHqActive = false; reopen(attempt, false) }
                        else if (wantRaw) reopen(attempt, false)
                        else if (n != null) reopen(n, false)
                        else fail("Không tạo được phiên camera cho ống kính ${l.id}")
                    }
                })
            d.createCaptureSession(cfg)
        } catch (e: Exception) {
            val n = nextAttempt(l, attempt)
            if (n != null) reopen(n, false) else fail("Lỗi tạo phiên camera: ${e.message}")
        }
    }

    private fun reopen(attempt: Int, raw: Boolean) {
        closeNow(Runnable {
            val g = gen
            wantRaw = raw
            attemptOpen(g, attempt)
        })
    }

    private fun info(): OpenInfo {
        val c = chars!!
        val l = lens!!
        val evr = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
        val step = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)
        val maxZoom = min(5f, sqrt(l.megapixels / 3f)).coerceAtLeast(1f)
        return OpenInfo(
            l, previewSize, physicalId == null && hwBase == 0f,
            c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90,
            evr?.lower ?: 0, evr?.upper ?: 0, step?.toFloat() ?: 0f, maxZoom, wantRaw,
            hwBase > 0f, caps()
        )
    }

    private fun caps(): Caps {
        val c = chars!!
        val cap = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES) ?: IntArray(0)
        val et = c.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
        val isoR = c.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
        return Caps(
            cap.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) && et != null && isoR != null,
            et?.lower ?: 0L, et?.upper ?: 0L, isoR?.lower ?: 0, isoR?.upper ?: 0,
            c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f,
            c.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES) ?: intArrayOf(CameraMetadata.CONTROL_AWB_MODE_AUTO)
        )
    }

    /** Đang chỉnh tay tốc độ/ISO (AE tắt). */
    private fun manualAe(): Boolean {
        val p = params
        return (p.shutterNs > 0L || p.iso > 0) && chars?.let { caps().manualSensor } == true
    }

    /** Đang lấy nét tay (AF tắt). */
    private fun manualFocus(): Boolean = params.focus >= 0f && (chars?.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f) > 0f

    // ---------------------------------------------------------------- preview

    private fun activeArray(): Rect = chars?.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: Rect(0, 0, 4000, 3000)

    private fun crop(z: Float): Rect {
        val a = activeArray()
        val w = (a.width() / z).toInt()
        val h = (a.height() / z).toInt()
        val l = a.centerX() - w / 2
        val t = a.centerY() - h / 2
        return Rect(l, t, l + w, t + h)
    }

    private fun hwRatio(z: Float): Float {
        val v = hwBase * z
        if (Build.VERSION.SDK_INT >= 30) {
            val r = chars?.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
            if (r != null) return v.coerceIn(r.lower, r.upper)
        }
        return v
    }

    private fun applyZoom(b: CaptureRequest.Builder) {
        if (hwBase > 0f && Build.VERSION.SDK_INT >= 30) {
            b.set(CaptureRequest.CONTROL_ZOOM_RATIO, hwRatio(zoom))
            b.set(CaptureRequest.SCALER_CROP_REGION, activeArray())
        } else {
            b.set(CaptureRequest.SCALER_CROP_REGION, crop(if (hwBase > 0f) max(1f, hwBase * zoom) else zoom))
        }
    }

    private fun applyCommon(b: CaptureRequest.Builder) {
        val c = chars ?: return
        b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
        val p = params
        val afm = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES) ?: IntArray(0)
        val minFocus = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        if (p.focus >= 0f && minFocus > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, p.focus.coerceIn(0f, minFocus))
        } else if (afm.contains(CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE))
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        else if (afm.contains(CameraMetadata.CONTROL_AF_MODE_AUTO))
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_AUTO)
        if (manualAe()) {
            val cp = caps()
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            val exp = if (p.shutterNs > 0L) p.shutterNs else lastExposureNs
            val iso = if (p.iso > 0) p.iso else lastIso
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, exp.coerceIn(cp.shutterMin, cp.shutterMax))
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso.coerceIn(cp.isoMin, cp.isoMax))
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ev)
        }
        val awbOk = c.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)?.contains(p.wb) == true
        b.set(CaptureRequest.CONTROL_AWB_MODE, if (awbOk) p.wb else CameraMetadata.CONTROL_AWB_MODE_AUTO)
        afRegions?.let {
            b.set(CaptureRequest.CONTROL_AF_REGIONS, it)
            b.set(CaptureRequest.CONTROL_AE_REGIONS, it)
        }
    }

    /** Trạng thái AF/AE gần nhất của luồng xem trước: nếu đã nét + đủ sáng thì chụp ngay, không chờ lại. */
    @Volatile private var lastAfState: Int? = null
    @Volatile private var focusSawScan = false
    @Volatile private var lastAeState: Int? = null

    private val repeatCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
            lastAfState = result.get(CaptureResult.CONTROL_AF_STATE)
            lastAeState = result.get(CaptureResult.CONTROL_AE_STATE)
            // ghi nhớ giá trị AE tự động gần nhất để làm điểm bắt đầu khi chuyển sang chỉnh tay
            if (result.get(CaptureResult.CONTROL_AE_MODE) != CameraMetadata.CONTROL_AE_MODE_OFF) {
                result.get(CaptureResult.SENSOR_EXPOSURE_TIME)?.let { if (it > 0L) lastExposureNs = it }
                result.get(CaptureResult.SENSOR_SENSITIVITY)?.let { if (it > 0) lastIso = it }
            }
            if (!focusPending || SystemClock.elapsedRealtime() - focusT0 < 150) return
            val af = result.get(CaptureResult.CONTROL_AF_STATE) ?: return
            if (af == CaptureResult.CONTROL_AF_STATE_ACTIVE_SCAN) focusSawScan = true
            // Trạng thái "đã khoá" còn sót lại từ lần chạm trước không được tính là nét: phải thấy AF quét thật rồi mới chốt
            // (hoặc chờ >1,2s mà không thấy quét thì coi như ống kính vốn đã nét sẵn).
            val settled = focusSawScan || SystemClock.elapsedRealtime() - focusT0 > 1200
            if (!settled) return
            if (af == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED) {
                focusPending = false
                main.post { cb.onFocus(true) }
            } else if (af == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED) {
                focusPending = false
                main.post { cb.onFocus(false) }
            }
        }
    }

    private fun startPreview() {
        val d = device ?: return
        val s = session ?: return
        val ps = previewSurface ?: return
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            b.addTarget(ps)
            applyCommon(b)
            applyZoom(b)
            previewBuilder = b
            s.setRepeatingRequest(b.build(), repeatCb, handler)
        } catch (e: Exception) {
            fail("Lỗi xem trước: ${e.message}")
        }
    }

    private fun updatePreview() {
        val b = previewBuilder ?: return
        val s = session ?: return
        try {
            applyCommon(b)
            applyZoom(b)
            s.setRepeatingRequest(b.build(), repeatCb, handler)
        } catch (_: Exception) {}
    }

    fun setEv(index: Int) {
        handler.post { ev = index; updatePreview() }
    }

    /** Đặt toàn bộ thông số camera (EV, tốc độ, ISO, WB, lấy nét). */
    fun setParams(p: CamParams) {
        handler.post { params = p; ev = p.ev; updatePreview() }
    }

    fun setZoom(z: Float) {
        handler.post { zoom = z.coerceAtLeast(1f); updatePreview() }
    }

    /** nx, ny: toạ độ chạm chuẩn hoá trong khung ngắm; bandFrac: phần chiều cao buffer hiển thị trong khung 65:24. */
    fun focusAt(nx: Float, ny: Float, bandFrac: Float, rot180: Boolean) {
        handler.post {
            val d = device ?: return@post
            val s = session ?: return@post
            val ps = previewSurface ?: return@post
            val a = activeArray()
            val cr = if (hwBase > 0f) crop(max(1f, hwBase * zoom)) else crop(zoom)
            var bx = nx
            var by = 0.5f + (ny - 0.5f) * bandFrac
            if (rot180) { bx = 1f - bx; by = 1f - by }
            val cx = cr.left + bx * cr.width()
            val cy = cr.top + by * cr.height()
            val half = (min(a.width(), a.height()) * 0.09f).toInt()   // vùng lớn hơn -> ít tương phản vẫn bắt nét nhanh
            val l = (cx - half).toInt().coerceIn(a.left, a.right - 3)
            val t = (cy - half).toInt().coerceIn(a.top, a.bottom - 3)
            val r = (cx + half).toInt().coerceIn(l + 1, a.right - 1)
            val bt = (cy + half).toInt().coerceIn(t + 1, a.bottom - 1)
            afRegions = arrayOf(MeteringRectangle(Rect(l, t, r, bt), MeteringRectangle.METERING_WEIGHT_MAX))
            focusPending = true
            focusSawScan = false
            focusT0 = SystemClock.elapsedRealtime()
            val my = ++focusToken
            handler.postDelayed({ if (my == focusToken) focusPending = false }, 3000)
            // sau ~3,5s thả khoá nét để camera tự lấy nét liên tục trở lại
            handler.postDelayed({ if (my == focusToken) releaseAfLock() }, 3500)
            try {
                // Đặt vùng nét mới vào luồng xem trước rồi kích hoạt AF NGAY. Không còn gửi AF_TRIGGER_CANCEL trước đó:
                // CANCEL khiến AF liên tục bỏ vị trí ống kính đang gần nét và quét lại từ đầu -> bắt nét chậm, thấy mờ nhiều giây.
                // (AF_TRIGGER_START tự bắt đầu lượt quét mới kể cả khi đang khoá ở lần chạm trước.)
                // Chỉ khi đang KHOÁ nét từ lần chạm trước mới cần huỷ để buộc quét lại (không thì giữ nguyên, quét nhanh hơn)
                val st0 = lastAfState
                if (st0 == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED || st0 == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED) {
                    val cb0 = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                    cb0.addTarget(ps)
                    applyCommon(cb0)
                    applyZoom(cb0)
                    cb0.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_CANCEL)
                    s.capture(cb0.build(), null, handler)
                }
                updatePreview()
                val tb = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                tb.addTarget(ps)
                applyCommon(tb)
                applyZoom(tb)
                tb.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START)
                s.capture(tb.build(), repeatCb, handler)
            } catch (_: Exception) {}
        }
    }

    private var focusToken = 0

    private fun releaseAfLock() {
        val d = device ?: return
        val s = session ?: return
        val ps = previewSurface ?: return
        if (busy) return
        try {
            val tb = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            tb.addTarget(ps)
            applyCommon(tb)
            applyZoom(tb)
            tb.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_CANCEL)
            s.capture(tb.build(), null, handler)
            updatePreview()
        } catch (_: Exception) {}
    }

    // ---------------------------------------------------------------- chụp

    fun capture(rotation: Int) {
        handler.post {
            val d = device
            val s = session
            val ps = previewSurface
            val c = chars
            if (d == null || s == null || ps == null || c == null) return@post
            if (busy) {
                if (queued.size < 3) queued.addLast(rotation)
                return@post
            }
            busy = true
            val g = gen
            val nr = nightReq
            nightReq = null
            val nightNow = nr != null && nightMode && !multiFrame && !hqActive && !wantRaw && !trailMode
            val trailNow = trailMode && !multiFrame && !hqActive && !wantRaw && !nightNow
            val nFrames = if (multiFrame && !hqActive && !wantRaw) MF_FRAMES else if (trailNow) TRAIL_FRAMES else 1
            val rawHqNow = rawHqActive && multiFrame && !hqActive && !wantRaw && nFrames == MF_FRAMES && rawReader != null
            val p = Pending(wantRaw, if (hwBase > 0f) 1f else zoom, rotation, nFrames, trailNow, if (nightNow) nr else null, rawHqNow)
            pending = p
            val afm = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES) ?: IntArray(0)
            val hasAf = afm.any { it != CameraMetadata.CONTROL_AF_MODE_OFF } && !manualFocus()
            val aeManual = manualAe()
            var fired = false
            val t0 = SystemClock.elapsedRealtime()
            val fire = Runnable {
                if (!fired && g == gen) { fired = true; if (p.night != null) doCaptureNight() else doCapture() }
            }
            val waitCb = object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult
                ) {
                    val af = result.get(CaptureResult.CONTROL_AF_STATE)
                    val ae = result.get(CaptureResult.CONTROL_AE_STATE)
                    val afOk = !hasAf || af == null ||
                        af == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED ||
                        af == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED
                    val aeOk = aeManual || ae == null ||
                        ae == CaptureResult.CONTROL_AE_STATE_CONVERGED ||
                        ae == CaptureResult.CONTROL_AE_STATE_FLASH_REQUIRED ||
                        ae == CaptureResult.CONTROL_AE_STATE_LOCKED
                    if (afOk && aeOk && SystemClock.elapsedRealtime() - t0 > 80) fire.run()
                }
            }
            // Đã nét (khoá hoặc AF liên tục đang nét) và phơi sáng ổn định -> chụp NGAY khoảnh khắc bấm,
            // không chạy lại AF/AE (trước đây chờ tới ~1,4 giây nên di chuyển máy là ảnh lệch so với lúc bấm).
            val af0 = lastAfState
            val ae0 = lastAeState
            // Chụp NGAY khoảnh khắc bấm. Chỉ chờ (tối đa 0,7s) khi AF đang quét do vừa chạm lấy nét,
            // hoặc AE đang chạy precapture. Trước đây còn chờ cả khi AF liên tục đang "quét nhẹ" lúc di chuyển máy
            // -> ảnh chụp trễ hàng trăm ms so với khung đóng băng.
            val afReady = !hasAf || af0 != CaptureResult.CONTROL_AF_STATE_ACTIVE_SCAN
            val aeReady = aeManual || ae0 != CaptureResult.CONTROL_AE_STATE_PRECAPTURE
            if (afReady && aeReady) {
                fire.run()
                return@post
            }
            try {
                val tb = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                tb.addTarget(ps)
                applyCommon(tb)
                applyZoom(tb)
                if (hasAf) tb.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START)
                if (!aeManual) tb.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CameraMetadata.CONTROL_AE_PRECAPTURE_TRIGGER_START)
                s.capture(tb.build(), waitCb, handler)
                previewBuilder?.let { s.setRepeatingRequest(it.build(), waitCb, handler) }
                handler.postDelayed(fire, 700)
            } catch (e: Exception) {
                idle()
                pending = null
                fail("Không thể chụp: ${e.message}")
            }
        }
    }

    private fun doCapture() {
        val d = device
        val s = session
        val jr = jpegReader
        val c = chars
        val p = pending
        if (d == null || s == null || jr == null || c == null || p == null) { idle(); return }
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            b.addTarget(jr.surface)
            if (p.rawWanted) rawReader?.let { b.addTarget(it.surface) }
            if (p.rawHq) {
                // HQ RAW: mỗi khung chụp kèm RAW; xin thêm bản đồ bù tối góc để bù vignette khi tự dựng ảnh từ RAW
                rawReader?.let { b.addTarget(it.surface) }
                try {
                    if (c.get(CameraCharacteristics.STATISTICS_INFO_AVAILABLE_LENS_SHADING_MAP_MODES)?.contains(CameraMetadata.STATISTICS_LENS_SHADING_MAP_MODE_ON) == true)
                        b.set(CaptureRequest.STATISTICS_LENS_SHADING_MAP_MODE, CameraMetadata.STATISTICS_LENS_SHADING_MAP_MODE_ON)
                } catch (_: Exception) {}
            }
            applyCommon(b)
            // Chụp toàn khung cảm biến; việc cắt 65:24 / zoom số làm ở bước xử lý để giữ nguyên điểm ảnh thật
            b.set(CaptureRequest.SCALER_CROP_REGION, activeArray())
            if (hwBase > 0f) {
                if (Build.VERSION.SDK_INT >= 30) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, hwRatio(zoom))
                else b.set(CaptureRequest.SCALER_CROP_REGION, crop(max(1f, hwBase * zoom)))
            }
            b.set(CaptureRequest.JPEG_QUALITY, 100.toByte())
            b.set(CaptureRequest.JPEG_ORIENTATION, 0)
            if (hqActive && hqMaxRes && Build.VERSION.SDK_INT >= 31) {
                // HQ: chụp ở độ phân giải tối đa của cảm biến (vd. 50MP); việc cắt 65:24 làm ở bước xử lý như thường
                val big = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE_MAXIMUM_RESOLUTION)
                b.set(CaptureRequest.SENSOR_PIXEL_MODE, CameraMetadata.SENSOR_PIXEL_MODE_MAXIMUM_RESOLUTION)
                if (big != null) {
                    b.set(CaptureRequest.SCALER_CROP_REGION, big)
                    val a = activeArray()
                    val k = big.width().toFloat() / a.width()
                    afRegions?.let { rs ->
                        val sc = rs.map {
                            val r = it.rect
                            MeteringRectangle(
                                Rect((r.left * k).toInt(), (r.top * k).toInt(), (r.right * k).toInt(), (r.bottom * k).toInt())
                                    .also { q -> q.intersect(big) }, it.meteringWeight
                            )
                        }.toTypedArray()
                        b.set(CaptureRequest.CONTROL_AF_REGIONS, sc)
                        b.set(CaptureRequest.CONTROL_AE_REGIONS, sc)
                    }
                }
            }
            // Ảnh thường: KHÔNG bật ZSL (khung lấy từ luồng xem trước bị ISP xử lý nhẹ -> mềm, dính nét chữ nhỏ).
            // Để máy dùng đường xử lý ảnh tĩnh đầy đủ.

            fun hq(key: CameraCharacteristics.Key<IntArray>, req: CaptureRequest.Key<Int>, mode: Int) {
                if (c.get(key)?.contains(mode) == true) b.set(req, mode)
            }
            /** Như hq nhưng ưu tiên `want`, không có thì dùng `fallback`. */
            fun hq2(key: CameraCharacteristics.Key<IntArray>, req: CaptureRequest.Key<Int>, want: Int, fallback: Int) {
                val av = c.get(key) ?: return
                if (av.contains(want)) b.set(req, want) else if (av.contains(fallback)) b.set(req, fallback)
            }
            val lightIsp = if (p.frames > 1) MF_LIGHT_ISP else appIsp
            if (p.frames > 1 || appIsp) {
                // HQ (LUNA) luôn dùng khung thô; ảnh thường dùng khung thô khi bật "app xử lí": giảm khử nhiễu/làm nét của máy để app tự ghép và xử lý, đồng thời không gom khung sau lúc bấm.
                hq2(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES,
                    CaptureRequest.NOISE_REDUCTION_MODE,
                    if (lightIsp) CameraMetadata.NOISE_REDUCTION_MODE_MINIMAL else CameraMetadata.NOISE_REDUCTION_MODE_FAST,
                    CameraMetadata.NOISE_REDUCTION_MODE_FAST)
                hq2(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES,
                    CaptureRequest.EDGE_MODE,
                    if (lightIsp) CameraMetadata.EDGE_MODE_OFF else CameraMetadata.EDGE_MODE_FAST,
                    CameraMetadata.EDGE_MODE_FAST)
            }
            if (p.trail) {
                // Vệt sáng: khoá phơi sáng + cân bằng trắng để 12 khung cùng độ sáng/màu, và cho AE được dùng thời gian phơi dài
                // (dải FPS thấp nhất ≥ 8) -> mỗi khung đã nhoè theo chuyển động, vệt liền mạch hơn.
                try { b.set(CaptureRequest.CONTROL_AE_LOCK, true) } catch (_: Exception) {}
                try { b.set(CaptureRequest.CONTROL_AWB_LOCK, true) } catch (_: Exception) {}
                try {
                    val rs = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                    val pr = rs?.filter { it.upper >= 8 }?.minWithOrNull(compareBy({ it.upper }, { it.lower }))
                    if (pr != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, pr)
                } catch (_: Exception) {}
            }
            // Ảnh thường khi TẮT "app xử lí": không đặt NOISE_REDUCTION_MODE / EDGE_MODE -> giữ mặc định của máy.
            hq(CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES,
                CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE, CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY)

            val cbk = object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(
                    session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult
                ) {
                    if (p.result == null) {
                        p.result = result
                        val pid = physicalId
                        if (pid != null && Build.VERSION.SDK_INT >= 29) {
                            p.physRes = try { result.physicalCameraResults[pid] } catch (_: Throwable) { null }
                        }
                    }
                    p.completed++
                    if (p.completed >= p.frames) {
                        tryFinish()
                        resumePreview()
                    }
                }

                override fun onCaptureFailed(
                    session: CameraCaptureSession, request: CaptureRequest,
                    failure: android.hardware.camera2.CaptureFailure
                ) {
                    idle()
                    try { pending?.raw?.close() } catch (_: Exception) {}
                    pending = null
                    resumePreview()
                    fail("Chụp thất bại")
                }
            }
            if (p.frames > 1) {
                val req = b.build()
                s.captureBurst(List(p.frames) { req }, cbk, handler)
            } else s.capture(b.build(), cbk, handler)
        } catch (e: Exception) {
            idle()
            pending = null
            fail("Không thể chụp: ${e.message}")
        }
    }

    // ---------------------------------------------------------------- LUNA Night (thiếu sáng)

    /** Chụp thiếu sáng `secs` giây: lấy nét/đo sáng như thường, rồi chụp liên tục tới hết giờ. */
    fun captureNight(rotation: Int, secs: Int, boost: Float, steady: Boolean) {
        nightReq = NightPlan(secs, boost, steady)
        capture(rotation)
    }

    /** Dừng sớm: không đặt thêm khung, ghép những khung đã có. */
    fun stopNight() {
        handler.post { pending?.let { if (it.night != null) it.stop = true } }
    }

    private fun pickMode(c: CameraCharacteristics, key: CameraCharacteristics.Key<IntArray>, want: Int, fallback: Int): Int? {
        val av = c.get(key) ?: return null
        return if (av.contains(want)) want else if (av.contains(fallback)) fallback else null
    }

    private fun doCaptureNight() {
        val d = device
        val s = session
        val jr = jpegReader
        val c = chars
        val p = pending
        val plan = p?.night
        if (d == null || s == null || jr == null || c == null || p == null || plan == null) { idle(); return }
        val g = gen
        try {
            p.session = LunaNight.Session(p.zoom, p.rotation)
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            b.addTarget(jr.surface)
            applyCommon(b)
            b.set(CaptureRequest.SCALER_CROP_REGION, activeArray())
            if (hwBase > 0f) {
                if (Build.VERSION.SDK_INT >= 30) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, hwRatio(zoom))
                else b.set(CaptureRequest.SCALER_CROP_REGION, crop(max(1f, hwBase * zoom)))
            }
            b.set(CaptureRequest.JPEG_QUALITY, NIGHT_JPEG_Q)
            b.set(CaptureRequest.JPEG_ORIENTATION, 0)
            // giữ nguyên điểm nét suốt lượt chụp (AF liên tục trong tối hay "săn" làm các khung lệch nét nhau)
            val afm = c.get(CameraCharacteristics.CONTROL_AF_AVAILABLE_MODES) ?: IntArray(0)
            if (!manualFocus() && afm.contains(CameraMetadata.CONTROL_AF_MODE_AUTO)) b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_AUTO)
            // khung thô vừa phải: khử nhiễu nhanh của máy (cắt đốm màu nặng), không làm nét; app tự ghép / khử nhiễu / làm nét
            pickMode(c, CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES,
                CameraMetadata.NOISE_REDUCTION_MODE_FAST, CameraMetadata.NOISE_REDUCTION_MODE_MINIMAL)?.let { b.set(CaptureRequest.NOISE_REDUCTION_MODE, it) }
            pickMode(c, CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES,
                CameraMetadata.EDGE_MODE_OFF, CameraMetadata.EDGE_MODE_FAST)?.let { b.set(CaptureRequest.EDGE_MODE, it) }
            pickMode(c, CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES,
                CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_HIGH_QUALITY, CameraMetadata.COLOR_CORRECTION_ABERRATION_MODE_FAST)?.let { b.set(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE, it) }
            try { b.set(CaptureRequest.CONTROL_AWB_LOCK, true) } catch (_: Exception) {}

            // --- kế hoạch phơi sáng mỗi khung
            val cp = caps()
            var tfNs: Long
            if (manualAe()) {
                // người dùng đã chỉnh tay tốc độ/ISO: giữ nguyên
                tfNs = b.get(CaptureRequest.SENSOR_EXPOSURE_TIME) ?: lastExposureNs
            } else if (cp.manualSensor) {
                // tích (thời gian x ISO) mà AE xem trước đang dùng, nhân hệ số cần thêm sáng. Nhoè trong từng khung KHÔNG sửa được
                // bằng ghép nhiều khung, nên: cầm tay -> khung rất ngắn (<= 1/30s), bù sáng bằng ISO + nhiều khung; máy vững
                // (chân máy) -> khung dài hơn (<= 0,3s), ISO thấp. Cảnh đã đủ sáng thì giữ khung ngắn như AE chọn (chỉ kéo dài ~3x).
                val prod = lastExposureNs.toDouble() * lastIso * plan.boost
                val cap = if (plan.steady) 300_000_000L else 33_000_000L
                val tfCap = min(cap, cp.shutterMax)
                val tfMin = max(cp.shutterMin, 5_000_000L)
                val wish = (lastExposureNs.toDouble() * plan.boost * 3.0).toLong()
                tfNs = max(tfMin, min(tfCap, wish))
                tfNs = min(tfNs, cp.shutterMax)
                val iso = (prod / tfNs).toInt().coerceIn(min(cp.isoMin, cp.isoMax), max(cp.isoMin, cp.isoMax))
                b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
                b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, tfNs)
                b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
                val maxFd = c.get(CameraCharacteristics.SENSOR_INFO_MAX_FRAME_DURATION) ?: Long.MAX_VALUE
                b.set(CaptureRequest.SENSOR_FRAME_DURATION, min(max(tfNs, 40_000_000L), maxFd))
            } else {
                // máy không cho app chỉnh tay: AE tự động nhưng khoá, dải FPS thấp nhất (cho phép phơi dài) + bù sáng
                try { b.set(CaptureRequest.CONTROL_AE_LOCK, true) } catch (_: Exception) {}
                var pr: android.util.Range<Int>? = null
                try {
                    pr = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                        ?.filter { it.upper >= 5 }?.minWithOrNull(compareBy({ it.upper }, { it.lower }))
                    if (pr != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, pr)
                } catch (_: Exception) {}
                tfNs = if (pr != null) 1_000_000_000L / pr.upper else 66_000_000L
                try {
                    val step = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
                    val rg = c.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
                    if (step > 0f && rg != null) {
                        val stops = Math.log(plan.boost.toDouble()) / Math.log(2.0)
                        val idx = Math.round(stops / step).toInt()
                        b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, (ev + idx).coerceIn(rg.lower, rg.upper))
                    }
                } catch (_: Exception) {}
            }
            val perChunk = (500_000_000L / max(tfNs, 1L)).toInt().coerceIn(2, 8)
            p.estTotal = ((plan.secs * 1_000_000_000L) / max(tfNs, 40_000_000L)).toInt().coerceIn(2, NIGHT_MAX_FRAMES)
            val est = p.estTotal
            val req = b.build()
            // chốt an toàn: nếu HAL kẹt thì vẫn kết thúc bằng những khung đã nhận
            handler.postDelayed({
                if (pending === p && g == gen && !p.nightDone) {
                    p.closed = true
                    p.scheduled = p.completed
                    p.failed = max(0, p.scheduled - p.got)
                    nightTryFinish(p)
                }
            }, plan.secs * 1000L + 8000L)
            // cầm tay: chờ 0,3s cho tay hết rung sau cú bấm rồi mới phơi (khung đầu là khung gốc dùng để căn chỉnh nên phải nét)
            val go = Runnable {
                if (pending === p && g == gen && !p.closed) {
                    p.t0 = SystemClock.elapsedRealtime()
                    main.post { cb.onNightStart(est) }
                    nightChunk(p, req, perChunk, g)
                }
            }
            if (plan.steady) go.run() else handler.postDelayed(go, 300)
        } catch (e: Exception) {
            try { p.session?.abort() } catch (_: Exception) {}
            idle()
            pending = null
            fail("Không thể chụp thiếu sáng: ${e.message}")
        }
    }

    /** Đặt một nhóm khung nữa (hoặc đóng lịch chụp nếu hết giờ / bị dừng). Nhóm sau được đặt khi nhóm trước sắp xong để cảm biến không nghỉ. */
    private fun nightChunk(p: Pending, req: CaptureRequest, chunk: Int, g: Int) {
        val s = session
        val plan = p.night
        if (s == null || plan == null || g != gen || pending !== p || p.closed) return
        val elapsed = SystemClock.elapsedRealtime() - p.t0
        if (p.stop || elapsed >= plan.secs * 1000L || p.scheduled >= NIGHT_MAX_FRAMES) {
            p.closed = true
            nightTryFinish(p)
            return
        }
        p.scheduled += chunk
        val cbk = object : CameraCaptureSession.CaptureCallback() {
            var doneInChunk = 0
            var nextQueued = false
            private fun step() {
                doneInChunk++
                if (!nextQueued && doneInChunk >= chunk - 1) { nextQueued = true; nightChunk(p, req, chunk, g) }
                nightTryFinish(p)
            }
            override fun onCaptureCompleted(session: CameraCaptureSession, request: CaptureRequest, result: TotalCaptureResult) {
                if (p.result == null) p.result = result
                p.completed++
                step()
            }
            override fun onCaptureFailed(session: CameraCaptureSession, request: CaptureRequest, failure: android.hardware.camera2.CaptureFailure) {
                p.completed++
                p.failed++
                step()
            }
        }
        try {
            s.captureBurst(List(chunk) { req }, cbk, handler)
        } catch (e: Exception) {
            p.scheduled -= chunk
            p.closed = true
            nightTryFinish(p)
        }
    }

    private fun nightTryFinish(p: Pending) {
        if (!p.closed || pending !== p || p.nightDone) return
        if (p.completed < p.scheduled) return
        if (p.got + p.failed < p.scheduled) return
        p.nightDone = true
        val res = p.result
        val jf = p.jpeg
        val ses = p.session
        if (res == null || jf == null || ses == null || p.got == 0) {
            try { ses?.abort() } catch (_: Exception) {}
            idle()
            pending = null
            resumePreview()
            fail("Không nhận được khung nào khi chụp thiếu sáng")
            return
        }
        pending = null
        idle()
        val l = lens!!
        val direct = physicalId == null && hwBase == 0f
        val meta = ShotMeta(
            exposureNs = res.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: 0L,
            iso = res.get(CaptureResult.SENSOR_SENSITIVITY) ?: 0,
            aperture = (if (direct) res.get(CaptureResult.LENS_APERTURE) else null) ?: l.aperture,
            focalMm = (if (direct) res.get(CaptureResult.LENS_FOCAL_LENGTH) else null) ?: l.focalMm,
            eq35 = l.eq35, zoom = p.zoom, rotation = p.rotation
        )
        resumePreview()
        val shot = ShotResult(jf, null, meta, emptyList(), false, false, ses)
        main.post { cb.onShot(shot) }
    }

    private fun resumePreview() {
        val d = device ?: return
        val s = session ?: return
        val ps = previewSurface ?: return
        try {
            val tb = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            tb.addTarget(ps)
            applyCommon(tb)
            applyZoom(tb)
            tb.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_CANCEL)
            tb.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CameraMetadata.CONTROL_AE_PRECAPTURE_TRIGGER_CANCEL)
            s.capture(tb.build(), null, handler)
            updatePreview()
        } catch (_: Exception) {}
    }

    private fun onJpeg(r: ImageReader) {
        val img = r.acquireNextImage() ?: return
        val p = pending
        try {
            if (p == null) return
            val buf = img.planes[0].buffer
            val f = File(ctx.cacheDir, "shot_${System.nanoTime()}.jpg")
            FileOutputStream(f).use { out ->
                val ch = out.channel
                while (buf.hasRemaining()) ch.write(buf)
            }
            if (p.night != null) {
                // LUNA Night: khung đi thẳng vào bộ ghép streaming (giải mã + căn chỉnh + cộng dồn ngay trong lúc còn phơi sáng)
                p.got++
                if (p.jpeg == null) p.jpeg = f
                p.session?.add(f)
                val gotNow = p.got
                val est = p.estTotal
                main.post { cb.onBurstFrame(gotNow, est) }
                nightTryFinish(p)
                return
            }
            val n = if (p.jpeg == null) { p.jpeg = f; 1 } else { p.extra.add(f); p.extra.size + 1 }
            if (p.frames > 1) main.post { cb.onBurstFrame(n, p.frames) }
        } finally {
            img.close()
        }
        tryFinish()
    }

    private fun onRaw(r: ImageReader) {
        val img = r.acquireNextImage() ?: return
        val p = pending
        if (p == null) { img.close(); return }
        if (p.rawHq) {
            // HQ RAW: ghi ngay khung RAW 16-bit ra tệp tạm (giải phóng bộ đệm ảnh), xử lý sau ở PhotoProcessor
            try {
                val f = File(ctx.cacheDir, "raw_${System.nanoTime()}.r16")
                writeRaw16(img, f)
                p.rawW = img.width
                p.rawH = img.height
                p.rawFiles.add(f)
            } catch (_: Throwable) {
                p.rawFail = true
            } finally {
                img.close()
            }
            tryFinish()
            return
        }
        p.raw = img
        tryFinish()
    }

    private fun writeRaw16(img: Image, f: File) {
        val pl = img.planes[0]
        val buf = pl.buffer
        val rs = pl.rowStride
        val w = img.width
        val h = img.height
        val row = ByteArray(w * 2)
        FileOutputStream(f).use { fo ->
            val bo = java.io.BufferedOutputStream(fo, 1 shl 20)
            for (y in 0 until h) {
                buf.position(y * rs)
                buf.get(row, 0, w * 2)
                bo.write(row)
            }
            bo.flush()
        }
    }

    private fun exifInt(rot: Int) = when (rot) { 90 -> 6; 180 -> 3; 270 -> 8; else -> 1 }

    private fun tryFinish() {
        val p = pending ?: return
        if (p.night != null) { nightTryFinish(p); return }
        val res = p.result ?: return
        val jf = p.jpeg ?: return
        if (p.completed < p.frames || p.extra.size < p.frames - 1) return
        if (p.rawWanted && p.raw == null) return
        if (p.rawHq && !p.rawFail && p.rawFiles.size < p.frames) return
        pending = null
        var rawIn: RawHq.Input? = null
        if (p.rawHq) {
            if (!p.rawFail && p.rawFiles.size >= 3 && p.rawW > 0) {
                var rm = try { p.physRes?.let { RawHq.metaFrom(chars!!, it) } } catch (_: Throwable) { null }
                if (rm == null) rm = try { RawHq.metaFrom(chars!!, res) } catch (_: Throwable) { null }
                if (rm != null) rawIn = RawHq.Input(p.rawFiles.toList(), p.rawW, p.rawH, rm)
            }
            if (rawIn == null) p.rawFiles.forEach { try { it.delete() } catch (_: Throwable) {} }
        }
        var dng: File? = null
        if (p.rawWanted) {
            try {
                val f = File(ctx.cacheDir, "shot_${System.nanoTime()}.dng")
                val dc = DngCreator(chars!!, res)
                dc.setOrientation(exifInt(p.rotation))
                FileOutputStream(f).use { out -> dc.writeImage(out, p.raw!!) }
                dc.close()
                dng = f
            } catch (_: Exception) {
                dng = null
            } finally {
                try { p.raw?.close() } catch (_: Exception) {}
            }
        }
        idle()
        val l = lens!!
        val direct = physicalId == null && hwBase == 0f
        val meta = ShotMeta(
            exposureNs = res.get(CaptureResult.SENSOR_EXPOSURE_TIME) ?: 0L,
            iso = res.get(CaptureResult.SENSOR_SENSITIVITY) ?: 0,
            aperture = (if (direct) res.get(CaptureResult.LENS_APERTURE) else null) ?: l.aperture,
            focalMm = (if (direct) res.get(CaptureResult.LENS_FOCAL_LENGTH) else null) ?: l.focalMm,
            eq35 = l.eq35, zoom = p.zoom, rotation = p.rotation
        )
        val shot = ShotResult(jf, dng, meta, p.extra.toList(), p.frames > 1, p.trail, null, rawIn)
        main.post { cb.onShot(shot) }
    }
}
