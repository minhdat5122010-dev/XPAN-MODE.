package com.xpanmode.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.util.Locale

/**
 * Bảng "Chỉnh sửa" thu gọn: thông số camera (EV, tốc độ, ISO, WB, lấy nét) và màu sắc
 * (tương phản, lạnh/ấm, lục lam/đỏ sậm, bão hoà, sắc nét). Mọi thay đổi áp dụng ngay.
 */
class EditPanel(ctx: Context) : FrameLayout(ctx) {
    var onCam: ((CamParams) -> Unit)? = null
    var onAdjust: ((Adjust) -> Unit)? = null
    var onSave: (() -> Unit)? = null
    var onReset: (() -> Unit)? = null
    var onClose: (() -> Unit)? = null

    private val dn = resources.displayMetrics.density
    private val col = LinearLayout(ctx)
    private var cam = CamParams()
    private var adj = Adjust()
    private var silent = false

    private var evMin = 0
    private var evMax = 0
    private var evStep = 0f
    private var shutters: List<Long> = emptyList()
    private var isos: List<Int> = emptyList()
    private var wbs: List<Int> = emptyList()
    private var manualSensor = false
    private var minFocus = 0f
    private val focusSteps = 20

    private class Row(val tv: TextView, val sb: SeekBar, val box: View)

    private lateinit var rEv: Row
    private lateinit var rS: Row
    private lateinit var rIso: Row
    private lateinit var rWb: Row
    private lateinit var rAf: Row
    private lateinit var rCon: Row
    private lateinit var rTemp: Row
    private lateinit var rTint: Row
    private lateinit var rSat: Row
    private lateinit var rSharp: Row
    private lateinit var note: TextView

    init {
        background = GradientDrawable().apply {
            setColor(0xEB121214.toInt())
            setStroke((1 * dn).toInt().coerceAtLeast(1), 0x33FFFFFF)
        }
        isClickable = true            // chặn chạm xuyên xuống khung ngắm
        val pad = (14 * dn).toInt()
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(col)
        addView(sv, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        // tiêu đề + nút
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(ctx)
        title.text = "CHỈNH SỬA"
        title.setTextColor(Color.WHITE)
        title.textSize = 14f
        title.typeface = Typeface.DEFAULT_BOLD
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        head.addView(smallBtn("Đặt lại") { onReset?.invoke() })
        head.addView(smallBtn("✕") { onClose?.invoke() })
        col.addView(head)

        val save = smallBtn("＋ Lưu thành bộ lọc") { onSave?.invoke() }
        (save as TextView).setTextColor(ORANGE)
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.topMargin = (8 * dn).toInt()
        save.gravity = Gravity.CENTER
        col.addView(save, slp)

        section("MÁY ẢNH")
        rEv = row("EV", 1) { p ->
            cam = cam.copy(ev = evMin + p)
            onCam?.invoke(cam)
        }
        rS = row("Tốc độ (S)", 1) { p ->
            cam = cam.copy(shutterNs = if (p == 0) 0L else shutters[p - 1])
            onCam?.invoke(cam)
            refreshText()
        }
        rIso = row("ISO", 1) { p ->
            cam = cam.copy(iso = if (p == 0) 0 else isos[p - 1])
            onCam?.invoke(cam)
            refreshText()
        }
        rWb = row("Cân bằng trắng (WB)", 1) { p ->
            cam = cam.copy(wb = if (p == 0) 1 else wbs[p - 1])
            onCam?.invoke(cam)
            refreshText()
        }
        rAf = row("Lấy nét (AF / MF)", focusSteps) { p ->
            cam = cam.copy(focus = if (p == 0) -1f else focusAt(p))
            onCam?.invoke(cam)
            refreshText()
        }
        note = TextView(ctx)
        note.setTextColor(0x99FFFFFF.toInt())
        note.textSize = 11f
        note.setPadding(0, (4 * dn).toInt(), 0, 0)
        col.addView(note)

        section("MÀU SẮC")
        rCon = row("Tương phản", 200) { p -> adj = adj.copy(contrast = p - 100); fireAdj() }
        rTemp = row("Lạnh ↔ Ấm", 200) { p -> adj = adj.copy(temp = p - 100); fireAdj() }
        rTint = row("Lục lam ↔ Đỏ sậm", 200) { p -> adj = adj.copy(tint = p - 100); fireAdj() }
        rSat = row("Bão hoà", 200) { p -> adj = adj.copy(sat = p - 100); fireAdj() }
        rSharp = row("Sắc nét (áp dụng khi chụp)", 100) { p -> adj = adj.copy(sharp = p); fireAdj() }
    }

    private fun fireAdj() {
        onAdjust?.invoke(adj)
        refreshText()
    }

    private fun smallBtn(text: String, click: () -> Unit): View {
        val t = TextView(context)
        t.text = text
        t.textSize = 12f
        t.setTextColor(Color.WHITE)
        t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding((10 * dn).toInt(), (6 * dn).toInt(), (10 * dn).toInt(), (6 * dn).toInt())
        t.background = GradientDrawable().apply {
            cornerRadius = 100f * dn
            setColor(0x22FFFFFF)
        }
        t.setOnClickListener { click() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.leftMargin = (6 * dn).toInt()
        t.layoutParams = lp
        return t
    }

    private fun section(text: String) {
        val t = TextView(context)
        t.text = text
        t.textSize = 11f
        t.letterSpacing = 0.15f
        t.setTextColor(ORANGE)
        t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding(0, (16 * dn).toInt(), 0, (2 * dn).toInt())
        col.addView(t)
    }

    private fun row(title: String, max: Int, onUser: (Int) -> Unit): Row {
        val box = LinearLayout(context)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, (6 * dn).toInt(), 0, 0)
        val line = LinearLayout(context)
        line.orientation = LinearLayout.HORIZONTAL
        val name = TextView(context)
        name.text = title
        name.textSize = 12f
        name.setTextColor(0xCCFFFFFF.toInt())
        val value = TextView(context)
        value.textSize = 12f
        value.setTextColor(Color.WHITE)
        value.typeface = Typeface.DEFAULT_BOLD
        value.gravity = Gravity.END
        line.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        line.addView(value)
        val sb = SeekBar(context)
        sb.max = max
        sb.progressTintList = ColorStateList.valueOf(ORANGE)
        sb.thumbTintList = ColorStateList.valueOf(ORANGE)
        sb.progressBackgroundTintList = ColorStateList.valueOf(0x55FFFFFF)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) { if (fromUser && !silent) onUser(p) }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        box.addView(line)
        box.addView(sb)
        col.addView(box)
        return Row(value, sb, box)
    }

    // ------------------------------------------------------------------ nhập trạng thái

    /** Gọi khi camera mở xong: cho biết dải giá trị camera hỗ trợ. */
    fun setCaps(c: CameraController.Caps, evMin: Int, evMax: Int, evStep: Float) {
        this.evMin = evMin; this.evMax = evMax; this.evStep = evStep
        manualSensor = c.manualSensor
        minFocus = c.minFocus
        val st = listOf(8000, 4000, 2000, 1000, 500, 250, 125, 60, 30, 15, 8, 4, 2)   // 1/x giây
        shutters = if (!c.manualSensor) emptyList() else st.map { 1_000_000_000L / it }
            .filter { it >= c.shutterMin && it <= c.shutterMax }
        isos = if (!c.manualSensor) emptyList() else listOf(50, 100, 200, 400, 800, 1600, 3200, 6400)
            .filter { it >= c.isoMin && it <= c.isoMax }
        // thứ tự từ lạnh -> ấm đảo lại: đèn dây tóc, huỳnh quang ấm, huỳnh quang, nắng, mây, bóng râm
        wbs = listOf(2, 4, 3, 5, 6, 8).filter { c.awbModes.contains(it) }
        rEv.sb.max = (evMax - evMin).coerceAtLeast(0)
        rS.sb.max = shutters.size
        rIso.sb.max = isos.size
        rWb.sb.max = wbs.size
        rAf.sb.max = if (minFocus > 0f) focusSteps else 0
        rEv.box.visibility = if (evMax > evMin) View.VISIBLE else View.GONE
        rS.box.visibility = if (shutters.isNotEmpty()) View.VISIBLE else View.GONE
        rIso.box.visibility = if (isos.isNotEmpty()) View.VISIBLE else View.GONE
        rWb.box.visibility = if (wbs.isNotEmpty()) View.VISIBLE else View.GONE
        rAf.box.visibility = if (minFocus > 0f) View.VISIBLE else View.GONE
        note.text = if (!manualSensor) "Ống kính này không cho app chỉnh tay tốc độ/ISO." else ""
        refresh()
    }

    fun setState(c: CamParams, a: Adjust) {
        cam = c
        adj = a
        refresh()
    }

    /** Cập nhật EV khi người dùng kéo thang EV ngoài màn hình. */
    fun setEv(v: Int) {
        cam = cam.copy(ev = v)
        refresh()
    }

    private fun focusAt(p: Int): Float = minFocus * (p - 1) / (focusSteps - 1).toFloat()

    private fun refresh() {
        silent = true
        rEv.sb.progress = (cam.ev - evMin).coerceIn(0, rEv.sb.max)
        rS.sb.progress = if (cam.shutterNs <= 0L) 0 else shutters.indexOfFirst { it == cam.shutterNs }.let { if (it < 0) 0 else it + 1 }
        rIso.sb.progress = if (cam.iso <= 0) 0 else isos.indexOf(cam.iso).let { if (it < 0) 0 else it + 1 }
        rWb.sb.progress = if (cam.wb == 1) 0 else wbs.indexOf(cam.wb).let { if (it < 0) 0 else it + 1 }
        rAf.sb.progress = if (cam.focus < 0f || minFocus <= 0f) 0 else
            (1 + Math.round(cam.focus / minFocus * (focusSteps - 1))).coerceIn(1, focusSteps)
        rCon.sb.progress = adj.contrast + 100
        rTemp.sb.progress = adj.temp + 100
        rTint.sb.progress = adj.tint + 100
        rSat.sb.progress = adj.sat + 100
        rSharp.sb.progress = adj.sharp
        silent = false
        refreshText()
    }

    private fun refreshText() {
        val ev = (cam.ev) * evStep
        rEv.tv.text = if (cam.ev == 0) "0.0" else String.format(Locale.US, "%+.1f", ev)
        val manual = (cam.shutterNs > 0L || cam.iso > 0) && manualSensor
        rEv.tv.alpha = if (manual) 0.4f else 1f
        rS.tv.text = if (cam.shutterNs <= 0L) "AUTO" else {
            val x = Math.round(1_000_000_000.0 / cam.shutterNs)
            if (x <= 1L) "1s" else "1/$x"
        }
        rIso.tv.text = if (cam.iso <= 0) "AUTO" else cam.iso.toString()
        rWb.tv.text = if (cam.wb == 1) "AUTO" else when (cam.wb) {
            2 -> "Đèn dây tóc"; 3 -> "Huỳnh quang"; 4 -> "Huỳnh quang ấm"; 5 -> "Nắng"
            6 -> "Trời mây"; 7 -> "Hoàng hôn"; 8 -> "Bóng râm"; else -> "AUTO"
        }
        rAf.tv.text = if (cam.focus < 0f) "AF" else if (cam.focus <= 0.01f) "MF ∞" else String.format(Locale.US, "MF %.2fm", 1f / cam.focus)
        rCon.tv.text = signed(adj.contrast)
        rTemp.tv.text = signed(adj.temp)
        rTint.tv.text = signed(adj.tint)
        rSat.tv.text = signed(adj.sat)
        rSharp.tv.text = adj.sharp.toString()
        if (manualSensor) note.text = if (manual) "S/ISO thủ công: EV tạm không có tác dụng." else ""
    }

    private fun signed(v: Int) = if (v == 0) "0" else String.format(Locale.US, "%+d", v)
}
