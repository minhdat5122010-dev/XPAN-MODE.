package com.xpanmode.app

import android.content.Context
import android.animation.ValueAnimator
import android.graphics.Bitmap
import android.view.HapticFeedbackConstants
import android.view.animation.DecelerateInterpolator
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs

/** Thanh trượt mảnh, bo tròn: rãnh xám, phần đã chọn màu cam (tính từ `origin`), núm trắng có chấm cam. */
class SlimSeek(ctx: Context) : View(ctx) {
    var max = 0
        set(v) { field = v.coerceAtLeast(0); if (progress > field) progress = field; invalidate() }
    var progress = 0
        set(v) { field = v.coerceIn(0, max); invalidate() }
    /** Giá trị mà phần cam bắt đầu tô từ đó (0 = từ mép trái; giữa = thanh hai chiều). */
    var origin = 0
        set(v) { field = v; invalidate() }
    var onUser: ((Int) -> Unit)? = null

    private val dn = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private val padX = 10f * dn
    private var ts = 1f
    private var tsAnim: ValueAnimator? = null

    private fun thumbTo(t: Float) {
        tsAnim?.cancel()
        tsAnim = ValueAnimator.ofFloat(ts, t).apply {
            duration = 160
            interpolator = OvershootInterpolator(2f)
            addUpdateListener { ts = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun xOf(v: Int): Float {
        val span = (width - 2f * padX).coerceAtLeast(1f)
        return padX + if (max <= 0) 0f else span * v / max
    }

    override fun onDraw(c: Canvas) {
        val cy = height / 2f
        val th = 4f * dn
        p.style = Paint.Style.FILL
        p.color = if (Theme.light) 0x26000000 else 0x33FFFFFF
        c.drawRoundRect(padX, cy - th / 2, width - padX, cy + th / 2, th, th, p)
        val x = xOf(progress)
        val x0 = xOf(origin.coerceIn(0, max))
        p.color = ORANGE
        val l = minOf(x, x0)
        val r = maxOf(x, x0)
        if (r - l > 0.5f) c.drawRoundRect(l, cy - th / 2, r, cy + th / 2, th, th, p)
        p.color = 0x55000000
        if (ts > 1.01f) {
            p.color = 0x33F47B20
            c.drawCircle(x, cy, 8.5f * dn * ts * 1.5f, p)      // quầng sáng khi đang chạm
        }
        p.color = 0x55000000
        c.drawCircle(x, cy + 1f * dn, 9f * dn * ts, p)
        p.color = Color.WHITE
        c.drawCircle(x, cy, 8.5f * dn * ts, p)
        p.color = ORANGE
        c.drawCircle(x, cy, 3.2f * dn * ts, p)
    }

    private fun setFromX(x: Float) {
        if (max <= 0) return
        val span = (width - 2f * padX).coerceAtLeast(1f)
        val v = Math.round(((x - padX) / span).coerceIn(0f, 1f) * max)
        if (v != progress) {
            progress = v
            if (max <= 30) performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            onUser?.invoke(v)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { downX = e.x; downY = e.y; dragging = false; thumbTo(1.3f) }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.x - downX
                val dy = e.y - downY
                if (!dragging && abs(dx) > slop && abs(dx) > abs(dy)) {
                    dragging = true
                    parent?.requestDisallowInterceptTouchEvent(true)
                }
                if (dragging) setFromX(e.x)
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging && abs(e.x - downX) <= slop && abs(e.y - downY) <= slop) setFromX(e.x)
                dragging = false
                thumbTo(1f)
            }
            MotionEvent.ACTION_CANCEL -> { dragging = false; thumbTo(1f) }
        }
        return true
    }
}

/**
 * Nền đục tối/sáng cho pop-up (không làm mờ ảnh nên không tốn CPU): dải màu + vài đường sáng mảnh.
 * `source` và `texFilter` giữ lại để không phải sửa chỗ gọi, hiện không dùng.
 */
class BlurBackdropView(ctx: Context) : View(ctx) {
    var source: CameraLayout? = null
    var texFilter: ColorFilter? = null

    private val dn = resources.displayMetrics.density
    private val radius = 22f * dn
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 1f * dn; color = 0x2EFFFFFF
    }
    private val clip = Path()

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        rebuild()
    }

    /** Dựng lại dải màu nền theo giao diện sáng/tối. */
    fun rebuild() {
        val w = width
        val h = height
        if (w <= 0 || h <= 0) return
        val light = Theme.light
        fill.shader = android.graphics.LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            if (light) intArrayOf(0xF7FBFBFC.toInt(), 0xF7F1F1F4.toInt(), 0xF9E7E7EB.toInt())
            else intArrayOf(0xF2191A1C.toInt(), 0xF2121214.toInt(), 0xF50B0B0D.toInt()),
            floatArrayOf(0f, 0.5f, 1f), android.graphics.Shader.TileMode.CLAMP
        )
        glow.shader = android.graphics.RadialGradient(
            w * 0.3f, 0f, w * 0.9f,
            intArrayOf(if (light) 0x30FFFFFF else 0x14FFFFFF, 0x00FFFFFF), null, android.graphics.Shader.TileMode.CLAMP
        )
        edge.color = if (light) 0x26000000 else 0x2EFFFFFF
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        clip.reset()
        clip.addRoundRect(0f, 0f, w, h, radius, radius, Path.Direction.CW)
        c.save()
        c.clipPath(clip)
        c.drawRect(0f, 0f, w, h, fill)
        c.drawRect(0f, 0f, w, h, glow)
        c.restore()
        val hw = edge.strokeWidth / 2f
        c.drawRoundRect(hw, hw, w - hw, h - hw, radius, radius, edge)
    }
}

/**
 * Pop-up "Chỉnh sửa" nổi ở bên phải: bo góc, nền kính mờ, thanh trượt mảnh. Thông số camera (EV, tốc độ, ISO, WB, lấy nét)
 * và màu sắc (tương phản, lạnh/ấm, lục lam/đỏ sậm, bão hoà, sắc nét). Mọi thay đổi áp dụng ngay.
 */
class EditPanel(ctx: Context) : FrameLayout(ctx) {
    var onCam: ((CamParams) -> Unit)? = null
    var onAdjust: ((Adjust) -> Unit)? = null
    var onSave: (() -> Unit)? = null
    var onReset: (() -> Unit)? = null
    var onClose: (() -> Unit)? = null

    private val dn = resources.displayMetrics.density
    private val col = LinearLayout(ctx)
    private var card: LinearLayout = col
    private val backdrop = BlurBackdropView(ctx)
    private var cam = CamParams()
    private var adj = Adjust()
    private var closing = false

    private var evMin = 0
    private var evMax = 0
    private var evStep = 0f
    private var shutters: List<Long> = emptyList()
    private var isos: List<Int> = emptyList()
    private var wbs: List<Int> = emptyList()
    private var manualSensor = false
    private var minFocus = 0f
    private val focusSteps = 20

    private class Row(val tv: TextView, val sb: SlimSeek, val box: View)

    // các thành phần cần đổi màu khi đổi giao diện sáng/tối
    private lateinit var titleView: TextView
    private val neutralPills = ArrayList<TextView>()
    private val nameViews = ArrayList<TextView>()
    private val valueViews = ArrayList<TextView>()
    private val cardBgs = ArrayList<GradientDrawable>()

    private lateinit var rEv: Row
    private lateinit var rS: Row
    private lateinit var rIso: Row
    private lateinit var rWb: Row
    private lateinit var rAf: Row
    private lateinit var rCon: Row
    private lateinit var rTemp: Row
    private lateinit var rTint: Row
    private lateinit var rSat: Row
    private lateinit var rSharp: Row
    private lateinit var note: TextView

    val isOpen: Boolean get() = visibility == View.VISIBLE && !closing

    init {
        isClickable = true            // chặn chạm xuyên xuống khung ngắm
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, 22f * dn)
            }
        }
        addView(backdrop, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        val pad = (14 * dn).toInt()
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, (18 * dn).toInt(), pad, (24 * dn).toInt())
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.overScrollMode = View.OVER_SCROLL_NEVER
        // mép trên/dưới mờ dần khi cuộn thay vì bị cắt cụt
        sv.isVerticalFadingEdgeEnabled = true
        sv.setFadingEdgeLength((40 * dn).toInt())
        sv.addView(col)
        addView(sv, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))

        // tiêu đề + nút
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(ctx)
        title.text = "Chỉnh sửa"
        title.setTextColor(Theme.ink)
        titleView = title
        title.textSize = 16f
        title.typeface = Typeface.DEFAULT_BOLD
        head.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val resetPill = pill("Đặt lại", Color.WHITE, 0x22FFFFFF, 0) { onReset?.invoke() }
        head.addView(resetPill)
        val x = pill("✕", Color.WHITE, 0x22FFFFFF, 0) { onClose?.invoke() }
        neutralPills.add(resetPill as TextView)
        neutralPills.add(x as TextView)
        x.gravity = Gravity.CENTER
        x.minWidth = (32 * dn).toInt()
        head.addView(x)
        col.addView(head)

        val save = pill("+  Lưu thành bộ lọc", ORANGE, 0x26F47B20, 0x99F47B20.toInt()) { onSave?.invoke() }
        (save as TextView).gravity = Gravity.CENTER
        val slp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.topMargin = (10 * dn).toInt()
        slp.leftMargin = 0
        col.addView(save, slp)

        section("MÁY ẢNH")
        rEv = row("EV", 1) { p ->
            cam = cam.copy(ev = evMin + p)
            onCam?.invoke(cam)
        }
        rS = row("Tốc độ (S)", 1) { p ->
            cam = cam.copy(shutterNs = if (p == 0) 0L else shutters[p - 1])
            onCam?.invoke(cam)
            refreshText()
        }
        rIso = row("ISO", 1) { p ->
            cam = cam.copy(iso = if (p == 0) 0 else isos[p - 1])
            onCam?.invoke(cam)
            refreshText()
        }
        rWb = row("Cân bằng trắng (WB)", 1) { p ->
            cam = cam.copy(wb = if (p == 0) 1 else wbs[p - 1])
            onCam?.invoke(cam)
            refreshText()
        }
        rAf = row("Lấy nét (AF / MF)", focusSteps) { p ->
            cam = cam.copy(focus = if (p == 0) -1f else focusAt(p))
            onCam?.invoke(cam)
            refreshText()
        }
        note = TextView(ctx)
        note.setTextColor(0x99FFFFFF.toInt())
        note.textSize = 11f
        note.setPadding(0, (6 * dn).toInt(), 0, (4 * dn).toInt())
        card.addView(note)

        section("MÀU SẮC")
        rCon = row("Tương phản", 200) { p -> adj = adj.copy(contrast = p - 100); fireAdj() }
        rTemp = row("Lạnh ↔ Ấm", 200) { p -> adj = adj.copy(temp = p - 100); fireAdj() }
        rTint = row("Lục lam ↔ Đỏ sậm", 200) { p -> adj = adj.copy(tint = p - 100); fireAdj() }
        rSat = row("Bão hoà", 200) { p -> adj = adj.copy(sat = p - 100); fireAdj() }
        rSharp = row("Sắc nét (áp dụng khi chụp)", 100) { p -> adj = adj.copy(sharp = p); fireAdj() }
        for (r in listOf(rCon, rTemp, rTint, rSat)) r.sb.origin = 100
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        pivotX = w.toFloat()          // "nổ" ra từ mép phải
        pivotY = h / 2f
    }

    /** Gắn nguồn hình để làm nền mờ (giao diện chính + khung ngắm). */
    fun bindBackdrop(src: CameraLayout) { backdrop.source = src }

    fun setBackdropFilter(f: ColorFilter?) { backdrop.texFilter = f }

    /** Đổi màu toàn bộ pop-up theo giao diện sáng/tối (Theme.light đã được đặt trước khi gọi). */
    fun applyTheme() {
        val light = Theme.light
        backdrop.rebuild()
        titleView.setTextColor(Theme.ink)
        for (t in neutralPills) {
            t.setTextColor(Theme.ink)
            (t.background as? GradientDrawable)?.setColor(if (light) 0x14000000 else 0x22FFFFFF)
        }
        for (t in nameViews) t.setTextColor(if (light) 0x991B1B1E.toInt() else 0xB3FFFFFF.toInt())
        for (t in valueViews) t.setTextColor(Theme.ink)
        for (g in cardBgs) g.setColor(if (light) 0x0F000000 else 0x14FFFFFF)
        note.setTextColor(if (light) 0x991B1B1E.toInt() else 0x99FFFFFF.toInt())
        invalidateAll(this)
    }

    private fun invalidateAll(v: View) {
        v.invalidate()
        if (v is ViewGroup) for (i in 0 until v.childCount) invalidateAll(v.getChildAt(i))
    }

    /** Hiện pop-up: nảy nhẹ từ phải vào. */
    fun open() {
        animate().cancel()
        closing = false
        visibility = View.VISIBLE
        alpha = 0f
        scaleX = 0.88f
        scaleY = 0.88f
        translationX = 36f * dn
        animate().alpha(1f).scaleX(1f).scaleY(1f).translationX(0f)
            .setDuration(280).setInterpolator(OvershootInterpolator(1.15f)).start()
        for (i in 0 until col.childCount) {
            val v = col.getChildAt(i)
            v.animate().cancel()
            v.alpha = 0f
            v.translationY = 16f * dn
            v.animate().alpha(1f).translationY(0f).setStartDelay(70L + i * 45L)
                .setDuration(280).setInterpolator(DecelerateInterpolator()).start()
        }
    }

    /** Ẩn pop-up: thu nhỏ và trượt về phải. */
    fun close() {
        if (visibility != View.VISIBLE || closing) return
        closing = true
        animate().cancel()
        animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).translationX(30f * dn)
            .setDuration(160).setInterpolator(AccelerateInterpolator())
            .withEndAction { visibility = View.GONE; closing = false }.start()
    }

    private fun fireAdj() {
        onAdjust?.invoke(adj)
        refreshText()
    }

    private fun pill(text: String, fg: Int, bg: Int, stroke: Int, click: () -> Unit): View {
        val t = TextView(context)
        t.text = text
        t.textSize = 12f
        t.setTextColor(fg)
        t.typeface = Typeface.DEFAULT_BOLD
        t.gravity = Gravity.CENTER
        t.setPadding((12 * dn).toInt(), (8 * dn).toInt(), (12 * dn).toInt(), (8 * dn).toInt())
        t.background = GradientDrawable().apply {
            cornerRadius = 100f * dn
            setColor(bg)
            if (stroke != 0) setStroke((1 * dn).toInt().coerceAtLeast(1), stroke)
        }
        t.setOnClickListener { click() }
        t.pressFeedback(0.92f)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.leftMargin = (6 * dn).toInt()
        t.layoutParams = lp
        return t
    }

    /** Nhãn nhóm + thẻ bo góc chứa các hàng bên dưới. */
    private fun section(text: String) {
        val t = TextView(context)
        t.text = text
        t.textSize = 11f
        t.letterSpacing = 0.15f
        t.setTextColor(ORANGE)
        t.typeface = Typeface.DEFAULT_BOLD
        t.setPadding((4 * dn).toInt(), (16 * dn).toInt(), 0, (6 * dn).toInt())
        col.addView(t)
        val c = LinearLayout(context)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding((12 * dn).toInt(), (6 * dn).toInt(), (12 * dn).toInt(), (6 * dn).toInt())
        val cardBg = GradientDrawable().apply {
            cornerRadius = 16f * dn
            setColor(if (Theme.light) 0x0F000000 else 0x14FFFFFF)
        }
        cardBgs.add(cardBg)
        c.background = cardBg
        col.addView(c, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        card = c
    }

    private fun row(title: String, max: Int, onUser: (Int) -> Unit): Row {
        val box = LinearLayout(context)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, (6 * dn).toInt(), 0, 0)
        val line = LinearLayout(context)
        line.orientation = LinearLayout.HORIZONTAL
        line.setPadding((2 * dn).toInt(), 0, (2 * dn).toInt(), 0)
        val name = TextView(context)
        name.text = title
        name.textSize = 12f
        name.setTextColor(0xB3FFFFFF.toInt())
        nameViews.add(name)
        val value = TextView(context)
        valueViews.add(value)
        value.textSize = 12f
        value.setTextColor(Color.WHITE)
        value.typeface = Typeface.DEFAULT_BOLD
        value.gravity = Gravity.END
        line.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        line.addView(value)
        val sb = SlimSeek(context)
        sb.max = max
        sb.onUser = onUser
        box.addView(line)
        box.addView(sb, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (30 * dn).toInt()))
        card.addView(box)
        return Row(value, sb, box)
    }

    // ------------------------------------------------------------------ nhập trạng thái

    /** Gọi khi camera mở xong: cho biết dải giá trị camera hỗ trợ. */
    fun setCaps(c: CameraController.Caps, evMin: Int, evMax: Int, evStep: Float) {
        this.evMin = evMin; this.evMax = evMax; this.evStep = evStep
        manualSensor = c.manualSensor
        minFocus = c.minFocus
        val st = listOf(8000, 4000, 2000, 1000, 500, 250, 125, 60, 30, 15, 8, 4, 2)   // 1/x giây
        shutters = if (!c.manualSensor) emptyList() else st.map { 1_000_000_000L / it }
            .filter { it >= c.shutterMin && it <= c.shutterMax }
        isos = if (!c.manualSensor) emptyList() else listOf(50, 100, 200, 400, 800, 1600, 3200, 6400)
            .filter { it >= c.isoMin && it <= c.isoMax }
        // thứ tự từ lạnh -> ấm đảo lại: đèn dây tóc, huỳnh quang ấm, huỳnh quang, nắng, mây, bóng râm
        wbs = listOf(2, 4, 3, 5, 6, 8).filter { c.awbModes.contains(it) }
        rEv.sb.max = (evMax - evMin).coerceAtLeast(0)
        rS.sb.max = shutters.size
        rIso.sb.max = isos.size
        rWb.sb.max = wbs.size
        rAf.sb.max = if (minFocus > 0f) focusSteps else 0
        rEv.sb.origin = (-evMin).coerceIn(0, rEv.sb.max)
        rEv.box.visibility = if (evMax > evMin) View.VISIBLE else View.GONE
        rS.box.visibility = if (shutters.isNotEmpty()) View.VISIBLE else View.GONE
        rIso.box.visibility = if (isos.isNotEmpty()) View.VISIBLE else View.GONE
        rWb.box.visibility = if (wbs.isNotEmpty()) View.VISIBLE else View.GONE
        rAf.box.visibility = if (minFocus > 0f) View.VISIBLE else View.GONE
        note.text = if (!manualSensor) "Ống kính này không cho app chỉnh tay tốc độ/ISO." else ""
        refresh()
    }

    fun setState(c: CamParams, a: Adjust) {
        cam = c
        adj = a
        refresh()
    }

    /** Cập nhật EV khi người dùng kéo thang EV ngoài màn hình. */
    fun setEv(v: Int) {
        cam = cam.copy(ev = v)
        refresh()
    }

    private fun focusAt(p: Int): Float = minFocus * (p - 1) / (focusSteps - 1).toFloat()

    private fun refresh() {
        rEv.sb.progress = (cam.ev - evMin).coerceIn(0, rEv.sb.max)
        rS.sb.progress = if (cam.shutterNs <= 0L) 0 else shutters.indexOfFirst { it == cam.shutterNs }.let { if (it < 0) 0 else it + 1 }
        rIso.sb.progress = if (cam.iso <= 0) 0 else isos.indexOf(cam.iso).let { if (it < 0) 0 else it + 1 }
        rWb.sb.progress = if (cam.wb == 1) 0 else wbs.indexOf(cam.wb).let { if (it < 0) 0 else it + 1 }
        rAf.sb.progress = if (cam.focus < 0f || minFocus <= 0f) 0 else
            (1 + Math.round(cam.focus / minFocus * (focusSteps - 1))).coerceIn(1, focusSteps)
        rCon.sb.progress = adj.contrast + 100
        rTemp.sb.progress = adj.temp + 100
        rTint.sb.progress = adj.tint + 100
        rSat.sb.progress = adj.sat + 100
        rSharp.sb.progress = adj.sharp
        refreshText()
    }

    private fun refreshText() {
        val ev = (cam.ev) * evStep
        rEv.tv.text = if (cam.ev == 0) "0.0" else String.format(Locale.US, "%+.1f", ev)
        val manual = (cam.shutterNs > 0L || cam.iso > 0) && manualSensor
        rEv.tv.alpha = if (manual) 0.4f else 1f
        rS.tv.text = if (cam.shutterNs <= 0L) "AUTO" else {
            val x = Math.round(1_000_000_000.0 / cam.shutterNs)
            if (x <= 1L) "1s" else "1/$x"
        }
        rIso.tv.text = if (cam.iso <= 0) "AUTO" else cam.iso.toString()
        rWb.tv.text = if (cam.wb == 1) "AUTO" else when (cam.wb) {
            2 -> "Đèn dây tóc"; 3 -> "Huỳnh quang"; 4 -> "Huỳnh quang ấm"; 5 -> "Nắng"
            6 -> "Trời mây"; 7 -> "Hoàng hôn"; 8 -> "Bóng râm"; else -> "AUTO"
        }
        rAf.tv.text = if (cam.focus < 0f) "AF" else if (cam.focus <= 0.01f) "MF ∞" else String.format(Locale.US, "MF %.2fm", 1f / cam.focus)
        rCon.tv.text = signed(adj.contrast)
        rTemp.tv.text = signed(adj.temp)
        rTint.tv.text = signed(adj.tint)
        rSat.tv.text = signed(adj.sat)
        rSharp.tv.text = adj.sharp.toString()
        if (manualSensor) note.text = if (manual) "S/ISO thủ công: EV tạm không có tác dụng." else ""
    }

    private fun signed(v: Int) = if (v == 0) "0" else String.format(Locale.US, "%+d", v)
}
