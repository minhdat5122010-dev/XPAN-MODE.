package com.xpanmode.app

import org.json.JSONArray
import org.json.JSONObject

/** Chỉnh màu (lệch so với bộ lọc đang chọn): tất cả -100..100, riêng sharp 0..100. */
data class Adjust(
    val contrast: Int = 0,
    val temp: Int = 0,     // lạnh (-) ↔ ấm (+)
    val tint: Int = 0,     // lục lam (-) ↔ đỏ sậm (+)
    val sat: Int = 0,
    val sharp: Int = 0
) {
    val isZero: Boolean get() = this == Adjust()

    fun toJson(): JSONObject = JSONObject().put("c", contrast).put("t", temp).put("n", tint).put("s", sat).put("h", sharp)

    companion object {
        fun fromJson(o: JSONObject?): Adjust =
            if (o == null) Adjust() else Adjust(o.optInt("c"), o.optInt("t"), o.optInt("n"), o.optInt("s"), o.optInt("h"))
    }
}

/** Thông số camera. shutterNs/iso = 0 là tự động; wb = hằng CONTROL_AWB_MODE_* (1 = tự động); focus < 0 là lấy nét tự động. */
data class CamParams(
    val ev: Int = 0,
    val shutterNs: Long = 0L,
    val iso: Int = 0,
    val wb: Int = 1,
    val focus: Float = -1f      // đơn vị diop (0 = vô cực)
) {
    fun toJson(): JSONObject =
        JSONObject().put("ev", ev).put("s", shutterNs).put("iso", iso).put("wb", wb).put("f", focus.toDouble())

    companion object {
        fun fromJson(o: JSONObject?): CamParams =
            if (o == null) CamParams()
            else CamParams(o.optInt("ev"), o.optLong("s"), o.optInt("iso"), o.optInt("wb", 1), o.optDouble("f", -1.0).toFloat())
    }
}

/** Bộ lọc do người dùng tự lưu: gồm tông màu + thông số camera tại thời điểm lưu. */
data class Preset(val id: String, val name: String, val look: XpanFilter, val cam: CamParams) {
    fun toJson(): JSONObject = JSONObject().put("id", id).put("name", name)
        .put("look", look.toJson()).put("cam", cam.toJson())

    companion object {
        fun fromJson(o: JSONObject): Preset {
            val name = o.optString("name", "Bộ lọc")
            return Preset(o.optString("id", name), name, XpanFilter.fromJson(o.getJSONObject("look"), name), CamParams.fromJson(o.optJSONObject("cam")))
        }

        fun listToJson(l: List<Preset>): String = JSONArray().also { a -> l.forEach { a.put(it.toJson()) } }.toString()

        fun listFromJson(s: String?): MutableList<Preset> {
            val out = ArrayList<Preset>()
            if (s.isNullOrBlank()) return out
            try {
                val a = JSONArray(s)
                for (i in 0 until a.length()) try { out.add(fromJson(a.getJSONObject(i))) } catch (_: Exception) {}
            } catch (_: Exception) {}
            return out
        }
    }
}
