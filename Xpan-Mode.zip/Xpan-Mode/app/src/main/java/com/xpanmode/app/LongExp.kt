package com.xpanmode.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Matrix
import android.graphics.Rect
import java.io.File
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.stream.IntStream
import kotlin.math.max
import kotlin.math.min

/**
 * Phơi sáng lâu (vệt sáng): chụp liên tục, mỗi khung vừa chụp xong được cộng dồn ngay (streaming, không giữ khung trong RAM).
 * Với mỗi điểm ảnh giữ hai thứ: TỔNG (để lấy trung bình) và GIÁ TRỊ SÁNG NHẤT. Ảnh cuối = trung bình (nền tĩnh sạch, ít nhiễu),
 * nhưng chỗ nào có nguồn sáng chạy qua (sáng nhất vượt hẳn trung bình) thì trộn dần sang giá trị sáng nhất -> vệt sáng đầy độ sáng
 * mà nền không bị "nhiễu sáng" như kiểu xếp chồng Lighten thuần. Không căn chỉnh khung: cần chân máy / để máy yên.
 */
object LongExp {
    private const val MAX_PX = 9_000_000L
    private const val MAX_INFLIGHT = 4
    private const val MAX_USED = 400
    /** Ngưỡng (thang 0..255) chênh lệch giữa sáng nhất và trung bình để bắt đầu / hết trộn sang vệt sáng. */
    private const val T0 = 24f
    private const val T1 = 80f

    private fun sstep(a: Float, b: Float, x: Float): Float {
        val t = ((x - a) / (b - a)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    class Session(private val zoom: Float, private val rotation: Int) {
        private val pool = Executors.newSingleThreadExecutor()
        private val inFlight = AtomicInteger(0)
        private val accepted = AtomicInteger(0)
        private val finished = AtomicInteger(0)
        private val pendingFiles = ConcurrentLinkedQueue<File>()
        @Volatile private var aborted = false
        @Volatile private var failure: Throwable? = null

        /** Số khung đã cộng dồn / số khung bỏ vì xử lí không kịp. */
        @Volatile var used = 0
            private set
        @Volatile var dropped = 0
            private set

        private var region: Rect? = null
        private var sample = 1
        private var w = 0
        private var h = 0
        private var sr: IntArray? = null
        private var sg: IntArray? = null
        private var sb: IntArray? = null
        private var mr: ByteArray? = null
        private var mg: ByteArray? = null
        private var mb: ByteArray? = null

        fun add(f: File) {
            if (aborted) { f.delete(); return }
            val n = accepted.get()
            if (n > 0 && (inFlight.get() >= MAX_INFLIGHT || n >= MAX_USED)) {
                f.delete()
                dropped++
                return
            }
            val idx = accepted.getAndIncrement()
            inFlight.incrementAndGet()
            pendingFiles.add(f)
            try {
                pool.execute {
                    try {
                        if (idx == 0) setup(f) else accumulate(f)
                    } catch (t: Throwable) {
                        if (idx == 0) failure = t
                    } finally {
                        pendingFiles.remove(f)
                        f.delete()
                        inFlight.decrementAndGet()
                        finished.incrementAndGet()
                    }
                }
            } catch (t: Throwable) {
                pendingFiles.remove(f)
                f.delete()
                inFlight.decrementAndGet()
                finished.incrementAndGet()
            }
        }

        fun abort() {
            aborted = true
            pool.shutdownNow()
            for (f in pendingFiles) f.delete()
            pendingFiles.clear()
            sr = null; sg = null; sb = null; mr = null; mg = null; mb = null
        }

        private fun decode(path: String, rg: Rect): Pair<IntArray, IntArray>? {
            @Suppress("DEPRECATION")
            val dec = BitmapRegionDecoder.newInstance(path, false) ?: return null
            try {
                val o = BitmapFactory.Options().apply {
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                    inSampleSize = sample
                }
                val b = dec.decodeRegion(rg, o) ?: return null
                val bw = b.width
                val bh = b.height
                val px = IntArray(bw * bh)
                b.getPixels(px, 0, bw, 0, 0, bw, bh)
                b.recycle()
                return Pair(intArrayOf(bw, bh), px)
            } finally {
                dec.recycle()
            }
        }

        private fun setup(f: File) {
            @Suppress("DEPRECATION")
            val dec = BitmapRegionDecoder.newInstance(f.absolutePath, false)
                ?: throw IllegalStateException("Không đọc được khung đầu")
            val bw = dec.width
            val bh = dec.height
            dec.recycle()
            // vùng cắt 65:24 (+ zoom số): cùng công thức với PhotoProcessor.process
            val z = zoom.coerceAtLeast(1f)
            // dải 65:24 luôn nằm theo cạnh dài cảm biến (đúng khung ngắm); ảnh dọc chỉ khác góc xoay EXIF
            val aspect = Body.ratio
            var cw = bw / z
            var ch = cw / aspect
            if (ch > bh / z) { ch = bh / z; cw = ch * aspect }
            val rawPx = cw.toLong() * ch.toLong()
            sample = if (rawPx <= MAX_PX) 1 else if (rawPx / 4 <= MAX_PX) 2 else 4
            val al = 8 * sample
            val cwi = (cw.toInt() / al) * al
            val chi = (ch.toInt() / al) * al
            val left = ((bw - cwi) / 2) / 2 * 2
            val top = ((bh - chi) / 2) / 2 * 2
            val rg = Rect(left, top, left + cwi, top + chi)
            val d = decode(f.absolutePath, rg) ?: throw IllegalStateException("decodeRegion trả về null")
            w = d.first[0]
            h = d.first[1]
            region = rg
            val n = w * h
            val ar = IntArray(n)
            val ag = IntArray(n)
            val ab = IntArray(n)
            val br = ByteArray(n)
            val bg = ByteArray(n)
            val bb = ByteArray(n)
            val px = d.second
            for (i in 0 until n) {
                val p = px[i]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                ar[i] = r; ag[i] = g; ab[i] = b
                br[i] = r.toByte(); bg[i] = g.toByte(); bb[i] = b.toByte()
            }
            sr = ar; sg = ag; sb = ab; mr = br; mg = bg; mb = bb
            used = 1
        }

        private fun accumulate(f: File) {
            if (aborted) return
            val rg = region ?: return
            val ar = sr ?: return
            val ag = sg ?: return
            val ab = sb ?: return
            val br = mr ?: return
            val bg = mg ?: return
            val bb = mb ?: return
            val d = decode(f.absolutePath, rg) ?: return
            if (d.first[0] != w || d.first[1] != h) return
            val px = d.second
            val n = w * h
            for (i in 0 until n) {
                val p = px[i]
                val r = (p shr 16) and 255
                val g = (p shr 8) and 255
                val b = p and 255
                ar[i] += r; ag[i] += g; ab[i] += b
                if (r > (br[i].toInt() and 255)) br[i] = r.toByte()
                if (g > (bg[i].toInt() and 255)) bg[i] = g.toByte()
                if (b > (bb[i].toInt() and 255)) bb[i] = b.toByte()
            }
            used++
        }

        /** Màu một điểm ảnh từ tổng (chia cho `cnt`) và giá trị sáng nhất: trung bình, trộn sang sáng nhất ở chỗ có vệt sáng. */
        private fun blend(i: Int, cnt: Int, ar: IntArray, ag: IntArray, ab: IntArray, br: ByteArray, bg: ByteArray, bb: ByteArray): Int {
            val inv = 1f / cnt
            val r0 = ar[i] * inv
            val g0 = ag[i] * inv
            val b0 = ab[i] * inv
            val r1 = (br[i].toInt() and 255).toFloat()
            val g1 = (bg[i].toInt() and 255).toFloat()
            val b1 = (bb[i].toInt() and 255).toFloat()
            val l0 = 0.299f * r0 + 0.587f * g0 + 0.114f * b0
            val l1 = 0.299f * r1 + 0.587f * g1 + 0.114f * b1
            val k = sstep(T0, T1, l1 - l0)
            val r = (r0 + k * (r1 - r0) + 0.5f).toInt().coerceIn(0, 255)
            val g = (g0 + k * (g1 - g0) + 0.5f).toInt().coerceIn(0, 255)
            val b = (b0 + k * (b1 - b0) + 0.5f).toInt().coerceIn(0, 255)
            return -0x1000000 or (r shl 16) or (g shl 8) or b
        }

        /** Ảnh xem trước cộng dồn hiện tại (cạnh dài ≤ maxEdge, đã xoay đúng chiều cầm máy), hoặc null nếu chưa có khung. */
        fun preview(maxEdge: Int): Bitmap? {
            val ar = sr ?: return null
            val ag = sg ?: return null
            val ab = sb ?: return null
            val br = mr ?: return null
            val bg = mg ?: return null
            val bb = mb ?: return null
            val cnt = max(used, 1)
            val ww = w
            val hh = h
            if (ww <= 0 || hh <= 0) return null
            val step = max(1, max(ww, hh) / maxEdge)
            val pw = ww / step
            val ph = hh / step
            val out = IntArray(pw * ph)
            for (y in 0 until ph) {
                val row = y * step * ww
                for (x in 0 until pw) out[y * pw + x] = blend(row + x * step, cnt, ar, ag, ab, br, bg, bb)
            }
            val bmp = Bitmap.createBitmap(pw, ph, Bitmap.Config.ARGB_8888)
            bmp.setPixels(out, 0, pw, 0, 0, pw, ph)
            if (rotation == 0) return bmp
            val m = Matrix()
            m.postRotate(rotation.toFloat())
            val r = Bitmap.createBitmap(bmp, 0, 0, pw, ph, m, true)
            if (r !== bmp) bmp.recycle()
            return r
        }

        /** Đợi các khung còn dở, ghép ảnh cuối (cùng kích thước vùng cắt), chạy bộ lọc màu `proc`. */
        fun finish(progress: ((Int) -> Unit)?, proc: (IntArray, Int, Int) -> Unit): Bitmap {
            pool.shutdown()
            while (!pool.awaitTermination(120, TimeUnit.MILLISECONDS)) {
                progress?.invoke(60 * finished.get() / max(accepted.get(), 1))
            }
            progress?.invoke(60)
            val fl = failure
            if (fl != null) throw fl
            val ar = sr; val ag = sg; val ab = sb; val br = mr; val bg = mg; val bb = mb
            if (aborted || used < 1 || ar == null || ag == null || ab == null || br == null || bg == null || bb == null)
                throw IllegalStateException("Không có khung nào để ghép")
            val n = w * h
            val cnt = used
            val out = IntArray(n)
            val rows = h
            IntStream.range(0, rows).parallel().forEach { y ->
                val row = y * w
                for (x in 0 until w) out[row + x] = blend(row + x, cnt, ar, ag, ab, br, bg, bb)
            }
            progress?.invoke(85)
            val cores = Runtime.getRuntime().availableProcessors().coerceIn(1, MultiFrame.coreCap)
            val chunk = (n + cores - 1) / cores
            IntStream.range(0, cores).parallel().forEach { t ->
                val from = t * chunk
                val to = min(n, from + chunk)
                if (from < to) proc(out, from, to)
            }
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.setPixels(out, 0, w, 0, 0, w, h)
            sr = null; sg = null; sb = null; mr = null; mg = null; mb = null
            progress?.invoke(95)
            return bmp
        }
    }
}
