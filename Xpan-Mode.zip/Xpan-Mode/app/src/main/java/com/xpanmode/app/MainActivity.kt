package com.xpanmode.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.*
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ImageReader
import android.media.MediaActionSound
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Size
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executor
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

const val BRAND = "HASSELBLAD"          // chữ trên thẻ ảnh; đổi tuỳ ý

class MainActivity : Activity() {

    companion object {
        const val RATIO = 65f / 24f       // tỉ lệ XPan
        const val ORANGE = 0xFFF47A20.toInt()
        const val REQ_CAM = 11
    }

    private lateinit var cm: CameraManager
    private lateinit var prefs: SharedPreferences
    private val camThread = HandlerThread("xpan-cam").also { it.start() }
    private val bg = Handler(camThread.looper)
    private val ui = Handler(Looper.getMainLooper())
    private val exec = Executor { bg.post(it) }
    private val sound = MediaActionSound()

    // views
    private lateinit var root: FrameLayout
    private lateinit var tv: TextureView
    private lateinit var veil: View
    private lateinit var vf: ViewfinderView
    private lateinit var shutter: ShutterView
    private lateinit var thumb: ImageView
    private lateinit var modeBtn: TextView
    private lateinit var gearBtn: TextView
    private lateinit var infoBtn: TextView
    private lateinit var filterBtn: TextView
    private lateinit var logo: TextView
    private lateinit var hint: TextView
    private lateinit var card: ImageView
    private val lensBtns = ArrayList<TextView>()

    // camera state
    private var lenses: List<Lens> = emptyList()
    private var notes: List<String> = emptyList()
    private var curIdx = -1
    private var gen = 0
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var previewSurface: Surface? = null
    private var previewReq: CaptureRequest.Builder? = null
    private var chars: CameraCharacteristics? = null
    private var previewSize = Size(1920, 1080)
    private var jpegSizes: List<Size> = emptyList()
    private var sizeTry = 0
    private var zoomNow = 1f
    private var hasAf = false
    private var evIdx = 0
    private var evMin = 0
    private var evMax = 0
    private var evStep = 1f / 3f
    private var evAccum = 0f
    @Volatile private var afState: Int? = null
    @Volatile private var aeState: Int? = null
    @Volatile private var capturing = false
    private var txs = 1f
    private var tys = 1f

    // ui state
    private var classic = false
    private var filterIdx = 0
    private var lastUri: Uri? = null
    private val fr = RectF()
    private var laidKey = ""

    private fun dp(v: Float) = v * resources.displayMetrics.density
    private fun dpi(v: Float) = dp(v).toInt()

    // ================================================================ vòng đời

    override fun onCreate(b: android.os.Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setDecorFitsSystemWindows(false)
        cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        prefs = getSharedPreferences("xpan", MODE_PRIVATE)
        classic = prefs.getBoolean("classic", false)
        filterIdx = prefs.getInt("filter", 0).coerceIn(0, Filters.list.size - 1)
        buildUi()
        lastUri = queryLastUri()
        loadThumb()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.insetsController?.let {
            it.hide(WindowInsets.Type.systemBars())
            it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
    }

    override fun onResume() {
        super.onResume()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), REQ_CAM)
        } else initCamera()
    }

    override fun onConfigurationChanged(c: android.content.res.Configuration) {
        super.onConfigurationChanged(c)
        tv.post { applyPreviewTransform() }
    }

    override fun onPause() {
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() {
        camThread.quitSafely()
        super.onDestroy()
    }

    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) {
        if (rc == REQ_CAM && r.isNotEmpty() && r[0] == PackageManager.PERMISSION_GRANTED) initCamera()
        else Toast.makeText(this, "Cần cấp quyền Camera để chụp ảnh", Toast.LENGTH_LONG).show()
    }

    private fun initCamera() {
        if (lenses.isEmpty()) {
            bg.post {
                val r = LensScanner.scan(cm)
                ui.post {
                    lenses = r.lenses; notes = r.notes
                    if (lenses.isEmpty()) {
                        Toast.makeText(this, "Không tìm thấy camera sau", Toast.LENGTH_LONG).show(); return@post
                    }
                    val saved = prefs.getFloat("lensEq", 0f)
                    curIdx = lenses.indices.minByOrNull { abs(lenses[it].eqMm - (if (saved > 0) saved else 24f)) } ?: 0
                    buildLensButtons()
                    laidKey = ""; relayout()
                    startCamera()
                }
            }
        } else startCamera()
    }

    private fun startCamera() {
        if (lenses.isEmpty() || curIdx < 0 || !tv.isAvailable) return
        openLens(lenses[curIdx])
    }

    // ================================================================ giao diện

    private fun buildUi() {
        root = FrameLayout(this)
        tv = TextureView(this)
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: android.graphics.SurfaceTexture, w: Int, h: Int) { startCamera() }
            override fun onSurfaceTextureSizeChanged(s: android.graphics.SurfaceTexture, w: Int, h: Int) { applyPreviewTransform() }
            override fun onSurfaceTextureDestroyed(s: android.graphics.SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: android.graphics.SurfaceTexture) {}
        }
        veil = View(this).apply { setBackgroundColor(0xFF8C8C8C.toInt()); alpha = 0f; visibility = View.GONE }
        vf = ViewfinderView(this).apply {
            onTap = { u, v -> focusAt(u, v) }
            onEvDelta = { dy -> changeEv(dy) }
        }
        shutter = ShutterView(this).apply { setOnClickListener { takePicture() } }
        thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(0xFF2A2A2A.toInt())
            setOnClickListener { lastUri?.let { u -> startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "image/jpeg").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } }
        }
        modeBtn = pill("").apply { setOnClickListener { toggleMode() } }
        gearBtn = glyph("⚙", 20f).apply { setOnClickListener { showSettings() } }
        infoBtn = glyph("ⓘ", 20f).apply { setOnClickListener { showLensInfo() } }
        filterBtn = TextView(this).apply {
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 12f
            setOnClickListener { setFilter((filterIdx + 1) % Filters.list.size, true) }
        }
        logo = TextView(this).apply {
            text = BRAND; gravity = Gravity.CENTER; setTextColor(0xFFD5D5D5.toInt())
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC); textSize = 17f; letterSpacing = 0.32f
            background = GradientDrawable().apply { setColor(0xFF2A2A2C.toInt()); cornerRadius = dp(4f) }
        }
        hint = TextView(this).apply {
            gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 15f; alpha = 0f
            background = GradientDrawable().apply { setColor(0x99000000.toInt()); cornerRadius = dp(14f) }
            setPadding(dpi(14f), dpi(6f), dpi(14f), dpi(6f))
        }
        card = ImageView(this).apply {
            setBackgroundColor(Color.WHITE); scaleType = ImageView.ScaleType.FIT_CENTER; visibility = View.GONE
            setOnClickListener { visibility = View.GONE }
        }

        listOf<View>(tv, veil, vf, logo, modeBtn, gearBtn, infoBtn, filterBtn, thumb, shutter, hint, card).forEach { root.addView(it) }
        root.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> relayout() }
        setContentView(root)
        applyStyle()
        setFilter(filterIdx, false)
    }

    private fun pill(t: String) = TextView(this).apply {
        text = t; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = 13f
        background = GradientDrawable().apply { setColor(0x66000000); cornerRadius = dp(16f); setStroke(dpi(1f), 0x88FFFFFF.toInt()) }
    }

    private fun glyph(t: String, size: Float) = TextView(this).apply {
        text = t; gravity = Gravity.CENTER; setTextColor(Color.WHITE); textSize = size
    }

    private fun View.place(x: Float, y: Float, w: Int, h: Int) {
        layoutParams = FrameLayout.LayoutParams(w, h).also { it.leftMargin = x.toInt(); it.topMargin = y.toInt() }
    }

    private fun buildLensButtons() {
        lensBtns.forEach { root.removeView(it) }
        lensBtns.clear()
        lenses.forEachIndexed { i, _ ->
            val t = TextView(this).apply { gravity = Gravity.CENTER; setOnClickListener { selectLens(i) } }
            lensBtns += t
            root.addView(t, root.indexOfChild(hint))
        }
        refreshLensButtons()
    }

    private fun mainRef(): Float =
        lenses.minByOrNull { abs(it.eqMm - 24f) }?.eqMm ?: 24f

    private fun refreshLensButtons() {
        val ref = mainRef()
        lensBtns.forEachIndexed { i, t ->
            val l = lenses[i]
            val sel = i == curIdx
            if (classic) {
                val r = l.eqMm / ref
                val s = if (abs(r - r.roundToInt()) < 0.15f && r >= 0.95f) "${r.roundToInt()}" else String.format(Locale.US, "%.1f", r).replace('.', ',')
                t.text = if (sel) "$s×" else s
                t.textSize = if (sel) 16f else 15f
                t.background = null
            } else {
                t.text = if (sel) "${l.eqMm.roundToInt()}\nmm" else "${l.eqMm.roundToInt()}"
                t.textSize = if (sel) 11f else 13f
                t.setLineSpacing(0f, 0.8f)
                t.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (sel) 0xB3000000.toInt() else 0x80000000.toInt()) }
            }
            t.setTextColor(if (sel) ORANGE else Color.WHITE)
        }
    }

    private fun applyStyle() {
        root.setBackgroundColor(if (classic) 0xFF1B1B1D.toInt() else Color.BLACK)
        vf.classic = classic
        shutter.classic = classic
        logo.visibility = if (classic) View.VISIBLE else View.GONE
        infoBtn.visibility = if (classic) View.VISIBLE else View.GONE
        modeBtn.text = if (classic) "⇄  Classic" else "⇄  Orange"
        if (classic) {
            filterBtn.text = Filters.list[filterIdx].short
            filterBtn.background = GradientDrawable().apply {
                setColor(0xFF101010.toInt()); cornerRadius = dp(6f)
                setStroke(dpi(2f), 0xFFE08A2C.toInt())
            }
            thumb.background = GradientDrawable().apply { setColor(0xFF2A2A2A.toInt()); setStroke(dpi(1.5f), 0xFF777777.toInt()) }
        } else {
            filterBtn.text = "▤"
            filterBtn.textSize = 18f
            filterBtn.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0x99000000.toInt()) }
            thumb.background = GradientDrawable().apply { setColor(0xFF2A2A2A.toInt()); cornerRadius = dp(6f) }
        }
        if (classic) filterBtn.textSize = 12f
        thumb.clipToOutline = true
        refreshLensButtons()
    }

    private fun toggleMode() {
        classic = !classic
        prefs.edit().putBoolean("classic", classic).apply()
        applyStyle()
        laidKey = ""; relayout()
    }

    private fun relayout() {
        val W = root.width; val H = root.height
        if (W == 0 || H == 0) return
        val key = "$W,$H,$classic,${lensBtns.size}"
        if (key == laidKey) return
        laidKey = key
        val w = W.toFloat(); val h = H.toFloat()

        val fw: Float; val fx: Float; val fy: Float
        if (classic) { fw = min(w * 0.80f, h * 0.60f * RATIO); fx = w * 0.012f; fy = h * 0.24f }
        else { fw = min(w * 0.89f, h * 0.76f * RATIO); fx = (w - fw) / 2f; fy = h * 0.14f }
        val fh = fw / RATIO
        fr.set(fx, fy, fx + fw, fy + fh)
        for (v in listOf<View>(tv, veil, vf)) v.place(fx, fy, fw.toInt(), fh.toInt())

        modeBtn.place(dp(14f), dp(12f), dpi(104f), dpi(32f))
        gearBtn.place(dp(126f), dp(12f), dpi(32f), dpi(32f))
        logo.place(w / 2f - dp(110f), dp(10f), dpi(220f), dpi(36f))
        infoBtn.place(dp(14f), h - dp(56f), dpi(40f), dpi(40f))
        hint.place(fx + fw / 2f - dp(90f), fy + dp(14f), dpi(180f), dpi(32f))
        card.place(0f, 0f, W, H)

        if (classic) {
            val cx = (fx + fw + w) / 2f
            filterBtn.place(cx - dp(32f), fy, dpi(64f), dpi(40f))
            val sh = dpi(84f); shutter.place(cx - sh / 2f, fy + fh / 2f - sh / 2f, sh, sh)
            val ts = dpi(54f); thumb.place(cx - ts / 2f, fy + fh - ts, ts, ts)
            val n = lensBtns.size; val bh = dp(38f)
            val top = fy + fh / 2f - n * bh / 2f
            lensBtns.forEachIndexed { i, t -> t.place(fx + fw - dp(58f), top + i * bh, dpi(48f), bh.toInt()) }
        } else {
            filterBtn.place(fx + fw - dp(56f), fy + dp(10f), dpi(42f), dpi(42f))
            val sh = dpi(74f); shutter.place(fx + fw - dp(64f) - sh / 2f, fy + fh * 0.50f - sh / 2f, sh, sh)
            val ts = dpi(50f); thumb.place(fx + fw - dp(60f) - ts / 2f, fy + fh - dp(66f), ts, ts)
            val n = lensBtns.size; val bs = dp(38f); val gap = dp(8f)
            val total = n * bs + (n - 1) * gap
            val x0 = fx + fw / 2f - total / 2f
            lensBtns.forEachIndexed { i, t -> t.place(x0 + i * (bs + gap), fy + fh - dp(52f), bs.toInt(), bs.toInt()) }
        }
        tv.post { applyPreviewTransform() }
    }

    private fun applyPreviewTransform() {
        val vw = tv.width.toFloat(); val vh = tv.height.toFloat()
        if (vw == 0f || vh == 0f) return
        val pw = previewSize.width.toFloat(); val ph = previewSize.height.toFloat()
        val k = max(vw / pw, vh / ph)
        txs = k * pw / vw; tys = k * ph / vh
        val m = Matrix()
        m.postScale(txs, tys, vw / 2f, vh / 2f)
        if (display?.rotation == Surface.ROTATION_270) m.postRotate(180f, vw / 2f, vh / 2f)
        tv.setTransform(m)
    }

    private fun filterPaint(cmx: ColorMatrix?): Paint? =
        cmx?.let { Paint().apply { colorFilter = ColorMatrixColorFilter(it) } }

    private fun setFilter(i: Int, announce: Boolean) {
        filterIdx = i
        prefs.edit().putInt("filter", i).apply()
        val f = Filters.list[i]
        tv.setLayerType(View.LAYER_TYPE_HARDWARE, filterPaint(f.matrix))
        filterBtn.text = if (classic) f.short else "▤"
        if (announce) flashHint(f.name)
    }

    private fun flashHint(t: String) {
        hint.text = t
        hint.animate().cancel()
        hint.alpha = 1f
        hint.animate().alpha(0f).setStartDelay(900).setDuration(300).start()
    }

    // ================================================================ camera

    private fun closeCamera() {
        gen++
        try { session?.close() } catch (e: Exception) {}
        try { device?.close() } catch (e: Exception) {}
        try { reader?.close() } catch (e: Exception) {}
        session = null; device = null; reader = null; previewReq = null
    }

    private fun selectLens(i: Int) {
        if (i == curIdx || capturing) return
        curIdx = i
        prefs.edit().putFloat("lensEq", lenses[i].eqMm).apply()
        refreshLensButtons()
        openLens(lenses[i])
    }

    @SuppressLint("MissingPermission")
    private fun openLens(l: Lens) {
        closeCamera()
        val my = gen
        sizeTry = 0
        val useFb = l.useFallback && l.parentId != null
        val id = if (useFb) l.parentId!! else l.openId
        zoomNow = if (useFb) l.zoom else 1f
        try {
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) {
                    if (my != gen) { d.close(); return }
                    device = d
                    l.status = if (useFb) "zoom ${String.format(Locale.US, "%.1f", l.zoom)}× trên camera logic ${l.parentId}" else "mở trực tiếp OK"
                    startSession()
                }
                override fun onDisconnected(d: CameraDevice) { d.close(); if (my == gen) device = null }
                override fun onError(d: CameraDevice, e: Int) {
                    d.close(); if (my == gen) device = null
                    fallbackOrFail(l, my, "lỗi $e")
                }
            }, bg)
        } catch (e: Exception) {
            fallbackOrFail(l, my, e.javaClass.simpleName)
        }
    }

    private fun fallbackOrFail(l: Lens, my: Int, why: String) {
        if (my != gen) return
        if (!l.useFallback && l.parentId != null) {
            l.useFallback = true
            ui.post { if (my == gen) openLens(l) }
        } else {
            l.status = "không mở được ($why)"
            ui.post { Toast.makeText(this, "Không mở được ống kính ${l.eqMm.roundToInt()}mm ($why)", Toast.LENGTH_LONG).show() }
        }
    }

    private fun IntArray?.has(v: Int) = this?.contains(v) == true

    private fun startSession() {
        val d = device ?: return
        val my = gen
        try {
            val ch = cm.getCameraCharacteristics(d.id)
            chars = ch
            val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP) ?: return
            if (sizeTry == 0) {
                jpegSizes = ((map.getOutputSizes(android.graphics.ImageFormat.JPEG)?.toList() ?: emptyList()) +
                    (map.getHighResolutionOutputSizes(android.graphics.ImageFormat.JPEG)?.toList() ?: emptyList()))
                    .sortedByDescending { it.width.toLong() * it.height }
            }
            val js = jpegSizes[min(sizeTry, jpegSizes.size - 1)]
            val aspect = js.width.toFloat() / js.height
            val ps = map.getOutputSizes(android.graphics.SurfaceTexture::class.java).toList()
                .filter { it.width.toLong() * it.height <= 3_100_000 && it.width >= it.height }
            previewSize = ps.filter { abs(it.width.toFloat() / it.height - aspect) < 0.03f }
                .maxByOrNull { it.width.toLong() * it.height }
                ?: ps.maxByOrNull { it.width.toLong() * it.height } ?: Size(1280, 720)

            hasAf = (ch.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f) > 0f
            val r = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
            evMin = r?.lower ?: 0; evMax = r?.upper ?: 0
            evStep = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: (1f / 3f)
            evIdx = evIdx.coerceIn(evMin, evMax)
            updateEvUi()

            reader?.close()
            reader = ImageReader.newInstance(js.width, js.height, android.graphics.ImageFormat.JPEG, 2).also {
                it.setOnImageAvailableListener({ rd -> onImage(rd) }, bg)
            }
            val st = tv.surfaceTexture ?: return
            st.setDefaultBufferSize(previewSize.width, previewSize.height)
            previewSurface = Surface(st)
            ui.post { applyPreviewTransform() }

            val outs = listOf(OutputConfiguration(previewSurface!!), OutputConfiguration(reader!!.surface))
            val sc = SessionConfiguration(SessionConfiguration.SESSION_REGULAR, outs, exec,
                object : CameraCaptureSession.StateCallback() {
                    override fun onConfigured(s: CameraCaptureSession) {
                        if (my != gen) { s.close(); return }
                        session = s; startPreview()
                    }
                    override fun onConfigureFailed(s: CameraCaptureSession) {
                        if (my != gen) return
                        if (sizeTry < 2 && sizeTry + 1 < jpegSizes.size) { sizeTry++; startSession() }
                        else ui.post { Toast.makeText(this@MainActivity, "Không cấu hình được phiên camera", Toast.LENGTH_LONG).show() }
                    }
                })
            d.createCaptureSession(sc)
        } catch (e: Exception) {
            ui.post { Toast.makeText(this, "Lỗi camera: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private fun applyCommon(b: CaptureRequest.Builder) {
        b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
        b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
        b.set(CaptureRequest.CONTROL_AWB_MODE, CaptureRequest.CONTROL_AWB_MODE_AUTO)
        b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evIdx)
        b.set(CaptureRequest.FLASH_MODE, CaptureRequest.FLASH_MODE_OFF)
        b.set(CaptureRequest.CONTROL_ZOOM_RATIO, zoomNow)
        if (hasAf) b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
    }

    /** Chất lượng cao nhất mà HAL hỗ trợ cho ảnh tĩnh. */
    private fun applyQuality(b: CaptureRequest.Builder) {
        val c = chars ?: return
        val hq = 2 // *_HIGH_QUALITY
        if (c.get(CameraCharacteristics.NOISE_REDUCTION_AVAILABLE_NOISE_REDUCTION_MODES).has(hq)) b.set(CaptureRequest.NOISE_REDUCTION_MODE, hq)
        if (c.get(CameraCharacteristics.EDGE_AVAILABLE_EDGE_MODES).has(hq)) b.set(CaptureRequest.EDGE_MODE, hq)
        if (c.get(CameraCharacteristics.COLOR_CORRECTION_AVAILABLE_ABERRATION_MODES).has(hq)) b.set(CaptureRequest.COLOR_CORRECTION_ABERRATION_MODE, hq)
        if (c.get(CameraCharacteristics.SHADING_AVAILABLE_MODES).has(hq)) b.set(CaptureRequest.SHADING_MODE, hq)
        if (c.get(CameraCharacteristics.HOT_PIXEL_AVAILABLE_HOT_PIXEL_MODES).has(hq)) b.set(CaptureRequest.HOT_PIXEL_MODE, hq)
        if (c.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES).has(hq)) b.set(CaptureRequest.TONEMAP_MODE, hq)
        b.set(CaptureRequest.JPEG_QUALITY, 100.toByte())
    }

    private val stateCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
            afState = res.get(CaptureResult.CONTROL_AF_STATE)
            aeState = res.get(CaptureResult.CONTROL_AE_STATE)
        }
    }

    private fun startPreview() {
        val d = device ?: return
        val s = session ?: return
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            b.addTarget(previewSurface!!)
            applyCommon(b)
            previewReq = b
            s.setRepeatingRequest(b.build(), stateCb, bg)
        } catch (e: Exception) { }
    }

    private fun updateRepeating() {
        try { session?.setRepeatingRequest(previewReq?.build() ?: return, stateCb, bg) } catch (e: Exception) { }
    }

    // ---- EV
    private fun changeEv(dy: Float) {
        evAccum += dy / dp(34f)
        val steps = evAccum.toInt()
        if (steps != 0) {
            evAccum -= steps
            evIdx = (evIdx + steps).coerceIn(evMin, evMax)
            previewReq?.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evIdx)
            updateRepeating(); updateEvUi()
        }
    }

    private fun updateEvUi() {
        val ev = evIdx * evStep
        val mx = max(abs(evMin), abs(evMax)).coerceAtLeast(1) * evStep
        ui.post {
            vf.evText = String.format(Locale.US, "%+.1f", ev).let { if (abs(ev) < 0.05f) "0.0" else it }
            vf.evNorm = (ev / mx).coerceIn(-1f, 1f)
            vf.invalidate()
        }
    }

    // ---- lấy nét chạm
    private fun focusAt(u: Float, v: Float) {
        vf.showFocus(u * vf.width, v * vf.height)
        val ch = chars ?: return; val s = session ?: return; val b = previewReq ?: return
        val arr = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE) ?: return
        var bx = 0.5f + (u - 0.5f) / txs
        var by = 0.5f + (v - 0.5f) / tys
        if (display?.rotation == Surface.ROTATION_270) { bx = 1f - bx; by = 1f - by }
        val half = (arr.width() * 0.06f).toInt()
        val x = (arr.left + bx * arr.width()).toInt().coerceIn(arr.left + half, arr.right - half) - half
        val y = (arr.top + by * arr.height()).toInt().coerceIn(arr.top + half, arr.bottom - half) - half
        val rect = arrayOf(MeteringRectangle(x, y, half * 2, half * 2, 1000))
        try {
            b.set(CaptureRequest.CONTROL_AF_REGIONS, rect)
            b.set(CaptureRequest.CONTROL_AE_REGIONS, rect)
            if (hasAf) {
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START)
                s.capture(b.build(), stateCb, bg)
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_IDLE)
            }
            s.setRepeatingRequest(b.build(), stateCb, bg)
        } catch (e: Exception) { }
    }

    // ================================================================ chụp

    private fun takePicture() {
        val s = session ?: return
        val d = device ?: return
        if (capturing) return
        capturing = true
        sound.play(MediaActionSound.SHUTTER_CLICK)
        flashEffect()
        try {
            val tb = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
            tb.addTarget(previewSurface!!)
            applyCommon(tb)
            tb.set(CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER, CaptureRequest.CONTROL_AE_PRECAPTURE_TRIGGER_START)
            if (hasAf) tb.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_START)
            afState = null; aeState = null
            s.capture(tb.build(), stateCb, bg)
            val t0 = SystemClock.uptimeMillis()
            val poll = object : Runnable {
                override fun run() {
                    val dt = SystemClock.uptimeMillis() - t0
                    val af = !hasAf || afState == CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED ||
                        afState == CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED
                    val ae = aeState != null && aeState != CaptureResult.CONTROL_AE_STATE_PRECAPTURE
                    if (dt > 1600 || (dt > 250 && af && ae)) captureStill() else bg.postDelayed(this, 50)
                }
            }
            bg.postDelayed(poll, 80)
        } catch (e: Exception) { capturing = false; endVeil() }
    }

    private fun captureStill() {
        val d = device ?: run { capturing = false; return }
        val s = session ?: run { capturing = false; return }
        val rd = reader ?: run { capturing = false; return }
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            b.addTarget(rd.surface)
            applyCommon(b); applyQuality(b)
            b.set(CaptureRequest.JPEG_ORIENTATION, jpegOrientation())
            s.capture(b.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(ss: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) { resumePreview() }
                override fun onCaptureFailed(ss: CameraCaptureSession, r: CaptureRequest, f: CaptureFailure) {
                    capturing = false; ui.post { endVeil(); Toast.makeText(this@MainActivity, "Chụp thất bại", Toast.LENGTH_SHORT).show() }
                    resumePreview()
                }
            }, bg)
        } catch (e: Exception) { capturing = false; ui.post { endVeil() } }
    }

    private fun resumePreview() {
        val s = session ?: return; val b = previewReq ?: return; val d = device ?: return
        try {
            if (hasAf) {
                val cb = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                cb.addTarget(previewSurface!!); applyCommon(cb)
                cb.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_CANCEL)
                s.capture(cb.build(), stateCb, bg)
            }
            b.set(CaptureRequest.CONTROL_AF_TRIGGER, CaptureRequest.CONTROL_AF_TRIGGER_IDLE)
            s.setRepeatingRequest(b.build(), stateCb, bg)
        } catch (e: Exception) { }
    }

    private fun jpegOrientation(): Int {
        val so = chars?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        val dd = when (display?.rotation) {
            Surface.ROTATION_90 -> 90; Surface.ROTATION_180 -> 180; Surface.ROTATION_270 -> 270; else -> 0
        }
        return (so - dd + 360) % 360
    }

    // ---- hiệu ứng chụp: nháy âm bản -> phủ xám mờ -> hiện ảnh
    private fun flashEffect() {
        ui.post {
            tv.setLayerType(View.LAYER_TYPE_HARDWARE, filterPaint(Filters.invert))
            ui.postDelayed({
                setFilterLayerOnly()
                veil.animate().cancel()
                veil.alpha = 0.86f; veil.visibility = View.VISIBLE
            }, 150)
        }
    }

    private fun setFilterLayerOnly() {
        tv.setLayerType(View.LAYER_TYPE_HARDWARE, filterPaint(Filters.list[filterIdx].matrix))
    }

    private fun endVeil() {
        veil.animate().cancel()
        veil.animate().alpha(0f).setDuration(450).withEndAction { veil.visibility = View.GONE }.start()
        thumb.scaleX = 0.6f; thumb.scaleY = 0.6f
        thumb.animate().scaleX(1f).scaleY(1f).setDuration(260).start()
    }

    private fun onImage(rd: ImageReader) {
        val img = try { rd.acquireNextImage() } catch (e: Exception) { null }
        if (img == null) { capturing = false; return }
        val buf = img.planes[0].buffer
        val bytes = ByteArray(buf.remaining()).also { buf.get(it) }
        img.close()
        val lens = lenses.getOrNull(curIdx)
        val filt = Filters.list[filterIdx]
        val wm = prefs.getBoolean("wm", true)
        val keep = prefs.getBoolean("keep", false)
        val dev = prefs.getString("dev", null) ?: defaultDeviceName()
        Thread { process(bytes, lens, filt, wm, keep, dev) }.start()
    }

    // ================================================================ xử lý ảnh đầu ra

    /**
     * Cắt XPan 65:24 từ chính giữa khung JPEG gốc ở độ phân giải đầy đủ (không resize),
     * áp màu theo từng dải để tiết kiệm RAM, lưu JPEG chất lượng 100 kèm EXIF.
     */
    private fun process(jpeg: ByteArray, lens: Lens?, filt: Filt, wm: Boolean, keep: Boolean, devName: String) {
        var out: Bitmap? = null
        try {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val src = File(cacheDir, "src.jpg").also { it.writeBytes(jpeg) }
            val ex = ExifInterface(src)
            val ori = ex.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            val rot = when (ori) {
                ExifInterface.ORIENTATION_ROTATE_180, ExifInterface.ORIENTATION_FLIP_VERTICAL -> 180
                ExifInterface.ORIENTATION_ROTATE_90, ExifInterface.ORIENTATION_TRANSPOSE -> 90
                ExifInterface.ORIENTATION_ROTATE_270, ExifInterface.ORIENTATION_TRANSVERSE -> 270
                else -> 0
            }
            val swap = rot == 90 || rot == 270

            if (keep) saveBytesToGallery(jpeg, "XPAN_${stamp}_ORIG.jpg")

            @Suppress("DEPRECATION")
            val dec = BitmapRegionDecoder.newInstance(jpeg, 0, jpeg.size, false)!!
            val iw = dec.width; val ih = dec.height
            val tr = if (swap) 1f / RATIO else RATIO
            var cw = iw; var chh = (iw / tr).toInt()
            if (chh > ih) { chh = ih; cw = (ih * tr).toInt() }
            cw = cw and 1.inv(); chh = chh and 1.inv()
            val left = (iw - cw) / 2; val top = (ih - chh) / 2
            val ow = if (swap) chh else cw
            val oh = if (swap) cw else chh

            var ss = 1
            while (out == null) {
                try { out = Bitmap.createBitmap(ow / ss, oh / ss, Bitmap.Config.ARGB_8888) }
                catch (e: OutOfMemoryError) { ss *= 2; if (ss > 4) throw e }
            }
            val bmp = out!!
            val canvas = Canvas(bmp)
            val paint = Paint(Paint.FILTER_BITMAP_FLAG)
            filt.matrix?.let { paint.colorFilter = ColorMatrixColorFilter(it) }
            canvas.save()
            when (rot) {
                90 -> { canvas.translate((chh / ss).toFloat(), 0f); canvas.rotate(90f) }
                180 -> { canvas.translate((cw / ss).toFloat(), (chh / ss).toFloat()); canvas.rotate(180f) }
                270 -> { canvas.translate(0f, (cw / ss).toFloat()); canvas.rotate(270f) }
            }
            val opts = BitmapFactory.Options().apply { inPreferredConfig = Bitmap.Config.ARGB_8888; inSampleSize = ss }
            val band = max(64, (chh / 8) / 16 * 16)
            var y = 0
            while (y < chh) {
                val bh = min(band, chh - y)
                val piece = dec.decodeRegion(Rect(left, top + y, left + cw, top + y + bh), opts)
                if (piece != null) { canvas.drawBitmap(piece, 0f, (y / ss).toFloat(), paint); piece.recycle() }
                y += bh
            }
            canvas.restore()
            dec.recycle()

            // JPEG 100 + EXIF
            val outFile = File(cacheDir, "out.jpg")
            FileOutputStream(outFile).use { bmp.compress(Bitmap.CompressFormat.JPEG, 100, it) }
            copyExif(ex, outFile, filt)
            val uri = saveFileToGallery(outFile, "XPAN_$stamp.jpg")

            // thẻ ảnh watermark (tuỳ chọn)
            val cardBmp: Bitmap? = if (wm) {
                val eq = ex.getAttributeInt(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, 0).let { if (it > 0) it else (lens?.eqMm?.roundToInt() ?: 0) }
                val fn = ex.getAttributeDouble(ExifInterface.TAG_F_NUMBER, 0.0)
                val et = ex.getAttributeDouble(ExifInterface.TAG_EXPOSURE_TIME, 0.0)
                val iso = ex.getAttributeInt(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, 0)
                val shut = if (et <= 0) "-" else if (et < 1) "1/${(1.0 / et).roundToInt()}" else "${String.format(Locale.US, "%.1f", et)}s"
                val line = "FL  ${eq}mm      Aperture  f/${String.format(Locale.US, "%.1f", fn)}      Shutter  $shut      ISO  $iso"
                val cb = makeCard(bmp, line, devName)
                val cf = File(cacheDir, "card.jpg")
                FileOutputStream(cf).use { cb.compress(Bitmap.CompressFormat.JPEG, 95, it) }
                saveFileToGallery(cf, "XPAN_${stamp}_CARD.jpg")
                cf.delete()
                cb
            } else null
            bmp.recycle(); out = null
            src.delete(); outFile.delete()

            ui.post {
                capturing = false
                if (uri != null) { lastUri = uri; loadThumb() }
                endVeil()
                if (cardBmp != null && classic) {
                    card.setImageBitmap(cardBmp); card.visibility = View.VISIBLE
                    card.postDelayed({ card.visibility = View.GONE }, 2600)
                }
            }
        } catch (e: Throwable) {
            out?.recycle()
            ui.post { capturing = false; endVeil(); Toast.makeText(this, "Lỗi xử lý ảnh: ${e.message}", Toast.LENGTH_LONG).show() }
        }
    }

    private val copyTags = listOf(
        ExifInterface.TAG_DATETIME, ExifInterface.TAG_DATETIME_ORIGINAL, ExifInterface.TAG_DATETIME_DIGITIZED,
        ExifInterface.TAG_MAKE, ExifInterface.TAG_MODEL, ExifInterface.TAG_F_NUMBER, ExifInterface.TAG_EXPOSURE_TIME,
        ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, ExifInterface.TAG_FOCAL_LENGTH, ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM,
        ExifInterface.TAG_EXPOSURE_BIAS_VALUE, ExifInterface.TAG_WHITE_BALANCE, ExifInterface.TAG_FLASH, ExifInterface.TAG_LENS_MODEL
    )

    private fun copyExif(from: ExifInterface, to: File, filt: Filt) {
        try {
            val oe = ExifInterface(to)
            for (t in copyTags) from.getAttribute(t)?.let { oe.setAttribute(t, it) }
            oe.setAttribute(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL.toString())
            oe.setAttribute(ExifInterface.TAG_SOFTWARE, "Xpan-Mode")
            oe.setAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION, "XPan 65:24 - ${filt.name}")
            oe.saveAttributes()
        } catch (e: Exception) { }
    }

    private fun makeCard(img: Bitmap, line: String, devName: String): Bitmap {
        val tw = min(img.width, 4096)
        val ih = (img.height * (tw.toFloat() / img.width)).toInt()
        val m = tw * 0.008f
        val top = ih * 0.22f; val bottom = ih * 0.34f
        val cw = (tw + 2 * m).toInt(); val chh = (ih + top + bottom).toInt()
        val bmp = Bitmap.createBitmap(cw, chh, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        c.drawBitmap(img, null, RectF(m, top, m + tw, top + ih), Paint(Paint.FILTER_BITMAP_FLAG))
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; color = 0xFF111111.toInt() }
        p.typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC); p.textSize = ih * 0.075f; p.letterSpacing = 0.32f
        c.drawText(BRAND, cw / 2f, top * 0.62f, p)
        p.typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL); p.letterSpacing = 0f; p.textSize = ih * 0.055f
        c.drawText(devName, cw / 2f, top + ih + bottom * 0.38f, p)
        p.textSize = ih * 0.026f; p.color = 0xFF666666.toInt()
        c.drawText(line, cw / 2f, top + ih + bottom * 0.58f, p)
        return bmp
    }

    private fun defaultDeviceName(): String {
        val man = Build.MANUFACTURER; val mod = Build.MODEL
        return if (mod.startsWith(man, true)) mod else "${man.uppercase(Locale.US)} $mod"
    }

    // ================================================================ thư viện ảnh

    private fun newImageValues(name: String) = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, name)
        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Xpan-Mode")
        put(MediaStore.Images.Media.IS_PENDING, 1)
    }

    private fun finishInsert(uri: Uri) {
        val v = ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }
        contentResolver.update(uri, v, null, null)
    }

    private fun saveFileToGallery(f: File, name: String): Uri? {
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, newImageValues(name)) ?: return null
        contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
        finishInsert(uri); return uri
    }

    private fun saveBytesToGallery(b: ByteArray, name: String): Uri? {
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, newImageValues(name)) ?: return null
        contentResolver.openOutputStream(uri)?.use { it.write(b) }
        finishInsert(uri); return uri
    }

    private fun queryLastUri(): Uri? {
        return try {
            val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            contentResolver.query(
                base, arrayOf(MediaStore.Images.Media._ID),
                "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? AND ${MediaStore.Images.Media.DISPLAY_NAME} NOT LIKE ?",
                arrayOf("Pictures/Xpan-Mode%", "%_CARD%"), "${MediaStore.Images.Media.DATE_ADDED} DESC"
            )?.use { c -> if (c.moveToFirst()) android.content.ContentUris.withAppendedId(base, c.getLong(0)) else null }
        } catch (e: Exception) { null }
    }

    private fun loadThumb() {
        val u = lastUri ?: return
        Thread {
            try {
                val b = contentResolver.loadThumbnail(u, Size(320, 320), null)
                ui.post { thumb.setImageBitmap(b) }
            } catch (e: Exception) { }
        }.start()
    }

    // ================================================================ hộp thoại

    private fun showSettings() {
        val ll = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dpi(20f), dpi(8f), dpi(20f), 0) }
        val c1 = CheckBox(this).apply { text = "Lưu thêm thẻ ảnh watermark (_CARD)"; isChecked = prefs.getBoolean("wm", true) }
        val c2 = CheckBox(this).apply { text = "Lưu thêm ảnh gốc từ cảm biến (_ORIG, không cắt/lọc)"; isChecked = prefs.getBoolean("keep", false) }
        val et = EditText(this).apply { hint = "Tên máy trên thẻ ảnh"; setText(prefs.getString("dev", defaultDeviceName())); setSingleLine() }
        ll.addView(c1); ll.addView(c2); ll.addView(et)
        AlertDialog.Builder(this).setTitle("Xpan-Mode").setView(ll)
            .setPositiveButton("Lưu") { _, _ ->
                prefs.edit().putBoolean("wm", c1.isChecked).putBoolean("keep", c2.isChecked)
                    .putString("dev", et.text.toString().trim().ifEmpty { defaultDeviceName() }).apply()
            }
            .setNeutralButton("Thông tin ống kính") { _, _ -> showLensInfo() }
            .setNegativeButton("Đóng", null).show()
    }

    private fun showLensInfo() {
        val sb = StringBuilder()
        sb.append("Máy: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})\n")
        sb.append("Phát hiện ${lenses.size} ống kính sau:\n\n")
        lenses.forEach { sb.append(it.describe()).append("\n\n") }
        if (notes.isNotEmpty()) sb.append("Ghi chú:\n").append(notes.joinToString("\n"))
        val tvv = TextView(this).apply { text = sb.toString(); textSize = 12f; setPadding(dpi(18f), dpi(8f), dpi(18f), dpi(8f)); setTextIsSelectable(true) }
        val sv = ScrollView(this).apply { addView(tvv) }
        AlertDialog.Builder(this).setTitle("Thông tin ống kính").setView(sv)
            .setPositiveButton("Đóng", null)
            .setNeutralButton("Sao chép") { _, _ ->
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("lens", sb.toString()))
                Toast.makeText(this, "Đã sao chép", Toast.LENGTH_SHORT).show()
            }.show()
    }
}
