package com.xpanmode.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.text.InputType
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.abs
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : Activity(), CameraController.Callback {
    private lateinit var prefs: Prefs
    private lateinit var repo: LensRepository
    private lateinit var cam: CameraController
    private lateinit var ui: CameraLayout
    private lateinit var root: FrameLayout
    private lateinit var review: ReviewView

    private var entries: List<ZoomEntry> = emptyList()
    private var selected = 0
    private var userZoom = 1f
    private var info: CameraController.OpenInfo? = null
    private var openedLensId: String? = null
    private var surface: SurfaceTexture? = null
    private var ready = false
    private var resumed = false
    private var shooting = false
    private var lastUri: Uri? = null
    private var reviewUri: Uri? = null
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var focusId = 0
    private var focusLoaded = false
    private val pendingSeqs = ArrayDeque<Int>()
    private var shotSeq = 0
    private var processingCount = 0
    private var pool: SoundPool? = null
    private var shutterId = 0
    private var shutterLoaded = false
    private var lensFxActive = false
    private var lensFxStart = 0L
    private val finishLensFxRunnable = Runnable {
        ui.lensFx.hide()
        lensFxActive = false
    }
    private var freezeActive = false
    private var revealed = false
    private var processed = false
    private var resultBmp: Bitmap? = null
    // hiệu ứng chụp theo video: 1 âm bản -> 2 xám phủ kín -> 3 xám tan -> 4 giữ ảnh -> 5 ảnh bay về thumbnail
    private var phase = 0
    private var negStart = 0L
    private var captureDone = false
    private var frozenBmp: Bitmap? = null
    private var pendingThumb: Bitmap? = null
    private val negCheck = Runnable { tryEndNegative() }
    private val dockRunnable = Runnable { dock() }
    private val chips = ArrayList<TextView>()
    private val warned = HashSet<String>()
    private val hideTray = Runnable { ui.tray.visibility = View.GONE }

    // ------------------------------------------------------------------ vòng đời

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        prefs = Prefs(this)
        repo = LensRepository(this)
        cam = CameraController(this, repo, this)
        cam.teleZoomOverride = prefs.teleZoom
        pool = SoundPool.Builder().setMaxStreams(2).setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        ).build().also { p ->
            p.setOnLoadCompleteListener { _, id, status ->
                if (status == 0) { if (id == shutterId) shutterLoaded = true else if (id == focusId) focusLoaded = true }
            }
            shutterId = p.load(this, R.raw.shutter_classic, 1)
            focusId = p.load(this, R.raw.focus_beep, 1)
        }

        ui = CameraLayout(this)
        review = ReviewView(this)
        root = FrameLayout(this)
        root.addView(ui, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        root.addView(review, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)
        hideBars()
        root.setOnApplyWindowInsetsListener { _, ins ->
            val cut = ins.displayCutout
            ui.setSafe(cut?.safeInsetLeft ?: 0, cut?.safeInsetRight ?: 0)
            ins
        }

        setupUi()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) { updateTransform() }
        }, null)

        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) initCamera()
        else requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            initCamera()
            maybeOpen()
        } else {
            toast("Cần cấp quyền Camera để sử dụng Xpan-Mode")
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        hideBars()
        if (ready) maybeOpen()
    }

    override fun onPause() {
        resumed = false
        cam.close()
        openedLensId = null
        info = null
        review.hide()
        releaseFreeze()
        super.onPause()
    }

    override fun onDestroy() {
        cam.release()
        exec.shutdown()
        pool?.release()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    private fun isVolumeKey(k: Int) = k == KeyEvent.KEYCODE_VOLUME_UP || k == KeyEvent.KEYCODE_VOLUME_DOWN

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (prefs.volumeShutter && isVolumeKey(keyCode) && review.visibility != View.VISIBLE) {
            if (event.repeatCount == 0) takePhoto()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (prefs.volumeShutter && isVolumeKey(keyCode) && review.visibility != View.VISIBLE) return true
        return super.onKeyUp(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (review.visibility == View.VISIBLE) review.hide() else super.onBackPressed()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------------------ khởi tạo camera / UI

    private fun initCamera() {
        repo.scan()
        entries = repo.entries()
        if (entries.isEmpty()) {
            toast("Không tìm thấy camera sau trên thiết bị")
            return
        }
        val key = prefs.entryKey
        selected = entries.indexOfFirst { it.key == key }.takeIf { it >= 0 }
            ?: entries.indices.minByOrNull { abs(entries[it].ratio - 1f) } ?: 0
        ui.ladder.labels = entries.map { it.ratioLabel }
        ui.pills.labels = entries.map { it.mmLabel }
        syncSel()
        ready = true
        loadLatestThumb()
        if (resumed) maybeOpen()
    }

    private fun setupUi() {
        ui.classic = prefs.classic
        ui.texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { surface = st; maybeOpen() }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { updateTransform() }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                cam.close(); surface = null; openedLensId = null; info = null
                return true
            }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        ui.texture.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateTransform() }

        val scaleDet = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val mz = info?.maxZoom ?: 1f
                userZoom = (userZoom * d.scaleFactor).coerceIn(1f, mz)
                cam.setZoom(userZoom)
                val lid = info?.lens?.id
                val idx = entries.indices.filter { entries[it].lens.id == lid }
                    .minByOrNull { abs(entries[it].zoom - userZoom) }
                if (idx != null && idx != selected) { selected = idx; syncSel() }
                return true
            }
        })
        val tapDet = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val i = info ?: return true
                val tw = ui.texture.width.toFloat()
                val th = ui.texture.height.toFloat()
                if (tw <= 0f || th <= 0f) return true
                val band = (i.preview.width.toFloat() / i.preview.height * 24f / 65f).coerceAtMost(1f)
                cam.focusAt(e.x / tw, e.y / th, band, jpegRotation(i) == 180)
                ui.focusBox.showAt(e.x, e.y)
                return true
            }
        })
        ui.texture.setOnTouchListener { _, e ->
            scaleDet.onTouchEvent(e)
            if (!scaleDet.isInProgress && e.pointerCount == 1) tapDet.onTouchEvent(e)
            true
        }

        ui.ladder.onSelect = { selectEntry(it) }
        ui.pills.onSelect = { selectEntry(it) }
        ui.ev.onChange = { cam.setEv(it) }
        ui.shutter.setOnClickListener { takePhoto() }
        // chạm: mở thẳng trong ứng dụng Thư viện; nhấn giữ: xem khung trắng + thông số trong app
        ui.thumb.setOnClickListener {
            lastUri?.let {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(it, "image/jpeg").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                } catch (t: Throwable) {
                    toast("Không mở được ứng dụng Thư viện")
                }
            }
        }
        ui.thumb.setOnLongClickListener { lastUri?.let { showReview(it) }; true }
        ui.toggle.setOnClickListener {
            prefs.classic = !prefs.classic
            ui.alpha = 0f
            ui.classic = prefs.classic
            ui.animate().alpha(1f).setDuration(220).start()
        }
        ui.gear.setOnClickListener { showSettings() }
        ui.filterBtn.setOnClickListener {
            if (ui.tray.visibility == View.VISIBLE) ui.tray.visibility = View.GONE
            else {
                ui.tray.visibility = View.VISIBLE
                main.removeCallbacks(hideTray)
                main.postDelayed(hideTray, 5000)
                ui.tray.post {
                    val c = chips.getOrNull(prefs.filter)
                    if (c != null) ui.tray.smoothScrollTo(c.left - (ui.tray.width - c.width) / 2, 0)
                }
            }
        }
        buildTray()
        applyFilter()

        review.onClose = { review.hide() }
        review.onOpen = {
            reviewUri?.let {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(it, "image/jpeg").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }
        }
        review.onSaveFrame = {
            val u = reviewUri
            if (u != null) exec.execute {
                var err: String? = null
                val r = try { PhotoProcessor.saveFramed(this, u, deviceName()) } catch (t: Throwable) { err = PhotoProcessor.errText(t); null }
                runOnUiThread { toast(if (r != null) "Đã lưu ảnh có khung vào Pictures/Xpan-Mode" else "Không lưu được ảnh khung: $err") }
            }
        }
    }

    private fun buildTray() {
        ui.trayRow.removeAllViews()
        chips.clear()
        val dn = resources.displayMetrics.density
        XpanFilter.all.forEachIndexed { i, f ->
            val tv = TextView(this)
            tv.text = f.name
            tv.textSize = 13f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.setPadding((16 * dn).toInt(), (7 * dn).toInt(), (16 * dn).toInt(), (7 * dn).toInt())
            tv.background = chipBg(false)
            tv.setOnClickListener {
                prefs.filter = i
                applyFilter()
                main.removeCallbacks(hideTray)
                main.postDelayed(hideTray, 1200)
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.rightMargin = (8 * dn).toInt()
            ui.trayRow.addView(tv, lp)
            chips.add(tv)
        }
    }

    private fun chipBg(sel: Boolean): GradientDrawable {
        val dn = resources.displayMetrics.density
        return GradientDrawable().apply {
            cornerRadius = 100f * dn
            setColor(if (sel) 0xE61E1108.toInt() else 0xCC141416.toInt())
            setStroke(((if (sel) 1.6f else 1f) * dn).toInt().coerceAtLeast(1), if (sel) ORANGE else 0x55FFFFFF)
        }
    }

    private fun applyFilter() {
        val f = XpanFilter.all[prefs.filter.coerceIn(0, XpanFilter.all.size - 1)]
        ui.filterBtn.label = f.name
        chips.forEachIndexed { i, tv ->
            tv.setTextColor(if (i == prefs.filter) ORANGE else Color.WHITE)
            tv.background = chipBg(i == prefs.filter)
        }
        setTexturePaint(false)
    }

    private fun setTexturePaint(invert: Boolean) {
        val f = XpanFilter.all[prefs.filter.coerceIn(0, XpanFilter.all.size - 1)]
        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(if (invert) XpanFilter.invertMatrix() else f.previewMatrix())
        ui.texture.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
    }

    private fun syncSel() {
        ui.ladder.selected = selected
        ui.pills.selected = selected
    }

    // ------------------------------------------------------------------ mở camera / chọn ống kính

    private fun maybeOpen() {
        if (!ready || !resumed || entries.isEmpty()) return
        val st = surface ?: return
        val e = entries[selected]
        userZoom = e.zoom
        cam.open(e.lens, st, repo.previewSize(e.lens), prefs.saveRaw, e.ratio / e.zoom)
    }

    /** Chụp đúng hình đang thấy trên khung ngắm (đã xoay/cắt theo ma trận của TextureView). */
    private fun grabPreview(): Bitmap? {
        val tv = ui.texture
        val w = tv.width
        val h = tv.height
        if (w <= 0 || h <= 0) return null
        return try {
            val raw = tv.getBitmap(w, h) ?: return null
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val m = Matrix()
            tv.getTransform(m)
            Canvas(out).drawBitmap(raw, m, Paint(Paint.FILTER_BITMAP_FLAG))
            raw.recycle()
            out
        } catch (t: Throwable) {
            null
        }
    }

    private fun fxNodes(): List<LensFxNode> = entries.map { e ->
        val eq = e.lens.eq35 * e.zoom
        val title = when {
            e.zoom > 1f -> "${e.ratioLabel}× CROP"
            e.ratio < 0.95f -> "ULTRA WIDE"
            e.ratio < 1.7f -> "WIDE"
            else -> "TELEPHOTO"
        }
        val ap = if (e.lens.aperture > 0f) String.format(Locale.US, " · f/%.1f", e.lens.aperture) else ""
        LensFxNode(title, "${eq.roundToInt()}mm$ap", e.ratioLabel, eq)
    }

    private fun startLensFx(from: Int, to: Int) {
        val frame: Bitmap? = grabPreview()
        main.removeCallbacks(finishLensFxRunnable)
        ui.lensFx.start(fxNodes(), from, to, frame, ColorMatrixColorFilter(curFilter().previewMatrix()))
        lensFxStart = SystemClock.uptimeMillis()
        lensFxActive = true
    }

    /** Giữ hiệu ứng tối thiểu ~1 giây rồi mờ dần để lộ khung ngắm của ống kính mới. */
    private fun finishLensFx() {
        if (!lensFxActive) return
        val remain = max(0L, 1100L - (SystemClock.uptimeMillis() - lensFxStart))
        main.removeCallbacks(finishLensFxRunnable)
        main.postDelayed(finishLensFxRunnable, remain)
    }

    private fun selectEntry(i: Int) {
        if (i !in entries.indices) return
        val e = entries[i]
        if (i == selected && openedLensId == e.lens.id) return
        val prev = selected
        startLensFx(prev, i)
        selected = i
        prefs.entryKey = e.key
        syncSel()
        if (openedLensId == e.lens.id) {
            userZoom = e.zoom
            cam.setZoom(userZoom)
            main.postDelayed({ finishLensFx() }, 900)
        } else {
            openedLensId = null
            maybeOpen()
            main.postDelayed({ finishLensFx() }, 6000)   // dự phòng nếu mở camera quá lâu / lỗi
        }
    }

    override fun onReady(info: CameraController.OpenInfo) {
        this.info = info
        openedLensId = info.lens.id
        ui.ev.min = info.evMin
        ui.ev.max = info.evMax
        ui.ev.step = info.evStep
        ui.ev.value = 0
        updateTransform()
        cam.setZoom(userZoom)
        finishLensFx()
    }

    override fun onError(msg: String) {
        toast(msg)
        finishLensFx()
        releaseFreeze()
    }

    /** Tiếng chỉ phát theo âm lượng đa phương tiện; tuỳ chọn im lặng khi máy ở chế độ im lặng/rung. */
    private fun soundAllowed(): Boolean {
        if (!prefs.respectSilent) return true
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        return am.ringerMode == AudioManager.RINGER_MODE_NORMAL
    }

    override fun onNote(msg: String) = toast(msg)

    override fun onFocus(ok: Boolean) {
        ui.focusBox.lock(ok)
        if (ok && prefs.focusSound && focusLoaded && soundAllowed()) pool?.play(focusId, 0.8f, 0.8f, 1, 0, 1f)
    }

    @Suppress("DEPRECATION")
    private fun dispRot(): Int = windowManager.defaultDisplay.rotation

    private fun jpegRotation(i: CameraController.OpenInfo): Int =
        (i.sensorOrientation - dispRot() * 90 + 360) % 360

    private fun updateTransform() {
        val i = info ?: return
        val tv = ui.texture
        val vw = tv.width.toFloat()
        val vh = tv.height.toFloat()
        if (vw == 0f || vh == 0f) return
        val rot = dispRot()
        val matrix = Matrix()
        val viewRect = RectF(0f, 0f, vw, vh)
        val bufRect = RectF(0f, 0f, i.preview.height.toFloat(), i.preview.width.toFloat())
        val cx = viewRect.centerX()
        val cy = viewRect.centerY()
        if (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270) {
            bufRect.offset(cx - bufRect.centerX(), cy - bufRect.centerY())
            matrix.setRectToRect(viewRect, bufRect, Matrix.ScaleToFit.FILL)
            val scale = max(vh / i.preview.height, vw / i.preview.width)
            matrix.postScale(scale, scale, cx, cy)
            matrix.postRotate(90f * (rot - 2), cx, cy)
        } else if (rot == Surface.ROTATION_180) {
            matrix.postRotate(180f, cx, cy)
        }
        tv.setTransform(matrix)
    }

    // ------------------------------------------------------------------ chụp ảnh

    private fun curFilter() = XpanFilter.all[prefs.filter.coerceIn(0, XpanFilter.all.size - 1)]

    private val failSafe = Runnable { releaseFreeze() }

    private val NEG_MIN = 1050L      // giữ âm bản tối thiểu (video: ~1,07s)
    private val NEG_MAX = 4000L      // tối đa nếu chụp chậm
    private val GREY_IN = 200L       // âm bản -> xám phẳng
    private val GREY_OUT = 600L      // xám tan dần để lộ ảnh
    private val HOLD = 650L          // giữ ảnh trước khi bay về thumbnail
    private val FLY = 330L           // ảnh thu nhỏ bay về thumbnail

    private fun takePhoto() {
        val i = info ?: return
        if (shooting || lensFxActive || phase != 0) return
        if (ui.texture.width <= 0 || ui.texture.height <= 0) return
        // Đóng băng đúng khung hình lúc bấm chụp
        val frozen: Bitmap? = grabPreview()
        shooting = true
        revealed = false
        processed = false
        resultBmp = null
        captureDone = false
        pendingThumb = null
        shotSeq++
        pendingSeqs.addLast(shotSeq)
        frozenBmp = frozen
        if (frozen != null) {
            // 1) tức thì: khung ngắm thành ảnh ÂM BẢN đóng băng, ẩn khung ngắm/thang EV/dải zoom
            ui.freeze.setImageBitmap(frozen)
            ui.freeze.colorFilter = ColorMatrixColorFilter(XpanFilter.invertMatrix())
            ui.freeze.alpha = 1f
            ui.freeze.visibility = View.VISIBLE
            freezeActive = true
            ui.setChromeHidden(true)
            ui.fx.reset()
            phase = 1
            negStart = SystemClock.uptimeMillis()
            main.removeCallbacks(negCheck)
            main.postDelayed(negCheck, NEG_MIN)
        }
        if (prefs.sound && shutterLoaded && soundAllowed()) pool?.play(shutterId, 1f, 1f, 1, 0, 1f)
        ui.shutter.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        cam.capture(jpegRotation(i))
        main.removeCallbacks(failSafe)
        main.postDelayed(failSafe, 15000)
        if (frozen == null) main.postDelayed({ if (phase == 0) shooting = false }, 400)
    }

    /** Hết pha âm bản khi ảnh đã chụp xong và đã giữ đủ thời gian (hoặc quá lâu). */
    private fun tryEndNegative() {
        if (phase != 1) return
        val el = SystemClock.uptimeMillis() - negStart
        if ((captureDone && el >= NEG_MIN) || el >= NEG_MAX) {
            startGrey()
        } else {
            main.removeCallbacks(negCheck)
            main.postDelayed(negCheck, if (el < NEG_MIN) NEG_MIN - el else 50L)
        }
    }

    private fun startGrey() {
        phase = 2
        // 2) âm bản -> xám phẳng
        ui.fx.greyIn(GREY_IN) {
            // xám đang phủ kín: đổi sang ảnh thật (đã áp bộ lọc) mà không bị lộ
            phase = 3
            revealed = true
            if (frozenBmp != null) ui.freeze.colorFilter = ColorMatrixColorFilter(curFilter().previewMatrix())
            applyResultIfReady()
            // 3) xám tan dần
            ui.fx.greyOut(GREY_OUT) {
                phase = 4
                main.removeCallbacks(dockRunnable)
                main.postDelayed(dockRunnable, HOLD)
            }
        }
    }

    private fun applyResultIfReady() {
        val r = resultBmp
        if (revealed && freezeActive && r != null) {
            ui.freeze.colorFilter = null
            ui.freeze.setImageBitmap(r)
        }
    }

    /** 4->5) giao diện trở lại ngay, ảnh vừa chụp thu nhỏ bay về ô thumbnail (ảnh lưu về máy). */
    private fun dock() {
        if (phase != 4) return
        phase = 5
        val bmp = resultBmp ?: frozenBmp
        val vfR = ui.vfRect()
        val thR = ui.thumbRect()
        ui.setChromeHidden(false)
        ui.freeze.visibility = View.GONE
        ui.freeze.setImageDrawable(null)
        freezeActive = false
        main.removeCallbacks(failSafe)
        if (bmp == null) { finishFly(null); return }
        ui.fly.start(bmp, vfR, thR, FLY) { finishFly(bmp) }
    }

    private fun finishFly(shown: Bitmap?) {
        phase = 0
        shooting = false
        frozenBmp = null
        val th = pendingThumb ?: shown?.let { coverThumb(it) }
        if (th != null) ui.thumb.setImageBitmap(th)
        popThumb()
    }

    private fun coverThumb(b: Bitmap): Bitmap {
        val side = kotlin.math.min(b.width, b.height)
        val sq = Bitmap.createBitmap(b, (b.width - side) / 2, (b.height - side) / 2, side, side)
        val out = Bitmap.createScaledBitmap(sq, 256, 256, true)
        if (sq !== b && sq !== out) sq.recycle()
        return out
    }

    /** Ô thumbnail "nảy" nhẹ khi nhận ảnh. */
    private fun popThumb() {
        ui.thumb.animate().cancel()
        ui.thumb.animate().scaleX(1.18f).scaleY(1.18f).setDuration(110).withEndAction {
            ui.thumb.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
        }.start()
    }

    private fun setThumbFromProcessing(th: Bitmap) {
        if (phase == 0) ui.thumb.setImageBitmap(th) else pendingThumb = th
    }

    private fun onProcessed(seq: Int, big: Bitmap?) {
        if (seq == shotSeq) {
            processed = true
            resultBmp = big
        }
    }

    private fun updateProcessingUi() {
        ui.thumb.alpha = if (processingCount > 0) 0.45f else 1f
    }

    /** Dừng khẩn cấp mọi hiệu ứng chụp (lỗi, tạm dừng, quá thời gian). */
    private fun releaseFreeze() {
        main.removeCallbacks(failSafe)
        main.removeCallbacks(negCheck)
        main.removeCallbacks(dockRunnable)
        ui.fx.reset()
        ui.fly.cancel()
        ui.setChromeHidden(false)
        ui.freeze.visibility = View.GONE
        ui.freeze.setImageDrawable(null)
        freezeActive = false
        frozenBmp = null
        phase = 0
        shooting = false
    }

    override fun onShot(shot: CameraController.ShotResult) {
        captureDone = true
        main.post { tryEndNegative() }
        val filter = curFilter()
        val seq = if (pendingSeqs.isEmpty()) shotSeq else pendingSeqs.removeFirst()
        processingCount++
        updateProcessingUi()
        exec.execute {
            var saved: Saved? = null
            try {
                val s: Saved = PhotoProcessor.process(this, shot, filter, prefs)
                saved = s
                lastUri = s.uri
                runOnUiThread {
                    processingCount = (processingCount - 1).coerceAtLeast(0)
                    updateProcessingUi()
                    s.thumb?.let { setThumbFromProcessing(it) }
                    onProcessed(seq, s.big)
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    processingCount = (processingCount - 1).coerceAtLeast(0)
                    updateProcessingUi()
                    toast("Lỗi xử lý ảnh: ${PhotoProcessor.errText(t)}")
                    onProcessed(seq, null)
                }
            }
            // file phụ (gốc, DNG, ảnh khung) làm sau, không làm chậm ảnh chính
            try {
                val s = saved
                if (s != null) PhotoProcessor.extras(this, shot, s, prefs)?.let { w -> runOnUiThread { toast(w) } }
            } catch (_: Throwable) {
            } finally {
                shot.jpeg.delete()
                shot.dng?.delete()
            }
        }
    }

    private fun deviceName(): String = prefs.deviceName.ifBlank { PhotoProcessor.defaultDeviceName() }

    private fun showReview(uri: Uri) {
        reviewUri = uri
        exec.execute {
            val bmp = try { PhotoProcessor.compose(this, uri, 2400, deviceName()) } catch (t: Throwable) { null }
            runOnUiThread { if (bmp != null) review.show(bmp) else toast("Không mở được ảnh") }
        }
    }

    private fun loadLatestThumb() {
        exec.execute {
            try {
                val sel = "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? AND ${MediaStore.Images.Media.DISPLAY_NAME} LIKE ? " +
                    "AND ${MediaStore.Images.Media.DISPLAY_NAME} NOT LIKE ? AND ${MediaStore.Images.Media.DISPLAY_NAME} NOT LIKE ?"
                val args = arrayOf("Pictures/Xpan-Mode%", "XPAN_%.jpg", "%FRAME%", "%FULL%")
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media._ID),
                    sel, args, "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { c ->
                    if (c.moveToFirst()) {
                        val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(0))
                        lastUri = uri
                        val th = PhotoProcessor.decodeUpright(this, uri, 256)
                        runOnUiThread { if (th != null) ui.thumb.setImageBitmap(th) }
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    // ------------------------------------------------------------------ cài đặt

    private fun showSettings() {
        val dn = resources.displayMetrics.density
        val pad = (16 * dn).toInt()
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(pad, pad, pad, pad)
        val oldRaw = prefs.saveRaw

        fun check(text: String, v: Boolean, set: (Boolean) -> Unit) {
            val cb = CheckBox(this)
            cb.text = text
            cb.isChecked = v
            cb.setOnCheckedChangeListener { _, c -> set(c) }
            col.addView(cb)
        }
        check("Lưu thêm file RAW (DNG) nếu ống kính hỗ trợ", prefs.saveRaw) { prefs.saveRaw = it }
        check("Giữ thêm ảnh gốc full-frame (không cắt, không lọc)", prefs.keepOriginal) { prefs.keepOriginal = it }
        check("Tự lưu thêm ảnh có khung + thông số", prefs.autoFrame) { prefs.autoFrame = it }
        check("Nút tăng/giảm âm lượng để chụp ảnh", prefs.volumeShutter) { prefs.volumeShutter = it }
        check("Âm thanh màn trập cổ điển", prefs.sound) { prefs.sound = it }
        check("Tiếng bíp khi lấy nét xong", prefs.focusSound) { prefs.focusSound = it }
        check("Im lặng khi máy ở chế độ im lặng/rung", prefs.respectSilent) { prefs.respectSilent = it }

        val label = TextView(this)
        label.text = "Tên máy hiển thị trên khung ảnh:"
        label.setPadding(0, pad / 2, 0, 0)
        col.addView(label)
        val name = EditText(this)
        name.inputType = InputType.TYPE_CLASS_TEXT
        name.hint = PhotoProcessor.defaultDeviceName()
        name.setText(prefs.deviceName)
        col.addView(name)

        val tl = TextView(this)
        tl.text = "Tỉ lệ zoom tele (0 = tự động; thử 3.0 nếu không chuyển được sang tele):"
        tl.setPadding(0, pad / 2, 0, 0)
        col.addView(tl)
        val teleEt = EditText(this)
        teleEt.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        teleEt.setText(if (prefs.teleZoom > 0f) prefs.teleZoom.toString() else "0")
        col.addView(teleEt)

        val rep = TextView(this)
        rep.typeface = Typeface.MONOSPACE
        rep.textSize = 11f
        rep.setPadding(0, pad, 0, 0)
        rep.text = "— THÔNG TIN ỐNG KÍNH —\n" + repo.report()
        col.addView(rep)

        val sv = ScrollView(this)
        sv.addView(col)
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("Cài đặt · Xpan-Mode")
            .setView(sv)
            .setPositiveButton("Xong", null)
            .create()
            .also { dlg ->
                dlg.setOnDismissListener {
                    prefs.deviceName = name.text.toString().trim()
                    val tz = (teleEt.text.toString().replace(',', '.').toFloatOrNull() ?: 0f).coerceAtLeast(0f)
                    if (tz != prefs.teleZoom) {
                        prefs.teleZoom = tz
                        cam.teleZoomOverride = tz
                        openedLensId = null; maybeOpen()
                    }
                    if (prefs.saveRaw != oldRaw) { openedLensId = null; maybeOpen() }
                    hideBars()
                }
            }
            .show()
    }
}
