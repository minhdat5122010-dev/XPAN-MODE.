package com.xpanmode.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.text.InputType
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.abs
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : Activity(), CameraController.Callback {
    private companion object {
        /** Phơi sáng lâu: thời gian chụp tối đa (giây) nếu người dùng không bấm dừng. */
        const val LE_MAX_SECS = 60
    }
    private lateinit var prefs: Prefs
    private lateinit var repo: LensRepository
    private lateinit var cam: CameraController
    private lateinit var ui: CameraLayout
    private lateinit var root: FrameLayout
    private lateinit var review: ReviewView
    private lateinit var panel: EditPanel
    private lateinit var settings: SettingsView
    private var settingsOpen = false
    private var presets: MutableList<Preset> = ArrayList()

    private var entries: List<ZoomEntry> = emptyList()
    private var selected = 0
    private var userZoom = 1f
    private var dragStartZoom = 1f
    private var dragSnap = 0f
    private var info: CameraController.OpenInfo? = null
    private var openedLensId: String? = null
    private var surface: SurfaceTexture? = null
    private var ready = false
    private var resumed = false
    private var shooting = false
    private var lastUri: Uri? = null
    private var reviewUri: Uri? = null
    private var lastFramed = false
    private var reviewFramed = false
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var focusId = 0
    private var focusLoaded = false
    private val pendingSeqs = ArrayDeque<Int>()
    private var shotSeq = 0
    private var processingCount = 0
    /** Live Art: bộ ghi vòng khung ngắm + hàng đợi clip theo thứ tự các lần bấm chụp ảnh thường (null = lần đó không có Live). */
    private var liveRec: LiveArt.Recorder? = null
    private val liveQueue = kotlin.collections.ArrayDeque<LiveArt.Clip?>()
    private var pool: SoundPool? = null
    private var shutterId = 0
    private var shutterLoaded = false
    private var curtainId = 0
    private var curtainLoaded = false
    /** Tiếng màn chập riêng của giao diện X2D II (file `x2d_curtain.wav`). */
    private var x2dCurtainId = 0
    private var x2dCurtainLoaded = false
    private val curtainSeqs = HashSet<Int>()
    private var timerRunId = 0
    private var timerLoaded = false
    private var timerRunStream = 0
    private var tickId = 0
    private var tickLoaded = false
    private var lensFxActive = false
    private var lensFxStart = 0L
    private val finishLensFxRunnable = Runnable {
        ui.lensFx.hide()
        lensFxActive = false
    }
    private var freezeActive = false
    private var revealed = false
    private var processed = false
    private var resultBmp: Bitmap? = null
    // hiệu ứng chụp theo video: 1 âm bản -> 2 xám phủ kín -> 3 xám tan -> 4 giữ ảnh -> 5 ảnh bay về thumbnail
    private var phase = 0
    /** Đang chạy hiệu ứng riêng của HQ ghép khung (phase = 6). */
    private var hqFxMode = false
    /** Đang chạy hiệu ứng LUNA Night (dùng chung đường đi của hqFxMode, khác ở view hiệu ứng). */
    private var nightFxMode = false
    /** Đang chạy hiệu ứng phơi sáng lâu (cũng đi chung đường của hqFxMode). */
    private var leFxMode = false
    private fun fx(): MultiFx = if (leFxMode) ui.leFx else if (nightFxMode) ui.nightFx else ui.hqFx
    /** Tốc độ quay (rad/s) lọc EMA từ con quay: nhỏ = máy đang vững (chân máy). */
    private var gyroEma = 1f
    private val gyroListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            val v = e.values
            val m = Math.sqrt((v[0] * v[0] + v[1] * v[1] + v[2] * v[2]).toDouble()).toFloat()
            gyroEma += (m - gyroEma) * 0.08f
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }
    private var gyroOn = false
    private fun startGyro() {
        if (gyroOn || !prefs.night) return
        try {
            val sm = getSystemService(SENSOR_SERVICE) as SensorManager
            val g = sm.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
            if (g != null) { sm.registerListener(gyroListener, g, SensorManager.SENSOR_DELAY_GAME); gyroOn = true }
        } catch (_: Throwable) {}
    }
    private fun stopGyro() {
        if (!gyroOn) return
        try { (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(gyroListener) } catch (_: Throwable) {}
        gyroOn = false
        gyroEma = 1f
    }
    private var negStart = 0L
    private var captureDone = false
    private var frozenBmp: Bitmap? = null
    private var pendingThumb: Bitmap? = null
    private val negCheck = Runnable { tryEndNegative() }
    private val dockRunnable = Runnable { dock() }
    private val warned = HashSet<String>()

    /** Hiện/ẩn khay bộ lọc dọc có hiệu ứng trượt + mờ (ảnh xem trước cập nhật mỗi giây khi đang mở). */
    /** Bấm nút filter hoặc tab XPAN × ở mép phải: mở ngăn kéo (cuộn tới ô đang chọn) hoặc đóng lại. */
    private fun toggleTray() {
        if (trayOpen()) { setTray(false); return }
        setTray(true)
        if (!Body.x2d) ui.palette.scrollToSelected()
    }

    /** Khay bộ lọc đang mở: ngăn kéo bên phải (XPAN) hoặc thẻ + bảng màu riêng (X2D II). */
    private fun trayOpen(): Boolean = if (Body.x2d) ui.x2dFilterOpen else ui.drawerOpen

    /** Mở/đóng ngăn kéo bộ lọc bên phải: giao diện camera thu nhỏ sang trái, ngăn kéo trượt vào. */
    private fun setTray(show: Boolean) {
        if (Body.x2d) ui.setX2dFilter(show) else ui.setDrawer(show)
    }

    /** Cả ba bảng (ngăn kéo XPAN, danh sách popup X2D II, thẻ bảng màu X2D II) luôn cùng trạng thái. */
    private fun palettes() = listOf(ui.palette, ui.x2dList, ui.x2dPad)

    private fun spin(v: View, deg: Float) {
        android.animation.ObjectAnimator.ofFloat(v, View.ROTATION, v.rotation, v.rotation + deg).apply {
            duration = 380
            interpolator = android.view.animation.OvershootInterpolator(1.2f)
            start()
        }
    }

    // ------------------------------------------------------------------ vòng đời

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        prefs = Prefs(this)
        presets = prefs.presets.toMutableList()
        repo = LensRepository(this)
        cam = CameraController(this, repo, this)
        pool = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        ).build().also { p ->
            p.setOnLoadCompleteListener { _, id, status ->
                if (status == 0) { if (id == shutterId) shutterLoaded = true else if (id == curtainId) curtainLoaded = true else if (id == x2dCurtainId) x2dCurtainLoaded = true else if (id == focusId) focusLoaded = true else if (id == tickId) tickLoaded = true else if (id == timerRunId) timerLoaded = true }
            }
            shutterId = p.load(this, R.raw.shutter_classic, 1)
            curtainId = p.load(this, R.raw.curtain, 1)
            x2dCurtainId = p.load(this, R.raw.x2d_curtain, 1)
            focusId = p.load(this, R.raw.focus_click, 1)
            tickId = p.load(this, R.raw.filter_tick, 1)
            timerRunId = p.load(this, R.raw.selftimer_run, 1)
        }

        ui = CameraLayout(this)
        review = ReviewView(this)
        panel = EditPanel(this)
        panel.visibility = View.GONE
        root = FrameLayout(this)
        root.addView(ui, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        val dnp = resources.displayMetrics.density
        val plp = FrameLayout.LayoutParams(
            minOf((350 * dnp).toInt(), (resources.displayMetrics.widthPixels * 0.5f).toInt()),   // rộng hơn bản trước (320dp) một chút, mở rộng sang trái
            ViewGroup.LayoutParams.MATCH_PARENT, android.view.Gravity.END)
        plp.setMargins(0, (12 * dnp).toInt(), (12 * dnp).toInt(), (12 * dnp).toInt())
        root.addView(panel, plp)
        panel.bindBackdrop(ui)
        root.addView(review, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        settings = SettingsView(this, prefs) { repo.report() }
        root.addView(settings, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)
        hideBars()
        root.setOnApplyWindowInsetsListener { _, ins ->
            val cut = ins.displayCutout
            ui.setSafe(cut?.safeInsetLeft ?: 0, cut?.safeInsetRight ?: 0)
            settings.setSafe(cut?.safeInsetLeft ?: 0, cut?.safeInsetRight ?: 0)
            (panel.layoutParams as FrameLayout.LayoutParams).rightMargin = (cut?.safeInsetRight ?: 0) + (12 * resources.displayMetrics.density).toInt()
            panel.requestLayout()
            ins
        }

        setupUi()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) { updateTransform() }
        }, null)

        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) initCamera()
        else requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            initCamera()
            maybeOpen()
        } else {
            toast("Cần cấp quyền Camera để sử dụng Xpan-Mode")
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        hideBars()
        startGyro()
        if (ready) maybeOpen()
        if (Body.x2d) startHud()
    }

    override fun onPause() {
        resumed = false
        stopHud()
        liveRec?.reset()
        liveQueue.clear()
        if (::ui.isInitialized) ui.lever.reset(true)
        stopTimerSounds()
        stopGyro()
        cam.close()
        openedLensId = null
        info = null
        review.hide()
        releaseFreeze()
        super.onPause()
    }

    override fun onDestroy() {
        cam.release()
        exec.shutdown()
        pool?.release()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    private fun isVolumeKey(k: Int) = k == KeyEvent.KEYCODE_VOLUME_UP || k == KeyEvent.KEYCODE_VOLUME_DOWN

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (prefs.volumeShutter && isVolumeKey(keyCode) && review.visibility != View.VISIBLE && !settingsOpen) {
            if (event.repeatCount == 0) takePhoto()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (prefs.volumeShutter && isVolumeKey(keyCode) && review.visibility != View.VISIBLE && !settingsOpen) return true
        return super.onKeyUp(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (settingsOpen) settings.hide()
        else if (review.visibility == View.VISIBLE) review.hide()
        else if (trayOpen()) setTray(false)
        else if (panel.isOpen) panel.close()
        else super.onBackPressed()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------------------ khởi tạo camera / UI

    private fun initCamera() {
        repo.scan()
        entries = repo.entries()
        if (entries.isEmpty()) {
            toast("Không tìm thấy camera sau trên thiết bị")
            return
        }
        val key = prefs.entryKey
        selected = entries.indexOfFirst { it.key == key }.takeIf { it >= 0 }
            ?: entries.indices.minByOrNull { abs(entries[it].ratio - 1f) } ?: 0
        ui.ladder.labels = entries.map { it.ratioLabel }
        ui.pills.labels = entries.map { it.mmLabel }
        syncSel()
        ready = true
        loadLatestThumb()
        if (resumed) maybeOpen()
    }

    private fun setupUi() {
        X2dPalette.green = prefs.x2dGreen
        Body.x2d = prefs.x2d
        ui.x2d = prefs.x2d
        ui.classic = prefs.classic
        ui.light = prefs.light
        panel.applyTheme()
        ui.texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { surface = st; maybeOpen() }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { updateTransform() }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                cam.close(); surface = null; openedLensId = null; info = null
                return true
            }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {
                // khung hình đầu tiên của ống kính mới đã tới: lúc này mới lộ khung ngắm thật (tránh thấy hình cũ/đen)
                if (fxAwaitFrame) { fxAwaitFrame = false; main.removeCallbacks(frameTimeoutRunnable); completeFx() }
            }
        }
        ui.texture.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateTransform() }

        val scaleDet = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val mz = info?.maxZoom ?: 1f
                userZoom = (userZoom * d.scaleFactor).coerceIn(1f, mz)
                cam.setZoom(userZoom)
                val lid = info?.lens?.id
                val idx = entries.indices.filter { entries[it].lens.id == lid }
                    .minByOrNull { abs(entries[it].zoom - userZoom) }
                if (idx != null && idx != selected) { selected = idx; syncSel() }
                updateZoomLabels()
                return true
            }
        })
        val tapDet = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val i = info ?: return true
                val tw = ui.texture.width.toFloat()
                val th = ui.texture.height.toFloat()
                if (tw <= 0f || th <= 0f) return true
                val band = (i.preview.width.toFloat() / i.preview.height / Body.ratio).coerceAtMost(1f)
                cam.focusAt(e.x / tw, e.y / th, band, jpegRotation(i) == 180)
                ui.focusBox.showAt(e.x, e.y)
                return true
            }
        })
        ui.texture.setOnTouchListener { _, e ->
            scaleDet.onTouchEvent(e)
            if (!scaleDet.isInProgress && e.pointerCount == 1) tapDet.onTouchEvent(e)
            true
        }

        ui.ladder.onSelect = { selectEntry(it) }
        ui.pills.onSelect = { selectEntry(it) }
        // vuốt dọc trên vùng chọn tiêu cự: thu phóng liên tục trong ống kính hiện tại (không đổi camera)
        for (zd in listOf(ui.ladder.zoomDrag, ui.pills.zoomDrag)) {
            zd.onStart = { dragStartZoom = userZoom; dragSnap = 0f }
            zd.onMove = { up -> zoomDragTo(up) }
            zd.onEnd = { ui.zoomHud.hideSoon() }
        }
        ui.ev.onChange = { v ->
            ui.ev.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            prefs.cam = prefs.cam.copy(ev = v)
            cam.setParams(prefs.cam)
            panel.setEv(v)
        }
        panel.onCam = { c ->
            prefs.cam = c
            cam.setParams(c)
            if (ui.ev.value != c.ev) ui.ev.value = c.ev
        }
        panel.onAdjust = { a ->
            prefs.adjust = a
            applyFilter()
        }
        panel.onReset = {
            prefs.adjust = Adjust()
            prefs.cam = CamParams()
            applyCam()
            panel.setState(prefs.cam, prefs.adjust)
            applyFilter()
        }
        panel.onSave = { promptSavePreset() }
        // ngăn kéo bảng màu: chọn bộ lọc, bảng chạm Tone × Color, thanh Palette (cường độ bộ lọc)
        for (pp in palettes()) {
            pp.onItem = { i -> filterTick(); selectFilter(i) }
            pp.onItemLong = { i -> onFilterLong(i) }
            pp.onPad = { c, t ->
                prefs.palette = PaletteSel(tone = t, color = c)
                applyFilter()
            }
            pp.onStrength = { v ->
                prefs.filterStrength = v
                applyFilter()
            }
        }
        // ngăn kéo không tự đóng khi chạm ra ngoài / bấm chụp; thoát bằng mũi tên back
        ui.back.setOnClickListener { setTray(false) }
        panel.onClose = { panel.close() }
        ui.edit.setOnClickListener {
            if (panel.isOpen) panel.close()
            else {
                setTray(false)
                panel.setState(prefs.cam, prefs.adjust)
                panel.open()
            }
        }
        ui.shutter.setOnClickListener { takePhoto() }
        // hẹn giờ kiểu cần gạt: tiếng dây cót chạy suốt lúc đếm ngược, hết giờ thì chụp
        ui.lever.listener = object : TimerLeverView.Listener {
            override fun onStart(secs: Float) { startTimerLoop() }
            override fun onEndSoon() { fadeTimerLoop() }
            override fun onFire() {
                stopTimerSounds()
                takePhoto()
            }
            override fun onCancel() { stopTimerSounds() }
        }
        ui.setTimerMode(prefs.timer)
        liveRec = LiveArt.Recorder(
            active = { cam.liveMode && prefs.liveArt && resumed && !prefs.hq && !prefs.night && !prefs.longExp },
            rotationNow = { info?.let { jpegRotation(it) } ?: 0 }
        )
        cam.liveSink = liveRec
        // chạm: mở thẳng trong ứng dụng Thư viện; nhấn giữ: xem khung trắng + thông số trong app
        ui.thumb.setOnClickListener { openAlbum() }
        ui.thumb.setOnLongClickListener { lastUri?.let { showReview(it) }; true }
        ui.thumb.pressFeedback(0.9f)
        ui.toggle.setOnClickListener {
            prefs.classic = !prefs.classic
            spin(ui.toggle, 180f)
            ui.animate().cancel()
            ui.animate().alpha(0f).setDuration(140).withEndAction {
                ui.classic = prefs.classic
                panel.applyTheme()
                ui.animate().alpha(1f).setDuration(260).start()
            }.start()
        }
        ui.gear.setOnClickListener { spin(ui.gear, 60f); openSettings() }
        // flash: tắt -> bật (chớp khi chụp) -> luôn bật (đèn sáng liên tục)
        ui.flash.state = prefs.flash
        ui.flash.setOnClickListener {
            if (!cam.hasFlash()) { toast("Ống kính đang chọn không có đèn flash"); return@setOnClickListener }
            prefs.flash = (prefs.flash + 1) % 3
            ui.flash.state = prefs.flash
            cam.applyFlashMode(prefs.flash)
            toast(when (prefs.flash) { 0 -> "Flash: tắt"; 1 -> "Flash: bật (đèn chớp khi chụp)"; else -> "Flash: luôn bật (đèn sáng liên tục)" })
        }
        // đổi giao diện sáng (trắng) / tối
        ui.theme.setOnClickListener {
            prefs.light = !prefs.light
            spin(ui.theme, 180f)
            ui.animate().cancel()
            ui.animate().alpha(0f).setDuration(140).withEndAction {
                ui.light = prefs.light
                panel.applyTheme()
                ui.animate().alpha(1f).setDuration(260).start()
            }.start()
        }
        ui.filterBtn.setOnClickListener { toggleTray() }
        ui.drawer.onTab = { toggleTray() }
        ui.wm.setOnClickListener { showCaptureMenu() }
        // X2D II: phím giả nằm đè lên nút gốc (trong suốt) và chuyển cú chạm cho nút gốc; bánh xe trên tay cầm + thanh EV trên màn hình
        ui.keyFilter.setOnClickListener { ui.filterBtn.performClick() }
        ui.keyTune.setOnClickListener { ui.edit.performClick() }
        ui.keyAlbum.setOnClickListener { openAlbum() }
        ui.keyAlbum.setOnLongClickListener { lastUri?.let { showReview(it) }; true }
        // hai nút ở cạnh trái thân máy: Cài đặt (viên thuốc dọc) và Flash (nút tròn); chuyển cú chạm cho nút gốc
        ui.sideGear.setOnClickListener { ui.gear.performClick() }
        ui.sideFlash.setOnClickListener {
            ui.flash.performClick()
            ui.sideFlash.flash = prefs.flash
        }
        ui.sideFlash.flash = prefs.flash
        ui.dial.onStep = { dir -> dialStep(dir) }
        // nút chế độ dưới bánh xe (bấm mở danh sách chọn nhanh) + nút xám chấm đỏ đổi bánh xe EV ⇄ MF
        ui.modeBtn.setOnClickListener { toggleModePopup() }
        ui.modePopup.onPick = { i -> pickMode(i) }
        ui.modePopup.onDismiss = { ui.modeBtn.open = false }
        ui.dialSwitch.setOnClickListener {
            prefs.dialFocus = !prefs.dialFocus
            refreshHud()          // chỉ đổi chữ EV / MF trên bánh xe + chấm đỏ, không hiện thông báo
        }
        ui.dialSwitch.mf = prefs.dialFocus
        refreshModeUi()
        ui.hud.onEv = { v -> ui.ev.value = v; ui.ev.onChange?.invoke(v) }
        if (Body.x2d) startHud()
        ui.night.setOnClickListener {
            if (shooting) return@setOnClickListener
            val st = Prefs.NIGHT_STEPS
            prefs.nightSecs = st[(st.indexOf(prefs.nightSecs) + 1) % st.size]
            ui.night.secs = prefs.nightSecs
        }
        updateNightBadge()
        ui.frame.grid = prefs.grid
        buildTray()
        applyFilter()

        review.onClose = { review.hide() }
        review.onOpen = {
            reviewUri?.let {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(it, "image/jpeg").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }
        }
        review.onSaveFrame = {
            val u = reviewUri
            if (u != null && reviewFramed) toast("Ảnh này đã có khung rồi")
            else if (u != null) exec.execute {
                var err: String? = null
                val r = try { PhotoProcessor.saveFramed(this, u, deviceName(), prefs.watermark) } catch (t: Throwable) { err = PhotoProcessor.errText(t); null }
                runOnUiThread { toast(if (r != null) "Đã lưu ảnh có khung vào Pictures/Xpan-Mode" else "Không lưu được ảnh khung: $err") }
            }
        }
    }

    /** Dựng danh sách bộ lọc trong ngăn kéo bảng màu (bộ lọc có sẵn + bộ lọc của tôi). */
    private fun buildTray() {
        val all = allFilters()
        x2dItems = all.mapIndexed { i, f -> PaletteItem(f.name, captionFor(f, i), filterAccent(f)) }
        for (pp in palettes()) {
            pp.setItems(x2dItems, XpanFilter.all.size)
            pp.setState(prefs.filter, prefs.palette.tone, prefs.palette.color, prefs.filterStrength)
        }
        refreshFilterCard()
    }

    private var x2dItems: List<PaletteItem> = emptyList()

    /** Thẻ chọn bộ lọc của X2D II hiện đúng tên / phụ đề / thanh màu của bộ lọc đang chọn. */
    private fun refreshFilterCard() {
        val it = x2dItems.getOrNull(prefs.filter) ?: return
        ui.x2dCard.setItem(it.name, it.caption, it.accent)
    }

    private fun captionFor(f: XpanFilter, i: Int): String = if (i >= XpanFilter.all.size) "Của tôi" else when (f.name) {
        "Original" -> "Gốc"
        "Natural" -> "Tự nhiên"
        "Portrait" -> "Chân dung"
        "Landscape" -> "Phong cảnh"
        "XPan Chrome" -> "Chrome"
        "Golden Hour" -> "Hoàng hôn"
        "Mono" -> "Đen trắng"
        "Fuji Film" -> "Fuji"
        "Leica M9" -> "Leica"
        "Vivo Zeiss" -> "Trong trẻo"
        else -> ""
    }

    private fun allFilters(): List<XpanFilter> = XpanFilter.all + presets.map { it.look }

    private fun baseFilter(): XpanFilter {
        val l = allFilters()
        return l[prefs.filter.coerceIn(0, l.size - 1)]
    }

    private fun selectFilter(i: Int) {
        val fromPreset = prefs.filter >= XpanFilter.all.size
        prefs.filter = i
        prefs.adjust = Adjust()
        // chọn bộ lọc mới: Tone / Color về giữa, Palette (cường độ) về 100
        prefs.palette = PaletteSel()
        prefs.filterStrength = 100
        val k = i - XpanFilter.all.size
        if (k >= 0 && k < presets.size) {
            prefs.cam = presets[k].cam
            // bộ lọc tự lưu kèm bảng màu thì nạp luôn bảng màu đó
            presets[k].look.palette?.let { prefs.palette = it }
            applyCam()
        } else if (fromPreset) {
            // rời bộ lọc đã lưu để sang bộ lọc có sẵn: trả thông số camera (EV, tốc độ, ISO, WB, nét) về mặc định
            prefs.cam = CamParams()
            applyCam()
        }
        panel.setState(prefs.cam, prefs.adjust)
        for (pp in palettes()) pp.setState(i, prefs.palette.tone, prefs.palette.color, prefs.filterStrength)
        applyFilter()
    }

    private fun applyCam() {
        cam.setParams(prefs.cam)
        if (ui.ev.max >= ui.ev.min) ui.ev.value = prefs.cam.ev.coerceIn(ui.ev.min, ui.ev.max)
    }

    private fun promptName(title: String, initial: String, ok: (String) -> Unit) {
        val dn = resources.displayMetrics.density
        val et = EditText(this)
        et.setSingleLine()
        et.setText(initial)
        et.setSelectAllOnFocus(true)
        val box = FrameLayout(this)
        val p = (20 * dn).toInt()
        box.setPadding(p, p / 2, p, 0)
        box.addView(et)
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("Lưu") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) ok(n)
            }
            .setNegativeButton("Huỷ", null)
            .create()
            .also { it.setOnDismissListener { hideBars() }; it.show() }
    }

    /** Lưu toàn bộ chỉnh sửa hiện tại (màu + thông số camera) thành một bộ lọc có tên. */
    private fun promptSavePreset() {
        promptName("Tên bộ lọc mới", "Bộ lọc ${presets.size + 1}") { n ->
            val p = Preset(java.util.UUID.randomUUID().toString(), n, curFilter().copy(name = n), prefs.cam)
            presets.add(p)
            prefs.presets = presets
            buildTray()
            selectFilter(XpanFilter.all.size + presets.size - 1)
            toast("Đã lưu bộ lọc \"$n\". Giữ vào tên bộ lọc để đổi tên hoặc xoá.")
        }
    }

    /** Giữ vào một bộ lọc: đổi tên / ghi đè / xoá (chỉ với bộ lọc tự lưu). */
    private fun onFilterLong(i: Int) {
        val k = i - XpanFilter.all.size
        if (k < 0 || k >= presets.size) {
            toast("Bộ lọc có sẵn không đổi tên được. Bấm nút Chỉnh sửa rồi \"Lưu thành bộ lọc\" để tạo bộ lọc riêng.")
            return
        }
        val p = presets[k]
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(p.name)
            .setItems(arrayOf("Đổi tên", "Ghi đè bằng chỉnh sửa hiện tại", "Xoá bộ lọc")) { _, which ->
                when (which) {
                    0 -> promptName("Đổi tên bộ lọc", p.name) { n ->
                        presets[k] = p.copy(name = n, look = p.look.copy(name = n))
                        prefs.presets = presets
                        buildTray()
                        applyFilter()
                    }
                    1 -> if (prefs.filter != i) toast("Hãy chọn bộ lọc này trước, chỉnh sửa rồi mới ghi đè.")
                    else {
                        presets[k] = p.copy(look = curFilter().copy(name = p.name), cam = prefs.cam)
                        prefs.presets = presets
                        prefs.adjust = Adjust()
                        prefs.filterStrength = 100
                        buildTray()
                        panel.setState(prefs.cam, prefs.adjust)
                        applyFilter()
                        toast("Đã cập nhật bộ lọc \"${p.name}\"")
                    }
                    2 -> AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                        .setTitle("Xoá \"${p.name}\"?")
                        .setPositiveButton("Xoá") { _, _ ->
                            presets.removeAt(k)
                            prefs.presets = presets
                            if (prefs.filter == i) { prefs.filter = 0; prefs.adjust = Adjust(); prefs.cam = CamParams(); applyCam() }
                            else if (prefs.filter > i) prefs.filter -= 1
                            buildTray()
                            panel.setState(prefs.cam, prefs.adjust)
                            applyFilter()
                        }
                        .setNegativeButton("Huỷ", null)
                        .create().also { it.setOnDismissListener { hideBars() }; it.show() }
                }
            }
            .create()
            .also { it.setOnDismissListener { hideBars() }; it.show() }
    }

    private fun applyFilter() {
        val f = baseFilter()
        ui.filterBtn.label = f.name
        for (pp in palettes()) pp.setSelected(prefs.filter)
        refreshFilterCard()
        setTexturePaint(false)
    }

    private fun setTexturePaint(invert: Boolean) {
        val f = curFilter()
        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(if (invert) XpanFilter.invertMatrix() else f.previewMatrix())
        ui.texture.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
        if (!invert) panel.setBackdropFilter(ColorMatrixColorFilter(f.previewMatrix()))
    }

    /** Vuốt lên = phóng to, xuống = thu nhỏ; mỗi ~150dp vuốt thì gấp đôi / giảm nửa. Giới hạn theo độ phân giải của ống kính. */
    private fun zoomDragTo(upPx: Float) {
        val i = info ?: return
        if (lensFxActive || i.lens.id != entries.getOrNull(selected)?.lens?.id) return
        val dn = resources.displayMetrics.density
        var z = (dragStartZoom * Math.pow(2.0, (upPx / (150f * dn)).toDouble()).toFloat()).coerceIn(1f, i.maxZoom)
        // hít vào các mốc tự nhiên của ống kính (1x gốc, mốc crop 2x...) để dễ quay về tiêu cự chuẩn
        val marks = entries.filter { it.lens.id == i.lens.id }.map { it.zoom }.filter { it <= i.maxZoom }
        val snap = marks.minByOrNull { abs(it - z) }
        if (snap != null && abs(snap - z) / snap < 0.035f) {
            z = snap
            if (dragSnap != snap) { dragSnap = snap; ui.pills.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
        } else {
            dragSnap = 0f
        }
        if (abs(z - userZoom) > 0.0005f) {
            userZoom = z
            cam.setZoom(z)
            val idx = entries.indices.filter { entries[it].lens.id == i.lens.id }
                .minByOrNull { abs(entries[it].zoom - userZoom) }
            if (idx != null && idx != selected) { selected = idx; syncSel() }
            updateZoomLabels()
        }
        val e = entries.getOrNull(selected) ?: return
        val ratio = e.ratio * userZoom / e.zoom
        ui.zoomHud.show("${repo.fmtRatio(ratio)}×  ·  ${(i.lens.eq35 * userZoom).roundToInt()}mm")
    }

    /** Khi đang ở giữa hai mốc (thu phóng liên tục) thì nút tiêu cự hiện số thực; đúng mốc thì về nhãn gốc. */
    private fun updateZoomLabels() {
        val i = info
        val e = entries.getOrNull(selected)
        if (i == null || e == null || i.lens.id != e.lens.id || abs(userZoom - e.zoom) < 0.02f) {
            ui.pills.liveLabel = null
            ui.ladder.liveLabel = null
            return
        }
        ui.pills.liveLabel = (i.lens.eq35 * userZoom).roundToInt().toString()
        ui.ladder.liveLabel = repo.fmtRatio(e.ratio * userZoom / e.zoom)
    }

    private fun syncSel() {
        ui.ladder.selected = selected
        ui.pills.selected = selected
    }

    // ------------------------------------------------------------------ mở camera / chọn ống kính

    private fun maybeOpen() {
        if (!ready || !resumed || settingsOpen || entries.isEmpty()) return
        val st = surface ?: return
        val e = entries[selected]
        userZoom = e.zoom
        cam.trailMode = false   // Thợ săn ánh sáng đã gỡ khỏi menu
        cam.nightMode = (prefs.night || prefs.longExp) && !prefs.hq
        cam.rawHq = prefs.hq && prefs.hqRaw
        cam.upMode = prefs.hq && prefs.up && !prefs.hqRaw
        cam.upDeviceIsp = prefs.upDeviceIsp
        cam.flashMode = prefs.flash
        cam.liveMode = prefs.liveArt && !prefs.hq && !prefs.night && !prefs.longExp   // luồng YUV cho Live Art (đổi chế độ -> mở lại camera)
        cam.multiFrame = prefs.hq     // HQ: chụp 50MP thật nếu máy cho, không thì ghép nhiều khung
        cam.open(e.lens, st, repo.previewSize(e.lens), prefs.saveRaw, e.ratio / e.zoom, prefs.hq)
    }

    /** Chụp đúng hình đang thấy trên khung ngắm (đã xoay/cắt theo ma trận của TextureView). */
    private fun grabPreview(): Bitmap? {
        val tv = ui.texture
        val w = tv.width
        val h = tv.height
        if (w <= 0 || h <= 0) return null
        return try {
            val raw = tv.getBitmap(w, h) ?: return null
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val m = Matrix()
            tv.getTransform(m)
            Canvas(out).drawBitmap(raw, m, Paint(Paint.FILTER_BITMAP_FLAG))
            raw.recycle()
            out
        } catch (t: Throwable) {
            null
        }
    }

    /** Mỗi lần bấm chụp ảnh thường: bắt đầu một clip Live Art (hoặc null) và xếp hàng cho onShot gắn vào ảnh. */
    private fun liveShutter(rotation: Int) {
        liveQueue.addLast(if (prefs.liveArt) liveRec?.shutter(rotation) else null)
    }

    private fun fxNodes(): List<LensFxNode> = entries.map { e ->
        val eq = e.lens.eq35 * e.zoom
        val title = when {
            e.zoom > 1f -> "${e.ratioLabel}× CROP"
            e.ratio < 0.95f -> "ULTRA WIDE"
            e.ratio < 1.7f -> "WIDE"
            else -> "TELEPHOTO"
        }
        val ap = if (e.lens.aperture > 0f) String.format(Locale.US, " · f/%.1f", e.lens.aperture) else ""
        LensFxNode(title, "${eq.roundToInt()}mm$ap", e.ratioLabel, eq)
    }

    private fun startLensFx(from: Int, to: Int) {
        val frame: Bitmap? = grabPreview()
        main.removeCallbacks(finishLensFxRunnable)
        main.removeCallbacks(completeLensFxRunnable)
        main.removeCallbacks(frameTimeoutRunnable)
        fxAwaitFrame = false
        ui.lensFx.start(fxNodes(), from, to, frame, ColorMatrixColorFilter(curFilter().previewMatrix()), lensLatencyMs)
        lensFxStart = SystemClock.uptimeMillis()
        lensFxActive = true
    }

    private val completeLensFxRunnable = Runnable { ui.lensFx.complete() }
    private var fxAwaitFrame = false
    /** Độ trễ thực đo được từ lúc bấm đến khi có khung hình mới (ms); animation lần sau kéo dài bám theo con số này. */
    private var lensLatencyMs = 600L
    private val frameTimeoutRunnable = Runnable {
        if (fxAwaitFrame) { fxAwaitFrame = false; completeFx() }
    }

    /**
     * Camera/zoom mới đã cấu hình xong: chờ KHUNG HÌNH ĐẦU TIÊN của nó (onReady chạy trước khi có hình, nếu lộ ngay sẽ thấy
     * hình cũ hoặc màn đen rồi mới nhảy sang cam mới). Có hình thì hiệu ứng mới chạy nốt và lộ khung ngắm thật.
     */
    private fun finishLensFx() {
        if (!lensFxActive || fxAwaitFrame) return
        fxAwaitFrame = true
        main.removeCallbacks(frameTimeoutRunnable)
        main.postDelayed(frameTimeoutRunnable, 350)   // dự phòng nếu không nhận được khung hình
    }

    private fun completeFx() {
        if (!lensFxActive) return
        val elapsed = SystemClock.uptimeMillis() - lensFxStart
        lensLatencyMs = ((lensLatencyMs + elapsed) / 2).coerceIn(250L, 1000L)
        val wait = max(0L, 90L - elapsed)
        main.removeCallbacks(completeLensFxRunnable)
        main.postDelayed(completeLensFxRunnable, wait)
        main.removeCallbacks(finishLensFxRunnable)
        main.postDelayed(finishLensFxRunnable, wait + 250)
    }

    private fun selectEntry(i: Int) {
        if (i !in entries.indices) return
        val e = entries[i]
        if (i == selected && openedLensId == e.lens.id) {
            // chạm lại đúng nút đang chọn sau khi đã vuốt thu phóng: về tiêu cự gốc của nút đó
            if (abs(userZoom - e.zoom) > 0.02f) {
                userZoom = e.zoom
                cam.setZoom(userZoom)
                updateZoomLabels()
                ui.zoomHud.hideSoon(0L)
            }
            return
        }
        val prev = selected
        startLensFx(prev, i)
        ui.pills.liveLabel = null
        ui.ladder.liveLabel = null
        selected = i
        prefs.entryKey = e.key
        syncSel()
        if (openedLensId == e.lens.id) {
            userZoom = e.zoom
            cam.setZoom(userZoom)
            main.postDelayed({ finishLensFx() }, 120)
        } else {
            openedLensId = null
            maybeOpen()
            main.postDelayed({ finishLensFx() }, 6000)   // dự phòng nếu mở camera quá lâu / lỗi
        }
    }

    override fun onReady(info: CameraController.OpenInfo) {
        this.info = info
        openedLensId = info.lens.id
        ui.ev.min = info.evMin
        ui.ev.max = info.evMax
        ui.ev.step = info.evStep
        val evNow = prefs.cam.ev.coerceIn(info.evMin, info.evMax)
        if (evNow != prefs.cam.ev) prefs.cam = prefs.cam.copy(ev = evNow)
        ui.ev.value = evNow
        panel.setCaps(info.caps, info.evMin, info.evMax, info.evStep)
        panel.setState(prefs.cam, prefs.adjust)
        cam.setParams(prefs.cam)
        if (info.viaZoom && warned.add(info.lens.id)) {
            toast("Máy chặn app bên thứ ba mở ống kính ${info.lens.eq35.toInt()}mm (ID ${info.lens.id}); " +
                "đang dùng zoom của camera chính nên có thể chỉ là crop, không phải tele thật.")
        }
        updateTransform()
        cam.setZoom(userZoom)
        updateZoomLabels()
        updateHqNote()
        finishLensFx()
    }

    override fun onError(msg: String) {
        curtainSeqs.clear()
        pendingSeqs.clear()
        toast(msg)
        finishLensFx()
        releaseFreeze()
    }

    /** Tiếng chỉ phát theo âm lượng đa phương tiện; tuỳ chọn im lặng khi máy ở chế độ im lặng/rung. */
    /** Tiếng "tạch" như bấm nấc máy ảnh cơ (kèm rung nhẹ) mỗi khi chọn / lướt qua một bộ lọc. */
    private fun filterTick() {
        (if (Body.x2d) ui.x2dCard else ui.palette as View).performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
        if (prefs.sound && tickLoaded && soundAllowed()) {
            pool?.play(tickId, 0.7f, 0.7f, 1, 0, 0.96f + Math.random().toFloat() * 0.1f)
        }
    }

    private fun hitView(v: View, x: Int, y: Int): Boolean {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return x >= loc[0] && x <= loc[0] + v.width && y >= loc[1] && y <= loc[1] + v.height
    }

    /** Chạm ra ngoài khay bộ lọc thì khay tự ẩn (chạm vẫn được chuyển tiếp xuống phía dưới). */
    private var swallowTouch = false

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        // đang mở bảng chỉnh thông số: chạm ra ngoài thì đóng bảng (và nuốt cú chạm đó để không lỡ chụp / lấy nét)
        if (::ui.isInitialized && ::panel.isInitialized) {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                swallowTouch = false
                if (panel.isOpen) {
                    val x = ev.rawX.toInt()
                    val y = ev.rawY.toInt()
                    // nút chỉnh sửa tự bật/tắt bảng của nó
                    if (!hitView(panel, x, y) && !hitView(ui.edit, x, y)) {
                        panel.close()
                        swallowTouch = true
                    }
                }
            }
            if (swallowTouch) {
                if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) swallowTouch = false
                return true
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun soundAllowed(): Boolean {
        if (!prefs.respectSilent) return true
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        return am.ringerMode == AudioManager.RINGER_MODE_NORMAL
    }

    override fun onFocus(ok: Boolean) {
        ui.focusBox.lock(ok)
        if (ok && prefs.focusSound && focusLoaded && soundAllowed()) pool?.play(focusId, 0.9f, 0.9f, 1, 0, 1f)
    }

    @Suppress("DEPRECATION")
    private fun dispRot(): Int = windowManager.defaultDisplay.rotation

    private fun jpegRotation(i: CameraController.OpenInfo): Int =
        (i.sensorOrientation - dispRot() * 90 + 360) % 360

    private fun updateTransform() {
        val i = info ?: return
        val tv = ui.texture
        val vw = tv.width.toFloat()
        val vh = tv.height.toFloat()
        if (vw == 0f || vh == 0f) return
        val rot = dispRot()
        val matrix = Matrix()
        val viewRect = RectF(0f, 0f, vw, vh)
        val bufRect = RectF(0f, 0f, i.preview.height.toFloat(), i.preview.width.toFloat())
        val cx = viewRect.centerX()
        val cy = viewRect.centerY()
        if (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270) {
            bufRect.offset(cx - bufRect.centerX(), cy - bufRect.centerY())
            matrix.setRectToRect(viewRect, bufRect, Matrix.ScaleToFit.FILL)
            val scale = max(vh / i.preview.height, vw / i.preview.width)
            matrix.postScale(scale, scale, cx, cy)
            matrix.postRotate(90f * (rot - 2), cx, cy)
        } else if (rot == Surface.ROTATION_180) {
            matrix.postRotate(180f, cx, cy)
        }
        tv.setTransform(matrix)
    }

    // ------------------------------------------------------------------ chụp ảnh

    private fun curFilter() =
        // Palette (cường độ) × trục Color (khuếch đại / giảm chất riêng của bộ lọc), rồi mới tới chỉnh tay + Tone / Color
        baseFilter().scaled(prefs.filterStrength / 100f * prefs.palette.colorCharacter).adjusted(prefs.adjust).withPalette(prefs.palette)

    private val failSafe = Runnable { releaseFreeze() }

    private val NEG_MIN = 1050L      // giữ âm bản tối thiểu (video: ~1,07s)
    private val NEG_MAX = 4000L      // tối đa nếu chụp chậm
    private val GREY_IN = 200L       // âm bản -> xám phẳng
    private val GREY_OUT = 600L      // xám tan dần để lộ ảnh
    private val HOLD = 650L          // giữ ảnh trước khi bay về thumbnail
    private val FLY = 330L           // ảnh thu nhỏ bay về thumbnail

    /**
     * Tiếng chụp của chế độ "màn chập": giao diện X2D II dùng tiếng màn chập riêng (hai tiếng cách nhau ~0,4 s: mở rồi đóng màn trập),
     * giao diện XPAN giữ tiếng cũ. [force] = true khi nghe thử trong hộp thoại chọn hiệu ứng (đã kiểm tra bật âm thanh bên ngoài).
     */
    private fun playCurtainSound(force: Boolean = false) {
        if (!force && !(prefs.sound && soundAllowed())) return
        if (Body.x2d && x2dCurtainLoaded) pool?.play(x2dCurtainId, 1f, 1f, 1, 0, 1f)
        else if (curtainLoaded) pool?.play(curtainId, 1f, 1f, 1, 0, 1f)
    }

    /** Chế độ "màn chập": chụp ngay, không đóng băng/rửa film; màn chập quét xuống + tiếng; bấm liên tiếp được. */
    private fun takePhotoCurtain() {
        val i = info ?: return
        if (lensFxActive || phase != 0) return
        if (curtainSeqs.size >= 4) return              // tối đa 1 tấm đang chụp + 3 tấm xếp hàng
        if (ui.texture.width <= 0 || ui.texture.height <= 0) return
        shotSeq++
        pendingSeqs.addLast(shotSeq)
        curtainSeqs.add(shotSeq)
        playCurtainSound()
        ui.shutter.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        cam.appIsp = prefs.appIsp
        liveShutter(jpegRotation(i))
        cam.capture(jpegRotation(i))
        ui.curtain.fire()
    }

    /** HQ ghép 5 khung: hiệu ứng riêng (khung nhoè + 5 cột rõ dần theo từng khung, rồi tiến trình ghép), thay cho rửa film/màn chập. */
    private fun takePhotoHq() {
        val i = info ?: return
        if (shooting || lensFxActive || phase != 0) return
        if (ui.texture.width <= 0 || ui.texture.height <= 0) return
        shooting = true
        revealed = false
        processed = false
        resultBmp = null
        captureDone = false
        pendingThumb = null
        shotSeq++
        pendingSeqs.addLast(shotSeq)
        ui.shutter.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        cam.appIsp = prefs.appIsp
        cam.upDeviceIsp = prefs.upDeviceIsp
        cam.capture(jpegRotation(i))
        main.removeCallbacks(failSafe)
        main.postDelayed(failSafe, if (cam.upMode) 70000L else 40000L)
        val frozen: Bitmap? = grabPreview()
        frozenBmp = frozen
        if (frozen != null) {
            hqFxMode = true
            phase = 6
            ui.setChromeHidden(true)
            ui.hqFx.start(frozen, cam.mfFrames)
        } else main.postDelayed({ if (phase == 0) shooting = false }, 400)
    }

    /** Phơi sáng lâu: chụp liên tục tối đa LE_MAX_SECS giây, ảnh cộng dồn hiện trực tiếp; bấm nút chụp lần nữa để dừng và xử lí. */
    private fun takePhotoLongExp() {
        val i = info ?: return
        if (shooting || lensFxActive || phase != 0) return
        if (ui.texture.width <= 0 || ui.texture.height <= 0) return
        shooting = true
        revealed = false
        processed = false
        resultBmp = null
        captureDone = false
        pendingThumb = null
        shotSeq++
        pendingSeqs.addLast(shotSeq)
        val frozen: Bitmap? = grabPreview()
        frozenBmp = frozen
        if (prefs.sound && shutterLoaded && soundAllowed()) pool?.play(shutterId, 1f, 1f, 1, 0, 1f)
        cam.appIsp = prefs.appIsp
        cam.captureLongExp(jpegRotation(i), LE_MAX_SECS)
        main.removeCallbacks(failSafe)
        main.postDelayed(failSafe, LE_MAX_SECS * 1000L + 45000L)
        if (frozen != null) {
            hqFxMode = true
            leFxMode = true
            phase = 6
            ui.setChromeHidden(true)
            ui.leFx.start(frozen)
        } else main.postDelayed({ if (phase == 0) shooting = false }, 400)
    }

    /** Bật/tắt phơi sáng lâu: không đi cùng HQ và thiếu sáng; mở lại camera để đổi số bộ đệm ảnh. */
    private fun toggleLongExp() {
        val on = !prefs.longExp
        if (on) {
            if (prefs.hq) { prefs.hq = false; prefs.hqRaw = false; prefs.up = false; updateHqNote(); toast("Đã tắt chế độ chất lượng cao (phơi sáng lâu dùng bộ ghép riêng)") }
            if (prefs.night) { prefs.night = false; updateNightBadge(); stopGyro(); toast("Đã tắt thiếu sáng (không đi cùng phơi sáng lâu)") }
            if (prefs.liveArt) { prefs.liveArt = false; liveRec?.reset(); updateHqNote(); toast("Đã tắt Live Art (không đi cùng Night ART)") }
        }
        prefs.longExp = on
        openedLensId = null
        maybeOpen()
        if (on) {
            ui.showModeSplash("LONG EXPOSURE")
            toast("Đặt máy lên chân đế hoặc chỗ vững, bấm chụp rồi bấm lại để dừng")
        }
    }

    /** Hệ số cần thêm sáng so với khung ngắm: độ sáng tuyến tính trung bình của khung xem trước so với mục tiêu ~0,20 (1..16). */
    private fun nightBoost(frozen: Bitmap?): Float {
        if (frozen == null) return 3f
        val w = frozen.width
        val h = frozen.height
        val sx = max(1, w / 48)
        val sy = max(1, h / 18)
        var sum = 0.0
        var n = 0
        var y = sy / 2
        while (y < h) {
            var x = sx / 2
            while (x < w) {
                val c = frozen.getPixel(x, y)
                val l = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0
                sum += Math.pow(l, 2.2)
                n++
                x += sx
            }
            y += sy
        }
        val mean = if (n > 0) sum / n else 0.05
        return (0.20 / max(mean, 0.0001)).toFloat().coerceIn(1f, 16f)
    }

    /** LUNA Night: đóng băng khung ngắm, chụp liên tục `nightSecs` giây (đếm ngược), ghép streaming rồi tone mapping thiếu sáng. */
    private fun takePhotoNight() {
        val i = info ?: return
        if (shooting || lensFxActive || phase != 0) return
        if (ui.texture.width <= 0 || ui.texture.height <= 0) return
        shooting = true
        revealed = false
        processed = false
        resultBmp = null
        captureDone = false
        pendingThumb = null
        shotSeq++
        pendingSeqs.addLast(shotSeq)
        // chế độ đêm của máy (nếu bật trong Cài đặt và hãng cho phép) thay cho bộ ghép LUNA Night
        val useExt = prefs.nightExt && cam.nightExtSupported()
        if (prefs.nightExt && !useExt) toast("Máy không mở chế độ đêm riêng cho app ngoài — dùng LUNA Night của app")
        val secs = if (useExt) 4 else prefs.nightSecs
        val frozen: Bitmap? = grabPreview()
        frozenBmp = frozen
        val boost = nightBoost(frozen)
        val steady = gyroEma < 0.03f
        if (prefs.sound && shutterLoaded && soundAllowed()) pool?.play(shutterId, 1f, 1f, 1, 0, 1f)
        cam.appIsp = prefs.appIsp
        if (useExt) cam.captureNightExt(jpegRotation(i)) else cam.captureNight(jpegRotation(i), secs, boost, steady)
        main.removeCallbacks(failSafe)
        main.postDelayed(failSafe, secs * 1000L + 45000L)
        if (frozen != null) {
            hqFxMode = true
            nightFxMode = true
            phase = 6
            ui.setChromeHidden(true)
            ui.nightFx.onSecond = {
                if (prefs.sound && tickLoaded && soundAllowed()) pool?.play(tickId, 0.45f, 0.45f, 1, 0, 1f)
            }
            ui.nightFx.start(frozen, secs, steady)
        } else main.postDelayed({ if (phase == 0) shooting = false }, 400)
    }

    private fun timerSoundOk() = prefs.sound && timerLoaded && soundAllowed()

    private var timerFadeStep = 0
    private val timerFadeRunnable = object : Runnable {
        override fun run() {
            val st = timerRunStream
            if (st == 0) return
            val n = timerFadeStep
            // vào: tiếng nhỏ + hơi chậm rồi vào nhịp (dây cót vừa nhả); ra: nhỏ dần + chậm dần (dây cót hết đà)
            val rampIn = n in 0..99
            val f = if (rampIn) n / 6f else (n - 100) / 10f
            if (rampIn) {
                val k = f.coerceIn(0f, 1f)
                pool?.setVolume(st, 0.25f + 0.75f * k, 0.25f + 0.75f * k)
                pool?.setRate(st, 0.82f + 0.18f * k)
                if (n < 6) { timerFadeStep++; main.postDelayed(this, 40) }
            } else {
                val k = f.coerceIn(0f, 1f)
                pool?.setVolume(st, 1f - 0.8f * k, 1f - 0.8f * k)
                pool?.setRate(st, 1f - 0.2f * k)
                if (n - 100 < 10) { timerFadeStep++; main.postDelayed(this, 40) }
            }
        }
    }

    private fun startTimerLoop() {
        stopTimerSounds()
        if (!timerSoundOk()) return
        timerRunStream = pool?.play(timerRunId, 0.25f, 0.25f, 1, -1, 0.82f) ?: 0
        timerFadeStep = 0
        main.post(timerFadeRunnable)
    }

    /** Gần hết giờ: tiếng dây cót nhỏ dần và chậm dần trong ~0,4s. */
    private fun fadeTimerLoop() {
        if (timerRunStream == 0) return
        main.removeCallbacks(timerFadeRunnable)
        timerFadeStep = 100
        main.post(timerFadeRunnable)
    }

    private fun stopTimerSounds() {
        main.removeCallbacks(timerFadeRunnable)
        if (timerRunStream != 0) { pool?.stop(timerRunStream); timerRunStream = 0 }
    }

    /** Bật/tắt hẹn giờ cần gạt (nút trong menu XPAN). */
    private fun toggleTimer() {
        prefs.timer = !prefs.timer
        stopTimerSounds()
        ui.setTimerMode(prefs.timer)
        toast(if (prefs.timer) "Hẹn giờ: giữ cán gạt xoay lên để lên dây (tối đa 10s), bấm trục để bắt đầu" else "Đã tắt hẹn giờ")
    }

    private fun updateNightBadge() {
        ui.night.secs = prefs.nightSecs
        ui.night.visibility = if (prefs.night) View.VISIBLE else View.GONE
        ui.requestLayout()
    }

    /** Bật/tắt chế độ thiếu sáng: không đi cùng HQ và vệt sáng; mở lại camera để đổi số bộ đệm ảnh. */
    private fun toggleNight() {
        val on = !prefs.night
        if (on) {
            if (prefs.longExp) { prefs.longExp = false; toast("Đã tắt phơi sáng lâu (không đi cùng thiếu sáng)") }
            if (prefs.hq) { prefs.hq = false; updateHqNote(); toast("Đã tắt chế độ chất lượng cao (thiếu sáng dùng bộ ghép riêng)") }
            if (prefs.lightTrail) { prefs.lightTrail = false; toast("Đã tắt vệt sáng (không đi cùng thiếu sáng)") }
            if (prefs.liveArt) { prefs.liveArt = false; liveRec?.reset(); updateHqNote(); toast("Đã tắt Live Art (không đi cùng Night ART)") }
        }
        prefs.night = on
        updateNightBadge()
        if (on) startGyro() else stopGyro()
        openedLensId = null
        maybeOpen()
    }

    /** Ảnh HQ đã xử lý xong: quét ảnh kết quả thay khung nhoè rồi bay về thumbnail. */
    private fun hqDone() {
        if (!hqFxMode) return
        hqFxMode = false
        val f = fx()
        nightFxMode = false
        leFxMode = false
        val r = resultBmp ?: frozenBmp
        f.complete(r) {
            val bmp = resultBmp ?: frozenBmp
            if (bmp != null) {
                ui.freeze.colorFilter = null
                ui.freeze.setImageBitmap(bmp)
                ui.freeze.alpha = 1f
                ui.freeze.visibility = View.VISIBLE
                freezeActive = true
            }
            f.stop()
            phase = 4
            main.removeCallbacks(dockRunnable)
            main.postDelayed(dockRunnable, 350L)
        }
    }

    override fun onNightStart(totalFrames: Int) {
        if (nightFxMode) ui.nightFx.startClock(totalFrames)
        if (leFxMode) ui.leFx.startClock()
    }

    override fun onBurstFrame(n: Int, total: Int) {
        if (nightFxMode) { ui.nightFx.setCaptured(n); return }
        if (leFxMode) { ui.leFx.setPreview(cam.longExpPreview(720)); return }
        if (!hqFxMode) {
            // vệt sáng: mỗi khung chụp xong một tiếng "tách" nhẹ để biết máy còn đang chụp (giữ yên máy)
            if (cam.trailMode && prefs.sound && focusLoaded && soundAllowed()) pool?.play(focusId, 0.5f, 0.5f, 1, 0, 1f)
            return
        }
        ui.hqFx.setCaptured(n)
        // mỗi khung chụp xong: một tiếng "tách"
        if (prefs.sound && focusLoaded && soundAllowed()) pool?.play(focusId, 0.9f, 0.9f, 1, 0, 1f)
    }

    private fun takePhoto() {
        // đang phơi sáng thiếu sáng: bấm lần nữa để dừng sớm (ghép những khung đã có)
        if ((nightFxMode || leFxMode) && shooting && !captureDone) { cam.stopNight(); if (leFxMode) ui.leFx.setStopping() else ui.nightFx.setStopping(); return }
        val i = info ?: return
        if (prefs.longExp && !prefs.night && cam.nightMode && !prefs.hq) { takePhotoLongExp(); return }
        if (prefs.night && cam.nightMode && !prefs.hq) { takePhotoNight(); return }
        if (prefs.hq && !cam.hqActive) { takePhotoHq(); return }
        if (prefs.captureFx == 1) { takePhotoCurtain(); return }
        if (shooting || lensFxActive || phase != 0) return
        // đóng ngăn kéo trước khi chụp để ảnh bay về đúng ô thumbnail
        if (ui.texture.width <= 0 || ui.texture.height <= 0) return
        shooting = true
        revealed = false
        processed = false
        resultBmp = null
        captureDone = false
        pendingThumb = null
        shotSeq++
        pendingSeqs.addLast(shotSeq)
        // Gửi lệnh chụp xuống camera NGAY (trước cả khi đóng băng/dựng hiệu ứng) để khung được lấy sớm nhất có thể
        if (prefs.sound && shutterLoaded && soundAllowed()) pool?.play(shutterId, 1f, 1f, 1, 0, 1f)
        ui.shutter.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        cam.appIsp = prefs.appIsp
        liveShutter(jpegRotation(i))
        cam.capture(jpegRotation(i))
        main.removeCallbacks(failSafe)
        main.postDelayed(failSafe, 15000)
        // Đóng băng khung hình lúc bấm chụp
        val frozen: Bitmap? = grabPreview()
        frozenBmp = frozen
        if (frozen != null) {
            // 1) tức thì: khung ngắm thành ảnh ÂM BẢN đóng băng, ẩn khung ngắm/thang EV/dải zoom
            ui.freeze.setImageBitmap(frozen)
            ui.freeze.colorFilter = ColorMatrixColorFilter(XpanFilter.invertMatrix())
            ui.freeze.alpha = 1f
            ui.freeze.visibility = View.VISIBLE
            freezeActive = true
            ui.setChromeHidden(true)
            ui.fx.reset()
            phase = 1
            negStart = SystemClock.uptimeMillis()
            main.removeCallbacks(negCheck)
            main.postDelayed(negCheck, NEG_MIN)
        }
        if (frozen == null) main.postDelayed({ if (phase == 0) shooting = false }, 400)
    }

    /** Hết pha âm bản khi ảnh đã chụp xong và đã giữ đủ thời gian (hoặc quá lâu). */
    private fun tryEndNegative() {
        if (phase != 1) return
        val el = SystemClock.uptimeMillis() - negStart
        if ((captureDone && el >= NEG_MIN) || el >= NEG_MAX) {
            startGrey()
        } else {
            main.removeCallbacks(negCheck)
            main.postDelayed(negCheck, if (el < NEG_MIN) NEG_MIN - el else 50L)
        }
    }

    private fun startGrey() {
        phase = 2
        // 2) âm bản -> xám phẳng
        ui.fx.greyIn(GREY_IN) {
            // xám đang phủ kín: đổi sang ảnh thật (đã áp bộ lọc) mà không bị lộ
            phase = 3
            revealed = true
            if (frozenBmp != null) ui.freeze.colorFilter = ColorMatrixColorFilter(curFilter().previewMatrix())
            applyResultIfReady()
            // 3) xám tan dần
            ui.fx.greyOut(GREY_OUT) {
                phase = 4
                main.removeCallbacks(dockRunnable)
                main.postDelayed(dockRunnable, HOLD)
            }
        }
    }

    private fun applyResultIfReady() {
        val r = resultBmp
        if (revealed && freezeActive && r != null) {
            ui.freeze.colorFilter = null
            ui.freeze.setImageBitmap(r)
        }
    }

    /** 4->5) giao diện trở lại ngay, ảnh vừa chụp thu nhỏ bay về ô thumbnail (ảnh lưu về máy). */
    private fun dock() {
        if (phase != 4) return
        phase = 5
        val bmp = resultBmp ?: frozenBmp
        val vfR = ui.vfRect()
        val thR = ui.thumbRect()
        ui.setChromeHidden(false)
        ui.freeze.visibility = View.GONE
        ui.freeze.setImageDrawable(null)
        freezeActive = false
        main.removeCallbacks(failSafe)
        if (bmp == null) { finishFly(null); return }
        ui.fly.soft = !ui.classic
        ui.fly.start(bmp, vfR, thR, FLY) { finishFly(bmp) }
    }

    private fun finishFly(shown: Bitmap?) {
        phase = 0
        shooting = false
        frozenBmp = null
        val th = pendingThumb ?: shown?.let { coverThumb(it) }
        if (th != null) ui.thumb.setImageBitmap(th)
        popThumb()
    }

    private fun coverThumb(b: Bitmap): Bitmap {
        val side = kotlin.math.min(b.width, b.height)
        val sq = Bitmap.createBitmap(b, (b.width - side) / 2, (b.height - side) / 2, side, side)
        val out = Bitmap.createScaledBitmap(sq, 256, 256, true)
        if (sq !== b && sq !== out) sq.recycle()
        return out
    }

    /** Ô thumbnail "nảy" nhẹ khi nhận ảnh. */
    private fun popThumb() {
        ui.thumb.animate().cancel()
        ui.thumb.animate().scaleX(1.18f).scaleY(1.18f).setDuration(110).withEndAction {
            ui.thumb.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
        }.start()
    }

    private fun setThumbFromProcessing(th: Bitmap) {
        if (phase == 0) ui.thumb.setImageBitmap(th) else pendingThumb = th
    }

    private fun onProcessed(seq: Int, big: Bitmap?) {
        if (seq == shotSeq) {
            processed = true
            resultBmp = big
            if (hqFxMode) hqDone()
        }
    }

    private fun updateProcessingUi() {
        ui.thumb.alpha = if (processingCount > 0) 0.45f else 1f
    }

    /** Dừng khẩn cấp mọi hiệu ứng chụp (lỗi, tạm dừng, quá thời gian). */
    private fun releaseFreeze() {
        main.removeCallbacks(failSafe)
        main.removeCallbacks(negCheck)
        main.removeCallbacks(dockRunnable)
        ui.fx.reset()
        hqFxMode = false
        nightFxMode = false
        leFxMode = false
        ui.hqFx.stop()
        ui.nightFx.stop()
        ui.leFx.stop()
        ui.proc.stop()
        ui.fly.cancel()
        ui.setChromeHidden(false)
        ui.freeze.visibility = View.GONE
        ui.freeze.setImageDrawable(null)
        freezeActive = false
        frozenBmp = null
        phase = 0
        shooting = false
    }

    override fun onShot(shot: CameraController.ShotResult) {
        captureDone = true
        main.post { tryEndNegative() }
        if (hqFxMode) { fx().beginMerge(); ui.proc.start() }
        if ((nightFxMode || leFxMode) && prefs.sound && shutterLoaded && soundAllowed()) pool?.play(shutterId, 0.8f, 0.8f, 1, 0, 0.9f)
        shot.up = prefs.hq && prefs.up
        // ảnh thường: lấy clip Live Art xếp hàng theo thứ tự bấm chụp
        if (shot.night == null && shot.longExp == null && !shot.wantFuse && !prefs.hq && !prefs.night && !prefs.longExp && liveQueue.isNotEmpty()) shot.live = liveQueue.removeFirst()
        val filter = curFilter()
        val seq = if (pendingSeqs.isEmpty()) shotSeq else pendingSeqs.removeFirst()
        val curtain = curtainSeqs.remove(seq)
        processingCount++
        updateProcessingUi()
        exec.execute {
            var saved: Saved? = null
            try {
                val s: Saved = PhotoProcessor.process(this, shot, filter, prefs) { pct -> runOnUiThread { if (hqFxMode) fx().setMerge(pct) } }
                saved = s
                lastUri = s.uri
                lastFramed = s.framed
                runOnUiThread {
                    processingCount = (processingCount - 1).coerceAtLeast(0)
                    updateProcessingUi()
                    s.thumb?.let { setThumbFromProcessing(it); if (curtain) popThumb() }
                    onProcessed(seq, if (curtain) null else s.big)
                    s.fuseMsg?.let { toast(it) }
                    // Live Art không ghép được vào ảnh: báo lý do cụ thể (khác máy khác lỗi) thay vì lặng lẽ chỉ còn ảnh tĩnh
                    LiveArt.lastError?.let { toast("Live Art không có trong ảnh này: $it"); LiveArt.lastError = null }
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    processingCount = (processingCount - 1).coerceAtLeast(0)
                    updateProcessingUi()
                    toast("Lỗi xử lý ảnh: ${PhotoProcessor.errText(t)}")
                    onProcessed(seq, null)
                }
            }
            // file phụ (gốc, DNG, ảnh khung) làm sau, không làm chậm ảnh chính
            try {
                val s = saved
                if (s != null) PhotoProcessor.extras(this, shot, s, prefs)?.let { w -> runOnUiThread { toast(w) } }
            } catch (_: Throwable) {
            } finally {
                shot.jpeg.delete()
                shot.dng?.delete()
                shot.extra.forEach { try { it.delete() } catch (_: Throwable) {} }
                shot.rawIn?.files?.forEach { try { it.delete() } catch (_: Throwable) {} }
            }
        }
    }

    /** Menu từ nút XPAN >: Khung ảnh / Hiệu ứng chụp (bảng trượt từ dưới lên, nền đặc, nút tròn có icon). */
    /**
     * Mở album: có ảnh vừa chụp / ảnh mới nhất thì mở thẳng ảnh đó trong ứng dụng Thư viện; chưa có thì mở ứng dụng Thư viện của máy
     * (trước đây chạm vào lúc chưa có ảnh nào thì không có phản ứng gì).
     */
    private fun openAlbum() {
        val u = lastUri
        try {
            if (u != null) {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "image/jpeg").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } else {
                startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
        } catch (t: Throwable) {
            toast(if (u != null) "Không mở được ứng dụng Thư viện" else "Chưa có ảnh nào, và không mở được ứng dụng Thư viện")
        }
    }

    /** Chữ giá trị hiện trên bánh xe: EV (+0.7) hoặc khoảng cách lấy nét tay (0.40m / ∞ / AF). */
    private fun dialValueText(): String {
        if (!prefs.dialFocus) {
            val ev = ui.ev.value * ui.ev.step
            return if (ui.ev.value == 0) "0.0" else String.format(Locale.US, "%+.1f", ev)
        }
        val f = prefs.cam.focus
        return when {
            f < 0f -> "AF"
            f < 0.01f -> "∞"
            else -> String.format(Locale.US, "%.2fm", 1f / f)
        }
    }

    /** Chuyển thân máy XPAN 65:24 ⇄ X2D II 4:3: đổi khổ cắt ảnh + toàn bộ bố cục giao diện, giữ nguyên mọi chức năng chụp. */
    private fun setBody(on: Boolean) {
        if (Body.x2d == on) return
        if (shooting) { toast("Đang chụp, thử lại sau giây lát"); return }
        prefs.x2d = on
        Body.x2d = on
        if (ui.drawerOpen) ui.setDrawer(false)
        if (ui.x2dFilterOpen) ui.setX2dFilter(false)
        liveRec?.reset()
        ui.animate().cancel()
        ui.animate().alpha(0f).setDuration(140).withEndAction {
            ui.x2d = on
            updateHqNote()          // X2D II không ghi chú chế độ ở góc trên trái (đã có nút chế độ dưới bánh xe)
            panel.applyTheme()
            updateTransform()
            if (on) startHud() else stopHud()
            ui.animate().alpha(1f).setDuration(260).start()
        }.start()
        toast(if (on) "X2D II · khổ 4:3" else "XPAN · khổ 65:24")
    }

    /** Bánh xe trên tay cầm X2D II: mỗi nấc +1 / -1, tuỳ Cài đặt mà chỉnh EV hoặc lấy nét tay. */
    private fun dialStep(dir: Int) {
        if (!prefs.dialFocus) {
            if (ui.ev.max <= ui.ev.min) return
            val v = (ui.ev.value + dir).coerceIn(ui.ev.min, ui.ev.max)
            if (v == ui.ev.value) return
            ui.ev.value = v
            ui.ev.onChange?.invoke(v)
            refreshHud()
            return
        }
        val minF = info?.caps?.minFocus ?: 0f
        if (minF <= 0f) { toast("Ống kính này không lấy nét tay được"); return }
        var f = prefs.cam.focus
        // từ tự động (âm): vuốt lên vào lấy nét tay ở khoảng giữa tầm, vuốt xuống thì giữ nguyên tự động
        f = if (f < 0f) (if (dir > 0) minF * 0.25f else -1f) else f + dir * (minF / 24f)
        if (f < 0f) f = -1f
        f = minOf(f, minF)
        if (f == prefs.cam.focus) return
        prefs.cam = prefs.cam.copy(focus = f)
        cam.setParams(prefs.cam)
        panel.setState(prefs.cam, prefs.adjust)
        refreshHud()
    }

    // ---- thông tin trên màn hình X2D II: cập nhật ~3 lần / giây khi đang ở giao diện này
    private var hudSlow = 0
    private val hudTick = object : Runnable {
        override fun run() {
            refreshHud()
            if (Body.x2d && resumed) ui.postDelayed(this, 350)
        }
    }

    private fun startHud() {
        if (!::ui.isInitialized) return
        ui.removeCallbacks(hudTick)
        hudSlow = 0
        ui.post(hudTick)
        startLevel()
    }

    private fun stopHud() {
        if (::ui.isInitialized) ui.removeCallbacks(hudTick)
        stopLevel()
    }

    // ---- thuỷ bình điện tử trên màn hình X2D II: thanh ngang = nghiêng trái / phải, thanh dọc = camera ngẩng / cúi
    private var levelReg = false
    private var lvX = 0f
    private var lvY = 0f
    private var lvZ = 0f
    private var lvInit = false
    private var lvRollOk = false
    private var lvPitchOk = false
    private val levelListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            if (!::ui.isInitialized || !Body.x2d) return
            val v = e.values
            if (!lvInit) { lvX = v[0]; lvY = v[1]; lvZ = v[2]; lvInit = true }
            else {
                lvX += (v[0] - lvX) * 0.25f
                lvY += (v[1] - lvY) * 0.25f
                lvZ += (v[2] - lvZ) * 0.25f
            }
            val n = Math.sqrt((lvX * lvX + lvY * lvY + lvZ * lvZ).toDouble()).toFloat()
            if (n < 1f) return
            // cầm ngang: ROTATION_90 -> "lên" của màn hình = +x thiết bị, "phải" = -y; ROTATION_270 ngược lại
            val sgn = if (windowManager.defaultDisplay.rotation == Surface.ROTATION_270) -1f else 1f
            val up = sgn * lvX
            val right = -sgn * lvY
            val roll = Math.toDegrees(Math.atan2(right.toDouble(), up.toDouble())).toFloat()
            val pitch = Math.toDegrees(Math.asin((-lvZ / n).coerceIn(-1f, 1f).toDouble())).toFloat()
            // mỗi núm tự xét riêng: thanh ngang trắng khi máy không nghiêng trái / phải, thanh dọc trắng khi camera hướng ra phía trước
            // (lệch < 1,2° thì trắng; đang trắng thì giữ tới 2° để không nhấp nháy)
            lvRollOk = abs(roll) < (if (lvRollOk) 2f else 1.2f)
            lvPitchOk = abs(pitch) < (if (lvPitchOk) 2f else 1.2f)
            val h = ui.hud
            h.rollDeg = roll
            h.pitchDeg = pitch
            h.levelRoll = lvRollOk
            h.levelPitch = lvPitchOk
            h.invalidate()
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    private fun startLevel() {
        if (levelReg || !Body.x2d) return
        try {
            val sm = getSystemService(SENSOR_SERVICE) as SensorManager
            val s = sm.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
            if (s != null) { lvInit = false; sm.registerListener(levelListener, s, SensorManager.SENSOR_DELAY_UI); levelReg = true }
        } catch (_: Throwable) {}
    }

    private fun stopLevel() {
        if (!levelReg) return
        try { (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(levelListener) } catch (_: Throwable) {}
        levelReg = false
    }

    private fun refreshHud() {
        if (!::ui.isInitialized || !Body.x2d) return
        val h = ui.hud
        h.iso = cam.lastIso
        h.expNs = cam.lastExposureNs
        h.fNumber = entries.getOrNull(selected)?.lens?.aperture ?: 0f
        h.evMin = ui.ev.min
        h.evMax = ui.ev.max
        h.evStep = ui.ev.step
        h.evValue = ui.ev.value
        h.mf = prefs.cam.focus >= 0f
        h.manual = prefs.cam.shutterNs > 0L || prefs.cam.iso > 0
        ui.dial.label = if (prefs.dialFocus) "MF" else "EV"
        ui.sideFlash.flash = prefs.flash
        ui.dialSwitch.mf = prefs.dialFocus
        refreshModeUi()
        ui.dial.valueText = dialValueText()
        if (hudSlow++ % 40 == 0) {
            try {
                val bm = getSystemService(android.content.Context.BATTERY_SERVICE) as? android.os.BatteryManager
                h.battery = bm?.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
            } catch (_: Throwable) {}
            try {
                val sf = android.os.StatFs(android.os.Environment.getExternalStorageDirectory().path)
                h.remaining = (sf.availableBytes / (12L * 1024 * 1024)).toInt().coerceIn(0, 99999)
            } catch (_: Throwable) {}
        }
        h.invalidate()
    }

    /** Bật/tắt Live Art (dùng chung cho menu XPAN và danh sách chế độ nhanh của X2D II). */
    private fun setLiveArt(on: Boolean) {
        prefs.liveArt = on
        liveRec?.reset()
        if (prefs.liveArt) {
            // Live Art loại trừ HQ / HQ RAW / UP và Night ART: bật Live thì các chế độ kia tự tắt
            val off = ArrayList<String>()
            if (prefs.hq) { prefs.hq = false; prefs.hqRaw = false; prefs.up = false; updateHqNote(); off.add("HQ / RAW / UP") }
            if (prefs.night) { prefs.night = false; updateNightBadge(); stopGyro(); off.add("Thiếu sáng") }
            if (prefs.longExp) { prefs.longExp = false; off.add("Phơi sáng lâu") }
            toast(if (off.isEmpty()) "Live Art: ảnh thường sẽ kèm ~3s chuyển động" else "Live Art bật · đã tắt ${off.joinToString(", ")}")
        }
        updateHqNote()
        openedLensId = null
        maybeOpen()      // luồng YUV của Live Art cần phiên camera mới
    }

    // ---- X2D II: nút chế độ dưới bánh xe + danh sách chọn nhanh (thay ghi chú chế độ ở góc trên trái màn hình)
    private val modeNames = listOf("Normal", "LUNA. HQ", "LUNA. HQ RAW", "LUNA. UP", "LUNA. Night Art", "LUNA. Live Art")

    private fun currentMode(): Int = when {
        prefs.longExp || prefs.night -> 4
        prefs.liveArt -> 5
        prefs.hq && prefs.hqRaw -> 2
        prefs.hq && prefs.up -> 3
        prefs.hq -> 1
        else -> 0
    }

    private fun refreshModeUi() {
        if (!::ui.isInitialized) return
        val m = currentMode()
        ui.modeBtn.text = modeNames[m]
        ui.modePopup.selected = m
    }

    private fun toggleModePopup() {
        if (ui.modePopup.visibility == View.VISIBLE) { ui.modePopup.dismiss(); return }
        ui.modePopup.items = modeNames
        ui.modePopup.selected = currentMode()
        ui.modeBtn.open = true
        ui.modePopup.show()
    }

    /** Chọn nhanh chế độ chụp từ danh sách; các chế độ loại trừ nhau nên bật cái này sẽ tự tắt cái kia (như trong menu XPAN). */
    private fun pickMode(i: Int) {
        if (shooting) { toast("Đang chụp, thử lại sau giây lát"); return }
        if (i == currentMode()) return
        when (i) {
            0 -> clearModes()
            1 -> toggleHq(false, false)
            2 -> {
                val rawOk = entries.getOrNull(selected)?.lens?.let { it.rawSize != null } == true
                if (rawOk) toggleHq(true, false) else toast("Ống kính đang chọn không có RAW")
            }
            3 -> toggleHq(false, true)
            4 -> showNightArtMenu()          // Night ART gồm hai chế độ con (phơi sáng lâu / thiếu sáng): chọn tiếp ở menu nhỏ
            5 -> setLiveArt(true)
        }
        refreshModeUi()
    }

    /** Về Normal: tắt HQ / RAW / UP, Night ART (phơi sáng lâu, thiếu sáng) và Live Art. */
    private fun clearModes() {
        if (prefs.hq || prefs.hqRaw || prefs.up) { prefs.hq = false; prefs.hqRaw = false; prefs.up = false }
        if (prefs.longExp) prefs.longExp = false
        if (prefs.night) { prefs.night = false; updateNightBadge(); stopGyro() }
        if (prefs.liveArt) { prefs.liveArt = false; liveRec?.reset() }
        openedLensId = null
        updateHqNote()
        maybeOpen()
    }

    private fun showCaptureMenu() {
        val fxName = if (prefs.captureFx == 1) "Màn chập" else "Rửa film"
        val wmNames = arrayOf("Cổ điển", "Gallery", "Dải thông số", "Logo + tên máy", "Chỉ logo", "Nền màu ảnh")
        val items = ArrayList<MenuSheetItem>()
        // đổi thân máy: XPAN 65:24 ⇄ X2D II 4:3 (giao diện Hasselblad X2D II, mọi chức năng chụp giữ nguyên)
        items.add(
            if (Body.x2d) MenuSheetItem(16, "65:24 (XPAN)", "Quay lại giao diện XPAN", true) { setBody(false) }
            else MenuSheetItem(16, "4:3 (X2D II)", "Giao diện Hasselblad X2D II") { setBody(true) }
        )
        items.add(MenuSheetItem(0, "Khung ảnh", if (prefs.autoFrame) wmNames[prefs.watermark] else "Tắt") { showWatermarkPicker() })
        items.add(MenuSheetItem(1, "Hiệu ứng chụp", fxName) { showFxPicker() })
        run {
            val on = prefs.hq && !prefs.hqRaw && !prefs.up
            items.add(MenuSheetItem(2, "High quality", if (on) "LUNA Engine" else "Tắt", on) { toggleHq(false) })
        }
        // HQ RAW: luôn hiện để so sánh với High quality; ống kính không cho app ngoài lấy RAW thì ghi rõ và không bật được
        run {
            val rawOk = entries.getOrNull(selected)?.lens?.let { it.rawSize != null } == true
            val on = prefs.hq && prefs.hqRaw && rawOk
            val sub = if (!rawOk) "Ống kính này không có RAW" else if (on) "RAW · LUNA Engine" else "Tắt"
            items.add(MenuSheetItem(7, "HQ RAW", sub, on) {
                if (rawOk) toggleHq(true) else toast("Ống kính đang chọn không có RAW")
            })
        }
        // UP (Ultra pixel): ghép JPEG như High quality nhưng làm nét mạnh hơn và ảnh ra 3× (≈ 12288×4536, 55,8 MP); tách riêng để so sánh với HQ
        run {
            val on = prefs.hq && !prefs.hqRaw && prefs.up
            items.add(MenuSheetItem(9, "UP", if (on) "Ultra pixel · 55,8 MP" else "Ultra pixel", on) { toggleHq(false, true) })
        }
        items.add(MenuSheetItem(15, "Live Art", if (prefs.liveArt) "Ảnh động · ~3s" else "Tắt", prefs.liveArt) { setLiveArt(!prefs.liveArt) })
        items.add(MenuSheetItem(11, "Hẹn giờ", if (prefs.timer) "Cần gạt · tối đa 10s" else "Tắt", prefs.timer) { toggleTimer() })
        // Night ART: gộp Phơi sáng lâu + Thiếu sáng; bấm vào mở menu hai nút
        items.add(MenuSheetItem(14, "Night ART", "( LUNA. Night Art 1 )", prefs.longExp || prefs.night) { showNightArtMenu() })
        items.add(MenuSheetItem(8, "Lưới bố cục", if (prefs.grid) "Chia 3 · 3×3" else "Tắt", prefs.grid) {
            prefs.grid = !prefs.grid
            ui.frame.grid = prefs.grid
        })
        // công tắc logo LUNA chỉ hiện khi đang bật chế độ chất lượng cao hoặc Night ART (phơi sáng lâu / thiếu sáng)
        if (prefs.hq || prefs.night || prefs.longExp) items.add(MenuSheetItem(3, "Logo LUNA", if (prefs.hqLogo) "Bật" else "Tắt", prefs.hqLogo) { prefs.hqLogo = !prefs.hqLogo })
        showMenuSheet(items) { hideBars() }
    }

    /** Menu con của Night ART: hai nút Phơi sáng lâu và Thiếu sáng (ảnh chụp xong nếu bật logo sẽ có chữ LUNA. Night Art). */
    private fun showNightArtMenu() {
        val items = ArrayList<MenuSheetItem>()
        items.add(MenuSheetItem(13, "Phơi sáng lâu", if (prefs.longExp) "Vệt sáng · bấm để dừng" else "Tắt", prefs.longExp) { toggleLongExp() })
        items.add(MenuSheetItem(5, "Thiếu sáng", if (prefs.night) "${prefs.nightSecs}s · LUNA Night" else "Tắt", prefs.night) { toggleNight() })
        showMenuSheet(items) { hideBars() }
    }

    /** Bật/tắt chế độ HQ: mở lại camera để thêm/bớt luồng ảnh độ phân giải tối đa. */
    private fun toggleHq(raw: Boolean = false, up: Boolean = false) {
        // bấm lại đúng chế độ đang bật thì tắt HQ; bấm chế độ kia thì chuyển sang chế độ đó
        if (prefs.hq && prefs.hqRaw == raw && prefs.up == up) { prefs.hq = false; prefs.hqRaw = false; prefs.up = false } else { prefs.hq = true; prefs.hqRaw = raw; prefs.up = up }
        if (prefs.hq && prefs.longExp) { prefs.longExp = false; toast("Đã tắt phơi sáng lâu (HQ dùng bộ ghép riêng)") }
        if (prefs.hq && prefs.night) { prefs.night = false; updateNightBadge(); toast("Đã tắt thiếu sáng (HQ dùng bộ ghép riêng)") }
        if (prefs.hq && prefs.lightTrail) { prefs.lightTrail = false; toast("Đã tắt vệt sáng (HQ không dùng cùng vệt sáng)") }
        if (prefs.hq && prefs.liveArt) { prefs.liveArt = false; liveRec?.reset(); toast("Đã tắt Live Art (HQ / RAW / UP không đi cùng Live Art)") }
        openedLensId = null
        updateHqNote()
        maybeOpen()
        // vừa bật HQ / HQ RAW / UP: màn đen giới thiệu ~1s
        if (prefs.hq) ui.showModeSplash(if (prefs.up) "ULTRA PIXEL" else "REAL DETAILS")
    }

    private fun updateHqNote() {
        // ghi chú góc trên-trái khung ngắm: HQ / UP, hoặc Live Art khi bật (Live Art loại trừ HQ nên không trùng)
        // X2D II: chế độ hiện ở nút chế độ dưới bánh xe, không ghi chú ở góc trên trái màn hình
        ui.frame.hqNote = (prefs.hq || prefs.liveArt) && !Body.x2d
        ui.frame.hqNoteText = when {
            prefs.hq && prefs.up -> "Shot with LUNA. UP"
            prefs.hq -> "Shot with LUNA Quality"
            else -> "Shot with LUNA. Live Art"
        }
        ui.frame.invalidate()
        refreshModeUi()
    }

    override fun onHqFailed() {
        toast("Máy không cho chụp độ phân giải tối đa cùng xem trước — chuyển sang HQ ghép nhiều khung.")
        updateHqNote()
    }

    /** Bảng chọn hiệu ứng chụp: Rửa film hoặc Màn chập (chụp ngay, liên tiếp). */
    private fun showFxPicker() {
        val dn = resources.displayMetrics.density
        fun dp(v: Float) = (v * dn).toInt()
        val light = Theme.light
        val sub = if (light) 0xFF6C6C74.toInt() else 0xFF9C9CA4.toInt()
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18f), dp(16f), dp(18f), dp(16f))
        box.background = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = 24f * dn
            setColor(if (light) 0xFFF1F1F4.toInt() else 0xFF17171A.toInt())
            setStroke(dp(1f).coerceAtLeast(1), if (light) 0x1F000000 else 0x24FFFFFF)
        }
        val title = TextView(this)
        title.text = "Hiệu ứng chụp"
        title.textSize = 17f
        title.typeface = android.graphics.Typeface.DEFAULT_BOLD
        title.setTextColor(Theme.ink)
        box.addView(title)
        val hint = TextView(this)
        hint.text = "Chọn cách máy phản hồi khi bấm chụp."
        hint.textSize = 12f
        hint.setTextColor(sub)
        hint.setPadding(0, dp(2f), 0, dp(12f))
        box.addView(hint)

        val names = arrayOf("Rửa film", "Màn chập")
        val descs = arrayOf(
            "Đóng băng khung, âm bản → xám → ảnh bay về album. Chờ xử lý xong mới chụp tấm tiếp.",
            "Chụp ngay, màn hình nháy đen một phát kèm tiếng. Bấm liên tiếp được, không chờ."
        )
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val cards = ArrayList<LinearLayout>()
        fun refresh() {
            cards.forEachIndexed { i, card ->
                val sel = i == prefs.captureFx
                card.background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = 16f * dn
                    setColor(if (light) Color.WHITE else 0xFF202024.toInt())
                    setStroke(dp(if (sel) 2f else 1f).coerceAtLeast(1), if (sel) 0xFFF47B20.toInt() else if (light) 0x1F000000 else 0x24FFFFFF)
                }
            }
        }
        for (i in 0 until 2) {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
            card.addView(FxPreviewView(this, i), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(96f)))
            val a = TextView(this)
            a.text = names[i]
            a.textSize = 13.5f
            a.typeface = android.graphics.Typeface.DEFAULT_BOLD
            a.setTextColor(Theme.ink)
            a.setPadding(0, dp(8f), 0, 0)
            card.addView(a)
            val b = TextView(this)
            b.text = descs[i]
            b.textSize = 11f
            b.setTextColor(sub)
            b.setPadding(0, dp(2f), 0, 0)
            card.addView(b)
            card.setOnClickListener {
                prefs.captureFx = i
                refresh()
                it.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                // nghe thử ngay tiếng của hiệu ứng vừa chọn
                if (prefs.sound && soundAllowed()) {
                    if (i == 1) playCurtainSound(true)
                    else if (i == 0 && shutterLoaded) pool?.play(shutterId, 1f, 1f, 1, 0, 1f)
                }
                it.postDelayed({ dlg.dismiss() }, 420)
                toast("Hiệu ứng chụp: ${names[i]}")
            }
            card.pressFeedback(0.97f, false)
            val lp = LinearLayout.LayoutParams(dp(150f), ViewGroup.LayoutParams.WRAP_CONTENT)
            if (i > 0) lp.leftMargin = dp(10f)
            row.addView(card, lp)
            cards.add(card)
        }
        refresh()
        val hs = android.widget.HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        hs.addView(row)
        box.addView(hs)
        dlg.setContentView(box)
        dlg.window?.let { w ->
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            w.setLayout(minOf(dp(560f), (resources.displayMetrics.widthPixels * 0.84f).toInt()), ViewGroup.LayoutParams.WRAP_CONTENT)
            w.setWindowAnimations(android.R.style.Animation_Dialog)
        }
        dlg.setOnDismissListener { hideBars() }
        dlg.show()
        dlg.window?.decorView?.systemUiVisibility = window.decorView.systemUiVisibility
    }

    /** Bảng chọn dấu chìm (mở từ menu nút XPAN ▾): 3 kiểu có hình minh hoạ. */
    private fun showWatermarkPicker() {
        val dn = resources.displayMetrics.density
        fun dp(v: Float) = (v * dn).toInt()
        val light = Theme.light
        val sub = if (light) 0xFF6C6C74.toInt() else 0xFF9C9CA4.toInt()
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18f), dp(16f), dp(18f), dp(16f))
        box.background = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = 24f * dn
            setColor(if (light) 0xFFF1F1F4.toInt() else 0xFF17171A.toInt())
            setStroke(dp(1f).coerceAtLeast(1), if (light) 0x1F000000 else 0x24FFFFFF)
        }
        val title = TextView(this)
        title.text = "Dấu chìm"
        title.textSize = 17f
        title.typeface = android.graphics.Typeface.DEFAULT_BOLD
        title.setTextColor(Theme.ink)
        box.addView(title)
        val hint = TextView(this)
        hint.text = "Bật công tắc để chụp ra ảnh có khung + dấu chìm, tắt để chỉ lưu ảnh sạch. Chọn kiểu khung bên dưới."
        hint.textSize = 12f
        hint.setTextColor(sub)
        hint.setPadding(0, dp(2f), 0, dp(12f))
        box.addView(hint)

        // công tắc bật/tắt dấu chìm (ảnh có khung) nằm ngay trong mục Dấu chìm
        val swRow = LinearLayout(this)
        swRow.orientation = LinearLayout.HORIZONTAL
        swRow.gravity = android.view.Gravity.CENTER_VERTICAL
        swRow.setPadding(dp(12f), dp(10f), dp(12f), dp(10f))
        swRow.background = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = 14f * dn
            setColor(if (light) Color.WHITE else 0xFF202024.toInt())
            setStroke(dp(1f).coerceAtLeast(1), if (light) 0x1F000000 else 0x24FFFFFF)
        }
        val swTx = LinearLayout(this)
        swTx.orientation = LinearLayout.VERTICAL
        val swA = TextView(this)
        swA.text = "Dấu chìm (ảnh có khung)"
        swA.textSize = 14f
        swA.typeface = android.graphics.Typeface.DEFAULT_BOLD
        swA.setTextColor(Theme.ink)
        swTx.addView(swA)
        val swB = TextView(this)
        swB.text = "Tắt: chỉ lưu ảnh đã cắt 65:24, không khung, không chữ."
        swB.textSize = 11.5f
        swB.setTextColor(sub)
        swB.setPadding(0, dp(2f), 0, 0)
        swTx.addView(swB)
        swRow.addView(swTx, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val swTg = SettingToggle(this)
        swTg.setChecked(prefs.autoFrame, false)
        swRow.addView(swTg, LinearLayout.LayoutParams(dp(48f), dp(28f)))
        swRow.setOnClickListener {
            val n = !swTg.checked
            swTg.setChecked(n)
            prefs.autoFrame = n
            it.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
        }
        val swLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        swLp.bottomMargin = dp(12f)
        box.addView(swRow, swLp)

        val names = arrayOf("Cổ điển", "Gallery", "Dải thông số", "Logo + tên máy", "Chỉ logo", "Nền màu ảnh")
        val descs = arrayOf("HASSELBLAD giữa, thông số dưới.", "Viền rộng, logo XPAN góc trái.", "Dải trắng mỏng, thông số bên phải.", "Tên máy | logo HASSELBLAD in ngay trong ảnh, không nền.", "Logo HASSELBLAD · Create to Inspire trong ảnh, không mã máy.", "Nền mờ theo màu ảnh, logo HASSELBLAD trên, tên máy + thông số dưới.")
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val cards = ArrayList<LinearLayout>()
        fun refresh() {
            cards.forEachIndexed { i, card ->
                val sel = i == prefs.watermark
                card.background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = 16f * dn
                    setColor(if (light) Color.WHITE else 0xFF202024.toInt())
                    setStroke(dp(if (sel) 2f else 1f).coerceAtLeast(1), if (sel) 0xFFF47B20.toInt() else if (light) 0x1F000000 else 0x24FFFFFF)
                }
            }
        }
        for (i in 0 until 6) {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
            card.addView(WatermarkPreviewView(this, i), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(84f)))
            val a = TextView(this)
            a.text = names[i]
            a.textSize = 13.5f
            a.typeface = android.graphics.Typeface.DEFAULT_BOLD
            a.setTextColor(Theme.ink)
            a.setPadding(0, dp(8f), 0, 0)
            card.addView(a)
            val b = TextView(this)
            b.text = descs[i]
            b.textSize = 11f
            b.setTextColor(sub)
            b.setPadding(0, dp(2f), 0, 0)
            card.addView(b)
            card.setOnClickListener {
                prefs.watermark = i
                refresh()
                it.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                it.postDelayed({ dlg.dismiss() }, 260)
                toast("Dấu chìm: ${names[i]}")
            }
            card.pressFeedback(0.97f, false)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.leftMargin = dp(10f)
            row.addView(card, lp)
            cards.add(card)
        }
        refresh()
        box.addView(row)
        dlg.setContentView(android.widget.ScrollView(this).also { it.addView(box) })
        dlg.window?.let { w ->
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            w.setLayout(minOf(dp(780f), (resources.displayMetrics.widthPixels * 0.9f).toInt()), ViewGroup.LayoutParams.WRAP_CONTENT)
            w.setWindowAnimations(android.R.style.Animation_Dialog)
        }
        dlg.setOnDismissListener { hideBars() }
        dlg.show()
        dlg.window?.decorView?.systemUiVisibility = window.decorView.systemUiVisibility
    }

    private fun deviceName(): String = prefs.deviceName.ifBlank { PhotoProcessor.defaultDeviceName() }

    private fun showReview(uri: Uri) {
        reviewUri = uri
        val framed = lastFramed && uri == lastUri
        reviewFramed = framed
        exec.execute {
            val bmp = try {
                if (framed) PhotoProcessor.decodeUpright(this, uri, 2400)
                else PhotoProcessor.compose(this, uri, 2400, deviceName(), prefs.watermark)
            } catch (t: Throwable) { null }
            runOnUiThread { if (bmp != null) review.show(bmp) else toast("Không mở được ảnh") }
        }
    }

    private fun loadLatestThumb() {
        exec.execute {
            try {
                val sel = "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? AND ${MediaStore.Images.Media.DISPLAY_NAME} LIKE ? " +
                    "AND ${MediaStore.Images.Media.DISPLAY_NAME} NOT LIKE ?"
                val args = arrayOf("Pictures/Xpan-Mode%", "XPAN_%.jpg", "%FULL%")
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME),
                    sel, args, "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { c ->
                    if (c.moveToFirst()) {
                        val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(0))
                        lastUri = uri
                        lastFramed = (c.getString(1) ?: "").contains("FRAME")
                        val th = PhotoProcessor.decodeUpright(this, uri, 256)
                        runOnUiThread { if (th != null) ui.thumb.setImageBitmap(th) }
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    // ------------------------------------------------------------------ cài đặt

    /** Mở màn Cài đặt riêng: tạm dừng camera và bỏ giữ sáng màn hình để tiết kiệm pin. */
    private fun openSettings() {
        if (settingsOpen) return
        settingsOpen = true
        setTray(false)
        if (panel.isOpen) panel.close()
        val oldRaw = prefs.saveRaw
        cam.close()
        openedLensId = null
        info = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        settings.onClosed = {
            settingsOpen = false
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (prefs.saveRaw != oldRaw) openedLensId = null
            X2dPalette.green = prefs.x2dGreen
            ui.refreshX2dColors()
            hideBars()
            maybeOpen()
        }
        settings.show()
    }
}
