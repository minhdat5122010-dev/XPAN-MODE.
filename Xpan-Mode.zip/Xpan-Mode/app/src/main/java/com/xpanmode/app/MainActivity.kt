package com.xpanmode.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentUris
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.graphics.Bitmap
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.text.InputType
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.TextureView
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.CheckBox
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors
import kotlin.math.abs
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : Activity(), CameraController.Callback {
    private companion object {
    }
    private lateinit var prefs: Prefs
    private lateinit var repo: LensRepository
    private lateinit var cam: CameraController
    private lateinit var ui: CameraLayout
    private lateinit var root: FrameLayout
    private lateinit var review: ReviewView
    private lateinit var panel: EditPanel
    private lateinit var settings: SettingsView
    private var settingsOpen = false
    private var presets: MutableList<Preset> = ArrayList()

    private var entries: List<ZoomEntry> = emptyList()
    private var selected = 0
    private var userZoom = 1f
    private var dragStartZoom = 1f
    private var dragSnap = 0f
    private var info: CameraController.OpenInfo? = null
    private var openedLensId: String? = null
    private var surface: SurfaceTexture? = null
    private var ready = false
    private var resumed = false
    private var shooting = false
    private var lastUri: Uri? = null
    private var reviewUri: Uri? = null
    private var lastFramed = false
    private var reviewFramed = false
    private val exec = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    private var focusId = 0
    private var focusLoaded = false
    private val pendingSeqs = ArrayDeque<Int>()
    private var shotSeq = 0
    private var processingCount = 0
    private var pool: SoundPool? = null
    private var shutterId = 0
    private var shutterLoaded = false
    private var curtainId = 0
    private var curtainLoaded = false
    private val curtainSeqs = HashSet<Int>()
    private var tickId = 0
    private var tickLoaded = false
    private var lastTickIdx = -1
    private var tickMuteUntil = 0L
    private var lensFxActive = false
    private var lensFxStart = 0L
    private val finishLensFxRunnable = Runnable {
        ui.lensFx.hide()
        lensFxActive = false
    }
    private var freezeActive = false
    private var revealed = false
    private var processed = false
    private var resultBmp: Bitmap? = null
    // hiệu ứng chụp theo video: 1 âm bản -> 2 xám phủ kín -> 3 xám tan -> 4 giữ ảnh -> 5 ảnh bay về thumbnail
    private var phase = 0
    /** Đang chạy hiệu ứng riêng của HQ ghép khung (phase = 6). */
    private var hqFxMode = false
    private var negStart = 0L
    private var captureDone = false
    private var frozenBmp: Bitmap? = null
    private var pendingThumb: Bitmap? = null
    private val negCheck = Runnable { tryEndNegative() }
    private val dockRunnable = Runnable { dock() }
    private val filterItems = ArrayList<FilterItemView>()
    private val warned = HashSet<String>()

    /** Hiện/ẩn khay bộ lọc dọc có hiệu ứng trượt + mờ (ảnh xem trước cập nhật mỗi giây khi đang mở). */
    /** Bấm nút filter hoặc tab XPAN × ở mép phải: mở ngăn kéo (cuộn tới ô đang chọn) hoặc đóng lại. */
    private fun toggleTray() {
        if (ui.tray.visibility == View.VISIBLE) { setTray(false); return }
        setTray(true)
        lastTickIdx = prefs.filter
        tickMuteUntil = SystemClock.uptimeMillis() + 600
        ui.tray.postDelayed({
            val c = filterItems.getOrNull(prefs.filter)
            if (c != null) ui.tray.smoothScrollTo(0, (c.top + ui.tray.paddingTop - 28 * resources.displayMetrics.density).toInt().coerceAtLeast(0))
        }, 40)
    }

    /** Mở/đóng ngăn kéo bộ lọc bên phải: giao diện camera thu nhỏ sang trái, ngăn kéo trượt vào. */
    private fun setTray(show: Boolean) {
        if (show) {
            ui.setDrawer(true)
        } else {
            ui.setDrawer(false)
        }
    }

    private fun spin(v: View, deg: Float) {
        android.animation.ObjectAnimator.ofFloat(v, View.ROTATION, v.rotation, v.rotation + deg).apply {
            duration = 380
            interpolator = android.view.animation.OvershootInterpolator(1.2f)
            start()
        }
    }

    // ------------------------------------------------------------------ vòng đời

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        prefs = Prefs(this)
        presets = prefs.presets.toMutableList()
        repo = LensRepository(this)
        cam = CameraController(this, repo, this)
        pool = SoundPool.Builder().setMaxStreams(4).setAudioAttributes(
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
        ).build().also { p ->
            p.setOnLoadCompleteListener { _, id, status ->
                if (status == 0) { if (id == shutterId) shutterLoaded = true else if (id == curtainId) curtainLoaded = true else if (id == focusId) focusLoaded = true else if (id == tickId) tickLoaded = true }
            }
            shutterId = p.load(this, R.raw.shutter_classic, 1)
            curtainId = p.load(this, R.raw.curtain, 1)
            focusId = p.load(this, R.raw.focus_click, 1)
            tickId = p.load(this, R.raw.filter_tick, 1)
        }

        ui = CameraLayout(this)
        review = ReviewView(this)
        panel = EditPanel(this)
        panel.visibility = View.GONE
        root = FrameLayout(this)
        root.addView(ui, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        val dnp = resources.displayMetrics.density
        val plp = FrameLayout.LayoutParams(
            minOf((320 * dnp).toInt(), (resources.displayMetrics.widthPixels * 0.46f).toInt()),
            ViewGroup.LayoutParams.MATCH_PARENT, android.view.Gravity.END)
        plp.setMargins(0, (12 * dnp).toInt(), (12 * dnp).toInt(), (12 * dnp).toInt())
        root.addView(panel, plp)
        panel.bindBackdrop(ui)
        root.addView(review, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        settings = SettingsView(this, prefs) { repo.report() }
        root.addView(settings, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        setContentView(root)
        hideBars()
        root.setOnApplyWindowInsetsListener { _, ins ->
            val cut = ins.displayCutout
            ui.setSafe(cut?.safeInsetLeft ?: 0, cut?.safeInsetRight ?: 0)
            settings.setSafe(cut?.safeInsetLeft ?: 0, cut?.safeInsetRight ?: 0)
            (panel.layoutParams as FrameLayout.LayoutParams).rightMargin = (cut?.safeInsetRight ?: 0) + (12 * resources.displayMetrics.density).toInt()
            panel.requestLayout()
            ins
        }

        setupUi()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) { updateTransform() }
        }, null)

        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) initCamera()
        else requestPermissions(arrayOf(Manifest.permission.CAMERA), 1)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            initCamera()
            maybeOpen()
        } else {
            toast("Cần cấp quyền Camera để sử dụng Xpan-Mode")
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        hideBars()
        if (ready) maybeOpen()
    }

    override fun onPause() {
        resumed = false
        cam.close()
        openedLensId = null
        info = null
        review.hide()
        releaseFreeze()
        super.onPause()
    }

    override fun onDestroy() {
        cam.release()
        exec.shutdown()
        pool?.release()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    private fun isVolumeKey(k: Int) = k == KeyEvent.KEYCODE_VOLUME_UP || k == KeyEvent.KEYCODE_VOLUME_DOWN

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (prefs.volumeShutter && isVolumeKey(keyCode) && review.visibility != View.VISIBLE && !settingsOpen) {
            if (event.repeatCount == 0) takePhoto()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (prefs.volumeShutter && isVolumeKey(keyCode) && review.visibility != View.VISIBLE && !settingsOpen) return true
        return super.onKeyUp(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (settingsOpen) settings.hide()
        else if (review.visibility == View.VISIBLE) review.hide()
        else if (ui.tray.visibility == View.VISIBLE) setTray(false)
        else if (panel.isOpen) panel.close()
        else super.onBackPressed()
    }

    @Suppress("DEPRECATION")
    private fun hideBars() {
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(WindowInsets.Type.systemBars())
                it.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------------------ khởi tạo camera / UI

    private fun initCamera() {
        repo.scan()
        entries = repo.entries()
        if (entries.isEmpty()) {
            toast("Không tìm thấy camera sau trên thiết bị")
            return
        }
        val key = prefs.entryKey
        selected = entries.indexOfFirst { it.key == key }.takeIf { it >= 0 }
            ?: entries.indices.minByOrNull { abs(entries[it].ratio - 1f) } ?: 0
        ui.ladder.labels = entries.map { it.ratioLabel }
        ui.pills.labels = entries.map { it.mmLabel }
        syncSel()
        ready = true
        loadLatestThumb()
        if (resumed) maybeOpen()
    }

    private fun setupUi() {
        ui.classic = prefs.classic
        ui.light = prefs.light
        panel.applyTheme()
        ui.texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { surface = st; maybeOpen() }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { updateTransform() }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
                cam.close(); surface = null; openedLensId = null; info = null
                return true
            }
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {
                // khung hình đầu tiên của ống kính mới đã tới: lúc này mới lộ khung ngắm thật (tránh thấy hình cũ/đen)
                if (fxAwaitFrame) { fxAwaitFrame = false; main.removeCallbacks(frameTimeoutRunnable); completeFx() }
            }
        }
        ui.texture.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> updateTransform() }

        val scaleDet = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val mz = info?.maxZoom ?: 1f
                userZoom = (userZoom * d.scaleFactor).coerceIn(1f, mz)
                cam.setZoom(userZoom)
                val lid = info?.lens?.id
                val idx = entries.indices.filter { entries[it].lens.id == lid }
                    .minByOrNull { abs(entries[it].zoom - userZoom) }
                if (idx != null && idx != selected) { selected = idx; syncSel() }
                updateZoomLabels()
                return true
            }
        })
        val tapDet = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                val i = info ?: return true
                val tw = ui.texture.width.toFloat()
                val th = ui.texture.height.toFloat()
                if (tw <= 0f || th <= 0f) return true
                val band = (i.preview.width.toFloat() / i.preview.height * 24f / 65f).coerceAtMost(1f)
                cam.focusAt(e.x / tw, e.y / th, band, jpegRotation(i) == 180)
                ui.focusBox.showAt(e.x, e.y)
                return true
            }
        })
        ui.texture.setOnTouchListener { _, e ->
            scaleDet.onTouchEvent(e)
            if (!scaleDet.isInProgress && e.pointerCount == 1) tapDet.onTouchEvent(e)
            true
        }

        ui.ladder.onSelect = { selectEntry(it) }
        ui.pills.onSelect = { selectEntry(it) }
        // vuốt dọc trên vùng chọn tiêu cự: thu phóng liên tục trong ống kính hiện tại (không đổi camera)
        for (zd in listOf(ui.ladder.zoomDrag, ui.pills.zoomDrag)) {
            zd.onStart = { dragStartZoom = userZoom; dragSnap = 0f }
            zd.onMove = { up -> zoomDragTo(up) }
            zd.onEnd = { ui.zoomHud.hideSoon() }
        }
        ui.ev.onChange = { v ->
            ui.ev.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            prefs.cam = prefs.cam.copy(ev = v)
            cam.setParams(prefs.cam)
            panel.setEv(v)
        }
        panel.onCam = { c ->
            prefs.cam = c
            cam.setParams(c)
            if (ui.ev.value != c.ev) ui.ev.value = c.ev
        }
        panel.onAdjust = { a ->
            prefs.adjust = a
            applyFilter()
        }
        panel.onReset = {
            prefs.adjust = Adjust()
            prefs.cam = CamParams()
            applyCam()
            panel.setState(prefs.cam, prefs.adjust)
            applyFilter()
        }
        panel.onSave = { promptSavePreset() }
        panel.onClose = { panel.close() }
        ui.edit.setOnClickListener {
            if (panel.isOpen) panel.close()
            else {
                setTray(false)
                panel.setState(prefs.cam, prefs.adjust)
                panel.open()
            }
        }
        ui.shutter.setOnClickListener { takePhoto() }
        // chạm: mở thẳng trong ứng dụng Thư viện; nhấn giữ: xem khung trắng + thông số trong app
        ui.thumb.setOnClickListener {
            lastUri?.let {
                try {
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(it, "image/jpeg").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                } catch (t: Throwable) {
                    toast("Không mở được ứng dụng Thư viện")
                }
            }
        }
        ui.thumb.setOnLongClickListener { lastUri?.let { showReview(it) }; true }
        ui.thumb.pressFeedback(0.9f)
        ui.toggle.setOnClickListener {
            prefs.classic = !prefs.classic
            spin(ui.toggle, 180f)
            ui.animate().cancel()
            ui.animate().alpha(0f).setDuration(140).withEndAction {
                ui.classic = prefs.classic
                panel.applyTheme()
                ui.animate().alpha(1f).setDuration(260).start()
            }.start()
        }
        ui.gear.setOnClickListener { spin(ui.gear, 60f); openSettings() }
        // đổi giao diện sáng (trắng) / tối
        ui.theme.setOnClickListener {
            prefs.light = !prefs.light
            spin(ui.theme, 180f)
            ui.animate().cancel()
            ui.animate().alpha(0f).setDuration(140).withEndAction {
                ui.light = prefs.light
                panel.applyTheme()
                ui.animate().alpha(1f).setDuration(260).start()
            }.start()
        }
        ui.filterBtn.setOnClickListener { toggleTray() }
        ui.drawer.onTab = { toggleTray() }
        ui.wm.setOnClickListener { showCaptureMenu() }
        buildTray()
        applyFilter()

        review.onClose = { review.hide() }
        review.onOpen = {
            reviewUri?.let {
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(it, "image/jpeg").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }
        }
        review.onSaveFrame = {
            val u = reviewUri
            if (u != null && reviewFramed) toast("Ảnh này đã có khung rồi")
            else if (u != null) exec.execute {
                var err: String? = null
                val r = try { PhotoProcessor.saveFramed(this, u, deviceName(), prefs.watermark) } catch (t: Throwable) { err = PhotoProcessor.errText(t); null }
                runOnUiThread { toast(if (r != null) "Đã lưu ảnh có khung vào Pictures/Xpan-Mode" else "Không lưu được ảnh khung: $err") }
            }
        }
    }

    private fun buildTray() {
        ui.trayRow.removeAllViews()
        filterItems.clear()
        val dn = resources.displayMetrics.density
        val builtIn = XpanFilter.all.size
        allFilters().forEachIndexed { i, f ->
            val v = FilterItemView(this)
            v.name = f.name
            v.filter = f
            v.caption = captionFor(f, i)
            v.selectedItem = i == prefs.filter
            v.setOnClickListener {
                v.pop(1.06f)
                filterTick()
                lastTickIdx = i
                selectFilter(i)
            }
            v.setOnLongClickListener { onFilterLong(i); true }
            v.pressFeedback(0.94f)
            val lp = LinearLayout.LayoutParams((FilterItemView.W_DP * dn).toInt(), (FilterItemView.H_DP * dn).toInt())
            lp.gravity = Gravity.CENTER_HORIZONTAL
            ui.trayRow.addView(v, lp)
            filterItems.add(v)
        }
        // chạm / cuộn khay thì gia hạn thời gian tự ẩn
        ui.tray.setOnScrollChangeListener { _, _, _, _, _ ->
            if (ui.tray.visibility == View.VISIBLE) {
                val idx = trayCenterIndex()
                if (idx != lastTickIdx) {
                    lastTickIdx = idx
                    // lúc khay tự cuộn tới ô đang chọn khi mở thì im lặng
                    if (SystemClock.uptimeMillis() >= tickMuteUntil) filterTick()
                }
            }
        }
    }

    private fun captionFor(f: XpanFilter, i: Int): String = if (i >= XpanFilter.all.size) "Của tôi" else when (f.name) {
        "Original" -> "Gốc"
        "Natural" -> "Tự nhiên"
        "Portrait" -> "Chân dung"
        "Landscape" -> "Phong cảnh"
        "XPan Chrome" -> "Chrome"
        "Golden Hour" -> "Hoàng hôn"
        "Mono" -> "Đen trắng"
        "Fuji Film" -> "Fuji"
        "Leica M9" -> "Leica"
        "Vivo Zeiss" -> "Trong trẻo"
        else -> ""
    }

    private fun allFilters(): List<XpanFilter> = XpanFilter.all + presets.map { it.look }

    private fun baseFilter(): XpanFilter {
        val l = allFilters()
        return l[prefs.filter.coerceIn(0, l.size - 1)]
    }

    private fun selectFilter(i: Int) {
        val fromPreset = prefs.filter >= XpanFilter.all.size
        prefs.filter = i
        prefs.adjust = Adjust()
        val k = i - XpanFilter.all.size
        if (k >= 0 && k < presets.size) {
            prefs.cam = presets[k].cam
            applyCam()
        } else if (fromPreset) {
            // rời bộ lọc đã lưu để sang bộ lọc có sẵn: trả thông số camera (EV, tốc độ, ISO, WB, nét) về mặc định
            prefs.cam = CamParams()
            applyCam()
        }
        panel.setState(prefs.cam, prefs.adjust)
        applyFilter()
    }

    private fun applyCam() {
        cam.setParams(prefs.cam)
        if (ui.ev.max >= ui.ev.min) ui.ev.value = prefs.cam.ev.coerceIn(ui.ev.min, ui.ev.max)
    }

    private fun promptName(title: String, initial: String, ok: (String) -> Unit) {
        val dn = resources.displayMetrics.density
        val et = EditText(this)
        et.setSingleLine()
        et.setText(initial)
        et.setSelectAllOnFocus(true)
        val box = FrameLayout(this)
        val p = (20 * dn).toInt()
        box.setPadding(p, p / 2, p, 0)
        box.addView(et)
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("Lưu") { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) ok(n)
            }
            .setNegativeButton("Huỷ", null)
            .create()
            .also { it.setOnDismissListener { hideBars() }; it.show() }
    }

    /** Lưu toàn bộ chỉnh sửa hiện tại (màu + thông số camera) thành một bộ lọc có tên. */
    private fun promptSavePreset() {
        promptName("Tên bộ lọc mới", "Bộ lọc ${presets.size + 1}") { n ->
            val p = Preset(java.util.UUID.randomUUID().toString(), n, curFilter().copy(name = n), prefs.cam)
            presets.add(p)
            prefs.presets = presets
            buildTray()
            selectFilter(XpanFilter.all.size + presets.size - 1)
            toast("Đã lưu bộ lọc \"$n\". Giữ vào tên bộ lọc để đổi tên hoặc xoá.")
        }
    }

    /** Giữ vào một bộ lọc: đổi tên / ghi đè / xoá (chỉ với bộ lọc tự lưu). */
    private fun onFilterLong(i: Int) {
        val k = i - XpanFilter.all.size
        if (k < 0 || k >= presets.size) {
            toast("Bộ lọc có sẵn không đổi tên được. Bấm nút Chỉnh sửa rồi \"Lưu thành bộ lọc\" để tạo bộ lọc riêng.")
            return
        }
        val p = presets[k]
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle(p.name)
            .setItems(arrayOf("Đổi tên", "Ghi đè bằng chỉnh sửa hiện tại", "Xoá bộ lọc")) { _, which ->
                when (which) {
                    0 -> promptName("Đổi tên bộ lọc", p.name) { n ->
                        presets[k] = p.copy(name = n, look = p.look.copy(name = n))
                        prefs.presets = presets
                        buildTray()
                        applyFilter()
                    }
                    1 -> if (prefs.filter != i) toast("Hãy chọn bộ lọc này trước, chỉnh sửa rồi mới ghi đè.")
                    else {
                        presets[k] = p.copy(look = curFilter().copy(name = p.name), cam = prefs.cam)
                        prefs.presets = presets
                        prefs.adjust = Adjust()
                        buildTray()
                        panel.setState(prefs.cam, prefs.adjust)
                        applyFilter()
                        toast("Đã cập nhật bộ lọc \"${p.name}\"")
                    }
                    2 -> AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
                        .setTitle("Xoá \"${p.name}\"?")
                        .setPositiveButton("Xoá") { _, _ ->
                            presets.removeAt(k)
                            prefs.presets = presets
                            if (prefs.filter == i) { prefs.filter = 0; prefs.adjust = Adjust(); prefs.cam = CamParams(); applyCam() }
                            else if (prefs.filter > i) prefs.filter -= 1
                            buildTray()
                            panel.setState(prefs.cam, prefs.adjust)
                            applyFilter()
                        }
                        .setNegativeButton("Huỷ", null)
                        .create().also { it.setOnDismissListener { hideBars() }; it.show() }
                }
            }
            .create()
            .also { it.setOnDismissListener { hideBars() }; it.show() }
    }

    private fun applyFilter() {
        val f = baseFilter()
        ui.filterBtn.label = f.name
        val all = allFilters()
        filterItems.forEachIndexed { i, v ->
            val sel = i == prefs.filter
            v.selectedItem = sel
            // ô đang chọn hiển thị đúng như khung ngắm (kèm phần chỉnh tay)
            v.filter = if (sel) f.adjusted(prefs.adjust) else all[i]
        }
        setTexturePaint(false)
    }

    private fun setTexturePaint(invert: Boolean) {
        val f = curFilter()
        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(if (invert) XpanFilter.invertMatrix() else f.previewMatrix())
        ui.texture.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
        if (!invert) panel.setBackdropFilter(ColorMatrixColorFilter(f.previewMatrix()))
    }

    /** Vuốt lên = phóng to, xuống = thu nhỏ; mỗi ~150dp vuốt thì gấp đôi / giảm nửa. Giới hạn theo độ phân giải của ống kính. */
    private fun zoomDragTo(upPx: Float) {
        val i = info ?: return
        if (lensFxActive || i.lens.id != entries.getOrNull(selected)?.lens?.id) return
        val dn = resources.displayMetrics.density
        var z = (dragStartZoom * Math.pow(2.0, (upPx / (150f * dn)).toDouble()).toFloat()).coerceIn(1f, i.maxZoom)
        // hít vào các mốc tự nhiên của ống kính (1x gốc, mốc crop 2x...) để dễ quay về tiêu cự chuẩn
        val marks = entries.filter { it.lens.id == i.lens.id }.map { it.zoom }.filter { it <= i.maxZoom }
        val snap = marks.minByOrNull { abs(it - z) }
        if (snap != null && abs(snap - z) / snap < 0.035f) {
            z = snap
            if (dragSnap != snap) { dragSnap = snap; ui.pills.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK) }
        } else {
            dragSnap = 0f
        }
        if (abs(z - userZoom) > 0.0005f) {
            userZoom = z
            cam.setZoom(z)
            val idx = entries.indices.filter { entries[it].lens.id == i.lens.id }
                .minByOrNull { abs(entries[it].zoom - userZoom) }
            if (idx != null && idx != selected) { selected = idx; syncSel() }
            updateZoomLabels()
        }
        val e = entries.getOrNull(selected) ?: return
        val ratio = e.ratio * userZoom / e.zoom
        ui.zoomHud.show("${repo.fmtRatio(ratio)}×  ·  ${(i.lens.eq35 * userZoom).roundToInt()}mm")
    }

    /** Khi đang ở giữa hai mốc (thu phóng liên tục) thì nút tiêu cự hiện số thực; đúng mốc thì về nhãn gốc. */
    private fun updateZoomLabels() {
        val i = info
        val e = entries.getOrNull(selected)
        if (i == null || e == null || i.lens.id != e.lens.id || abs(userZoom - e.zoom) < 0.02f) {
            ui.pills.liveLabel = null
            ui.ladder.liveLabel = null
            return
        }
        ui.pills.liveLabel = (i.lens.eq35 * userZoom).roundToInt().toString()
        ui.ladder.liveLabel = repo.fmtRatio(e.ratio * userZoom / e.zoom)
    }

    private fun syncSel() {
        ui.ladder.selected = selected
        ui.pills.selected = selected
    }

    // ------------------------------------------------------------------ mở camera / chọn ống kính

    private fun maybeOpen() {
        if (!ready || !resumed || settingsOpen || entries.isEmpty()) return
        val st = surface ?: return
        val e = entries[selected]
        userZoom = e.zoom
        cam.multiFrame = prefs.hq     // HQ: chụp 50MP thật nếu máy cho, không thì ghép nhiều khung
        cam.open(e.lens, st, repo.previewSize(e.lens), prefs.saveRaw, e.ratio / e.zoom, prefs.hq)
    }

    /** Chụp đúng hình đang thấy trên khung ngắm (đã xoay/cắt theo ma trận của TextureView). */
    private fun grabPreview(): Bitmap? {
        val tv = ui.texture
        val w = tv.width
        val h = tv.height
        if (w <= 0 || h <= 0) return null
        return try {
            val raw = tv.getBitmap(w, h) ?: return null
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val m = Matrix()
            tv.getTransform(m)
            Canvas(out).drawBitmap(raw, m, Paint(Paint.FILTER_BITMAP_FLAG))
            raw.recycle()
            out
        } catch (t: Throwable) {
            null
        }
    }

    private fun fxNodes(): List<LensFxNode> = entries.map { e ->
        val eq = e.lens.eq35 * e.zoom
        val title = when {
            e.zoom > 1f -> "${e.ratioLabel}× CROP"
            e.ratio < 0.95f -> "ULTRA WIDE"
            e.ratio < 1.7f -> "WIDE"
            else -> "TELEPHOTO"
        }
        val ap = if (e.lens.aperture > 0f) String.format(Locale.US, " · f/%.1f", e.lens.aperture) else ""
        LensFxNode(title, "${eq.roundToInt()}mm$ap", e.ratioLabel, eq)
    }

    private fun startLensFx(from: Int, to: Int) {
        val frame: Bitmap? = grabPreview()
        main.removeCallbacks(finishLensFxRunnable)
        main.removeCallbacks(completeLensFxRunnable)
        main.removeCallbacks(frameTimeoutRunnable)
        fxAwaitFrame = false
        ui.lensFx.start(fxNodes(), from, to, frame, ColorMatrixColorFilter(curFilter().previewMatrix()), lensLatencyMs)
        lensFxStart = SystemClock.uptimeMillis()
        lensFxActive = true
    }

    private val completeLensFxRunnable = Runnable { ui.lensFx.complete() }
    private var fxAwaitFrame = false
    /** Độ trễ thực đo được từ lúc bấm đến khi có khung hình mới (ms); animation lần sau kéo dài bám theo con số này. */
    private var lensLatencyMs = 600L
    private val frameTimeoutRunnable = Runnable {
        if (fxAwaitFrame) { fxAwaitFrame = false; completeFx() }
    }

    /**
     * Camera/zoom mới đã cấu hình xong: chờ KHUNG HÌNH ĐẦU TIÊN của nó (onReady chạy trước khi có hình, nếu lộ ngay sẽ thấy
     * hình cũ hoặc màn đen rồi mới nhảy sang cam mới). Có hình thì hiệu ứng mới chạy nốt và lộ khung ngắm thật.
     */
    private fun finishLensFx() {
        if (!lensFxActive || fxAwaitFrame) return
        fxAwaitFrame = true
        main.removeCallbacks(frameTimeoutRunnable)
        main.postDelayed(frameTimeoutRunnable, 350)   // dự phòng nếu không nhận được khung hình
    }

    private fun completeFx() {
        if (!lensFxActive) return
        val elapsed = SystemClock.uptimeMillis() - lensFxStart
        lensLatencyMs = ((lensLatencyMs + elapsed) / 2).coerceIn(250L, 1000L)
        val wait = max(0L, 90L - elapsed)
        main.removeCallbacks(completeLensFxRunnable)
        main.postDelayed(completeLensFxRunnable, wait)
        main.removeCallbacks(finishLensFxRunnable)
        main.postDelayed(finishLensFxRunnable, wait + 250)
    }

    private fun selectEntry(i: Int) {
        if (i !in entries.indices) return
        val e = entries[i]
        if (i == selected && openedLensId == e.lens.id) {
            // chạm lại đúng nút đang chọn sau khi đã vuốt thu phóng: về tiêu cự gốc của nút đó
            if (abs(userZoom - e.zoom) > 0.02f) {
                userZoom = e.zoom
                cam.setZoom(userZoom)
                updateZoomLabels()
                ui.zoomHud.hideSoon(0L)
            }
            return
        }
        val prev = selected
        startLensFx(prev, i)
        ui.pills.liveLabel = null
        ui.ladder.liveLabel = null
        selected = i
        prefs.entryKey = e.key
        syncSel()
        if (openedLensId == e.lens.id) {
            userZoom = e.zoom
            cam.setZoom(userZoom)
            main.postDelayed({ finishLensFx() }, 120)
        } else {
            openedLensId = null
            maybeOpen()
            main.postDelayed({ finishLensFx() }, 6000)   // dự phòng nếu mở camera quá lâu / lỗi
        }
    }

    override fun onReady(info: CameraController.OpenInfo) {
        this.info = info
        openedLensId = info.lens.id
        ui.ev.min = info.evMin
        ui.ev.max = info.evMax
        ui.ev.step = info.evStep
        val evNow = prefs.cam.ev.coerceIn(info.evMin, info.evMax)
        if (evNow != prefs.cam.ev) prefs.cam = prefs.cam.copy(ev = evNow)
        ui.ev.value = evNow
        panel.setCaps(info.caps, info.evMin, info.evMax, info.evStep)
        panel.setState(prefs.cam, prefs.adjust)
        cam.setParams(prefs.cam)
        if (info.viaZoom && warned.add(info.lens.id)) {
            toast("Máy chặn app bên thứ ba mở ống kính ${info.lens.eq35.toInt()}mm (ID ${info.lens.id}); " +
                "đang dùng zoom của camera chính nên có thể chỉ là crop, không phải tele thật.")
        }
        updateTransform()
        cam.setZoom(userZoom)
        updateZoomLabels()
        updateHqNote()
        finishLensFx()
    }

    override fun onError(msg: String) {
        curtainSeqs.clear()
        pendingSeqs.clear()
        toast(msg)
        finishLensFx()
        releaseFreeze()
    }

    /** Tiếng chỉ phát theo âm lượng đa phương tiện; tuỳ chọn im lặng khi máy ở chế độ im lặng/rung. */
    /** Tiếng "tạch" như bấm nấc máy ảnh cơ (kèm rung nhẹ) mỗi khi chọn / lướt qua một bộ lọc. */
    private fun filterTick() {
        ui.tray.performHapticFeedback(android.view.HapticFeedbackConstants.CLOCK_TICK)
        if (prefs.sound && tickLoaded && soundAllowed()) {
            pool?.play(tickId, 0.7f, 0.7f, 1, 0, 0.96f + Math.random().toFloat() * 0.1f)
        }
    }

    /** Ô bộ lọc nằm gần tâm khay nhất (theo vị trí cuộn hiện tại). */
    private fun trayCenterIndex(): Int {
        val h = (FilterItemView.H_DP * resources.displayMetrics.density).toInt().coerceAtLeast(1)
        val y = ui.tray.scrollY + ui.tray.height / 2 - ui.tray.paddingTop
        return (y / h).coerceIn(0, (filterItems.size - 1).coerceAtLeast(0))
    }

    private fun hitView(v: View, x: Int, y: Int): Boolean {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return x >= loc[0] && x <= loc[0] + v.width && y >= loc[1] && y <= loc[1] + v.height
    }

    /** Chạm ra ngoài khay bộ lọc thì khay tự ẩn (chạm vẫn được chuyển tiếp xuống phía dưới). */
    private var swallowTouch = false

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        // đang mở bảng chỉnh thông số: chạm ra ngoài thì đóng bảng (và nuốt cú chạm đó để không lỡ chụp / lấy nét)
        if (::ui.isInitialized && ::panel.isInitialized) {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
                swallowTouch = false
                if (panel.isOpen) {
                    val x = ev.rawX.toInt()
                    val y = ev.rawY.toInt()
                    // nút chỉnh sửa tự bật/tắt bảng của nó
                    if (!hitView(panel, x, y) && !hitView(ui.edit, x, y)) {
                        panel.close()
                        swallowTouch = true
                    }
                }
            }
            if (swallowTouch) {
                if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) swallowTouch = false
                return true
            }
        }
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && ::ui.isInitialized && ui.tray.visibility == View.VISIBLE) {
            val x = ev.rawX.toInt()
            val y = ev.rawY.toInt()
            // nút bộ lọc tự xử lý việc bật/tắt khay của nó
            if (!hitView(ui.drawer, x, y) && !hitView(ui.tray, x, y) && !hitView(ui.filterBtn, x, y)) {
                setTray(false)
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun soundAllowed(): Boolean {
        if (!prefs.respectSilent) return true
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        return am.ringerMode == AudioManager.RINGER_MODE_NORMAL
    }

    override fun onFocus(ok: Boolean) {
        ui.focusBox.lock(ok)
        if (ok && prefs.focusSound && focusLoaded && soundAllowed()) pool?.play(focusId, 0.9f, 0.9f, 1, 0, 1f)
    }

    @Suppress("DEPRECATION")
    private fun dispRot(): Int = windowManager.defaultDisplay.rotation

    private fun jpegRotation(i: CameraController.OpenInfo): Int =
        (i.sensorOrientation - dispRot() * 90 + 360) % 360

    private fun updateTransform() {
        val i = info ?: return
        val tv = ui.texture
        val vw = tv.width.toFloat()
        val vh = tv.height.toFloat()
        if (vw == 0f || vh == 0f) return
        val rot = dispRot()
        val matrix = Matrix()
        val viewRect = RectF(0f, 0f, vw, vh)
        val bufRect = RectF(0f, 0f, i.preview.height.toFloat(), i.preview.width.toFloat())
        val cx = viewRect.centerX()
        val cy = viewRect.centerY()
        if (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270) {
            bufRect.offset(cx - bufRect.centerX(), cy - bufRect.centerY())
            matrix.setRectToRect(viewRect, bufRect, Matrix.ScaleToFit.FILL)
            val scale = max(vh / i.preview.height, vw / i.preview.width)
            matrix.postScale(scale, scale, cx, cy)
            matrix.postRotate(90f * (rot - 2), cx, cy)
        } else if (rot == Surface.ROTATION_180) {
            matrix.postRotate(180f, cx, cy)
        }
        tv.setTransform(matrix)
    }

    // ------------------------------------------------------------------ chụp ảnh

    private fun curFilter() = baseFilter().adjusted(prefs.adjust)

    private val failSafe = Runnable { releaseFreeze() }

    private val NEG_MIN = 1050L      // giữ âm bản tối thiểu (video: ~1,07s)
    private val NEG_MAX = 4000L      // tối đa nếu chụp chậm
    private val GREY_IN = 200L       // âm bản -> xám phẳng
    private val GREY_OUT = 600L      // xám tan dần để lộ ảnh
    private val HOLD = 650L          // giữ ảnh trước khi bay về thumbnail
    private val FLY = 330L           // ảnh thu nhỏ bay về thumbnail

    /** Chế độ "màn chập": chụp ngay, không đóng băng/rửa film; màn chập quét xuống + tiếng; bấm liên tiếp được. */
    private fun takePhotoCurtain() {
        val i = info ?: return
        if (lensFxActive || phase != 0) return
        if (curtainSeqs.size >= 4) return              // tối đa 1 tấm đang chụp + 3 tấm xếp hàng
        if (ui.tray.visibility == View.VISIBLE) setTray(false)
        if (ui.texture.width <= 0 || ui.texture.height <= 0) return
        shotSeq++
        pendingSeqs.addLast(shotSeq)
        curtainSeqs.add(shotSeq)
        if (prefs.sound && curtainLoaded && soundAllowed()) pool?.play(curtainId, 1f, 1f, 1, 0, 1f)
        ui.shutter.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        cam.capture(jpegRotation(i))
        ui.curtain.fire()
    }

    /** HQ ghép 5 khung: hiệu ứng riêng (khung nhoè + 5 cột rõ dần theo từng khung, rồi tiến trình ghép), thay cho rửa film/màn chập. */
    private fun takePhotoHq() {
        val i = info ?: return
        if (shooting || lensFxActive || phase != 0) return
        if (ui.tray.visibility == View.VISIBLE) setTray(false)
        if (ui.texture.width <= 0 || ui.texture.height <= 0) return
        shooting = true
        revealed = false
        processed = false
        resultBmp = null
        captureDone = false
        pendingThumb = null
        shotSeq++
        pendingSeqs.addLast(shotSeq)
        ui.shutter.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        cam.capture(jpegRotation(i))
        main.removeCallbacks(failSafe)
        main.postDelayed(failSafe, 40000)
        val frozen: Bitmap? = grabPreview()
        frozenBmp = frozen
        if (frozen != null) {
            hqFxMode = true
            phase = 6
            ui.setChromeHidden(true)
            ui.hqFx.start(frozen, 5)
        } else main.postDelayed({ if (phase == 0) shooting = false }, 400)
    }

    /** Ảnh HQ đã xử lý xong: quét ảnh kết quả thay khung nhoè rồi bay về thumbnail. */
    private fun hqDone() {
        if (!hqFxMode) return
        hqFxMode = false
        val r = resultBmp ?: frozenBmp
        ui.hqFx.complete(r) {
            val bmp = resultBmp ?: frozenBmp
            if (bmp != null) {
                ui.freeze.colorFilter = null
                ui.freeze.setImageBitmap(bmp)
                ui.freeze.alpha = 1f
                ui.freeze.visibility = View.VISIBLE
                freezeActive = true
            }
            ui.hqFx.stop()
            phase = 4
            main.removeCallbacks(dockRunnable)
            main.postDelayed(dockRunnable, 350L)
        }
    }

    override fun onBurstFrame(n: Int, total: Int) {
        if (!hqFxMode) return
        ui.hqFx.setCaptured(n)
        // mỗi khung chụp xong: một tiếng "tách"
        if (prefs.sound && focusLoaded && soundAllowed()) pool?.play(focusId, 0.9f, 0.9f, 1, 0, 1f)
    }

    private fun takePhoto() {
        val i = info ?: return
        if (prefs.hq && !cam.hqActive) { takePhotoHq(); return }
        if (prefs.captureFx == 1) { takePhotoCurtain(); return }
        if (shooting || lensFxActive || phase != 0) return
        // đóng ngăn kéo trước khi chụp để ảnh bay về đúng ô thumbnail
        if (ui.tray.visibility == View.VISIBLE) setTray(false)
        if (ui.texture.width <= 0 || ui.texture.height <= 0) return
        shooting = true
        revealed = false
        processed = false
        resultBmp = null
        captureDone = false
        pendingThumb = null
        shotSeq++
        pendingSeqs.addLast(shotSeq)
        // Gửi lệnh chụp xuống camera NGAY (trước cả khi đóng băng/dựng hiệu ứng) để khung được lấy sớm nhất có thể
        if (prefs.sound && shutterLoaded && soundAllowed()) pool?.play(shutterId, 1f, 1f, 1, 0, 1f)
        ui.shutter.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
        cam.capture(jpegRotation(i))
        main.removeCallbacks(failSafe)
        main.postDelayed(failSafe, 15000)
        // Đóng băng khung hình lúc bấm chụp
        val frozen: Bitmap? = grabPreview()
        frozenBmp = frozen
        if (frozen != null) {
            // 1) tức thì: khung ngắm thành ảnh ÂM BẢN đóng băng, ẩn khung ngắm/thang EV/dải zoom
            ui.freeze.setImageBitmap(frozen)
            ui.freeze.colorFilter = ColorMatrixColorFilter(XpanFilter.invertMatrix())
            ui.freeze.alpha = 1f
            ui.freeze.visibility = View.VISIBLE
            freezeActive = true
            ui.setChromeHidden(true)
            ui.fx.reset()
            phase = 1
            negStart = SystemClock.uptimeMillis()
            main.removeCallbacks(negCheck)
            main.postDelayed(negCheck, NEG_MIN)
        }
        if (frozen == null) main.postDelayed({ if (phase == 0) shooting = false }, 400)
    }

    /** Hết pha âm bản khi ảnh đã chụp xong và đã giữ đủ thời gian (hoặc quá lâu). */
    private fun tryEndNegative() {
        if (phase != 1) return
        val el = SystemClock.uptimeMillis() - negStart
        if ((captureDone && el >= NEG_MIN) || el >= NEG_MAX) {
            startGrey()
        } else {
            main.removeCallbacks(negCheck)
            main.postDelayed(negCheck, if (el < NEG_MIN) NEG_MIN - el else 50L)
        }
    }

    private fun startGrey() {
        phase = 2
        // 2) âm bản -> xám phẳng
        ui.fx.greyIn(GREY_IN) {
            // xám đang phủ kín: đổi sang ảnh thật (đã áp bộ lọc) mà không bị lộ
            phase = 3
            revealed = true
            if (frozenBmp != null) ui.freeze.colorFilter = ColorMatrixColorFilter(curFilter().previewMatrix())
            applyResultIfReady()
            // 3) xám tan dần
            ui.fx.greyOut(GREY_OUT) {
                phase = 4
                main.removeCallbacks(dockRunnable)
                main.postDelayed(dockRunnable, HOLD)
            }
        }
    }

    private fun applyResultIfReady() {
        val r = resultBmp
        if (revealed && freezeActive && r != null) {
            ui.freeze.colorFilter = null
            ui.freeze.setImageBitmap(r)
        }
    }

    /** 4->5) giao diện trở lại ngay, ảnh vừa chụp thu nhỏ bay về ô thumbnail (ảnh lưu về máy). */
    private fun dock() {
        if (phase != 4) return
        phase = 5
        val bmp = resultBmp ?: frozenBmp
        val vfR = ui.vfRect()
        val thR = ui.thumbRect()
        ui.setChromeHidden(false)
        ui.freeze.visibility = View.GONE
        ui.freeze.setImageDrawable(null)
        freezeActive = false
        main.removeCallbacks(failSafe)
        if (bmp == null) { finishFly(null); return }
        ui.fly.soft = !ui.classic
        ui.fly.start(bmp, vfR, thR, FLY) { finishFly(bmp) }
    }

    private fun finishFly(shown: Bitmap?) {
        phase = 0
        shooting = false
        frozenBmp = null
        val th = pendingThumb ?: shown?.let { coverThumb(it) }
        if (th != null) ui.thumb.setImageBitmap(th)
        popThumb()
    }

    private fun coverThumb(b: Bitmap): Bitmap {
        val side = kotlin.math.min(b.width, b.height)
        val sq = Bitmap.createBitmap(b, (b.width - side) / 2, (b.height - side) / 2, side, side)
        val out = Bitmap.createScaledBitmap(sq, 256, 256, true)
        if (sq !== b && sq !== out) sq.recycle()
        return out
    }

    /** Ô thumbnail "nảy" nhẹ khi nhận ảnh. */
    private fun popThumb() {
        ui.thumb.animate().cancel()
        ui.thumb.animate().scaleX(1.18f).scaleY(1.18f).setDuration(110).withEndAction {
            ui.thumb.animate().scaleX(1f).scaleY(1f).setDuration(150).start()
        }.start()
    }

    private fun setThumbFromProcessing(th: Bitmap) {
        if (phase == 0) ui.thumb.setImageBitmap(th) else pendingThumb = th
    }

    private fun onProcessed(seq: Int, big: Bitmap?) {
        if (seq == shotSeq) {
            processed = true
            resultBmp = big
            if (hqFxMode) hqDone()
        }
    }

    private fun updateProcessingUi() {
        ui.thumb.alpha = if (processingCount > 0) 0.45f else 1f
    }

    /** Dừng khẩn cấp mọi hiệu ứng chụp (lỗi, tạm dừng, quá thời gian). */
    private fun releaseFreeze() {
        main.removeCallbacks(failSafe)
        main.removeCallbacks(negCheck)
        main.removeCallbacks(dockRunnable)
        ui.fx.reset()
        hqFxMode = false
        ui.hqFx.stop()
        ui.fly.cancel()
        ui.setChromeHidden(false)
        ui.freeze.visibility = View.GONE
        ui.freeze.setImageDrawable(null)
        freezeActive = false
        frozenBmp = null
        phase = 0
        shooting = false
    }

    override fun onShot(shot: CameraController.ShotResult) {
        captureDone = true
        main.post { tryEndNegative() }
        if (hqFxMode) ui.hqFx.beginMerge()
        val filter = curFilter()
        val seq = if (pendingSeqs.isEmpty()) shotSeq else pendingSeqs.removeFirst()
        val curtain = curtainSeqs.remove(seq)
        processingCount++
        updateProcessingUi()
        exec.execute {
            var saved: Saved? = null
            try {
                val s: Saved = PhotoProcessor.process(this, shot, filter, prefs) { pct -> runOnUiThread { if (hqFxMode) ui.hqFx.setMerge(pct) } }
                saved = s
                lastUri = s.uri
                lastFramed = s.framed
                runOnUiThread {
                    processingCount = (processingCount - 1).coerceAtLeast(0)
                    updateProcessingUi()
                    s.thumb?.let { setThumbFromProcessing(it); if (curtain) popThumb() }
                    onProcessed(seq, if (curtain) null else s.big)
                    s.fuseMsg?.let { toast(it) }
                }
            } catch (t: Throwable) {
                runOnUiThread {
                    processingCount = (processingCount - 1).coerceAtLeast(0)
                    updateProcessingUi()
                    toast("Lỗi xử lý ảnh: ${PhotoProcessor.errText(t)}")
                    onProcessed(seq, null)
                }
            }
            // file phụ (gốc, DNG, ảnh khung) làm sau, không làm chậm ảnh chính
            try {
                val s = saved
                if (s != null) PhotoProcessor.extras(this, shot, s, prefs)?.let { w -> runOnUiThread { toast(w) } }
            } catch (_: Throwable) {
            } finally {
                shot.jpeg.delete()
                shot.dng?.delete()
                shot.extra.forEach { try { it.delete() } catch (_: Throwable) {} }
            }
        }
    }

    /** Menu từ nút XPAN >: Khung ảnh / Hiệu ứng chụp (bảng trượt từ dưới lên, nền đặc, nút tròn có icon). */
    private fun showCaptureMenu() {
        val fxName = if (prefs.captureFx == 1) "Màn chập" else "Rửa film"
        val wmNames = arrayOf("Cổ điển", "Gallery", "Dải thông số", "Logo + tên máy", "Chỉ logo")
        val items = ArrayList<MenuSheetItem>()
        items.add(MenuSheetItem(0, "Khung ảnh", wmNames[prefs.watermark]) { showWatermarkPicker() })
        items.add(MenuSheetItem(1, "Hiệu ứng chụp", fxName) { showFxPicker() })
        run {
            val hz = entries.getOrNull(selected)?.lens?.let { repo.hqSize(it) }
            val sub = when {
                !prefs.hq -> "Tắt"
                hz != null -> "Bật · ${((hz.width.toLong() * hz.height) / 1_000_000f).roundToInt()}MP"
                else -> "Bật · ghép 5 khung"
            }
            items.add(MenuSheetItem(2, "High quality", sub, prefs.hq) { toggleHq() })
        }
        showMenuSheet(items) { hideBars() }
    }

    /** Bật/tắt chế độ HQ: mở lại camera để thêm/bớt luồng ảnh độ phân giải tối đa. */
    private fun toggleHq() {
        prefs.hq = !prefs.hq
        val sz = entries.getOrNull(selected)?.lens?.let { repo.hqSize(it) }
        if (prefs.hq && sz != null) {
            toast("HQ bật: chụp ${((sz.width.toLong() * sz.height) / 1_000_000f).roundToInt()}MP rồi crop khung Xpan.")
        } else if (prefs.hq) {
            toast("HQ bật: chụp 5 khung liên tiếp rồi ghép lên 2× độ phân giải — giữ máy yên khoảng 1 giây. (Tạm không lưu RAW)")
        } else toast("Đã tắt HQ")
        openedLensId = null
        updateHqNote()
        maybeOpen()
    }

    private fun updateHqNote() {
        ui.frame.hqNote = prefs.hq
    }

    override fun onHqFailed() {
        toast("Máy không cho chụp độ phân giải tối đa cùng xem trước — chuyển sang HQ ghép nhiều khung.")
        updateHqNote()
    }

    /** Bảng chọn hiệu ứng chụp: Rửa film hoặc Màn chập (chụp ngay, liên tiếp). */
    private fun showFxPicker() {
        val dn = resources.displayMetrics.density
        fun dp(v: Float) = (v * dn).toInt()
        val light = Theme.light
        val sub = if (light) 0xFF6C6C74.toInt() else 0xFF9C9CA4.toInt()
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18f), dp(16f), dp(18f), dp(16f))
        box.background = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = 24f * dn
            setColor(if (light) 0xFFF1F1F4.toInt() else 0xFF17171A.toInt())
            setStroke(dp(1f).coerceAtLeast(1), if (light) 0x1F000000 else 0x24FFFFFF)
        }
        val title = TextView(this)
        title.text = "Hiệu ứng chụp"
        title.textSize = 17f
        title.typeface = android.graphics.Typeface.DEFAULT_BOLD
        title.setTextColor(Theme.ink)
        box.addView(title)
        val hint = TextView(this)
        hint.text = "Chọn cách máy phản hồi khi bấm chụp."
        hint.textSize = 12f
        hint.setTextColor(sub)
        hint.setPadding(0, dp(2f), 0, dp(12f))
        box.addView(hint)

        val names = arrayOf("Rửa film", "Màn chập")
        val descs = arrayOf(
            "Đóng băng khung, âm bản → xám → ảnh bay về album. Chờ xử lý xong mới chụp tấm tiếp.",
            "Chụp ngay, màn hình nháy đen một phát kèm tiếng. Bấm liên tiếp được, không chờ."
        )
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val cards = ArrayList<LinearLayout>()
        fun refresh() {
            cards.forEachIndexed { i, card ->
                val sel = i == prefs.captureFx
                card.background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = 16f * dn
                    setColor(if (light) Color.WHITE else 0xFF202024.toInt())
                    setStroke(dp(if (sel) 2f else 1f).coerceAtLeast(1), if (sel) 0xFFF47B20.toInt() else if (light) 0x1F000000 else 0x24FFFFFF)
                }
            }
        }
        for (i in 0 until 2) {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
            card.addView(FxPreviewView(this, i), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(96f)))
            val a = TextView(this)
            a.text = names[i]
            a.textSize = 13.5f
            a.typeface = android.graphics.Typeface.DEFAULT_BOLD
            a.setTextColor(Theme.ink)
            a.setPadding(0, dp(8f), 0, 0)
            card.addView(a)
            val b = TextView(this)
            b.text = descs[i]
            b.textSize = 11f
            b.setTextColor(sub)
            b.setPadding(0, dp(2f), 0, 0)
            card.addView(b)
            card.setOnClickListener {
                prefs.captureFx = i
                refresh()
                it.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                // nghe thử ngay tiếng của hiệu ứng vừa chọn
                if (prefs.sound && soundAllowed()) {
                    if (i == 1 && curtainLoaded) pool?.play(curtainId, 1f, 1f, 1, 0, 1f)
                    else if (i == 0 && shutterLoaded) pool?.play(shutterId, 1f, 1f, 1, 0, 1f)
                }
                it.postDelayed({ dlg.dismiss() }, 420)
                toast("Hiệu ứng chụp: ${names[i]}")
            }
            card.pressFeedback(0.97f, false)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.leftMargin = dp(10f)
            row.addView(card, lp)
            cards.add(card)
        }
        refresh()
        box.addView(row)
        dlg.setContentView(box)
        dlg.window?.let { w ->
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            w.setLayout(minOf(dp(560f), (resources.displayMetrics.widthPixels * 0.84f).toInt()), ViewGroup.LayoutParams.WRAP_CONTENT)
            w.setWindowAnimations(android.R.style.Animation_Dialog)
        }
        dlg.setOnDismissListener { hideBars() }
        dlg.show()
        dlg.window?.decorView?.systemUiVisibility = window.decorView.systemUiVisibility
    }

    /** Bảng chọn dấu chìm (mở từ menu nút XPAN ▾): 3 kiểu có hình minh hoạ. */
    private fun showWatermarkPicker() {
        val dn = resources.displayMetrics.density
        fun dp(v: Float) = (v * dn).toInt()
        val light = Theme.light
        val sub = if (light) 0xFF6C6C74.toInt() else 0xFF9C9CA4.toInt()
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(18f), dp(16f), dp(18f), dp(16f))
        box.background = android.graphics.drawable.GradientDrawable().apply {
            cornerRadius = 24f * dn
            setColor(if (light) 0xFFF1F1F4.toInt() else 0xFF17171A.toInt())
            setStroke(dp(1f).coerceAtLeast(1), if (light) 0x1F000000 else 0x24FFFFFF)
        }
        val title = TextView(this)
        title.text = "Dấu chìm"
        title.textSize = 17f
        title.typeface = android.graphics.Typeface.DEFAULT_BOLD
        title.setTextColor(Theme.ink)
        box.addView(title)
        val hint = TextView(this)
        hint.text = "Kiểu khung + chữ trên ảnh có khung (bật ở Cài đặt, hoặc khi xem lại / lưu ảnh khung)."
        hint.textSize = 12f
        hint.setTextColor(sub)
        hint.setPadding(0, dp(2f), 0, dp(12f))
        box.addView(hint)

        val names = arrayOf("Cổ điển", "Gallery", "Dải thông số", "Logo + tên máy", "Chỉ logo")
        val descs = arrayOf("HASSELBLAD giữa, thông số dưới.", "Viền rộng, logo XPAN góc trái.", "Dải trắng mỏng, thông số bên phải.", "Tên máy | logo HASSELBLAD in ngay trong ảnh, không nền.", "Logo HASSELBLAD · Create to Inspire trong ảnh, không mã máy.")
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val cards = ArrayList<LinearLayout>()
        fun refresh() {
            cards.forEachIndexed { i, card ->
                val sel = i == prefs.watermark
                card.background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = 16f * dn
                    setColor(if (light) Color.WHITE else 0xFF202024.toInt())
                    setStroke(dp(if (sel) 2f else 1f).coerceAtLeast(1), if (sel) 0xFFF47B20.toInt() else if (light) 0x1F000000 else 0x24FFFFFF)
                }
            }
        }
        for (i in 0 until 5) {
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.setPadding(dp(10f), dp(10f), dp(10f), dp(10f))
            card.addView(WatermarkPreviewView(this, i), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(84f)))
            val a = TextView(this)
            a.text = names[i]
            a.textSize = 13.5f
            a.typeface = android.graphics.Typeface.DEFAULT_BOLD
            a.setTextColor(Theme.ink)
            a.setPadding(0, dp(8f), 0, 0)
            card.addView(a)
            val b = TextView(this)
            b.text = descs[i]
            b.textSize = 11f
            b.setTextColor(sub)
            b.setPadding(0, dp(2f), 0, 0)
            card.addView(b)
            card.setOnClickListener {
                prefs.watermark = i
                refresh()
                it.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
                it.postDelayed({ dlg.dismiss() }, 260)
                toast("Dấu chìm: ${names[i]}")
            }
            card.pressFeedback(0.97f, false)
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            if (i > 0) lp.leftMargin = dp(10f)
            row.addView(card, lp)
            cards.add(card)
        }
        refresh()
        box.addView(row)
        dlg.setContentView(box)
        dlg.window?.let { w ->
            w.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            w.setLayout(minOf(dp(780f), (resources.displayMetrics.widthPixels * 0.9f).toInt()), ViewGroup.LayoutParams.WRAP_CONTENT)
            w.setWindowAnimations(android.R.style.Animation_Dialog)
        }
        dlg.setOnDismissListener { hideBars() }
        dlg.show()
        dlg.window?.decorView?.systemUiVisibility = window.decorView.systemUiVisibility
    }

    private fun deviceName(): String = prefs.deviceName.ifBlank { PhotoProcessor.defaultDeviceName() }

    private fun showReview(uri: Uri) {
        reviewUri = uri
        val framed = lastFramed && uri == lastUri
        reviewFramed = framed
        exec.execute {
            val bmp = try {
                if (framed) PhotoProcessor.decodeUpright(this, uri, 2400)
                else PhotoProcessor.compose(this, uri, 2400, deviceName(), prefs.watermark)
            } catch (t: Throwable) { null }
            runOnUiThread { if (bmp != null) review.show(bmp) else toast("Không mở được ảnh") }
        }
    }

    private fun loadLatestThumb() {
        exec.execute {
            try {
                val sel = "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? AND ${MediaStore.Images.Media.DISPLAY_NAME} LIKE ? " +
                    "AND ${MediaStore.Images.Media.DISPLAY_NAME} NOT LIKE ?"
                val args = arrayOf("Pictures/Xpan-Mode%", "XPAN_%.jpg", "%FULL%")
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME),
                    sel, args, "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { c ->
                    if (c.moveToFirst()) {
                        val uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, c.getLong(0))
                        lastUri = uri
                        lastFramed = (c.getString(1) ?: "").contains("FRAME")
                        val th = PhotoProcessor.decodeUpright(this, uri, 256)
                        runOnUiThread { if (th != null) ui.thumb.setImageBitmap(th) }
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    // ------------------------------------------------------------------ cài đặt

    /** Mở màn Cài đặt riêng: tạm dừng camera và bỏ giữ sáng màn hình để tiết kiệm pin. */
    private fun openSettings() {
        if (settingsOpen) return
        settingsOpen = true
        setTray(false)
        if (panel.isOpen) panel.close()
        val oldRaw = prefs.saveRaw
        cam.close()
        openedLensId = null
        info = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        settings.onClosed = {
            settingsOpen = false
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            if (prefs.saveRaw != oldRaw) openedLensId = null
            hideBars()
            maybeOpen()
        }
        settings.show()
    }
}
