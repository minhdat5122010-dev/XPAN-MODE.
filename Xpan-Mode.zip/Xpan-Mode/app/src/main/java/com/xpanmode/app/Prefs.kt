package com.xpanmode.app

import android.content.Context
import org.json.JSONObject

class Prefs(ctx: Context) {
    companion object {
        val NIGHT_STEPS = intArrayOf(3, 5, 8, 10)
    }
    private val sp = ctx.getSharedPreferences("xpan_mode", Context.MODE_PRIVATE)

    /** true = giao diện Hasselblad (xám đậm), false = giao diện tối giản (đen + nút cam) */
    var classic: Boolean
        get() = sp.getBoolean("classic", true)
        set(v) = sp.edit().putBoolean("classic", v).apply()

    /** true = giao diện trắng (sáng), false = giao diện tối */
    var light: Boolean
        get() = sp.getBoolean("light", false)
        set(v) = sp.edit().putBoolean("light", v).apply()

    /**
     * Chỉ số bộ lọc đang chọn (bộ lọc dựng sẵn rồi tới bộ lọc tự lưu). Lưu kèm số bộ lọc dựng sẵn tại thời điểm lưu
     * để khi thêm bộ lọc mới, lựa chọn bộ lọc tự lưu cũ không bị lệch sang bộ lọc khác.
     */
    var filter: Int
        get() {
            val v = sp.getInt("filter", 0)
            val n = sp.getInt("filter_n", 7)
            return if (v >= n) v + (XpanFilter.all.size - n) else v
        }
        set(v) = sp.edit().putInt("filter", v).putInt("filter_n", XpanFilter.all.size).apply()

    var entryKey: String?
        get() = sp.getString("entry", null)
        set(v) = sp.edit().putString("entry", v).apply()

    var saveRaw: Boolean
        get() = sp.getBoolean("raw", false)
        set(v) = sp.edit().putBoolean("raw", v).apply()

    /** Chế độ HQ: chụp ở độ phân giải tối đa của cảm biến rồi mới crop 65:24 (chỉ máy hỗ trợ). */
    var hq: Boolean
        get() = sp.getBoolean("hq", false)
        set(v) = sp.edit().putBoolean("hq", v).apply()

    /** Ảnh thường: true = app tự xử lí (tắt khử nhiễu/làm nét của máy, app khử nhiễu màu + làm nét tự nhiên); false = dùng xử lí của máy. */
    var appIsp: Boolean
        get() = sp.getBoolean("app_isp", true)
        set(v) = sp.edit().putBoolean("app_isp", v).apply()

    /** Chế độ HQ: in chữ LUNA ở góc trên-trái ảnh (nằm trong ảnh, mọi kiểu khung). Mặc định tắt. */
    var hqLogo: Boolean
        get() = sp.getBoolean("hq_logo", false)
        set(v) = sp.edit().putBoolean("hq_logo", v).apply()

    /** Chế độ HQ: khử sương mù nhẹ (giảm lớp sương mỏng phủ lên chi tiết). Mặc định tắt để so sánh. */
    var dehaze: Boolean
        get() = sp.getBoolean("dehaze", false)
        set(v) = sp.edit().putBoolean("dehaze", v).apply()

    /** Thợ săn ánh sáng - Vệt sáng: phơi sáng dài giả lập (chỉ ở chế độ thường, không đi cùng HQ). */
    var lightTrail: Boolean
        get() = sp.getBoolean("light_trail", false)
        set(v) = sp.edit().putBoolean("light_trail", v).apply()

    /** Chế độ thiếu sáng (LUNA Night): chụp liên tục vài giây rồi ghép. Không đi cùng HQ / vệt sáng. */
    var night: Boolean
        get() = sp.getBoolean("night", false)
        set(v) = sp.edit().putBoolean("night", v).apply()

    /** Thời gian phơi sáng của chế độ thiếu sáng (giây): 3, 5, 8 hoặc 10. */
    var nightSecs: Int
        get() = sp.getInt("night_secs", 5).let { if (it in NIGHT_STEPS) it else 5 }
        set(v) = sp.edit().putInt("night_secs", v).apply()

    /** HQ RAW: nguồn ghép của chế độ HQ là khung RAW (cùng với prefs.hq = true) thay vì JPEG. */
    var hqRaw: Boolean
        get() = sp.getBoolean("hq_raw", false)
        set(v) = sp.edit().putBoolean("hq_raw", v).apply()

    var keepOriginal: Boolean
        get() = sp.getBoolean("keep_original", false)
        set(v) = sp.edit().putBoolean("keep_original", v).apply()

    var autoFrame: Boolean
        get() = sp.getBoolean("auto_frame", false)
        set(v) = sp.edit().putBoolean("auto_frame", v).apply()

    /** Chỉnh màu đang áp lên bộ lọc được chọn (reset khi đổi bộ lọc). */
    var adjust: Adjust
        get() = try { Adjust.fromJson(JSONObject(sp.getString("adjust", "{}") ?: "{}")) } catch (_: Exception) { Adjust() }
        set(v) = sp.edit().putString("adjust", v.toJson().toString()).apply()

    /** Thông số camera đang dùng (EV, tốc độ, ISO, WB, lấy nét). */
    var cam: CamParams
        get() = try { CamParams.fromJson(JSONObject(sp.getString("cam", "{}") ?: "{}")) } catch (_: Exception) { CamParams() }
        set(v) = sp.edit().putString("cam", v.toJson().toString()).apply()

    /** Các bộ lọc người dùng tự lưu. */
    var presets: List<Preset>
        get() = Preset.listFromJson(sp.getString("presets", null))
        set(v) = sp.edit().putString("presets", Preset.listToJson(v)).apply()

    var sound: Boolean
        get() = sp.getBoolean("sound", true)
        set(v) = sp.edit().putBoolean("sound", v).apply()

    var focusSound: Boolean
        get() = sp.getBoolean("focus_sound", true)
        set(v) = sp.edit().putBoolean("focus_sound", v).apply()

    var respectSilent: Boolean
        get() = sp.getBoolean("respect_silent", true)
        set(v) = sp.edit().putBoolean("respect_silent", v).apply()

    var volumeShutter: Boolean
        get() = sp.getBoolean("volume_shutter", true)
        set(v) = sp.edit().putBoolean("volume_shutter", v).apply()

    /** Kiểu dấu chìm của ảnh có khung: 0 = cổ điển (HASSELBLAD giữa), 1 = Gallery (logo XPAN), 2 = Dải thông số, 3 = Logo + tên máy trong ảnh, 4 = chỉ logo HASSELBLAD + Create to Inspire trong ảnh. */
    var watermark: Int
        get() = sp.getInt("watermark", 0).coerceIn(0, 5)
        set(v) = sp.edit().putInt("watermark", v).apply()

    /** Hiệu ứng chụp: 0 = loát ảnh (đóng băng, âm bản, xám, ảnh bay về album), 1 = màn chập (chụp ngay, bấm liên tiếp). */
    var captureFx: Int
        get() = sp.getInt("captureFx", 0).coerceIn(0, 1)
        set(v) = sp.edit().putInt("captureFx", v).apply()

    var deviceName: String
        get() = sp.getString("device_name", "") ?: ""
        set(v) = sp.edit().putString("device_name", v).apply()
}
