package com.xpanmode.app

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Icon nét mảnh trong đĩa tròn của menu: 0 = khung ảnh (dấu chìm), 1 = hiệu ứng chụp (lá chắn sáng). */
class MenuIconView(ctx: Context, private val kind: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dn = ctx.resources.displayMetrics.density
    var light = false
    var tint = Color.WHITE
    var disc = 0xFF2A2A2E.toInt()
    var on = false

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f
        p.style = Paint.Style.FILL
        p.color = disc
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.7f * dn
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = if (on) 0xFFF47B20.toInt() else tint
        val u = r / 24f   // đơn vị: bán kính đĩa = 24
        if (kind == 0) {
            // khung ảnh: viền ngoài + ảnh bên trong + dải chữ ký ở dưới
            val out = RectF(cx - 12f * u, cy - 11f * u, cx + 12f * u, cy + 11f * u)
            c.drawRoundRect(out, 3f * u, 3f * u, p)
            val inner = RectF(cx - 8.5f * u, cy - 7.5f * u, cx + 8.5f * u, cy + 3.5f * u)
            c.drawRoundRect(inner, 1.5f * u, 1.5f * u, p)
            val m = Path()
            m.moveTo(cx - 8.5f * u, cy + 3.5f * u)
            m.lineTo(cx - 3f * u, cy - 2.5f * u)
            m.lineTo(cx + 0.5f * u, cy + 1.2f * u)
            m.lineTo(cx + 3f * u, cy - 1.2f * u)
            m.lineTo(cx + 8.5f * u, cy + 3.5f * u)
            c.drawPath(m, p)
            c.drawLine(cx - 4.5f * u, cy + 7.4f * u, cx + 4.5f * u, cy + 7.4f * u, p)
        } else if (kind == 4) {
            // Thợ săn ánh sáng: tia sáng 4 cánh + chấm nhỏ
            val s = Path()
            val sr = 12f * u
            val rr = 3.2f * u
            s.moveTo(cx, cy - sr)
            s.quadTo(cx + rr, cy - rr, cx + sr, cy)
            s.quadTo(cx + rr, cy + rr, cx, cy + sr)
            s.quadTo(cx - rr, cy + rr, cx - sr, cy)
            s.quadTo(cx - rr, cy - rr, cx, cy - sr)
            c.drawPath(s, p)
            p.style = Paint.Style.FILL
            c.drawCircle(cx + 10f * u, cy - 9f * u, 1.5f * u, p)
        } else if (kind == 5) {
            // chế độ ban đêm: trăng lưỡi liềm
            val moon = Path()
            moon.addCircle(cx, cy, 10.5f * u, Path.Direction.CW)
            val cut = Path()
            cut.addCircle(cx + 6f * u, cy - 4f * u, 9f * u, Path.Direction.CW)
            moon.op(cut, Path.Op.DIFFERENCE)
            c.drawPath(moon, p)
        } else if (kind == 6) {
            // vệt sáng: ba vệt dài ngắn khác nhau kết thúc bằng chấm sáng
            c.drawLine(cx - 13f * u, cy - 6f * u, cx + 6f * u, cy - 6f * u, p)
            c.drawLine(cx - 13f * u, cy, cx + 11f * u, cy, p)
            c.drawLine(cx - 13f * u, cy + 6f * u, cx + 2f * u, cy + 6f * u, p)
            p.style = Paint.Style.FILL
            c.drawCircle(cx + 9f * u, cy - 6f * u, 2f * u, p)
            c.drawCircle(cx + 14f * u, cy, 2.2f * u, p)
            c.drawCircle(cx + 5f * u, cy + 6f * u, 1.8f * u, p)
        } else if (kind == 8) {
            // lưới bố cục: khung bo góc chia 3x3
            val box = RectF(cx - 12f * u, cy - 12f * u, cx + 12f * u, cy + 12f * u)
            c.drawRoundRect(box, 3f * u, 3f * u, p)
            c.drawLine(cx - 4f * u, cy - 12f * u, cx - 4f * u, cy + 12f * u, p)
            c.drawLine(cx + 4f * u, cy - 12f * u, cx + 4f * u, cy + 12f * u, p)
            c.drawLine(cx - 12f * u, cy - 4f * u, cx + 12f * u, cy - 4f * u, p)
            c.drawLine(cx - 12f * u, cy + 4f * u, cx + 12f * u, cy + 4f * u, p)
        } else if (kind == 7) {
            // HQ RAW: khung bo góc chứa chữ "RAW"
            val box = RectF(cx - 14f * u, cy - 9f * u, cx + 14f * u, cy + 9f * u)
            c.drawRoundRect(box, 4f * u, 4f * u, p)
            p.style = Paint.Style.FILL
            p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            p.textSize = 8.6f * u
            p.textAlign = Paint.Align.CENTER
            val fm = p.fontMetrics
            c.drawText("RAW", cx, cy - (fm.ascent + fm.descent) / 2f, p)
            p.typeface = Typeface.DEFAULT
        } else if (kind == 3) {
            // logo LUNA: khung bo góc chứa chữ "LUNA"
            val box = RectF(cx - 14f * u, cy - 9f * u, cx + 14f * u, cy + 9f * u)
            c.drawRoundRect(box, 4f * u, 4f * u, p)
            p.style = Paint.Style.FILL
            p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            p.textSize = 8.6f * u
            p.textAlign = Paint.Align.CENTER
            val fm = p.fontMetrics
            c.drawText("LUNA", cx, cy - (fm.ascent + fm.descent) / 2f, p)
            p.typeface = Typeface.DEFAULT
        } else if (kind == 2) {
            // HQ: khung chữ nhật bo góc chứa chữ "HQ"
            val box = RectF(cx - 13f * u, cy - 9f * u, cx + 13f * u, cy + 9f * u)
            c.drawRoundRect(box, 4f * u, 4f * u, p)
            p.style = Paint.Style.FILL
            p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            p.textSize = 11.5f * u
            p.textAlign = Paint.Align.CENTER
            val fm = p.fontMetrics
            c.drawText("HQ", cx, cy - (fm.ascent + fm.descent) / 2f, p)
            p.typeface = Typeface.DEFAULT
        } else {
            // lá chắn sáng: vòng tròn + 6 nan
            c.drawCircle(cx, cy, 11.5f * u, p)
            val inR = 4.6f * u
            val outR = 11.5f * u
            for (i in 0 until 6) {
                val a = Math.toRadians(i * 60.0 - 90.0)
                val a2 = Math.toRadians(i * 60.0 - 90.0 + 60.0)
                val x1 = cx + (inR * cos(a)).toFloat()
                val y1 = cy + (inR * sin(a)).toFloat()
                val x2 = cx + (inR * cos(a2)).toFloat()
                val y2 = cy + (inR * sin(a2)).toFloat()
                c.drawLine(x1, y1, x2, y2, p)
                val a3 = Math.toRadians(i * 60.0 - 90.0 - 28.0)
                c.drawLine(x1, y1, cx + (outR * cos(a3)).toFloat(), cy + (outR * sin(a3)).toFloat(), p)
            }
        }
    }
}

class MenuSheetItem(val kind: Int, val title: String, val sub: String, val on: Boolean = false, val action: () -> Unit)

/**
 * Bảng chọn dạng "bottom sheet" nền đặc (như bảng chỉnh thông số ống kính): thanh kéo trên đầu, các nút tròn có icon
 * xếp lưới 3 cột, tên bên dưới. Trượt lên khi mở, trượt xuống khi đóng.
 */
fun Activity.showMenuSheet(items: List<MenuSheetItem>, onDismiss: () -> Unit) {
    val dn = resources.displayMetrics.density
    fun dp(v: Float) = (v * dn).toInt()
    val light = Theme.light
    val bg = if (light) 0xFFF1F1F4.toInt() else 0xFF17171A.toInt()
    val ink = Theme.ink
    val sub = if (light) 0xFF6C6C74.toInt() else 0xFF9C9CA4.toInt()
    val discCol = if (light) 0xFFE2E2E8.toInt() else 0xFF2A2A2E.toInt()
    val iconCol = if (light) 0xFF111114.toInt() else Color.WHITE

    val dlg = Dialog(this)
    dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
    val root = FrameLayout(this)
    val sheet = LinearLayout(this)
    sheet.orientation = LinearLayout.VERTICAL
    sheet.gravity = Gravity.CENTER_HORIZONTAL
    sheet.setPadding(dp(18f), dp(10f), dp(18f), dp(18f))
    val rad = 26f * dn
    sheet.background = GradientDrawable().apply {
        cornerRadii = floatArrayOf(rad, rad, rad, rad, 0f, 0f, 0f, 0f)
        setColor(bg)
        setStroke(dp(1f).coerceAtLeast(1), if (light) 0x1F000000 else 0x24FFFFFF)
    }
    sheet.isClickable = true   // chạm vào bảng không đóng

    val grip = View(this)
    grip.background = GradientDrawable().apply {
        cornerRadius = 3f * dn
        setColor(if (light) 0x33000000 else 0x4DFFFFFF)
    }
    sheet.addView(grip, LinearLayout.LayoutParams(dp(34f), dp(4f)).apply { bottomMargin = dp(14f) })

    val cols = 3
    val cells = ArrayList<View>()
    var closing = false
    fun close(after: (() -> Unit)? = null) {
        if (closing) return
        closing = true
        sheet.animate().cancel()
        sheet.animate().translationY(sheet.height.toFloat() + dp(8f)).setDuration(190)
            .setInterpolator(AccelerateInterpolator(1.4f))
            .withEndAction { dlg.dismiss(); after?.invoke() }.start()
        root.animate().alpha(0f).setDuration(190).start()
    }

    var rowLayout: LinearLayout? = null
    items.forEachIndexed { i, it ->
        if (i % cols == 0) {
            rowLayout = LinearLayout(this).also { r ->
                r.orientation = LinearLayout.HORIZONTAL
                sheet.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
        }
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER_HORIZONTAL
        cell.setPadding(dp(4f), dp(4f), dp(4f), dp(4f))
        val ic = MenuIconView(this, it.kind)
        ic.light = light; ic.tint = iconCol; ic.disc = discCol; ic.on = it.on
        cell.addView(ic, LinearLayout.LayoutParams(dp(56f), dp(56f)))
        val t = TextView(this)
        t.text = it.title
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        t.setTextColor(ink)
        t.setPadding(0, dp(7f), 0, 0)
        cell.addView(t)
        val s = TextView(this)
        s.text = it.sub
        s.textSize = 10.5f
        s.gravity = Gravity.CENTER
        s.setTextColor(sub)
        cell.addView(s)
        cell.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).start()
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(200).setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
        cell.setOnClickListener { _ -> close { it.action() } }
        rowLayout!!.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        cells.add(cell)
    }
    // ô trống cho đủ hàng để các nút không giãn ra
    val rem = items.size % cols
    if (rem != 0) repeat(cols - rem) {
        rowLayout!!.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
    }

    val sw = min(dp(420f), (resources.displayMetrics.widthPixels * 0.8f).toInt())
    root.addView(sheet, FrameLayout.LayoutParams(sw, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
    root.setOnClickListener { close() }
    dlg.setContentView(root)
    dlg.setCancelable(false)
    dlg.setOnKeyListener { _, k, ev ->
        if (k == KeyEvent.KEYCODE_BACK && ev.action == KeyEvent.ACTION_UP) { close(); true } else false
    }
    dlg.window?.let { w ->
        w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        w.setDimAmount(0.38f)
    }
    dlg.setOnDismissListener { onDismiss() }

    // hiệu ứng mở: bảng trượt lên, các nút nổi lên lần lượt
    sheet.visibility = View.INVISIBLE
    cells.forEach { it.alpha = 0f; it.translationY = dp(14f).toFloat() }
    dlg.show()
    dlg.window?.decorView?.systemUiVisibility = window.decorView.systemUiVisibility
    sheet.post {
        sheet.translationY = sheet.height.toFloat()
        sheet.visibility = View.VISIBLE
        sheet.animate().translationY(0f).setDuration(280).setInterpolator(DecelerateInterpolator(2.2f)).start()
        cells.forEachIndexed { i, v ->
            v.animate().alpha(1f).translationY(0f).setStartDelay(90L + i * 45L).setDuration(240)
                .setInterpolator(DecelerateInterpolator(1.8f)).start()
        }
    }
}
