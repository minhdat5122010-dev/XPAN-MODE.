package com.xpanmode.app

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Icon nét mảnh trong đĩa tròn của menu: 0 = khung ảnh (dấu chìm), 1 = hiệu ứng chụp (lá chắn sáng). */
class MenuIconView(ctx: Context, private val kind: Int) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dn = ctx.resources.displayMetrics.density
    var light = false
    var tint = Color.WHITE
    var disc = 0xFF2A2A2E.toInt()
    var on = false

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r = min(w, h) / 2f
        p.style = Paint.Style.FILL
        p.color = disc
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.7f * dn
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = if (on) 0xFFF47B20.toInt() else tint
        val u = r / 24f   // đơn vị: bán kính đĩa = 24
        if (kind == 0) {
            // khung ảnh: viền ngoài + ảnh bên trong + dải chữ ký ở dưới
            val out = RectF(cx - 12f * u, cy - 11f * u, cx + 12f * u, cy + 11f * u)
            c.drawRoundRect(out, 3f * u, 3f * u, p)
            val inner = RectF(cx - 8.5f * u, cy - 7.5f * u, cx + 8.5f * u, cy + 3.5f * u)
            c.drawRoundRect(inner, 1.5f * u, 1.5f * u, p)
            val m = Path()
            m.moveTo(cx - 8.5f * u, cy + 3.5f * u)
            m.lineTo(cx - 3f * u, cy - 2.5f * u)
            m.lineTo(cx + 0.5f * u, cy + 1.2f * u)
            m.lineTo(cx + 3f * u, cy - 1.2f * u)
            m.lineTo(cx + 8.5f * u, cy + 3.5f * u)
            c.drawPath(m, p)
            c.drawLine(cx - 4.5f * u, cy + 7.4f * u, cx + 4.5f * u, cy + 7.4f * u, p)
        } else if (kind == 4) {
            // Thợ săn ánh sáng: tia sáng 4 cánh + chấm nhỏ
            val s = Path()
            val sr = 12f * u
            val rr = 3.2f * u
            s.moveTo(cx, cy - sr)
            s.quadTo(cx + rr, cy - rr, cx + sr, cy)
            s.quadTo(cx + rr, cy + rr, cx, cy + sr)
            s.quadTo(cx - rr, cy + rr, cx - sr, cy)
            s.quadTo(cx - rr, cy - rr, cx, cy - sr)
            c.drawPath(s, p)
            p.style = Paint.Style.FILL
            c.drawCircle(cx + 10f * u, cy - 9f * u, 1.5f * u, p)
        } else if (kind == 15) {
            // Live Art: chấm giữa + vòng liền + vòng nét đứt (như biểu tượng ảnh động)
            p.style = Paint.Style.FILL
            c.drawCircle(cx, cy, 2.6f * u, p)
            p.style = Paint.Style.STROKE
            c.drawCircle(cx, cy, 7.2f * u, p)
            for (i in 0 until 16) {
                val a = Math.toRadians(i * 22.5 - 90.0)
                val a2 = Math.toRadians(i * 22.5 - 90.0 + 11.0)
                c.drawLine(
                    cx + (11.6f * u * cos(a)).toFloat(), cy + (11.6f * u * sin(a)).toFloat(),
                    cx + (11.6f * u * cos(a2)).toFloat(), cy + (11.6f * u * sin(a2)).toFloat(), p
                )
            }
        } else if (kind == 14) {
            // Night ART: trăng lưỡi liềm + tia sáng 4 cánh
            val moon = Path()
            moon.addCircle(cx - 2.5f * u, cy + 1f * u, 9.5f * u, Path.Direction.CW)
            val cut = Path()
            cut.addCircle(cx + 2.5f * u, cy - 2.5f * u, 8f * u, Path.Direction.CW)
            moon.op(cut, Path.Op.DIFFERENCE)
            c.drawPath(moon, p)
            val sx = cx + 8f * u
            val sy = cy - 7.5f * u
            val sr = 4.6f * u
            val star = Path()
            star.moveTo(sx, sy - sr)
            star.quadTo(sx, sy, sx + sr, sy)
            star.quadTo(sx, sy, sx, sy + sr)
            star.quadTo(sx, sy, sx - sr, sy)
            star.quadTo(sx, sy, sx, sy - sr)
            c.drawPath(star, p)
        } else if (kind == 5) {
            // chế độ ban đêm: trăng lưỡi liềm
            val moon = Path()
            moon.addCircle(cx, cy, 10.5f * u, Path.Direction.CW)
            val cut = Path()
            cut.addCircle(cx + 6f * u, cy - 4f * u, 9f * u, Path.Direction.CW)
            moon.op(cut, Path.Op.DIFFERENCE)
            c.drawPath(moon, p)
        } else if (kind == 6) {
            // vệt sáng: ba vệt dài ngắn khác nhau kết thúc bằng chấm sáng
            c.drawLine(cx - 13f * u, cy - 6f * u, cx + 6f * u, cy - 6f * u, p)
            c.drawLine(cx - 13f * u, cy, cx + 11f * u, cy, p)
            c.drawLine(cx - 13f * u, cy + 6f * u, cx + 2f * u, cy + 6f * u, p)
            p.style = Paint.Style.FILL
            c.drawCircle(cx + 9f * u, cy - 6f * u, 2f * u, p)
            c.drawCircle(cx + 14f * u, cy, 2.2f * u, p)
            c.drawCircle(cx + 5f * u, cy + 6f * u, 1.8f * u, p)
        } else if (kind == 13) {
            // phơi sáng lâu: ba vệt sáng cong chạy song song
            for (i in -1..1) {
                val path = Path()
                val o = i * 5f * u
                path.moveTo(cx - 12f * u, cy + 8f * u + o)
                path.cubicTo(cx - 4f * u, cy + 8f * u + o, cx + 2f * u, cy - 8f * u + o, cx + 12f * u, cy - 8f * u + o)
                c.drawPath(path, p)
            }
        } else if (kind == 8) {
            // lưới bố cục: khung bo góc chia 3x3
            val box = RectF(cx - 12f * u, cy - 12f * u, cx + 12f * u, cy + 12f * u)
            c.drawRoundRect(box, 3f * u, 3f * u, p)
            c.drawLine(cx - 4f * u, cy - 12f * u, cx - 4f * u, cy + 12f * u, p)
            c.drawLine(cx + 4f * u, cy - 12f * u, cx + 4f * u, cy + 12f * u, p)
            c.drawLine(cx - 12f * u, cy - 4f * u, cx + 12f * u, cy - 4f * u, p)
            c.drawLine(cx - 12f * u, cy + 4f * u, cx + 12f * u, cy + 4f * u, p)
        } else if (kind == 11) {
            // hẹn giờ: trục tròn + cán gạt hướng xuống
            val hy = cy - 4f * u
            c.drawCircle(cx, hy, 6.5f * u, p)
            p.strokeCap = Paint.Cap.ROUND
            c.drawLine(cx, hy + 6.5f * u, cx - 2.6f * u, cy + 10f * u, p)
            c.drawCircle(cx - 3f * u, cy + 10.5f * u, 2.2f * u, p)
            p.strokeCap = Paint.Cap.BUTT
        } else if (kind == 9) {
            // UP (Ultra pixel): khung bo góc chứa chữ "UP"
            val box = RectF(cx - 14f * u, cy - 9f * u, cx + 14f * u, cy + 9f * u)
            c.drawRoundRect(box, 4f * u, 4f * u, p)
            p.style = Paint.Style.FILL
            p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            p.textSize = 8.6f * u
            p.textAlign = Paint.Align.CENTER
            val fm = p.fontMetrics
            c.drawText("UP", cx, cy - (fm.ascent + fm.descent) / 2f, p)
            p.typeface = Typeface.DEFAULT
        } else if (kind == 7) {
            // HQ RAW: khung bo góc chứa chữ "RAW"
            val box = RectF(cx - 14f * u, cy - 9f * u, cx + 14f * u, cy + 9f * u)
            c.drawRoundRect(box, 4f * u, 4f * u, p)
            p.style = Paint.Style.FILL
            p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            p.textSize = 8.6f * u
            p.textAlign = Paint.Align.CENTER
            val fm = p.fontMetrics
            c.drawText("RAW", cx, cy - (fm.ascent + fm.descent) / 2f, p)
            p.typeface = Typeface.DEFAULT
        } else if (kind == 3) {
            // logo LUNA: khung bo góc chứa chữ "LUNA"
            val box = RectF(cx - 14f * u, cy - 9f * u, cx + 14f * u, cy + 9f * u)
            c.drawRoundRect(box, 4f * u, 4f * u, p)
            p.style = Paint.Style.FILL
            p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            p.textSize = 8.6f * u
            p.textAlign = Paint.Align.CENTER
            val fm = p.fontMetrics
            c.drawText("LUNA", cx, cy - (fm.ascent + fm.descent) / 2f, p)
            p.typeface = Typeface.DEFAULT
        } else if (kind == 2) {
            // HQ: khung chữ nhật bo góc chứa chữ "HQ"
            val box = RectF(cx - 13f * u, cy - 9f * u, cx + 13f * u, cy + 9f * u)
            c.drawRoundRect(box, 4f * u, 4f * u, p)
            p.style = Paint.Style.FILL
            p.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            p.textSize = 11.5f * u
            p.textAlign = Paint.Align.CENTER
            val fm = p.fontMetrics
            c.drawText("HQ", cx, cy - (fm.ascent + fm.descent) / 2f, p)
            p.typeface = Typeface.DEFAULT
        } else {
            // lá chắn sáng: vòng tròn + 6 nan
            c.drawCircle(cx, cy, 11.5f * u, p)
            val inR = 4.6f * u
            val outR = 11.5f * u
            for (i in 0 until 6) {
                val a = Math.toRadians(i * 60.0 - 90.0)
                val a2 = Math.toRadians(i * 60.0 - 90.0 + 60.0)
                val x1 = cx + (inR * cos(a)).toFloat()
                val y1 = cy + (inR * sin(a)).toFloat()
                val x2 = cx + (inR * cos(a2)).toFloat()
                val y2 = cy + (inR * sin(a2)).toFloat()
                c.drawLine(x1, y1, x2, y2, p)
                val a3 = Math.toRadians(i * 60.0 - 90.0 - 28.0)
                c.drawLine(x1, y1, cx + (outR * cos(a3)).toFloat(), cy + (outR * sin(a3)).toFloat(), p)
            }
        }
    }
}

class MenuSheetItem(val kind: Int, val title: String, val sub: String, val on: Boolean = false, val action: () -> Unit)

/**
 * Bảng chọn các chế độ (menu nút XPAN). Màn ngang: bảng dựng đứng dính MÉP PHẢI, cao hết màn hình, hai góc trái bo tròn lớn, nền gradient nâu đen mờ
 * (xem được khung ngắm phía sau), tay nắm dọc ở mép trái, nút tròn xếp lưới 4 cột x 3 hàng như bảng "Thêm" của camera hệ thống; trượt từ phải vào.
 * Màn dọc: bottom sheet dính đáy, 3 cột, trượt lên.
 */
fun Activity.showMenuSheet(items: List<MenuSheetItem>, onDismiss: () -> Unit) {
    val dn = resources.displayMetrics.density
    fun dp(v: Float) = (v * dn).toInt()
    val dm = resources.displayMetrics
    val side = dm.widthPixels > dm.heightPixels          // màn ngang: bảng dính mép phải
    val light = Theme.light
    val ink = Theme.ink
    val sub = if (light) 0xFF6C6C74.toInt() else 0xFF9C9CA4.toInt()
    val discCol = if (light) 0xFFE2E2E8.toInt() else if (side) 0xFF211D1B.toInt() else 0xFF2A2A2E.toInt()
    val iconCol = if (light) 0xFF111114.toInt() else Color.WHITE

    val dlg = Dialog(this)
    dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
    val root = FrameLayout(this)
    val panel = FrameLayout(this)            // khung bảng (nền + tay nắm), là phần được trượt vào / ra
    val sheet = LinearLayout(this)
    sheet.orientation = LinearLayout.VERTICAL
    sheet.gravity = if (side) Gravity.CENTER else Gravity.CENTER_HORIZONTAL
    val rad = (if (side) 30f else 26f) * dn
    if (side) {
        sheet.setPadding(dp(30f), dp(10f), dp(16f), dp(10f))
        // nền nâu đen mờ như bảng "Thêm" của camera hệ thống: hơi ấm và trong ở mép trái, đậm dần sang phải; bo tròn hai góc trái
        panel.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            if (light) intArrayOf(0xF6F4F1EE.toInt(), 0xF8E9E7E4.toInt()) else intArrayOf(0xEC2A211B.toInt(), 0xF5121212.toInt())
        ).apply {
            cornerRadii = floatArrayOf(rad, rad, 0f, 0f, 0f, 0f, rad, rad)
            setStroke(dp(1f).coerceAtLeast(1), if (light) 0x1F000000 else 0x20FFFFFF)
        }
    } else {
        sheet.setPadding(dp(18f), dp(10f), dp(18f), dp(18f))
        // nền kiểu bảng "Thêm": xám sáng mờ ở trên đậm dần xuống gần đen ở dưới, bo tròn hai góc trên
        panel.background = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            if (light) intArrayOf(0xF8FBFBFD.toInt(), 0xFAECECF1.toInt()) else intArrayOf(0xF2606166.toInt(), 0xFA131315.toInt())
        ).apply {
            cornerRadii = floatArrayOf(rad, rad, rad, rad, 0f, 0f, 0f, 0f)
            setStroke(dp(1f).coerceAtLeast(1), if (light) 0x1F000000 else 0x24FFFFFF)
        }
    }
    panel.isClickable = true   // chạm vào bảng không đóng
    panel.addView(sheet, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, if (side) ViewGroup.LayoutParams.MATCH_PARENT else ViewGroup.LayoutParams.WRAP_CONTENT))

    fun gripDrawable() = GradientDrawable().apply {
        cornerRadius = 3f * dn
        setColor(if (light) 0x33000000 else 0x4DFFFFFF)
    }
    if (side) {
        // tay nắm dọc ở mép trái bảng
        val g = View(this)
        g.background = gripDrawable()
        panel.addView(g, FrameLayout.LayoutParams(dp(4f), dp(36f), Gravity.START or Gravity.CENTER_VERTICAL).apply { leftMargin = dp(11f) })
    } else {
        val g = View(this)
        g.background = gripDrawable()
        sheet.addView(g, LinearLayout.LayoutParams(dp(34f), dp(4f)).apply { bottomMargin = dp(14f) })
    }

    val maxCols = if (side) 4 else 3
    val cols = min(maxCols, items.size).coerceAtLeast(1)
    val cells = ArrayList<View>()
    // các hàng nằm trong ScrollView: quá nhiều nút thì cuộn; màn ngang thì căn giữa theo chiều dọc cho các hàng cách đều
    val content = LinearLayout(this)
    content.orientation = LinearLayout.VERTICAL
    content.gravity = Gravity.CENTER_VERTICAL
    val scroll = android.widget.ScrollView(this)
    scroll.isVerticalScrollBarEnabled = false
    scroll.overScrollMode = View.OVER_SCROLL_NEVER
    scroll.isFillViewport = true
    scroll.addView(content, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    sheet.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, if (side) 0 else ViewGroup.LayoutParams.WRAP_CONTENT, if (side) 1f else 0f))
    var closing = false
    fun close(after: (() -> Unit)? = null) {
        if (closing) return
        closing = true
        panel.animate().cancel()
        val a = panel.animate()
        if (side) a.translationX(panel.width.toFloat() + dp(8f)) else a.translationY(panel.height.toFloat() + dp(8f))
        a.setDuration(190).setInterpolator(AccelerateInterpolator(1.4f))
            .withEndAction { dlg.dismiss(); after?.invoke() }.start()
        root.animate().alpha(0f).setDuration(190).start()
    }

    var rowLayout: LinearLayout? = null
    items.forEachIndexed { i, it ->
        if (i % cols == 0) {
            rowLayout = LinearLayout(this).also { r ->
                r.orientation = LinearLayout.HORIZONTAL
                r.setPadding(0, if (side) dp(7f) else 0, 0, if (side) dp(7f) else 0)
                content.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
        }
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.gravity = Gravity.CENTER_HORIZONTAL
        cell.setPadding(dp(4f), dp(4f), dp(4f), dp(4f))
        val ic = MenuIconView(this, it.kind)
        ic.light = light; ic.tint = iconCol; ic.disc = discCol; ic.on = it.on
        cell.addView(ic, LinearLayout.LayoutParams(dp(if (side) 58f else 56f), dp(if (side) 58f else 56f)))
        val t = TextView(this)
        t.text = it.title
        t.textSize = 13f
        t.gravity = Gravity.CENTER
        t.setTextColor(ink)
        t.setPadding(0, dp(7f), 0, 0)
        cell.addView(t)
        val s = TextView(this)
        s.text = it.sub
        s.textSize = 10.5f
        s.gravity = Gravity.CENTER
        s.setTextColor(sub)
        cell.addView(s)
        cell.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).start()
                android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(200).setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
        cell.setOnClickListener { _ -> close { it.action() } }
        rowLayout!!.addView(cell, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        cells.add(cell)
    }
    // ô trống cho đủ hàng để các nút không giãn ra
    val rem = items.size % cols
    if (rem != 0) repeat(cols - rem) {
        rowLayout!!.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
    }

    if (side) {
        // rộng ~62% màn hình (nhiều nút) hoặc vừa đủ các cột (menu con ít nút); dính mép phải, cao hết màn hình
        val full = min((dm.widthPixels * 0.62f).toInt(), dp(4f * 140f + 46f))
        val sw = if (items.size > 4) full else min(full, dp(130f) * cols + dp(46f))
        root.addView(panel, FrameLayout.LayoutParams(sw, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.END))
    } else {
        // đủ nút để lấp hàng -> rộng hết màn hình; ít nút (menu con) -> thu hẹp, canh giữa đáy
        val sw = if (items.size >= maxCols) ViewGroup.LayoutParams.MATCH_PARENT else min(dp(150f) * cols + dp(36f), dm.widthPixels)
        root.addView(panel, FrameLayout.LayoutParams(sw, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
    }
    root.setOnClickListener { close() }
    dlg.setContentView(root)
    dlg.setCancelable(false)
    dlg.setOnKeyListener { _, k, ev ->
        if (k == KeyEvent.KEYCODE_BACK && ev.action == KeyEvent.ACTION_UP) { close(); true } else false
    }
    dlg.window?.let { w ->
        w.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
        w.setDimAmount(if (side) 0.22f else 0.38f)
    }
    dlg.setOnDismissListener { onDismiss() }

    // hiệu ứng mở: bảng trượt vào (từ phải / từ dưới), các nút nổi lên lần lượt
    panel.visibility = View.INVISIBLE
    cells.forEach { it.alpha = 0f; if (side) it.translationX = dp(14f).toFloat() else it.translationY = dp(14f).toFloat() }
    dlg.show()
    dlg.window?.decorView?.systemUiVisibility = window.decorView.systemUiVisibility
    panel.post {
        if (side) panel.translationX = panel.width.toFloat() else panel.translationY = panel.height.toFloat()
        panel.visibility = View.VISIBLE
        val a = panel.animate()
        if (side) a.translationX(0f) else a.translationY(0f)
        a.setDuration(280).setInterpolator(DecelerateInterpolator(2.2f)).start()
        cells.forEachIndexed { i, v ->
            val b = v.animate().alpha(1f)
            if (side) b.translationX(0f) else b.translationY(0f)
            b.setStartDelay(90L + i * 45L).setDuration(240).setInterpolator(DecelerateInterpolator(1.8f)).start()
        }
    }
}
