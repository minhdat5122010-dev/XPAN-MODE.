plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.xpanmode.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.xpanmode.app"
        minSdk = 29          // Camera2 physical camera id (API 28+) + MediaStore scoped storage (API 29+)
        targetSdk = 34
        versionCode = 19
        versionName = "3.4.4"
    }

    // Keystore cố định nằm trong repo: mọi bản build (GitHub Actions hay máy bạn) đều ký cùng một chữ ký,
    // nên cài đè (update) không còn báo xung đột chữ ký.
    signingConfigs {
        create("xpan") {
            storeFile = file("xpan-release.keystore")
            storePassword = "xpanmode"
            keyAlias = "xpan"
            keyPassword = "xpanmode"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("xpan")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("xpan")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
}
