# Xpan-Mode

App chụp ảnh riêng cho chế độ **XPan 65:24** (Android, Kotlin + Camera2), giao diện lấy cảm hứng từ camera Hasselblad trên Oppo.

## Tính năng
- **Hai giao diện**, đổi qua lại bằng nút `⇄` ở góc trên trái:
  - **Orange**: nền đen, khung ngắm viền mờ, nút chụp cam, dải tiêu cự (mm) phía dưới.
  - **Classic**: bảng đen có chữ HASSELBLAD, nút chụp kim loại, danh sách zoom (0,6 / 1 / 2 / 3×) bên phải, thẻ ảnh trắng sau khi chụp.
- **Hiệu ứng chụp**: nháy âm bản → phủ xám mờ → hiện ảnh, thumbnail nảy lên.
- **Bộ lọc** (chạm nút phim / ô "Original" để đổi, áp cả lên preview): Original, Hasselblad Natural, Leica Classic (đậm đà, cổ điển), Zeiss Clear (trong trẻo, sáng da), Leica Mono.
- **Đọc đầy đủ ống kính**: quét mọi camera ID, kể cả **ID ẩn** và **ID vật lý** của camera logic (tele thường nằm ở đây).
  Với mỗi ống kính: thử mở trực tiếp; nếu OEM chặn thì tự chuyển sang mở camera logic + `zoom ratio` để HAL chuyển sang tele.
  Bấm ⚙ → "Thông tin ống kính" để xem: ID, tiêu cự thực/tương đương 35mm, khẩu độ, cảm biến, MP tối đa, trạng thái mở. Có nút sao chép để gửi cho mình khi debug.
- **Chất lượng ảnh**: JPEG độ phân giải tối đa của cảm biến, `JPEG_QUALITY=100`, bật chế độ HIGH_QUALITY cho khử nhiễu / làm nét / sắc sai / tone map / shading (nếu máy hỗ trợ).
  Cắt 65:24 ở **chính giữa khung gốc, giữ nguyên chiều rộng, không resize**; áp màu theo từng dải để không tràn RAM; lưu JPEG q100 kèm EXIF.
  Tuỳ chọn lưu thêm ảnh gốc `_ORIG` và thẻ ảnh watermark `_CARD`.
- Chạm để lấy nét, kéo dọc mép trái khung để chỉnh EV.
- Ảnh lưu ở `Pictures/Xpan-Mode`.

## Build
**Cách 1 – GitHub Actions (không cần cài gì):** đẩy repo lên GitHub → tab *Actions* → workflow *Build APK* → tải artifact `Xpan-Mode-debug-apk`.

**Cách 2 – Android Studio:** mở thư mục dự án, đợi Gradle sync, bấm Run. (Android Studio sẽ tự tạo Gradle wrapper.)

Yêu cầu: Android 11+ (API 30), thiết bị có camera sau.

## Lưu ý
- Tên "Hasselblad" / "Leica" / "Zeiss" ở đây chỉ mô tả phong cách màu; bộ lọc là tự dựng, không phải profile màu chính hãng. Nếu phát hành công khai, nên đổi `BRAND` trong `MainActivity.kt` và tên bộ lọc trong `Views.kt` để tránh vấn đề nhãn hiệu.
- Một số hãng chặn app bên thứ ba mở camera tele trực tiếp; khi đó app dùng zoom trên camera logic. Xem trạng thái từng ống kính trong màn "Thông tin ống kính".
