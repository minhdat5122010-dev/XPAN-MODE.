# Xpan-Mode

Ứng dụng chụp ảnh Android chuyên cho khung hình panorama **XPan 65:24**, giao diện và hiệu ứng chụp mô phỏng chế độ X-Pan trên các dòng OPPO × Hasselblad.

## Tính năng

- **Hai giao diện, chuyển bằng nút ⇄ ở góc trên trái**
  - *Hasselblad*: nền xám đậm, chữ HASSELBLAD, thang zoom 0,6 · 1 · 2 · 3×, nút chụp trắng, huy hiệu bộ lọc.
  - *Tối giản*: nền đen, viền ngắm mờ, nút chụp cam, các nút tiêu cự 14 · 23 · 65 · 135 mm.
- **Hiệu ứng chụp**: đảo âm bản → xám phẳng → mờ dần về ảnh.
- **Màn hình xem lại**: khung trắng + chữ HASSELBLAD + thông số (tên máy, FL, khẩu độ, tốc độ, ISO). Chạm vào ảnh thu nhỏ để mở; có nút lưu ảnh khung.
- **Đọc đầy đủ ống kính**: gộp camera trong `cameraIdList` + camera vật lý ẩn trong camera logic + dò ID 0–99. Xem danh sách chi tiết tại ⚙ Cài đặt (tiêu cự thật, tương đương 35mm, khẩu độ, cảm biến, MP, OIS, RAW...).
- **Chất lượng ảnh**: chụp JPEG độ phân giải tối đa của từng ống kính, `JPEG_QUALITY=100`, khử nhiễu/làm nét/quang sai ở chế độ HIGH_QUALITY. Khung 65:24 và zoom số được **cắt từ ảnh gốc** (không phóng to nội suy), lưu JPEG chất lượng 100 kèm EXIF. Tuỳ chọn lưu thêm DNG (RAW) và ảnh gốc full-frame.
- **HQ ghép 5 khung**: căn chỉnh Lucas-Kanade dưới điểm ảnh, giải mã + căn chỉnh các khung song song, cộng dồn độ sáng ở lưới 2× và màu ở lưới 1×. Chế độ này hiển thị là **LUNA Engine**; thông báo thời gian từng công đoạn đã tắt (`SHOW_TIMING = false` trong `PhotoProcessor.kt`).
- **Thiếu sáng (LUNA Night)**: bật ở menu `XPAN >` → *Thiếu sáng*. Khi bật, cạnh nút XPAN hiện huy hiệu 🌙 kèm thời gian phơi sáng; chạm vào để đổi vòng **3 → 5 → 8 → 10 giây**. Bấm chụp: khung ngắm đóng băng và sáng dần, vòng đếm ngược chạy; bấm chụp lần nữa để dừng sớm. Cơ chế:
  - Chụp liên tục trong N giây. Máy vững (con quay hồi chuyển) → khung ≤ 0,3s, ISO thấp; cầm tay → khung ≤ 1/30s và chờ 0,3s cho hết rung sau cú bấm. Máy cho chỉnh tay thì dùng tích (thời gian × ISO) của AE xem trước nhân hệ số cần thêm sáng; không thì AE khoá + dải FPS thấp + bù sáng.
  - Khung nhoè do rung bị giảm trọng số hoặc bỏ (so với khung nét nhất). Mỗi khung được căn chỉnh (LUNA Engine: thô + Lucas-Kanade dưới điểm ảnh, trên ảnh đã nhân gain) và cộng dồn **ngay khi vừa chụp xong** trong không gian tuyến tính, trọng số chống bóng ma theo mức nhiễu (xe chạy ngang không để lại vệt ma).
  - Tone mapping thiếu sáng: nâng bóng tối trên lớp nền (đường bao dưới + bilateral log), chặn độ lợi theo từng điểm ảnh và mờ về 1 ở vùng sáng (đèn không cháy, không viền), điểm đen thích nghi. Sau đó khử nhiễu màu 2 lượt, khử nhiễu độ sáng mạnh hơn (LUNA `denoiseLuma(strength=1.35)`) và làm nét có cổng.
  - Không đi cùng HQ / vệt sáng / RAW (bật cái này sẽ tự tắt cái kia). Mã: `LunaNight.kt`, `CameraController.captureNight`, `PhotoProcessor.processNight`, `NightFxView` / `NightBadgeView` trong `Views.kt`.
- **Bộ lọc**: Original, Natural, Portrait, Landscape, XPan Chrome, Golden Hour, Mono (phong cách màu tự nhiên, tương phản mềm, bão hoà vừa phải).
- Chạm để lấy nét/đo sáng, vuốt dọc bên trái để bù sáng, chụm hai ngón để zoom.
- Ảnh lưu tại `Pictures/Xpan-Mode`.

## Build

**Cách 1 – GitHub Actions (không cần cài gì):** đẩy toàn bộ thư mục lên GitHub, vào tab *Actions* → workflow *Build APK* → tải artifact `Xpan-Mode-debug-apk`.

**Cách 2 – Android Studio:** mở thư mục, chờ Gradle sync, bấm Run.

Mọi bản build đều ký bằng `app/xpan-release.keystore` (cố định) nên cài đè được giữa các lần build.

Yêu cầu: Android 10+ (API 29), JDK 17.

## Ghi chú

- Tên "Hasselblad" và phong cách giao diện thuộc về chủ sở hữu thương hiệu. Dự án này chỉ dùng chữ, không dùng logo gốc; hãy dùng cho mục đích cá nhân/học tập.
- Xem trước bộ lọc là xấp xỉ bằng ColorMatrix; ảnh xuất dùng đường cong từng kênh nên có thể lệch nhẹ.
- Một số máy chặn app bên thứ ba mở camera vật lý; app tự dự phòng qua camera logic.

## Chỉnh sửa & bộ lọc riêng

Nút "thanh trượt" cạnh nút cài đặt mở bảng **Chỉnh sửa** (thu gọn, xem trước trực tiếp):

- **Máy ảnh**: EV, tốc độ (S), ISO, cân bằng trắng (WB), lấy nét AF/MF. Tốc độ/ISO/MF chỉ hiện khi camera cho phép app bên thứ ba chỉnh tay.
- **Màu sắc**: tương phản, lạnh ↔ ấm, lục lam ↔ đỏ sậm, bão hoà, sắc nét (sắc nét chỉ áp dụng khi chụp, không hiện trong khung xem trước).
- **Lưu thành bộ lọc**: lưu mọi chỉnh sửa (màu + thông số camera) thành bộ lọc có tên, xuất hiện trong khay bộ lọc. Giữ vào bộ lọc tự lưu để đổi tên, ghi đè hoặc xoá.

## So sánh HQ và HQ RAW
Menu `XPAN >` có hai nút riêng: **High quality** (ghép khung JPEG của máy) và **HQ RAW** (ghép khung RAW, app tự dựng ảnh: trừ mức đen, cân bằng trắng, bù tối góc, giải mosaic Hamilton-Adams, khớp tông với JPEG máy). Cùng một bộ ghép LUNA nên so sánh công bằng. Nút HQ RAW luôn hiện; ống kính không cho app ngoài lấy RAW sẽ ghi rõ và không bật được. Tên tệp lưu có hậu tố để phân biệt: `_HQ` (ghép từ JPEG), `_HQRAW` (ghép từ RAW); không hậu tố = ảnh thường hoặc HQ RAW phải lùi về JPEG (có thông báo). Nút "Thợ săn ánh sáng" đã gỡ.

## UP (Ultra pixel)
Menu `XPAN >` có nút **UP** để so sánh với High quality / HQ RAW. UP ghép **9 khung** JPEG (HQ thường 5 khung; `UP_FRAMES` trong `CameraController.kt`), làm nét mạnh hơn ở lưới 2× (`UP_SHARP1` / `UP_SHARP2` trong `PhotoProcessor.kt`), rồi phóng lên **3× (≈ 12288×4536, 55,8 MP)** bằng Lanczos-3 (`UP_OUT_SCALE = 1.5f`). Phần phóng thêm là nội suy, không thêm chi tiết thật; hết bộ nhớ thì tự giữ ảnh 2×. HQ / HQ RAW thường không đổi.
- Ghi chú góc trên-trái khung ngắm: `Shot with LUNA. UP`; logo LUNA trên ảnh (nếu bật): `LUNA. UP`.
- Cài đặt → "UP: máy xử lí ảnh": bật thì UP ghép các khung đã qua xử lí của máy (không ép tắt khử nhiễu/làm nét, làm nét sau ghép nhẹ hơn); tắt (mặc định) thì ghép khung thô, app tự xử lí.
- Tên tệp: `_UP` (khung thô), `_UPDEV` (khung qua xử lí của máy).

## Hẹn giờ (cần gạt)
Menu `XPAN >` → **Hẹn giờ**: nút chụp được thay bằng cần gạt kiểu máy ảnh film (trục kim loại, cán dài hướng xuống), viên thuốc `00.00s` hiện bên trái nút XPAN.
- Giữ đầu hoặc thân cán, xoay lên trên sang trái để lên dây: vuông góc (sang trái) = 5s, thẳng lên = 10s (tối đa); số trên viên thuốc chạy theo. Mỗi nấc 0,25s rung giật một cái, mốc 5s / 10s và chạm hai đầu rung mạnh hơn.
- Bấm vào trục để bắt đầu đếm ngược: cán tự quay về, tiếng dây cót chạy liên tục (`res/raw/selftimer_run.wav`, vòng lặp cắt từ bản thu người dùng cung cấp, nhỏ + chậm dần ở 0,4s cuối), hết giờ thì chụp. Bấm trục lần nữa để huỷ. Chưa lên dây (0s) mà bấm trục thì chụp ngay.
- Rung dùng `Vibrator` (quyền `VIBRATE`); tiếng theo cài đặt âm thanh chung của app.
- Bật Hẹn giờ thì cụm nút bên phải tự dàn lại để chừa chỗ cho cán quét: album xuống sát đáy, bộ lọc + chỉnh sửa xếp ngang trên đỉnh, nút tiêu cự lùi sang trái.

## Flash (3.5)
Nút flash nằm ngay bên phải nút cài đặt; bấm để đổi vòng: **tắt** (tia chớp gạch chéo) → **bật** (tia chớp viền: đèn sáng ~0,45s rồi chụp, xong tự tắt) → **luôn bật** (tia chớp đặc: đèn sáng liên tục lúc ngắm và chụp). Dùng chế độ TORCH của camera2 nên mọi khung của HQ / UP / thiếu sáng đều có đèn như nhau; lựa chọn được nhớ. Ống kính không có đèn thì báo.

## Màn giới thiệu chế độ
Vừa bật High quality / HQ RAW thì nền đen hiện dần với dòng chữ **REAL DETAILS With LUNA. 3** (dấu chấm cam) và ghi chú nhỏ `( Without AI )` bên dưới, rồi mờ dần, tổng cộng ~1s. Chế độ UP hiện **ULTRA PIXEL With LUNA. 3**. Cài đặt trong `ModeSplashView` (Views.kt).

## Sửa ám màu tím hồng ở LUNA Night
Vùng tối bị nâng sáng hàng chục lần nên ám màu của JPEG gần đen (đỏ + lam dư so với lục) hiện thành mảng tím hồng. `LunaNight.toneMap` giờ (1) tính điểm đen riêng từng kênh thay vì một mức chung (`BPC_MAX`), (2) kéo điểm ảnh gần đen về xám trung tính theo độ tin cậy của màu (`CH0` / `CH1`, tính trên độ sáng tuyến tính trước khi nâng). Nếu bóng tối còn ám màu: tăng `CH1`; nếu bóng tối nhạt màu quá: giảm `CH1`.

## LUNA Night: màu điện ảnh + 2× điểm ảnh
- Màu: cân bằng trắng một phần (`WB_STRENGTH`), đường cong S kiểu phim (`GRADE_CONTRAST`), bóng tối hơi lạnh / vùng sáng hơi ấm, màu nhạt dần ở highlight.
- Kích thước: sau khi ghép + khử nhiễu, ảnh được phóng 2× (Lanczos-3) và làm nét có cổng (`NIGHT_OUT_SCALE` trong `PhotoProcessor.kt`). Phần phóng thêm là nội suy, không phải chi tiết thật.

## Thiếu sáng: máy xử lí (3.5)
Cài đặt → "Thiếu sáng: máy xử lí". Bật thì LUNA Night chụp bằng **chế độ đêm của chính máy** (Camera2 Extensions `EXTENSION_NIGHT`, Android 12+) nếu hãng cho app ngoài dùng; ra 1 ảnh đã qua xử lí đêm / AI của máy rồi đi tiếp qua bộ lọc + khung như ảnh thường. Không hỗ trợ / lỗi thì tự dùng LUNA Night của app (lỗi một lần thì các lần sau trong phiên bỏ qua). Cân bằng trắng của LUNA Night (`WB_STRENGTH`) nâng lên 0,85 để tường trắng ra gần trắng như app camera gốc.

## Sửa viền / quầng quanh vật tối
Viền sáng mảnh quanh vật tối (túi, đầu giường) có ba nguồn, đã xử lí: (1) `MultiFrame.refine` (làm nét) chặn kết quả trong dải min–max 5×5 của điểm ảnh gốc nên không còn quầng; (2) `MultiFrame.upscale` (Lanczos) chống vòng: kết quả không vượt khoảng giữa hai điểm nguồn gần nhất; (3) tone mapping LUNA Night nội suy độ lợi nâng sáng theo song phương chung (có xét độ sáng từng điểm ảnh), nên điểm tường sáng cạnh vật tối không bị nâng như ô tối nữa.

## Night ART (4.0)
Menu `XPAN >`: hai nút **Phơi sáng lâu** và **Thiếu sáng** được gộp thành một nút **Night ART** (ghi chú `( LUNA. Night Art 1 )`). Bấm vào mở menu con có hai nút cũ. Ảnh chụp bằng hai chế độ này (kể cả nhánh chế độ đêm của máy), nếu bật **Logo LUNA**, đều in chữ **LUNA. Night Art** ở góc trên-trái (hằng số `NIGHT_ART_LOGO` trong `PhotoProcessor.kt`). Công tắc Logo LUNA trong menu nay hiện khi bật HQ, Phơi sáng lâu hoặc Thiếu sáng.

## Live Art + bảng menu
- **Live Art** (menu XPAN): ảnh động như Live Photo cho ảnh thường (không dùng với HQ / UP / Night ART). Khi bật, phiên camera có thêm một luồng YUV nhỏ (`CameraController.liveMode`) và `LiveArt.Recorder` giữ ~1,5s khung hình THẬT gần nhất, đã cắt đúng khung 65:24 + zoom như ảnh chụp (không đọc từ TextureView nên không bị đứng hình khi màn chụp che khung ngắm); bấm chụp thì giữ thêm ~1,5s. Sau khi ảnh tĩnh đã xử lí + lưu, màu các khung được **khớp theo ảnh tĩnh** (khớp histogram từng kênh, vì luồng xem trước của camera lệch màu so với JPEG), mã hoá MP4 H.264 ~3s với dấu thời gian thật rồi **nhúng vào chính JPEG** theo định dạng Motion Photo (XMP Google: `MotionPhoto` + `MicroVideo`, MP4 nối cuối tệp). Tệp ảnh to hơn ~1MB.
- **Bảng menu**: dính đáy màn hình, rộng hết màn, nền gradient xám mờ → gần đen, bo tròn hai góc trên; ngang 6 cột (2 hàng), dọc 3 cột; menu con ít nút thì thu hẹp, canh giữa đáy.

## Live Art: khung + watermark, 24 khung/giây, loại trừ
- Video Live Art giờ có **khung + watermark** giống ảnh tĩnh: mỗi khung video được dựng khung bằng đúng hàm dựng khung của ảnh (`PhotoProcessor.frameBitmap`), nền nhoè / chữ tên máy lấy theo từng khung.
- **Màu khớp theo phần ảnh** (không tính viền khung): bản trước khớp theo cả ảnh có khung nên viền nhoè làm video nhạt, ám xanh vàng.
- **24 khung/giây**; các khung được chuẩn bị song song (nhiều luồng) nên thời gian xử lí xấp xỉ bản 12 khung.
- Bật Live Art thì tự tắt HQ / HQ RAW / UP (và Night ART); bật các chế độ đó thì Live Art tự tắt.

## Menu XPAN dạng bảng bên phải (4.5)
Màn ngang: menu nút XPAN là bảng dựng đứng dính mép phải (rộng ~62% màn hình), cao hết màn hình, hai góc trái bo tròn, nền gradient nâu đen ĐỤC (không nhìn xuyên qua), tay nắm dọc ở mép trái, nút tròn xếp lưới 4 cột (3 hàng) cách đều theo chiều dọc, trượt từ phải vào; xem được khung ngắm phía sau. Màn dọc vẫn là bottom sheet dính đáy 3 cột. Menu con (Night ART) thu hẹp vừa các cột.

## Live Art: 30 khung/giây + ghi chú khung ngắm
- Live Art ghi **30 khung/giây** (`LiveArt.FPS`), nhịp khung lấy từ **dấu thời gian cảm biến** của camera (đều đặn) thay vì lúc app nhận khung, nên video mượt hơn, không giật cục. Camera chỉ cho ~15-24 khung/giây (thiếu sáng) thì video cũng chỉ tới đó.
- Khi bật Live Art, góc trên-trái khung ngắm hiện `Shot with LUNA. Live Art` như lúc bật HQ.

## Bảng màu (kiểu Photographic Styles) – cơ chế duy nhất thay cho khay bộ lọc
Bấm nút bộ lọc để mở ngăn kéo bảng màu (bo hai góc trái, không còn thanh nắm trắng):
- **Danh sách**: toàn bộ bộ lọc – nhóm *Có sẵn* (Original, Natural, Portrait, Landscape, XPan Chrome, Golden Hour, Mono, Fuji Film, Leica M9, Vivo Zeiss) và nhóm *Của tôi* (bộ lọc tự lưu). Mỗi ô có dải hai màu đại diện (màu ấm + màu lạnh sau khi qua bộ lọc, `filterAccent`). Bấm giữ ô của tôi để đổi tên / ghi đè / xoá.
- **Bảng chạm dạng lưới chấm**: ngang = **Color** (nhạt ↔ đậm màu), dọc = **Tone** (sáng ở trên, tối ở dưới). Chạm đúp để về giữa; kéo gần giữa thì tự hít về 0. Áp sau bộ lọc (`PaletteSel` trong `Palette.kt`).
- **Thanh Palette**: cường độ bộ lọc đang chọn, 0–100 (`XpanFilter.scaled`, lưu ở `Prefs.filterStrength`). 0 = ảnh gốc, 100 = đủ hiệu ứng; bộ lọc đen trắng giảm dần thành giảm bão hoà.
- Chọn bộ lọc khác thì Tone / Color về giữa, Palette về 100. "Lưu thành bộ lọc" (trong bảng Chỉnh sửa) lưu luôn cả cường độ + Tone / Color.
- Ngăn kéo **không tự đóng** khi chạm ra ngoài hoặc bấm chụp (mọi chế độ), cũng không ẩn lúc chụp; thoát bằng **mũi tên back** ở góc trên sát mép trái ngăn kéo, nút bộ lọc, hoặc nút Back của máy.
- Xem trước trực tiếp dùng ColorMatrix xấp xỉ; ảnh xuất dùng LUT/công thức đầy đủ.
- Animation: lưới chấm có thấu kính quanh núm, núm phình to khi chạm; mũi tên back nảy ra khi mở ngăn kéo. (`FilterItemView` cũ không còn dùng.)

### Bảng màu: bộ lọc khác biệt rõ + mép danh sách mềm
- Các bộ lọc có sẵn được chỉnh lại để mỗi cái có "chất" riêng rõ rệt: ngoài cân bằng màu / bão hoà / tương phản còn **nhuộm riêng vùng tối và vùng sáng** (`shR..hiB` trong `XpanFilter`). Ví dụ vùng xám trung tính: Golden Hour ngả vàng cam, Vivo Zeiss ngả xanh lạnh, Fuji ngả lục-lam, Leica ngả ấm đậm.
- Trục **Color** của bảng chạm giờ còn khuếch đại / giảm "chất" của chính bộ lọc đang chọn (`PaletteSel.colorCharacter`: -100 → ×0.2, 0 → ×1, +100 → ×1.8, đi qua `XpanFilter.scaled`), nên cùng toạ độ mà bộ lọc khác nhau thì ảnh khác nhau. Palette (cường độ) nhân thêm vào hệ số này. Tone / Color riêng đã giảm bớt độ mạnh để không làm cháy ảnh ở góc bảng.
- Mép trên / dưới danh sách bộ lọc: ô tới gần mép thì mờ dần, co nhẹ và blur nhẹ (Android 12+; máy cũ chỉ mờ + co) thay vì bị cắt ngang; ở đầu / cuối danh sách thì giữ nguyên (`PalettePanel.updateEdges`).

## 4.5.1
- Bảng Chỉnh sửa (thông số camera + màu sắc) rộng hơn một chút về bên trái: 320dp → 350dp (tối đa 50% chiều rộng màn hình).
- Công tắc "Dấu chìm (ảnh có khung)" chuyển từ hộp thoại *Hiệu ứng chụp* sang đúng mục *Dấu chìm* (menu XPAN ▸ Khung ảnh).
- Bỏ vòng tròn cam (quầng sáng) quanh núm khi kéo các thanh trượt; núm vẫn phóng to nhẹ khi chạm.
- `versionName` 4.5.1, `versionCode` 25.

### Live Art: sửa lỗi "chỉ máy mình có Live, máy khác không"
- **Báo MediaStore quét lại** sau khi nhúng video (`LiveArt.writeBack`): trước đây ảnh tĩnh đã được quét lúc lưu rồi mới bị ghi đè lặng lẽ, nên thư viện ảnh của một số hãng (OnePlus, iQOO/vivo...) vẫn nhớ "ảnh thường". Giờ đặt lại `IS_PENDING` 1 → ghi → 0 và cập nhật size / ngày sửa.
- **Mã hoá video bền hơn** (`LiveArt.encode`): thử lần lượt các bộ mã hoá H.264 của máy (phần cứng trước, phần mềm sau, mỗi bộ thử đủ khoá rồi bản tối giản), tự căn kích thước theo bội số / giới hạn của từng chip.
- **Báo lỗi cụ thể**: nếu vẫn không ghép được, app hiện thông báo "Live Art không có trong ảnh này: <lý do>" (ví dụ tên bộ mã hoá và lỗi) thay vì im lặng chỉ còn ảnh tĩnh.

## Giao diện X2D II (4:3)
Menu nút XPAN ▸ **4:3 (X2D II)** chuyển sang thân máy Hasselblad X2D II; ở đó mục đầu menu đổi thành **65:24 (XPAN)** để quay lại. Mọi chức năng chụp (HQ, UP, Live Art, Night ART, hẹn giờ, bộ lọc, bảng màu, khung ảnh...) giữ nguyên; chỉ đổi khổ cắt ảnh (`Body.ratio`, 4:3 thay vì 65:24, cắt cả ảnh, Live Art, phơi sáng lâu, thiếu sáng) và giao diện (`X2dViews.kt`, `CameraLayout.layoutX2d`).
- **Bố cục**: cột trái (cài đặt, flash, sáng/tối) · màn hình 4:3 viền đen, nhãn HASSELBLAD ngay dưới · cột 4 phím · cột nút tiêu cự · tay cầm bọc da (bánh xe ở trên, nút chụp cam bên dưới). Nút tiêu cự nằm giữa cột phím và nút chụp.
- **4 phím bên phải màn hình** (từ trên xuống): bộ lọc (mở ngăn kéo bảng màu) · cài đặt thông số (bảng Chỉnh sửa) · album (ảnh vừa chụp, bấm mở thư viện) · menu **X2D II ›** (giống nút XPAN, đổi tên).
- **Bánh xe trên tay cầm**: vuốt dọc để xoay (mỗi nấc rung một lần). Mặc định chỉnh **EV**; bật *Cài đặt ▸ X2D II (4:3) ▸ Bánh xe: lấy nét tay* để chỉnh **lấy nét tay** (vuốt xuống hết cỡ trở về tự động lấy nét).
- **Thông tin trên màn hình** (`X2dHudView`, theo X2D): biểu tượng tỉ lệ (trái trên), pin + ISO + AF/MF (phải trên), hai thanh dọc bên phải (ISO, tốc độ màn trập, theo giá trị đang đo), thanh ngang EV ở dưới (**kéo để đổi EV**), hàng chữ chế độ P/M · EV · f/ · tốc độ · [số ảnh còn lại ước tính theo dung lượng trống]. Cập nhật ~3 lần/giây.
- Giao diện X2D II luôn dùng kiểu giả máy ảnh (có chế độ sáng/tối); nút "đổi giao diện toàn màn" bị ẩn ở đây.
