# Xpan-Mode

Ứng dụng chụp ảnh Android chuyên cho khung hình panorama **XPan 65:24**, giao diện và hiệu ứng chụp mô phỏng chế độ X-Pan trên các dòng OPPO × Hasselblad.

## Tính năng

- **Hai giao diện, chuyển bằng nút ⇄ ở góc trên trái**
  - *Hasselblad*: nền xám đậm, chữ HASSELBLAD, thang zoom 0,6 · 1 · 2 · 3×, nút chụp trắng, huy hiệu bộ lọc.
  - *Tối giản*: nền đen, viền ngắm mờ, nút chụp cam, các nút tiêu cự 14 · 23 · 65 · 135 mm.
- **Hiệu ứng chụp**: đảo âm bản → xám phẳng → mờ dần về ảnh.
- **Màn hình xem lại**: khung trắng + chữ HASSELBLAD + thông số (tên máy, FL, khẩu độ, tốc độ, ISO). Chạm vào ảnh thu nhỏ để mở; có nút lưu ảnh khung.
- **Đọc đầy đủ ống kính**: gộp camera trong `cameraIdList` + camera vật lý ẩn trong camera logic + dò ID 0–99. Xem danh sách chi tiết tại ⚙ Cài đặt (tiêu cự thật, tương đương 35mm, khẩu độ, cảm biến, MP, OIS, RAW...).
- **Chất lượng ảnh**: chụp JPEG độ phân giải tối đa của từng ống kính, `JPEG_QUALITY=100`, khử nhiễu/làm nét/quang sai ở chế độ HIGH_QUALITY. Khung 65:24 và zoom số được **cắt từ ảnh gốc** (không phóng to nội suy), lưu JPEG chất lượng 100 kèm EXIF. Tuỳ chọn lưu thêm DNG (RAW) và ảnh gốc full-frame.
- **HQ ghép 5 khung**: căn chỉnh Lucas-Kanade dưới điểm ảnh, giải mã + căn chỉnh các khung song song, cộng dồn độ sáng ở lưới 2× và màu ở lưới 1×. Chế độ này hiển thị là **LUNA Engine**; thông báo thời gian từng công đoạn đã tắt (`SHOW_TIMING = false` trong `PhotoProcessor.kt`).
- **Thiếu sáng (LUNA Night)**: bật ở menu `XPAN >` → *Thiếu sáng*. Khi bật, cạnh nút XPAN hiện huy hiệu 🌙 kèm thời gian phơi sáng; chạm vào để đổi vòng **3 → 5 → 8 → 10 giây**. Bấm chụp: khung ngắm đóng băng và sáng dần, vòng đếm ngược chạy; bấm chụp lần nữa để dừng sớm. Cơ chế:
  - Chụp liên tục trong N giây. Máy vững (con quay hồi chuyển) → khung ≤ 0,3s, ISO thấp; cầm tay → khung ≤ 1/30s và chờ 0,3s cho hết rung sau cú bấm. Máy cho chỉnh tay thì dùng tích (thời gian × ISO) của AE xem trước nhân hệ số cần thêm sáng; không thì AE khoá + dải FPS thấp + bù sáng.
  - Khung nhoè do rung bị giảm trọng số hoặc bỏ (so với khung nét nhất). Mỗi khung được căn chỉnh (LUNA Engine: thô + Lucas-Kanade dưới điểm ảnh, trên ảnh đã nhân gain) và cộng dồn **ngay khi vừa chụp xong** trong không gian tuyến tính, trọng số chống bóng ma theo mức nhiễu (xe chạy ngang không để lại vệt ma).
  - Tone mapping thiếu sáng: nâng bóng tối trên lớp nền (đường bao dưới + bilateral log), chặn độ lợi theo từng điểm ảnh và mờ về 1 ở vùng sáng (đèn không cháy, không viền), điểm đen thích nghi. Sau đó khử nhiễu màu 2 lượt, khử nhiễu độ sáng mạnh hơn (LUNA `denoiseLuma(strength=1.35)`) và làm nét có cổng.
  - Không đi cùng HQ / vệt sáng / RAW (bật cái này sẽ tự tắt cái kia). Mã: `LunaNight.kt`, `CameraController.captureNight`, `PhotoProcessor.processNight`, `NightFxView` / `NightBadgeView` trong `Views.kt`.
- **Bộ lọc**: Original, Natural, Portrait, Landscape, XPan Chrome, Golden Hour, Mono (phong cách màu tự nhiên, tương phản mềm, bão hoà vừa phải).
- Chạm để lấy nét/đo sáng, vuốt dọc bên trái để bù sáng, chụm hai ngón để zoom.
- Ảnh lưu tại `Pictures/Xpan-Mode`.

## Build

**Cách 1 – GitHub Actions (không cần cài gì):** đẩy toàn bộ thư mục lên GitHub, vào tab *Actions* → workflow *Build APK* → tải artifact `Xpan-Mode-debug-apk`.

**Cách 2 – Android Studio:** mở thư mục, chờ Gradle sync, bấm Run.

Mọi bản build đều ký bằng `app/xpan-release.keystore` (cố định) nên cài đè được giữa các lần build.

Yêu cầu: Android 10+ (API 29), JDK 17.

## Ghi chú

- Tên "Hasselblad" và phong cách giao diện thuộc về chủ sở hữu thương hiệu. Dự án này chỉ dùng chữ, không dùng logo gốc; hãy dùng cho mục đích cá nhân/học tập.
- Xem trước bộ lọc là xấp xỉ bằng ColorMatrix; ảnh xuất dùng đường cong từng kênh nên có thể lệch nhẹ.
- Một số máy chặn app bên thứ ba mở camera vật lý; app tự dự phòng qua camera logic.

## Chỉnh sửa & bộ lọc riêng

Nút "thanh trượt" cạnh nút cài đặt mở bảng **Chỉnh sửa** (thu gọn, xem trước trực tiếp):

- **Máy ảnh**: EV, tốc độ (S), ISO, cân bằng trắng (WB), lấy nét AF/MF. Tốc độ/ISO/MF chỉ hiện khi camera cho phép app bên thứ ba chỉnh tay.
- **Màu sắc**: tương phản, lạnh ↔ ấm, lục lam ↔ đỏ sậm, bão hoà, sắc nét (sắc nét chỉ áp dụng khi chụp, không hiện trong khung xem trước).
- **Lưu thành bộ lọc**: lưu mọi chỉnh sửa (màu + thông số camera) thành bộ lọc có tên, xuất hiện trong khay bộ lọc. Giữ vào bộ lọc tự lưu để đổi tên, ghi đè hoặc xoá.

## So sánh HQ và HQ RAW
Menu `XPAN >` có hai nút riêng: **High quality** (ghép khung JPEG của máy) và **HQ RAW** (ghép khung RAW, app tự dựng ảnh: trừ mức đen, cân bằng trắng, bù tối góc, giải mosaic Hamilton-Adams, khớp tông với JPEG máy). Cùng một bộ ghép LUNA nên so sánh công bằng. Nút HQ RAW luôn hiện; ống kính không cho app ngoài lấy RAW sẽ ghi rõ và không bật được. Tên tệp lưu có hậu tố để phân biệt: `_HQ` (ghép từ JPEG), `_HQRAW` (ghép từ RAW); không hậu tố = ảnh thường hoặc HQ RAW phải lùi về JPEG (có thông báo). Nút "Thợ săn ánh sáng" đã gỡ.

## UP (Ultra pixel)
Menu `XPAN >` có nút **UP** để so sánh với High quality / HQ RAW. UP ghép **9 khung** JPEG (HQ thường 5 khung; `UP_FRAMES` trong `CameraController.kt`), làm nét mạnh hơn ở lưới 2× (`UP_SHARP1` / `UP_SHARP2` trong `PhotoProcessor.kt`), rồi phóng lên **3× (≈ 12288×4536, 55,8 MP)** bằng Lanczos-3 (`UP_OUT_SCALE = 1.5f`). Phần phóng thêm là nội suy, không thêm chi tiết thật; hết bộ nhớ thì tự giữ ảnh 2×. HQ / HQ RAW thường không đổi.
- Ghi chú góc trên-trái khung ngắm: `Shot with LUNA. UP`; logo LUNA trên ảnh (nếu bật): `LUNA. UP`.
- Cài đặt → "UP: máy xử lí ảnh": bật thì UP ghép các khung đã qua xử lí của máy (không ép tắt khử nhiễu/làm nét, làm nét sau ghép nhẹ hơn); tắt (mặc định) thì ghép khung thô, app tự xử lí.
- Tên tệp: `_UP` (khung thô), `_UPDEV` (khung qua xử lí của máy).

## Hẹn giờ (cần gạt)
Menu `XPAN >` → **Hẹn giờ**: nút chụp được thay bằng cần gạt kiểu máy ảnh film (trục kim loại, cán dài hướng xuống), viên thuốc `00.00s` hiện bên trái nút XPAN.
- Giữ đầu hoặc thân cán, xoay lên trên sang trái để lên dây: vuông góc (sang trái) = 5s, thẳng lên = 10s (tối đa); số trên viên thuốc chạy theo. Mỗi nấc 0,25s rung giật một cái, mốc 5s / 10s và chạm hai đầu rung mạnh hơn.
- Bấm vào trục để bắt đầu đếm ngược: cán tự quay về, tiếng dây cót chạy liên tục (`res/raw/selftimer_run.wav`, vòng lặp cắt từ bản thu người dùng cung cấp, nhỏ + chậm dần ở 0,4s cuối), hết giờ thì chụp. Bấm trục lần nữa để huỷ. Chưa lên dây (0s) mà bấm trục thì chụp ngay.
- Rung dùng `Vibrator` (quyền `VIBRATE`); tiếng theo cài đặt âm thanh chung của app.
- Bật Hẹn giờ thì cụm nút bên phải tự dàn lại để chừa chỗ cho cán quét: album xuống sát đáy, bộ lọc + chỉnh sửa xếp ngang trên đỉnh, nút tiêu cự lùi sang trái.

## Flash (3.5)
Nút flash nằm ngay bên phải nút cài đặt; bấm để đổi vòng: **tắt** (tia chớp gạch chéo) → **bật** (tia chớp viền: đèn sáng ~0,45s rồi chụp, xong tự tắt) → **luôn bật** (tia chớp đặc: đèn sáng liên tục lúc ngắm và chụp). Dùng chế độ TORCH của camera2 nên mọi khung của HQ / UP / thiếu sáng đều có đèn như nhau; lựa chọn được nhớ. Ống kính không có đèn thì báo.

## Màn giới thiệu chế độ
Vừa bật High quality / HQ RAW thì nền đen hiện dần với dòng chữ **REAL DETAILS With LUNA. 3** (dấu chấm cam) và ghi chú nhỏ `( Without AI )` bên dưới, rồi mờ dần, tổng cộng ~1s. Chế độ UP hiện **ULTRA PIXEL With LUNA. 3**. Cài đặt trong `ModeSplashView` (Views.kt).

## Sửa ám màu tím hồng ở LUNA Night
Vùng tối bị nâng sáng hàng chục lần nên ám màu của JPEG gần đen (đỏ + lam dư so với lục) hiện thành mảng tím hồng. `LunaNight.toneMap` giờ (1) tính điểm đen riêng từng kênh thay vì một mức chung (`BPC_MAX`), (2) kéo điểm ảnh gần đen về xám trung tính theo độ tin cậy của màu (`CH0` / `CH1`, tính trên độ sáng tuyến tính trước khi nâng). Nếu bóng tối còn ám màu: tăng `CH1`; nếu bóng tối nhạt màu quá: giảm `CH1`.

## LUNA Night: màu điện ảnh + 2× điểm ảnh
- Màu: cân bằng trắng một phần (`WB_STRENGTH`), đường cong S kiểu phim (`GRADE_CONTRAST`), bóng tối hơi lạnh / vùng sáng hơi ấm, màu nhạt dần ở highlight.
- Kích thước: sau khi ghép + khử nhiễu, ảnh được phóng 2× (Lanczos-3) và làm nét có cổng (`NIGHT_OUT_SCALE` trong `PhotoProcessor.kt`). Phần phóng thêm là nội suy, không phải chi tiết thật.

## Thiếu sáng: máy xử lí (3.5)
Cài đặt → "Thiếu sáng: máy xử lí". Bật thì LUNA Night chụp bằng **chế độ đêm của chính máy** (Camera2 Extensions `EXTENSION_NIGHT`, Android 12+) nếu hãng cho app ngoài dùng; ra 1 ảnh đã qua xử lí đêm / AI của máy rồi đi tiếp qua bộ lọc + khung như ảnh thường. Không hỗ trợ / lỗi thì tự dùng LUNA Night của app (lỗi một lần thì các lần sau trong phiên bỏ qua). Cân bằng trắng của LUNA Night (`WB_STRENGTH`) nâng lên 0,85 để tường trắng ra gần trắng như app camera gốc.

## Sửa viền / quầng quanh vật tối
Viền sáng mảnh quanh vật tối (túi, đầu giường) có ba nguồn, đã xử lí: (1) `MultiFrame.refine` (làm nét) chặn kết quả trong dải min–max 5×5 của điểm ảnh gốc nên không còn quầng; (2) `MultiFrame.upscale` (Lanczos) chống vòng: kết quả không vượt khoảng giữa hai điểm nguồn gần nhất; (3) tone mapping LUNA Night nội suy độ lợi nâng sáng theo song phương chung (có xét độ sáng từng điểm ảnh), nên điểm tường sáng cạnh vật tối không bị nâng như ô tối nữa.
