# Xpan-Mode

Ứng dụng chụp ảnh Android chuyên cho khung hình panorama **XPan 65:24**, giao diện và hiệu ứng chụp mô phỏng chế độ X-Pan trên các dòng OPPO × Hasselblad.

## Tính năng

- **Hai giao diện, chuyển bằng nút ⇄ ở góc trên trái**
  - *Hasselblad*: nền xám đậm, chữ HASSELBLAD, thang zoom 0,6 · 1 · 2 · 3×, nút chụp trắng, huy hiệu bộ lọc.
  - *Tối giản*: nền đen, viền ngắm mờ, nút chụp cam, các nút tiêu cự 14 · 23 · 65 · 135 mm.
- **Hiệu ứng chụp**: đảo âm bản → xám phẳng → mờ dần về ảnh.
- **Màn hình xem lại**: khung trắng + chữ HASSELBLAD + thông số (tên máy, FL, khẩu độ, tốc độ, ISO). Chạm vào ảnh thu nhỏ để mở; có nút lưu ảnh khung.
- **Đọc đầy đủ ống kính**: gộp camera trong `cameraIdList` + camera vật lý ẩn trong camera logic + dò ID 0–99. Xem danh sách chi tiết tại ⚙ Cài đặt (tiêu cự thật, tương đương 35mm, khẩu độ, cảm biến, MP, OIS, RAW...).
- **Chất lượng ảnh**: chụp JPEG độ phân giải tối đa của từng ống kính, `JPEG_QUALITY=100`, khử nhiễu/làm nét/quang sai ở chế độ HIGH_QUALITY. Khung 65:24 và zoom số được **cắt từ ảnh gốc** (không phóng to nội suy), lưu JPEG chất lượng 100 kèm EXIF. Tuỳ chọn lưu thêm DNG (RAW) và ảnh gốc full-frame.
- **HQ ghép 5 khung**: căn chỉnh Lucas-Kanade dưới điểm ảnh, giải mã + căn chỉnh các khung song song, cộng dồn độ sáng ở lưới 2× và màu ở lưới 1×. Chế độ này hiển thị là **LUNA Engine**; thông báo thời gian từng công đoạn đã tắt (`SHOW_TIMING = false` trong `PhotoProcessor.kt`).
- **Thiếu sáng (LUNA Night)**: bật ở menu `XPAN >` → *Thiếu sáng* (hoặc *Thợ săn ánh sáng → Chế độ ban đêm*). Khi bật, cạnh nút XPAN hiện huy hiệu 🌙 kèm thời gian phơi sáng; chạm vào để đổi vòng **3 → 5 → 8 → 10 giây**. Bấm chụp: khung ngắm đóng băng và sáng dần, vòng đếm ngược chạy; bấm chụp lần nữa để dừng sớm. Cơ chế:
  - Chụp liên tục trong N giây. Máy vững (con quay hồi chuyển) → khung dài, ISO thấp; cầm tay → khung ngắn 1/8s. Máy cho chỉnh tay thì dùng tích (thời gian × ISO) của AE xem trước nhân hệ số cần thêm sáng; không thì AE khoá + dải FPS thấp + bù sáng.
  - Mỗi khung được căn chỉnh (LUNA Engine: thô + Lucas-Kanade dưới điểm ảnh, trên ảnh đã nhân gain) và cộng dồn **ngay khi vừa chụp xong** trong không gian tuyến tính, trọng số chống bóng ma theo mức nhiễu (xe chạy ngang không để lại vệt ma).
  - Tone mapping thiếu sáng: nâng bóng tối trên lớp nền (đường bao dưới + bilateral log), chặn độ lợi theo từng điểm ảnh và mờ về 1 ở vùng sáng (đèn không cháy, không viền), điểm đen thích nghi. Sau đó khử nhiễu màu 2 lượt, khử nhiễu độ sáng mạnh hơn (LUNA `denoiseLuma(strength=1.35)`) và làm nét có cổng.
  - Không đi cùng HQ / vệt sáng / RAW (bật cái này sẽ tự tắt cái kia). Mã: `LunaNight.kt`, `CameraController.captureNight`, `PhotoProcessor.processNight`, `NightFxView` / `NightBadgeView` trong `Views.kt`.
- **Bộ lọc**: Original, Natural, Portrait, Landscape, XPan Chrome, Golden Hour, Mono (phong cách màu tự nhiên, tương phản mềm, bão hoà vừa phải).
- Chạm để lấy nét/đo sáng, vuốt dọc bên trái để bù sáng, chụm hai ngón để zoom.
- Ảnh lưu tại `Pictures/Xpan-Mode`.

## Build

**Cách 1 – GitHub Actions (không cần cài gì):** đẩy toàn bộ thư mục lên GitHub, vào tab *Actions* → workflow *Build APK* → tải artifact `Xpan-Mode-debug-apk`.

**Cách 2 – Android Studio:** mở thư mục, chờ Gradle sync, bấm Run.

Mọi bản build đều ký bằng `app/xpan-release.keystore` (cố định) nên cài đè được giữa các lần build.

Yêu cầu: Android 10+ (API 29), JDK 17.

## Ghi chú

- Tên "Hasselblad" và phong cách giao diện thuộc về chủ sở hữu thương hiệu. Dự án này chỉ dùng chữ, không dùng logo gốc; hãy dùng cho mục đích cá nhân/học tập.
- Xem trước bộ lọc là xấp xỉ bằng ColorMatrix; ảnh xuất dùng đường cong từng kênh nên có thể lệch nhẹ.
- Một số máy chặn app bên thứ ba mở camera vật lý; app tự dự phòng qua camera logic.

## Chỉnh sửa & bộ lọc riêng

Nút "thanh trượt" cạnh nút cài đặt mở bảng **Chỉnh sửa** (thu gọn, xem trước trực tiếp):

- **Máy ảnh**: EV, tốc độ (S), ISO, cân bằng trắng (WB), lấy nét AF/MF. Tốc độ/ISO/MF chỉ hiện khi camera cho phép app bên thứ ba chỉnh tay.
- **Màu sắc**: tương phản, lạnh ↔ ấm, lục lam ↔ đỏ sậm, bão hoà, sắc nét (sắc nét chỉ áp dụng khi chụp, không hiện trong khung xem trước).
- **Lưu thành bộ lọc**: lưu mọi chỉnh sửa (màu + thông số camera) thành bộ lọc có tên, xuất hiện trong khay bộ lọc. Giữ vào bộ lọc tự lưu để đổi tên, ghi đè hoặc xoá.
