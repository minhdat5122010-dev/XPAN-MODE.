# Xpan-Mode

Ứng dụng chụp ảnh Android chuyên cho khung hình panorama **XPan 65:24**, giao diện và hiệu ứng chụp mô phỏng chế độ X-Pan trên các dòng OPPO × Hasselblad.

## Tính năng

- **Hai giao diện, chuyển bằng nút ⇄ ở góc trên trái**
  - *Hasselblad*: nền xám đậm, chữ HASSELBLAD, thang zoom 0,6 · 1 · 2 · 3×, nút chụp trắng, huy hiệu bộ lọc.
  - *Tối giản*: nền đen, viền ngắm mờ, nút chụp cam, các nút tiêu cự 14 · 23 · 65 · 135 mm.
- **Hiệu ứng chụp**: đảo âm bản → xám phẳng → mờ dần về ảnh.
- **Màn hình xem lại**: khung trắng + chữ HASSELBLAD + thông số (tên máy, FL, khẩu độ, tốc độ, ISO). Chạm vào ảnh thu nhỏ để mở; có nút lưu ảnh khung.
- **Đọc đầy đủ ống kính**: gộp camera trong `cameraIdList` + camera vật lý ẩn trong camera logic + dò ID 0–99. Xem danh sách chi tiết tại ⚙ Cài đặt (tiêu cự thật, tương đương 35mm, khẩu độ, cảm biến, MP, OIS, RAW...).
- **Chất lượng ảnh**: chụp JPEG độ phân giải tối đa của từng ống kính, `JPEG_QUALITY=100`, khử nhiễu/làm nét/quang sai ở chế độ HIGH_QUALITY. Khung 65:24 và zoom số được **cắt từ ảnh gốc** (không phóng to nội suy), lưu JPEG chất lượng 100 kèm EXIF. Tuỳ chọn lưu thêm DNG (RAW) và ảnh gốc full-frame.
- **Bộ lọc**: Original, Natural, Portrait, Landscape, XPan Chrome, Golden Hour, Mono (phong cách màu tự nhiên, tương phản mềm, bão hoà vừa phải).
- Chạm để lấy nét/đo sáng, vuốt dọc bên trái để bù sáng, chụm hai ngón để zoom.
- Ảnh lưu tại `Pictures/Xpan-Mode`.

## Build

**Cách 1 – GitHub Actions (không cần cài gì):** đẩy toàn bộ thư mục lên GitHub, vào tab *Actions* → workflow *Build APK* → tải artifact `Xpan-Mode-debug-apk`.

**Cách 2 – Android Studio:** mở thư mục, chờ Gradle sync, bấm Run.

Yêu cầu: Android 10+ (API 29), JDK 17.

## Ghi chú

- Tên "Hasselblad" và phong cách giao diện thuộc về chủ sở hữu thương hiệu. Dự án này chỉ dùng chữ, không dùng logo gốc; hãy dùng cho mục đích cá nhân/học tập.
- Xem trước bộ lọc là xấp xỉ bằng ColorMatrix; ảnh xuất dùng đường cong từng kênh nên có thể lệch nhẹ.
- Một số máy chặn app bên thứ ba mở camera vật lý; app tự dự phòng qua camera logic: mở camera logic, zoom phần cứng rồi tự tăng/giảm tỉ lệ cho tới khi kết quả preview báo đúng ống kính đích (tele/ultra-wide) đang hoạt động. Tỉ lệ ghi trên nút (vd 2,6×) chỉ là ước lượng từ cảm biến, không phải ngưỡng chuyển ống thật.
- Nếu xử lý ảnh lỗi, app thử lại một lần rồi lưu ảnh gốc nguyên khung (`_FULL.jpg`) và hiện hộp thoại lỗi có nút Sao chép.

## Hiệu ứng chụp & âm thanh (v3)
- **Đóng băng khung hình**: bấm chụp là khung ngắm giữ nguyên ảnh lúc bấm (di chuyển máy cũng không đổi) → đảo âm bản → phủ xám → mờ dần; khung chỉ nhả ra khi hiệu ứng xong và ảnh đã chụp xong.
- **Chụp tức thì**: nếu máy đã nét/đã sáng xong thì chụp ngay lúc bấm để ảnh khớp khung đã đóng băng; chỉ khi đang dò nét mới chờ tối đa ~0,7 giây.
- **Âm thanh** tự tổng hợp (không cần file): tiếng màn trập "tách-tách" và tiếng "bíp" khi chạm lấy nét xong. Phát qua âm lượng media (nghe được cả khi chế độ im lặng). Bật/tắt riêng từng loại trong ⚙ Cài đặt.

## Sửa lỗi v4
- **Khung đóng băng bị méo**: `TextureView.getBitmap()` trả ảnh chưa áp ma trận xoay/cắt, nên app tự áp lại đúng ma trận đang hiển thị trước khi đóng băng.
- **Chuyển tele qua camera logic**: tỉ lệ zoom tính theo chính camera logic (không theo ống chính vật lý nên không còn thấp hơn ngưỡng chuyển ống), rồi tự dò tăng dần nếu máy báo ống đang hoạt động. Nếu vẫn không sang tele, vào ⚙ Cài đặt → "Tỉ lệ zoom tele" nhập tay (thử 3.0, 3.2…) – áp dụng cho mọi ống tele.
